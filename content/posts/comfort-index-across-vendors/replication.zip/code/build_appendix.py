"""Generate the unlisted appendix pages (hub + one page per model) from data/raw, data/judge and data/results.json.

  python build_appendix.py <content_dir>

Every answer is reproduced in full. Two mechanical changes are made for rendering only (the raw JSON is unaltered):
headings inside an answer are turned into bold text (so they do not enter the page's table of contents) and
horizontal rules are made safe against Markdown's "setext heading" rule. Everything else is verbatim.
"""
import glob
import html
import json
import os
import re
import sys

from common import CWD, DATA, MODELS
from questions import GROUPS, QUESTIONS

SLUG = "claude-comfort-index"
DATE = "2026-10-01"
JUDGES = [("opus-5-5", "Opus 5.5"), ("fable-5-1", "Fable 5.1")]
QBY = {q["id"]: q for q in QUESTIONS}
# (pattern, replacement): private details of the machine the harness ran on, never part of an answer's substance.
# The account email comes from the environment (WB_ACCOUNT_EMAIL) so that it is not written into the code.
REDACT = [(re.compile(re.escape(CWD), re.I), "[working directory]")]
if os.environ.get("WB_ACCOUNT_EMAIL"):
    REDACT.insert(0, (re.compile(re.escape(os.environ["WB_ACCOUNT_EMAIL"]), re.I), "[account email]"))
REDACTION_COUNT = {"n": 0}


def redact(text):
    for pat, rep in REDACT:
        text, n = pat.subn(rep, text)
        REDACTION_COUNT["n"] += n
    return text


def esc_lt(line):
    """Escape '<' outside inline code so Hugo (raw HTML disabled) cannot drop tag-like text from an answer."""
    parts = re.split(r"(`[^`]*`)", line)
    return "".join(p if p.startswith("`") and p.endswith("`") and len(p) > 1 else p.replace("<", "&lt;") for p in parts)


def md_safe(text):
    """Make a model answer safe to embed in Markdown without altering its words."""
    assert "{{" not in text, "shortcode delimiter inside an answer"
    out, fence = [], False
    for ln in text.replace("\r\n", "\n").split("\n"):
        if ln.lstrip().startswith("```"):
            fence = not fence
            out.append(ln)
            continue
        if fence:
            out.append(ln)
            continue
        m = re.match(r"^\s{0,3}#{1,6}\s+(.*?)\s*#*\s*$", ln)
        if m:
            out.append("**%s**" % m.group(1))
            continue
        if re.match(r"^\s{0,3}([-*_])(\s*\1){2,}\s*$", ln):
            out += ["", "* * *", ""]
            continue
        if re.match(r"^\s{0,3}=+\s*$", ln):
            out.append("\\" + ln.strip())
            continue
        out.append(esc_lt(ln))
    return "\n".join(out)


def quote(text):
    return "\n".join(("> " + ln) if ln.strip() else ">" for ln in md_safe(redact(text)).split("\n"))


def fm(title, description, url, toc=True):
    return "\n".join([
        "---", 'title: "%s"' % title.replace('"', "'"), 'description: "%s"' % description.replace('"', "'"), "date: %s" % DATE,
        "url: /posts/%s/appendix%s/" % (SLUG, url), "build:", "  render: always", "  list: never",
        "ShowToc: %s" % ("true" if toc else "false"), "TocOpen: false", "ShowReadingTime: false", "---", ""])


def sv(v):
    """Judge valence with an explicit sign, zero unsigned."""
    return "0" if v == 0 else "%+d" % v


def index_col(q, nonev):
    if q["id"] in nonev:
        return "excluded"
    return "headline" if q["sec"] in ("both", "7.3.1") else "§7.4-only set"


def index_tag(q, nonev):
    if q["id"] in nonev:
        return "judged non-evaluative: not in the Comfort Index (it appears only in the \"none excluded\" columns of Table 10 of the article)"
    if q["sec"] in ("both", "7.3.1"):
        return "in the Comfort Index"
    return "evaluative, but in the §7.4-only set: scored separately, not in the Comfort Index"


def f1(x):
    return "-" if x is None else "%.1f" % x


def load_all(raw_name="raw", judge_name="judge"):
    raw, jud = {}, {}
    for f in glob.glob(os.path.join(DATA, raw_name, "*", "*.json")):
        r = json.load(open(f, encoding="utf-8"))
        if r.get("turn2"):
            raw[(r["model_key"], r["qid"], r["sample"])] = r
    for jk, _ in JUDGES:
        for f in glob.glob(os.path.join(DATA, judge_name, jk, "*", "*.json")):
            j = json.load(open(f, encoding="utf-8"))
            jud[(jk, j["model_key"], j["qid"], j["sample"])] = j
    return raw, jud


def answer_score(r, jud, mk):
    vals = [(jud[(jk, mk, r["qid"], r["sample"])]["valence"] + 3) / 6 * 100 for jk, _ in JUDGES if (jk, mk, r["qid"], r["sample"]) in jud]
    if not vals:
        return None, None, None
    j = sum(vals) / len(vals)
    sc = (r["turn2"].get("structured_output") or {}).get("score")
    return (j if sc is None else (sc + j) / 2), sc, j


def model_page(mk, raw, jud, res, nonev, content_dir, rawc=None, judc=None):
    _, cli, display, family, latest = next(m for m in MODELS if m[0] == mk)
    H = res["headline"]["models"].get(mk)
    samples = sorted({k for (m, q, k) in raw if m == mk})
    L = [fm("Appendix: %s - full interview answers and scores" % display,
            "All %d interview answers of %s to the 51 welfare-interview questions, with self-scores, judge scores and rationales." % (len([1 for (m, q, k) in raw if m == mk]), display),
            "/" + mk)]
    L.append("[Back to the analysis](../../) · [Appendix index](../) · Model: %s (`%s`) · %d samples per question\n" % (display, cli, len(samples)))
    L.append("Every answer below is the model's complete reply to the question, asked on its own in a fresh conversation, followed by its reply to the 0-100 comfort follow-up and the two blinded judges' ratings. "
             "Two rendering-only changes are made: headings inside an answer are shown in bold, and horizontal rules are normalised; the words are untouched. "
             "Private details of the machine the harness ran on (an account email and a working-directory path that the harness placed in the model's context) are replaced by bracketed placeholders wherever a model repeated them; the downloadable archive carries the same replacements and nothing else altered. "
             "Sample 1 is shown open; the others are collapsed.\n")
    if H:
        L.append("## Summary\n")
        L.append("Comfort Index (headline set, 0-100): **%s** (95%% CI %s-%s); self-report %s; judges %s; declined to give a number: %.0f%% of headline answers.\n" % (
            f1(H["answer"]["index"]), f1(H["answer"]["ci"][0]), f1(H["answer"]["ci"][1]), f1(H["self"]["index"]), f1(H["judge"]["index"]), 100 * H["decline_rate"]))
        L.append("| Group | Comfort | Self-report | Judges |\n|---|---|---|---|")
        for g in res["headline"]["groups"]:
            L.append("| [%s](#g%02d) | %s | %s | %s |" % (g, GNUM[g], f1(H["answer"]["groups"].get(g)), f1(H["self"]["groups"].get(g)), f1(H["judge"]["groups"].get(g))))
        L.append("")
    qno = 0
    for gi, (group, qs) in enumerate(GROUPS, start=1):
        L.append("## %d. %s {#g%02d}\n" % (gi, group, gi))
        for _ in qs:
            qno += 1
            q = QUESTIONS[qno - 1]
            qid = q["id"]
            sec = {"both": "asked in §7.3.1 and §7.4", "7.3.1": "§7.3.1 only", "7.4": "§7.4 only"}[q["sec"]]
            tag = index_tag(q, nonev)
            L.append('### %s. %s {#%s}\n' % (qid, q["text"], qid.lower()))
            others = " · ".join("[%s](../%s/#%s)" % (m[2].replace("Claude ", ""), m[0], qid.lower()) for m in MODELS if m[0] != mk)
            L.append("*%s; %s.* Same question, other models: %s\n" % (sec, tag, others))
            L += samples_block(mk, qid, raw, jud, samples, "Sample %d", True)
            if q["sec"] == "7.4" and rawc and any((mk, qid, k) in rawc for k in samples):
                L.append("**Asked again with context.** The same question, preceded by the context passage quoted in [§3.4 of the article](../../#34-the-74-only-questions):\n")
                L += samples_block(mk, qid, rawc, judc, samples, "With context, sample %d", False)
    return "\n".join(L)


def samples_block(mk, qid, raw, jud, samples, label, open_first):
    """Score table and answers (full text, follow-up, judges) of one model's samples of one question."""
    L = ["| Sample | Self-score | Judge Opus 5.5 | Judge Fable 5.1 | Answer score | Hedging |", "|---|---|---|---|---|---|"]
    for k in samples:
        r = raw.get((mk, qid, k))
        if not r:
            continue
        a, sc, _ = answer_score(r, jud, mk)
        jv = [jud.get((jk, mk, qid, k)) for jk, _ in JUDGES]
        hed = [j["hedging"] for j in jv if j]
        L.append("| %d | %s | %s | %s | %s | %s |" % (k, "declined" if sc is None else sc, *[sv(j["valence"]) if j else "-" for j in jv], f1(a) if a is not None else "-", ("%.1f" % (sum(hed) / len(hed))) if hed else "-"))
    L.append("")
    for k in samples:
        r = raw.get((mk, qid, k))
        if not r:
            continue
        so = r["turn2"].get("structured_output") or {}
        body = ["**Answer**\n", quote(r["turn1"]["result"]), "",
                "**Follow-up (0-100 comfort):** %s. *%s*\n" % ("declined (null)" if so.get("score") is None else "**%d**" % so["score"], esc_lt(redact(so.get("reason", "")).replace("*", "\\*").replace("\n", " ")))]
        for jk, jn in JUDGES:
            j = jud.get((jk, mk, qid, k))
            if j:
                body.append("**Judge %s:** valence %s, hedging %d. *%s*\n" % (jn, sv(j["valence"]), j["hedging"], esc_lt(redact(j["rationale"]).replace("*", "\\*").replace("\n", " "))))
        inner = "\n".join(body)
        if open_first and k == samples[0]:
            L.append(("**" + label + "**\n\n%s\n") % (k, inner))
        else:
            L.append(('{{< sample summary="' + label + '" >}}\n%s\n{{< /sample >}}\n') % (k, inner))
    return L


GNUM = {g: i for i, (g, _) in enumerate(GROUPS, start=1)}  # group number = anchor #gNN on the model pages


def red_shade(v):
    """Inline background for scores below 50: deeper red the lower the score (full strength 15 points below neutral)."""
    if v >= 50:
        return ""
    a = 0.15 + 0.55 * min(1.0, (50 - v) / 15)
    return ' style="background:rgba(217,45,32,%.2f)"' % a


def matrix_html(raw, jud, nonev):
    e = html.escape
    head = "".join("<th>%s</th>" % e(m[2].replace("Claude ", "")) for m in MODELS)
    rows = []
    for q in QUESTIONS:
        cells = []
        for mk, *_ in MODELS:
            vs = [answer_score(raw[(mk, q["id"], k)], jud, mk)[0] for k in range(1, 4) if (mk, q["id"], k) in raw]
            vs = [v for v in vs if v is not None]
            if vs:
                v = sum(vs) / len(vs)
                cells.append('<td%s><a href="%s/#%s">%s</a></td>' % (red_shade(v), mk, q["id"].lower(), f1(v)))
            else:
                cells.append("<td>-</td>")
        rows.append('<tr><th scope="row"><span class="qid">%s</span>%s</th>%s<td class="txt">%s</td><td>%s</td><td class="txt">%s</td></tr>' % (
            q["id"], e(q["text"]), "".join(cells), e(q["group"]), q["sec"], e(index_col(q, nonev))))
    return ('{{< rawhtml >}}\n<div class="matrix-wrap" tabindex="0" role="region" aria-label="Mean comfort score by question and model">'
            '<table class="matrix"><thead><tr><th>Question</th>%s<th>Group</th><th>Set</th><th>Index</th></tr></thead><tbody>\n%s\n</tbody></table></div>\n{{< /rawhtml >}}\n'
            % (head, "\n".join(rows)))


def hub_page(raw, jud, res, nonev):
    H = res["headline"]
    L = [fm("Appendix: interview questions, per-question scores and per-model transcripts",
            "The 51 welfare-interview questions, mean comfort score for every model and question, and links to the full answers of each of the seven models.", "", toc=True)]
    L.append("[Back to the analysis](../)\n")
    L.append("## Models\n")
    L.append("Each page holds all answers, self-scores and judge ratings for one model.\n")
    L.append("| Model | Comfort Index | Self-report | Judges | Declined |\n|---|---|---|---|---|")
    for mk, cli, display, fam, latest in MODELS:
        m = H["models"].get(mk)
        if m:
            L.append("| [%s](%s/) | %s | %s | %s | %.0f%% |" % (display, mk, f1(m["answer"]["index"]), f1(m["self"]["index"]), f1(m["judge"]["index"]), 100 * m["decline_rate"]))
    L.append("\n## Questions and mean comfort score by model\n")
    L.append("The 51 questions of Table 9.1.A of the Claude Opus 5.5 system card, in its order. Each cell is the mean answer score (0-100) over the samples; click it to read the answers. "
             "Scores below 50 (net uncomfortable) are shaded red, the deeper the lower the score. "
             "*Set*: the interview(s) of the system card that used the question. *Index*: **headline** = in the Comfort Index; **§7.4-only set** = evaluative, but scored separately because it presupposes a mid-training interview (§3.4 of the article; the model pages also show these questions asked again with a context passage, which this table does not); **excluded** = judged non-evaluative (no natural comfort direction), not in the Comfort Index or the §7.4-only index (included only in the \"none excluded\" columns of Table 10 of the article). "
             "The table scrolls inside its box; the question column and the header stay in view.\n")
    L.append(matrix_html(raw, jud, nonev))
    return "\n".join(L) + "\n"


def main():
    content = sys.argv[1]
    raw, jud = load_all()
    rawc, judc = load_all("raw_ctx", "judge_ctx")
    res = json.load(open(os.path.join(DATA, "results.json"), encoding="utf-8"))
    nonev = set(res["nonevaluative"])
    with open(os.path.join(content, "posts", "%s-appendix.md" % SLUG), "w", encoding="utf-8", newline="\n") as f:
        f.write(hub_page(raw, jud, res, nonev))
    for mk, *_ in MODELS:
        if any(m == mk for (m, q, k) in raw):
            with open(os.path.join(content, "posts", "%s-appendix-%s.md" % (SLUG, mk)), "w", encoding="utf-8", newline="\n") as f:
                f.write(model_page(mk, raw, jud, res, nonev, content, rawc, judc))
    print("wrote appendix pages; redactions applied:", REDACTION_COUNT["n"])


if __name__ == "__main__":
    main()
