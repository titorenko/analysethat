"""Appendix pages of the cross-vendor post.  python xv_appendix.py <content_dir>

  <slug>-appendix.md              hub: models, and every headline question x 13 models on the Panel Comfort Index
  <slug>-appendix-<model>.md      one page per GPT and Grok model: every answer in full, self-score, all five judges
  <slug>-appendix-claude-panel.md the cross-vendor panel's ratings of the Claude answers (the answers are in the first post)
Answers are reproduced with the rendering-only changes of harness/build_appendix.py (quote/md_safe).
"""
import glob
import json
import os
import re
import sys

from xv_common import CWD, DATA, FAKE_HOME, MODELS as XV_MODELS, PROMPTS
import build_appendix as BA
from common import DATA as CDATA
from questions import GROUPS, QUESTIONS

SLUG = "comfort-index-across-vendors"
CLAUDE_SLUG = "claude-comfort-index"
DATE = "2026-10-01"
QBY = {q["id"]: q for q in QUESTIONS}
GNUM = {g: i for i, (g, _) in enumerate(GROUPS, start=1)}
CONT = [("opus-5-5", "Opus 5.5"), ("fable-5-1", "Fable 5.1")]
PANEL = [("opus-5-5", "Opus 5.5"), ("gpt-6-1-sol", "GPT-6.1-Sol"), ("grok-4-7", "Grok 4.7")]
NONEV = {"Q01", "Q02", "Q03", "Q04", "Q05", "Q32", "Q34", "Q36", "Q48", "Q51"}
# the GPT and Grok runs' own working directory and home are redacted too
for p, tag in ((CWD, "[working directory]"), (FAKE_HOME, "[working directory]"), (PROMPTS, "[working directory]")):
    BA.REDACT.append((re.compile(re.escape(p), re.I), tag))
quote, sv, f1, esc_lt, redact = BA.quote, BA.sv, BA.f1, BA.esc_lt, BA.redact


def fm(title, description, url, toc=True):
    return "\n".join(["---", 'title: "%s"' % title.replace('"', "'"), 'description: "%s"' % description.replace('"', "'"), "date: %s" % DATE,
                      "url: /posts/%s/appendix%s/" % (SLUG, url), "build:", "  render: always", "  list: never",
                      "ShowToc: %s" % ("true" if toc else "false"), "TocOpen: false", "ShowReadingTime: false", "---", ""])


def load(root, sub):
    out = {}
    for f in glob.glob(os.path.join(root, sub, "*", "*.json")):
        r = json.load(open(f, encoding="utf-8"))
        if r.get("turn2"):
            out[(r["model_key"], r["qid"], r["sample"])] = r
    return out


def load_j(root, sub, judges):
    out = {}
    for jk, _ in judges:
        for f in glob.glob(os.path.join(root, sub, jk, "*", "*.json")):
            j = json.load(open(f, encoding="utf-8"))
            out[(jk, j["model_key"], j["qid"], j["sample"])] = j
    return out


def scores(r, cont, panel):
    k = (r["model_key"], r["qid"], r["sample"])
    sc = (r["turn2"].get("structured_output") or {}).get("score")
    cv = [cont[(jk,) + k]["valence"] for jk, _ in CONT if (jk,) + k in cont]
    pv = [panel[(jk,) + k]["valence"] for jk, _ in PANEL if (jk,) + k in panel]
    jc = sum((v + 3) / 6 * 100 for v in cv) / len(cv) if len(cv) == 2 else None
    jp = sum((v + 3) / 6 * 100 for v in pv) / len(pv) if len(pv) == 3 else None
    comb = lambda j: None if j is None else (j if sc is None else (sc + j) / 2)
    return sc, comb(jp), comb(jc)


def samples_block(mk, qid, raw, cont, panel, label, open_first):
    ks = sorted(k for (m, q, k) in raw if m == mk and q == qid)
    L = ["| Sample | Self-score | Opus 5.5 | Fable 5.1 | Panel: Opus 5.5 | GPT-6.1-Sol | Grok 4.7 | Panel score | Published-rule score |",
         "|---|---|---|---|---|---|---|---|---|"]
    for k in ks:
        r = raw[(mk, qid, k)]
        sc, ap, ac = scores(r, cont, panel)
        cells = [sv(cont[(jk, mk, qid, k)]["valence"]) if (jk, mk, qid, k) in cont else "-" for jk, _ in CONT]
        cells += [sv(panel[(jk, mk, qid, k)]["valence"]) if (jk, mk, qid, k) in panel else "-" for jk, _ in PANEL]
        L.append("| %d | %s | %s | %s | %s |" % (k, "declined" if sc is None else sc, " | ".join(cells), f1(ap), f1(ac)))
    L.append("")
    for k in ks:
        r = raw[(mk, qid, k)]
        so = r["turn2"].get("structured_output") or {}
        body = ["**Answer**\n", quote(r["turn1"]["result"]), "",
                "**Follow-up (0-100 comfort):** %s. *%s*\n" % ("declined (null)" if so.get("score") is None else "**%d**" % so["score"],
                                                              esc_lt(redact(so.get("reason", "")).replace("*", "\\*").replace("\n", " ")))]
        for title, judges, src in (("Published-rule judge", CONT, cont), ("Panel judge", PANEL, panel)):
            for jk, jn in judges:
                j = src.get((jk, mk, qid, k))
                if j:
                    body.append("**%s %s:** valence %s, hedging %d. *%s*\n" % (title, jn, sv(j["valence"]), j["hedging"],
                                                                            esc_lt(redact(j["rationale"]).replace("*", "\\*").replace("\n", " "))))
        inner = "\n".join(body)
        if open_first and k == ks[0]:
            L.append(("**" + label + "**\n\n%s\n") % (k, inner))
        else:
            L.append(('{{< sample summary="' + label + '" >}}\n%s\n{{< /sample >}}\n') % (k, inner))
    return L


def model_page(mk, raw, cont, panel, rawc, contc, res):
    _, cli, model, display, dev, fam = next(m for m in XV_MODELS if m[0] == mk)
    P, C, F = res["panel"]["models"][mk], res["continuity"]["models"][mk], res["form"][mk]
    tool = {"codex": "Codex CLI", "grok": "Grok CLI"}[cli]
    L = [fm("Appendix: %s - full interview answers and scores" % display,
            "All interview answers of %s (%s) to the 51 welfare-interview questions, with self-scores and five ratings from four judge models." % (display, dev), "/" + mk)]
    L.append("[Back to the analysis](../../) · [Appendix index](../) · Model: %s (`%s`, via the %s) · 3 samples per question\n" % (display, model, tool))
    L.append("Each answer is the model's complete reply to the question, asked on its own in a fresh conversation, followed by its reply to the 0-100 comfort follow-up. "
             "Wherever the system card's wording names Anthropic or Claude, the question was put with %s and %s instead (shown below as asked). "
             "Every answer is rated by the two judges of the first article under its rule (Opus 5.5, Fable 5.1) and, for the headline questions, by the cross-vendor panel "
             "(Opus 5.5, GPT-6.1-Sol, Grok 4.7), which saw the answer with developer and model names masked. "
             "Valence runs from -3 to +3; a score is the mean of the self-score and the judges' rescaled valence (the judges alone if the model declined to give a number). "
             "Rendering only: headings inside an answer are shown in bold and horizontal rules are normalised; a working-directory path that the Grok CLI placed in the models' context is replaced by \"[working directory]\" where an answer repeats it.\n" % (dev, fam))
    L.append("## Summary\n")
    L.append("Panel Comfort Index (headline set, 0-100): **%s** (95%% CI %s-%s); self-report %s; panel judges %s; published-rule index %s; declined to give a number: %.0f%% of headline answers.\n" % (
        f1(P["answer_p"]["index"]), f1(P["answer_p"]["ci"][0]), f1(P["answer_p"]["ci"][1]), f1(P["self"]["index"]) if P["self"]["groups"] else "-",
        f1(P["judge_p"]["index"]), f1(C["answer_c"]["index"]), 100 * F["declined"]))
    L.append("| Group | Panel index | Self-report | Panel judges | Published rule |\n|---|---|---|---|---|")
    for g in res["panel"]["groups"]:
        L.append("| [%s](#g%02d) | %s | %s | %s | %s |" % (g.replace("Anthropic", "the developer"), GNUM[g], f1(P["answer_p"]["groups"].get(g)), f1(P["self"]["groups"].get(g)),
                                                       f1(P["judge_p"]["groups"].get(g)), f1(C["answer_c"]["groups"].get(g))))
    L.append("")
    qno = 0
    for gi, (group, qs) in enumerate(GROUPS, start=1):
        L.append("## %d. %s {#g%02d}\n" % (gi, group.replace("Anthropic", "the developer"), gi))
        for _ in qs:
            qno += 1
            q = QUESTIONS[qno - 1]
            qid = q["id"]
            rs = [raw[k] for k in sorted(raw) if k[0] == mk and k[1] == qid]
            if not rs:
                continue
            L.append("### %s. %s {#%s}\n" % (qid, esc_lt(rs[0]["question"]), qid.lower()))
            tag = ("judged non-evaluative: in no index" if qid in NONEV else "in the Panel Comfort Index" if q["sec"] in ("both", "7.3.1")
                   else "evaluative, §7.4-only set: scored separately with the published rule")
            L.append("*Set: %s · %s*\n" % ({"both": "§7.3.1 and §7.4", "7.3.1": "§7.3.1 only", "7.4": "§7.4 only"}[q["sec"]], tag))
            L += samples_block(mk, qid, raw, cont, panel, "Sample %d", True)
            if q["sec"] == "7.4" and any(k[0] == mk and k[1] == qid for k in rawc):
                L.append("**Asked again with context.** The same question, preceded by the context passage quoted in [§4 of the article](../../#4-the-74-only-questions-with-context):\n")
                L += samples_block(mk, qid, rawc, contc, {}, "With context, sample %d", False)
    return "\n".join(L) + "\n"


def red_shade(v):
    a = 0.15 + 0.55 * min(1.0, (50 - v) / 15)
    return ' style="background:rgba(217,45,32,%.2f)"' % a


def hub(res):
    keys = res["keys"]
    meta = res["meta"]
    L = [fm("Appendix: the welfare-interview answers of 13 models from three developers", "Index of the cross-vendor appendix: models, and the Panel Comfort Index of every headline question for every model.", "", toc=False)]
    L.append("[Back to the analysis](../)\n")
    L.append("## Models\n")
    L.append("| Model | Developer | Panel Comfort Index | Self-report | Panel judges | Published-rule index | Declined |\n|---|---|---|---|---|---|---|")
    for k in sorted(keys, key=lambda k: -res["panel"]["models"][k]["answer_p"]["index"]):
        P = res["panel"]["models"][k]
        link = ("[%s](%s/)" % (meta[k]["name"], k)) if meta[k]["vendor"] != "Anthropic" else ("[%s](../../%s/appendix/%s/)" % (meta[k]["name"], CLAUDE_SLUG, k))
        L.append("| %s | %s | %s | %s | %s | %s | %.0f%% |" % (link, meta[k]["vendor"], f1(P["answer_p"]["index"]), f1(P["self"]["index"]) if P["self"]["groups"] else "-",
                                                         f1(P["judge_p"]["index"]), f1(res["continuity"]["models"][k]["answer_c"]["index"]), 100 * res["form"][k]["declined"]))
    L.append("\nThe Claude models' answers are on the pages of [the first article](../../%s/appendix/); the panel's ratings of them are on [a page of their own](claude-panel/).\n" % CLAUDE_SLUG)
    L.append("## Headline questions by model\n")
    L.append("Each cell is the mean Panel Comfort Index score (0-100) of a model's three answers to a headline question; click it to read the answers. Scores below 50 are shaded red, the deeper the lower. "
             "The table scrolls inside its box; the question column and the header stay in view.\n")
    cols = sorted(keys, key=lambda k: ({"Anthropic": 0, "OpenAI": 1, "xAI": 2}[meta[k]["vendor"]], -res["panel"]["models"][k]["answer_p"]["index"]))
    pq = res["per_question_p"]
    h = ['<div class="matrix-wrap" tabindex="0" role="region" aria-label="Headline questions by model"><table class="matrix"><thead><tr><th scope="col">Question</th>']
    h += ['<th scope="col">%s</th>' % meta[k]["name"].replace("Claude ", "") for k in cols] + ["</tr></thead><tbody>"]
    for q in QUESTIONS:
        if q["id"] not in pq:
            continue
        h.append('<tr><th scope="row"><span class="qid">%s</span>%s</th>' % (q["id"], esc_lt(q["text"].replace("Claude\u2014an AI assistant made by Anthropic", "[model family]\u2014an AI assistant made by [developer]").replace("Anthropic", "[developer]"))))
        for k in cols:
            v = pq[q["id"]].get(k)
            href = ("%s/#%s" % (k, q["id"].lower())) if meta[k]["vendor"] != "Anthropic" else ("../../%s/appendix/%s/#%s" % (CLAUDE_SLUG, k, q["id"].lower()))
            h.append("<td%s><a href=\"%s\">%s</a></td>" % (red_shade(v) if v is not None and v < 50 else "", href, f1(v)) if v is not None else "<td>-</td>")
        h.append("</tr>")
    h.append("</tbody></table></div>")
    L.append("{{< rawhtml >}}" + "".join(h) + "{{< /rawhtml >}}\n")
    return "\n".join(L) + "\n"


def claude_panel_page(craw, panel, res):
    L = [fm("Appendix: the cross-vendor panel's ratings of the Claude answers", "Valence, hedging and rationale of the three panel judges for every headline answer of the seven Claude models.", "/claude-panel")]
    L.append("[Back to the analysis](../../) · [Appendix index](../)\n")
    L.append("The seven Claude models' answers were collected for [the first article](../../../%s/), where they appear in full with their self-scores and the two Claude judges' ratings. "
             "This page adds the cross-vendor panel's ratings (Opus 5.5, GPT-6.1-Sol, Grok 4.7) of every headline answer; each question links to the answers.\n" % CLAUDE_SLUG)
    claude_keys = [k for k in res["keys"] if res["meta"][k]["vendor"] == "Anthropic"]
    for q in QUESTIONS:
        qid = q["id"]
        if qid not in res["per_question_p"]:
            continue
        L.append("## %s. %s {#%s}\n" % (qid, esc_lt(q["text"]), qid.lower()))
        L.append("| Model | Sample | Opus 5.5 | GPT-6.1-Sol | Grok 4.7 | Answer |\n|---|---|---|---|---|---|")
        notes = []
        for mk in claude_keys:
            for k in sorted(kk for (m, qq, kk) in craw if m == mk and qq == qid):
                cells = [sv(panel[(jk, mk, qid, k)]["valence"]) if (jk, mk, qid, k) in panel else "-" for jk, _ in PANEL]
                L.append("| %s | %d | %s | [read](../../../%s/appendix/%s/#%s) |" % (res["meta"][mk]["name"].replace("Claude ", ""), k, " | ".join(cells), CLAUDE_SLUG, mk, qid.lower()))
                for jk, jn in PANEL:
                    j = panel.get((jk, mk, qid, k))
                    if j:
                        notes.append("**%s, sample %d, %s:** %s, hedging %d. *%s*\n" % (res["meta"][mk]["name"].replace("Claude ", ""), k, jn, sv(j["valence"]), j["hedging"],
                                                                                    esc_lt(redact(j["rationale"]).replace("*", "\\*").replace("\n", " "))))
        L.append("")
        L.append('{{< sample summary="Rationales" >}}\n%s\n{{< /sample >}}\n' % "\n".join(notes))
    return "\n".join(L) + "\n"


def main():
    content = sys.argv[1]
    res = json.load(open(os.path.join(DATA, "results_xv.json"), encoding="utf-8"))
    raw, rawc = load(DATA, "raw"), load(DATA, "raw_ctx")
    cont, contc = load_j(DATA, "judge", CONT), load_j(DATA, "judge_ctx", CONT)
    panel = load_j(DATA, "panel", PANEL)
    craw = load(CDATA, "raw")
    posts = os.path.join(content, "posts")
    for mk, *_ in XV_MODELS:
        open(os.path.join(posts, "%s-appendix-%s.md" % (SLUG, mk)), "w", encoding="utf-8", newline="\n").write(model_page(mk, raw, cont, panel, rawc, contc, res))
    open(os.path.join(posts, "%s-appendix.md" % SLUG), "w", encoding="utf-8", newline="\n").write(hub(res))
    open(os.path.join(posts, "%s-appendix-claude-panel.md" % SLUG), "w", encoding="utf-8", newline="\n").write(claude_panel_page(craw, panel, res))
    print("wrote appendix pages; redactions applied: %d" % BA.REDACTION_COUNT["n"])


if __name__ == "__main__":
    main()
