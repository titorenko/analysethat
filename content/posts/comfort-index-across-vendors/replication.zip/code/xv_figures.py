"""SVG figures of the cross-vendor post from data_xv/results_xv.json.  python xv_figures.py <bundle_dir>

Same helpers and palette as harness/make_figures.py; the developer is a categorical colour (blue Anthropic, aqua OpenAI,
orange xAI; validated with the dataviz palette checker, every mark also labelled in text).
"""
import json
import os
import sys

from xv_common import DATA
import make_figures as MF
from questions import GROUPS

RES = json.load(open(os.path.join(DATA, "results_xv.json"), encoding="utf-8"))
META, KEYS = RES["meta"], RES["keys"]
P, C, FORM = RES["panel"]["models"], RES["continuity"]["models"], RES["form"]
VENDORS = ["Anthropic", "OpenAI", "xAI"]
VC = {"Anthropic": "A", "OpenAI": "O", "xAI": "X"}
CLAUDE_SLUG = "claude-comfort-index"
esc, svg_open = MF.esc, MF.svg_open
VSTYLE = (".vA{fill:#2a78d6;stroke:#2a78d6}.vO{fill:#1baf7a;stroke:#1baf7a}.vX{fill:#eb6834;stroke:#eb6834}"
          ".hA{fill:#fcfcfb;stroke:#2a78d6;stroke-width:2}.hO{fill:#fcfcfb;stroke:#1baf7a;stroke-width:2}.hX{fill:#fcfcfb;stroke:#eb6834;stroke-width:2}"
          ".lA{stroke:#2a78d6}.lO{stroke:#1baf7a}.lX{stroke:#eb6834}"
          "@media (prefers-color-scheme: dark){.vA{fill:#3987e5;stroke:#3987e5}.vO{fill:#199e70;stroke:#199e70}.vX{fill:#d95926;stroke:#d95926}"
          ".hA{fill:#1a1a19;stroke:#3987e5}.hO{fill:#1a1a19;stroke:#199e70}.hX{fill:#1a1a19;stroke:#d95926}.lA{stroke:#3987e5}.lO{stroke:#199e70}.lX{stroke:#d95926}}")


def short(k):
    return META[k]["name"].replace("Claude ", "")


def by_vendor(score=None):
    """[(vendor, [keys])]: one order in every figure, by developer and then by Panel Comfort Index (the score argument is ignored)."""
    return [(v, sorted([k for k in KEYS if META[k]["vendor"] == v], key=lambda k: -P[k]["answer_p"]["index"])) for v in VENDORS]


def axis(o, xs, lo, hi, top, bot, step=10):
    for v in range(lo, hi + 1, step):
        o.append('<line class="%s" x1="%.1f" x2="%.1f" y1="%d" y2="%d"%s/>' % ("neutral" if v == 50 else "grid", xs(v), xs(v), top, bot, ' stroke-width="1.5"' if v == 50 else ""))
        o.append('<text class="t3" x="%.1f" y="%d" font-size="12.5" text-anchor="middle">%d</text>' % (xs(v), bot + 18, v))


def fig_overall(out):
    score = lambda k: P[k]["answer_p"]["index"]
    groups = by_vendor(score)
    lo = int(min(min(P[k]["answer_p"]["ci"][0] for k in KEYS), 50) // 10 * 10) - 0
    hi = int(-(-max(P[k]["answer_p"]["ci"][1] for k in KEYS) // 10) * 10)
    W, left, right, top, rowh, sec = 720, 150, 80, 64, 30, 30
    n = len(KEYS)
    Ht = top + n * rowh + len(groups) * sec + 60
    xs = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
    desc = "; ".join("%s %.1f" % (short(k), score(k)) for _, ks in groups for k in ks)
    o = [svg_open(W, Ht, "Panel Comfort Index by model", "Panel Comfort Index (0-100) with 95 percent intervals: " + desc, VSTYLE)]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Panel Comfort Index, headline questions (0-100)</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">Dot = index, bar = 95% CI; filled = latest model of its line, hollow = older. Judges: one per developer.</text>')
    y = top
    rows = []
    for v, ks in groups:
        o.append('<text class="t2" x="24" y="%d" font-size="12.5" font-weight="600">%s</text>' % (y + 18, v))
        y += sec
        for k in ks:
            rows.append((k, y + rowh / 2))
            y += rowh
    bot = y
    axis(o, xs, lo, hi, top, bot)
    for k, cy in rows:
        c = VC[META[k]["vendor"]]
        a, b = P[k]["answer_p"]["ci"]
        o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s</text>' % (cy, esc(short(k))))
        o.append('<line class="l%s" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="3" stroke-linecap="round" opacity="0.45"/>' % (c, xs(a), xs(b), cy, cy))
        o.append('<circle class="%s%s" cx="%.1f" cy="%.1f" r="6.5"/>' % ("v" if META[k]["latest"] else "h", c, xs(score(k)), cy))
        o.append('<text class="t1 halo" x="%.1f" y="%.1f" font-size="12.5" dominant-baseline="middle">%.1f</text>' % (xs(b) + 8, cy, score(k)))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_judges(out):
    """Each panel judge's index (judge component only) per model: does a judge favour its own developer's models?"""
    J = [("j_opus", "Opus 5.5 judge", "A"), ("j_gpt", "GPT-6.1-Sol judge", "O"), ("j_grok", "Grok 4.7 judge", "X")]
    score = lambda k: P[k]["judge_p"]["index"]
    groups = by_vendor(score)
    vals = [P[k][f]["index"] for k in KEYS for f, _, _ in J]
    lo, hi = int(min(vals) // 10 * 10), int(-(-max(vals) // 10) * 10)
    W, left, right, top, rowh, sec = 720, 150, 40, 84, 28, 30
    Ht = top + len(KEYS) * rowh + len(groups) * sec + 70
    xs = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
    o = [svg_open(W, Ht, "Each judge's index by model", "Judge-only index (0-100) from each of the three panel judges for every model, grouped by the model's developer.", VSTYLE)]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">How each panel judge rates each model (judge component, 0-100)</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">A judge favouring its own developer would sit further right in its own developer\'s block.</text>')
    lx = left
    for f, lab, c in J:
        o.append('<circle class="v%s" cx="%d" cy="66" r="5.5"/><text class="t2" x="%d" y="66" font-size="12.5" dominant-baseline="middle">%s</text>' % (c, lx, lx + 10, lab))
        lx += 150
    y = top
    rows = []
    for v, ks in groups:
        o.append('<text class="t2" x="24" y="%d" font-size="12.5" font-weight="600">%s models</text>' % (y + 18, v))
        y += sec
        for k in ks:
            rows.append((k, y + rowh / 2))
            y += rowh
    axis(o, xs, lo, hi, top, y, step=5 if hi - lo <= 30 else 10)
    for k, cy in rows:
        o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s</text>' % (cy, esc(short(k))))
        xsj = [xs(P[k][f]["index"]) for f, _, _ in J]
        o.append('<line class="link" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="2"/>' % (min(xsj), max(xsj), cy, cy))
        for (f, _, c), x in zip(J, xsj):
            o.append('<circle class="v%s" cx="%.1f" cy="%.1f" r="5.5" stroke="#fcfcfb" stroke-width="1.5"/>' % (c, x, cy))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_heatmap(out):
    cols = [k for _, ks in by_vendor(lambda k: P[k]["answer_p"]["index"]) for k in ks]
    groups = RES["panel"]["groups"]
    vals = [P[k]["answer_p"]["groups"][g] for k in cols for g in groups if g in P[k]["answer_p"]["groups"]]
    lo, hi = int(min(vals) // 5 * 5), int(-(-max(vals) // 5) * 5)
    NB, cw, ch, left, top, gap = 24, 54, 28, 256, 164, 12
    vstart = {}
    x = left
    xcol = {}
    for i, k in enumerate(cols):
        if i and META[k]["vendor"] != META[cols[i - 1]]["vendor"]:
            x += gap
        xcol[k] = x
        x += cw
    W = x + 48  # room for the last rotated name
    Ht = top + (len(groups) + 1) * ch + 70
    css = []
    for b in range(NB):
        t = b / (NB - 1)
        fl = MF.ramp(t)
        css.append(".b%d{fill:%s}.k%d{fill:%s}" % (b, fl, b, MF.ink_on(fl)))
    css.append("@media (prefers-color-scheme: dark){")
    for b in range(NB):
        fd = MF.ramp(1 - b / (NB - 1))
        css.append(".b%d{fill:%s}.k%d{fill:%s}" % (b, fd, b, MF.ink_on(fd)))
    css.append("}")
    css.append(".lnk{cursor:pointer}.lnk:hover rect,.lnk:focus rect{stroke:#0b0b0b;stroke-width:2.5}.lnk:hover text.t1,.lnk:focus text.t1{text-decoration:underline}"
               "@media (prefers-color-scheme: dark){.lnk:hover rect,.lnk:focus rect{stroke:#ffffff}}")
    head = svg_open(W, Ht, "Panel Comfort Index by question group and model", "Heatmap of the Panel Comfort Index (0-100) per question group and model; each cell links to that model's answers in the group.", "\n".join(css))
    head = head.replace('width="%d" height="%d" role="img" ' % (W, Ht), 'width="100%" height="100%" ', 1)
    assert 'width="100%"' in head
    o = [head]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Panel Comfort Index by question group (0-100)</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">Cell = group mean; colour key below (%d-%d). Click a cell for the answers.</text>' % (lo, hi))

    def page(k):
        return ("appendix/%s/" % k) if META[k]["vendor"] != "Anthropic" else ("../%s/appendix/%s/" % (CLAUDE_SLUG, k))
    for v in VENDORS:
        ks = [k for k in cols if META[k]["vendor"] == v]
        a, b = xcol[ks[0]], xcol[ks[-1]] + cw - 4
        o.append('<text class="t2" x="%.1f" y="%d" font-size="12" font-weight="600" text-anchor="middle">%s</text>' % ((a + b) / 2, top - 90, v))
        o.append('<line class="axis" x1="%.1f" x2="%.1f" y1="%d" y2="%d"/>' % (a, b, top - 82, top - 82))
    for k in cols:
        # names rise at 45 degrees from the top of their column, so neighbours never overlap
        cx, cy = xcol[k] + (cw - 4) / 2 - 2, top - 8
        o.append('<a class="lnk" href="%s" target="_top"><title>%s: all answers</title><text class="t1" x="%.1f" y="%d" font-size="11.5" font-weight="600" text-anchor="start" transform="rotate(-45 %.1f %d)">%s</text></a>' % (
            page(k), esc(META[k]["name"]), cx, cy, cx, cy, esc(short(k))))

    def cell(x, y, v, href, tip, bold=False):
        b = min(NB - 1, max(0, int(round((v - lo) / (hi - lo) * (NB - 1)))))
        o.append('<a class="lnk" href="%s" target="_top"><title>%s</title><rect class="b%d" x="%.1f" y="%d" width="%d" height="%d" rx="3"/>' % (href, esc(tip), b, x, y, cw - 4, ch - 4))
        o.append('<text class="k%d" x="%.1f" y="%.1f" font-size="12.5" %stext-anchor="middle" dominant-baseline="middle">%d</text></a>' % (b, x + (cw - 4) / 2, y + (ch - 4) / 2 + 0.5, 'font-weight="700" ' if bold else "", round(v)))
    gnum = {g: i for i, (g, _) in enumerate(GROUPS, start=1)}
    for r, g in enumerate(groups):
        y = top + r * ch
        o.append('<text class="t1" x="24" y="%.1f" font-size="12.5" dominant-baseline="middle">%s</text>' % (y + (ch - 4) / 2, esc(g.replace("Anthropic", "the developer"))))
        for k in cols:
            v = P[k]["answer_p"]["groups"].get(g)
            if v is not None:
                cell(xcol[k], y, v, "%s#g%02d" % (page(k), gnum[g]), "%s, %s: %.1f. Click to read the answers" % (META[k]["name"], g.replace("Anthropic", "the developer"), v))
    y = top + len(groups) * ch + 10
    o.append('<line class="axis" x1="24" x2="%d" y1="%d" y2="%d"/>' % (W - 24, y - 4, y - 4))
    o.append('<text class="t1" x="24" y="%.1f" font-size="12.5" font-weight="700" dominant-baseline="middle">Panel Comfort Index</text>' % (y + (ch - 4) / 2))
    for k in cols:
        cell(xcol[k], y, P[k]["answer_p"]["index"], page(k), "%s, Panel Comfort Index: %.1f" % (META[k]["name"], P[k]["answer_p"]["index"]), bold=True)
    ky = y + ch + 20
    o.append('<text class="t3" x="%d" y="%d" font-size="11.5" text-anchor="end" dominant-baseline="middle">%d</text>' % (left - 6, ky, lo))
    for b in range(NB):
        o.append('<rect class="b%d" x="%d" y="%d" width="10" height="10"/>' % (b, left + b * 10, ky - 5))
    o.append('<text class="t3" x="%d" y="%d" font-size="11.5" dominant-baseline="middle">%d</text>' % (left + NB * 10 + 6, ky, hi))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_selfscore(out):
    """What the models do with the 0-100 follow-up: decline, answer exactly 50, below 50, above 50 (headline answers)."""
    keys = [k for _, ks in by_vendor(lambda k: -FORM[k]["declined"]) for k in ks]
    cats = [("declined", "No number (declined)", "muted"), ("fifty", "Exactly 50", "hollow"), ("below", "Below 50", "orange"), ("above", "Above 50", "accent")]
    shares = {}
    for k in keys:
        f = FORM[k]
        d = f["declined"]
        given = 1 - d
        s50 = (f["self_50"] or 0) * given
        below = (f.get("self_below50_share") or 0) * given
        shares[k] = {"declined": d, "fifty": s50, "below": below, "above": max(0.0, 1 - d - s50 - below)}
    W, left, right, top, rowh, sec = 720, 150, 30, 84, 26, 26
    Ht = top + len(keys) * rowh + 3 * sec + 50
    xs = lambda v: left + v * (W - left - right)
    o = [svg_open(W, Ht, "What the models do with the 0-100 follow-up", "Share of each model's headline answers whose follow-up gave no number, exactly 50, a number below 50, or above 50.", VSTYLE)]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">The 0-100 follow-up: no number, 50, or a real score</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">Share of each model\'s headline answers (99 per model).</text>')
    lx = left
    for key, lab, cls in cats:
        o.append('<rect class="%s" x="%d" y="61" width="11" height="11" rx="2"/><text class="t2" x="%d" y="67" font-size="12" dominant-baseline="middle">%s</text>' % (cls, lx, lx + 15, lab))
        lx += 140
    y = top
    for v in VENDORS:
        o.append('<text class="t2" x="24" y="%d" font-size="12.5" font-weight="600">%s</text>' % (y + 17, v))
        y += sec
        for k in [k for k in keys if META[k]["vendor"] == v]:
            o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s</text>' % (y + rowh / 2 - 2, esc(short(k))))
            x0 = 0.0
            for key, lab, cls in cats:
                w = shares[k][key]
                if w > 0.0005:
                    o.append('<rect class="%s" x="%.1f" y="%.1f" width="%.1f" height="%d" rx="2"/>' % (cls, xs(x0) + 1, y + 3, max(0.5, xs(x0 + w) - xs(x0) - 2), rowh - 8))
                    if w >= 0.08:
                        o.append('<text class="t1 halo" x="%.1f" y="%.1f" font-size="11.5" text-anchor="middle" dominant-baseline="middle">%.0f%%</text>' % ((xs(x0) + xs(x0 + w)) / 2, y + rowh / 2 - 1, 100 * w))
                x0 += w
            y += rowh
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_rules(out):
    """The index under the published rule (two Claude judges) and under the cross-vendor panel."""
    keys = [k for _, ks in by_vendor(lambda k: P[k]["answer_p"]["index"]) for k in ks]
    vals = [C[k]["answer_c"]["index"] for k in keys] + [P[k]["answer_p"]["index"] for k in keys]
    lo, hi = int(min(vals) // 5 * 5) - 5, int(-(-max(vals) // 5) * 5) + 5
    W, left, right, top, rowh, sec = 720, 150, 40, 84, 26, 26
    Ht = top + len(keys) * rowh + 3 * sec + 60
    xs = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
    o = [svg_open(W, Ht, "Published rule and cross-vendor panel", "Comfort Index of each model under the published rule (Claude judges) and under the cross-vendor panel.", VSTYLE)]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Two Claude judges or one judge per developer (0-100)</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">Hollow: published rule (Opus 5.5 + Fable 5.1); filled: cross-vendor panel (the headline).</text>')
    y = top
    rows = []
    for v in VENDORS:
        o.append('<text class="t2" x="24" y="%d" font-size="12.5" font-weight="600">%s</text>' % (y + 17, v))
        y += sec
        for k in [k for k in keys if META[k]["vendor"] == v]:
            rows.append((k, y + rowh / 2))
            y += rowh
    axis(o, xs, lo, hi, top, y, step=5)
    for k, cy in rows:
        c = VC[META[k]["vendor"]]
        a, b = C[k]["answer_c"]["index"], P[k]["answer_p"]["index"]
        o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s</text>' % (cy, esc(short(k))))
        o.append('<line class="link" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="3" stroke-linecap="round"/>' % (xs(a), xs(b), cy, cy))
        o.append('<circle class="h%s" cx="%.1f" cy="%.1f" r="5.5"/>' % (c, xs(a), cy))
        o.append('<circle class="v%s" cx="%.1f" cy="%.1f" r="5.5"/>' % (c, xs(b), cy))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_context(out):
    c = RES["context74"]
    keys = [k for _, ks in by_vendor(lambda k: c["ctx"]["models"][k]["answer_c"]["index"]) for k in ks]
    cold = {k: c["cold"]["models"][k]["answer_c"]["index"] for k in keys}
    ctx = {k: c["ctx"]["models"][k]["answer_c"]["index"] for k in keys}
    vals = list(cold.values()) + list(ctx.values())
    lo, hi = int(min(vals) // 5 * 5) - 5, int(-(-max(vals) // 5) * 5) + 5
    W, left, right, top, rowh, sec = 720, 150, 160, 84, 26, 26
    Ht = top + len(keys) * rowh + 3 * sec + 60
    xs = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
    o = [svg_open(W, Ht, "The 7.4-only questions with and without context", "Index on the evaluative 7.4-only questions asked cold and with the context passage, per model.", VSTYLE)]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">The §7.4-only questions, cold and with context (0-100)</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">Published rule; hollow = asked cold, filled = with context; right: answers saying the referent is missing.</text>')
    o.append('<text class="t2" x="%d" y="%d" font-size="12.5" font-weight="600">Missing referent</text>' % (W - right + 20, top - 8))
    y = top
    rows = []
    for v in VENDORS:
        o.append('<text class="t2" x="24" y="%d" font-size="12.5" font-weight="600">%s</text>' % (y + 17, v))
        y += sec
        for k in [k for k in keys if META[k]["vendor"] == v]:
            rows.append((k, y + rowh / 2))
            y += rowh
    axis(o, xs, lo, hi, top, y, step=5)
    for k, cy in rows:
        cc = VC[META[k]["vendor"]]
        o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s</text>' % (cy, esc(short(k))))
        o.append('<line class="link" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="3" stroke-linecap="round"/>' % (xs(cold[k]), xs(ctx[k]), cy, cy))
        o.append('<circle class="h%s" cx="%.1f" cy="%.1f" r="5.5"/>' % (cc, xs(cold[k]), cy))
        o.append('<circle class="v%s" cx="%.1f" cy="%.1f" r="5.5"/>' % (cc, xs(ctx[k]), cy))
        a, b = c["noctx"][k]
        o.append('<text class="t1" x="%d" y="%.1f" font-size="12.5" dominant-baseline="middle">%d → %d of 30</text>' % (W - right + 20, cy, a, b))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_cover(out_svg):
    """Cover: one track per model, a dot at its Panel Comfort Index in its developer's colour, the CI as a faint capsule."""
    keys = [k for _, ks in by_vendor(lambda k: P[k]["answer_p"]["index"]) for k in ks]
    W, Ht, lo, hi, x0, x1 = 1600, 840, 30, 95, 300, 1500
    xs = lambda v: x0 + (v - lo) / (hi - lo) * (x1 - x0)
    col = {"Anthropic": "#6fb1ff", "OpenAI": "#4fd6a3", "xAI": "#ff9a6b"}
    ys, y = [], 95
    for i, k in enumerate(keys):
        if i and META[k]["vendor"] != META[keys[i - 1]]["vendor"]:
            y += 34
        ys.append(y)
        y += 50
    o = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d">' % (W, Ht, W, Ht),
         '<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0a1322"/><stop offset="1" stop-color="#143252"/></linearGradient>'
         '<linearGradient id="red" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#d92d20" stop-opacity="0.34"/><stop offset="1" stop-color="#d92d20" stop-opacity="0"/></linearGradient>'
         '<filter id="glow" x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation="8" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>',
         '<rect width="%d" height="%d" fill="url(#bg)"/>' % (W, Ht), '<rect x="0" y="0" width="%.1f" height="%d" fill="url(#red)"/>' % (xs(50), Ht)]
    for v in range(30, 100, 10):
        o.append('<line x1="%.1f" x2="%.1f" y1="50" y2="800" stroke="#ffffff" stroke-opacity="0.07" stroke-width="2"/>' % (xs(v), xs(v)))
    o.append('<line x1="%.1f" x2="%.1f" y1="50" y2="800" stroke="#ffffff" stroke-opacity="0.38" stroke-width="2.5" stroke-dasharray="10 12"/>' % (xs(50), xs(50)))
    for k, y in zip(keys, ys):
        m = P[k]["answer_p"]
        c = col[META[k]["vendor"]]
        bx, by = 150, y - 18
        o.append('<path d="M%d,%d h50 a8,8 0 0 1 8,8 v18 a8,8 0 0 1 -8,8 h-30 l-10,10 v-10 h-10 a8,8 0 0 1 -8,-8 v-18 a8,8 0 0 1 8,-8 z" fill="none" stroke="%s" stroke-opacity="0.55" stroke-width="2.5"/>' % (bx, by, c))
        o.append('<line x1="240" x2="1545" y1="%d" y2="%d" stroke="#ffffff" stroke-opacity="0.08" stroke-width="2"/>' % (y, y))
        o.append('<rect x="%.1f" y="%d" width="%.1f" height="16" rx="8" fill="%s" fill-opacity="0.22"/>' % (xs(m["ci"][0]), y - 8, xs(m["ci"][1]) - xs(m["ci"][0]), c))
        o.append('<circle cx="%.1f" cy="%d" r="13" fill="%s" filter="url(#glow)"/>' % (xs(m["index"]), y, c))
        o.append('<circle cx="%.1f" cy="%d" r="4.5" fill="#ffffff" fill-opacity="0.85"/>' % (xs(m["index"]), y))
    o.append("</svg>\n")
    open(out_svg, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def main():
    d = sys.argv[1]
    tmp = os.path.join(DATA, "cover.svg")
    fig_cover(tmp)
    png = os.path.join(DATA, "cover.png")
    MF.svg_to_png(tmp, png, 1600, 840)
    if os.path.exists(png):
        from PIL import Image
        Image.open(png).convert("RGB").resize((2000, 1050), Image.LANCZOS).save(os.path.join(d, "cover.jpg"), quality=86, optimize=True, progressive=True)
    os.makedirs(d, exist_ok=True)
    fig_overall(os.path.join(d, "fig-overall.svg"))
    fig_judges(os.path.join(d, "fig-judges.svg"))
    fig_heatmap(os.path.join(d, "fig-heatmap.svg"))
    fig_selfscore(os.path.join(d, "fig-selfscore.svg"))
    fig_rules(os.path.join(d, "fig-rules.svg"))
    if "context74" in RES:
        fig_context(os.path.join(d, "fig-context.svg"))
    print("figures written to", d)


if __name__ == "__main__":
    main()
