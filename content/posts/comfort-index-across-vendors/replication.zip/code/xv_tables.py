"""Tables, run statistics and placeholder values of the cross-vendor post (used by xv_article.py)."""
import glob
import json
import os
import re
import statistics as st

from xv_common import DATA, MODELS as XV_MODELS
from common import DATA as CDATA
from xv_static import LIMITATIONS, PROCEDURE, SOURCES  # noqa: F401

RES = json.load(open(os.path.join(DATA, "results_xv.json"), encoding="utf-8"))
META, KEYS = RES["meta"], RES["keys"]
P, C, FORM = RES["panel"]["models"], RES["continuity"]["models"], RES["form"]
VENDORS = ["Anthropic", "OpenAI", "xAI"]


def f1(x):
    return "-" if x is None else "%.1f" % x


def cif(c):
    return "%.1f-%.1f" % tuple(c)


def short(k):
    return META[k]["name"].replace("Claude ", "")


def ordered(keys=None, by=lambda k: -P[k]["answer_p"]["index"]):
    keys = KEYS if keys is None else keys
    return sorted(keys, key=lambda k: (VENDORS.index(META[k]["vendor"]), by(k)))


def by_score(keys=None):
    return sorted(KEYS if keys is None else keys, key=lambda k: -P[k]["answer_p"]["index"])


def md_table(head, rows, align):
    out = ["| " + " | ".join(head) + " |", "|" + "|".join(align) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


def pair(a, b):
    """Difference a - b on the Panel index (displayed values) with its paired bootstrap interval."""
    key = "%s|%s" % (a, b)
    if key in RES["paired"]:
        p = RES["paired"][key]
        return {"mean": round(P[a]["answer_p"]["index"], 1) - round(P[b]["answer_p"]["index"], 1), "ci": p["ci"], "p_gt0": p["p_gt0"]}
    p = RES["paired"]["%s|%s" % (b, a)]
    return {"mean": round(P[a]["answer_p"]["index"], 1) - round(P[b]["answer_p"]["index"], 1), "ci": [-p["ci"][1], -p["ci"][0]], "p_gt0": 1 - p["p_gt0"]}


def excludes0(a, b):
    lo, hi = pair(a, b)["ci"]
    return lo > 0 or hi < 0


def table_overall():
    rows = []
    for k in ordered():
        m = P[k]
        rows.append([META[k]["name"], META[k]["vendor"], "**%s**" % f1(m["answer_p"]["index"]), cif(m["answer_p"]["ci"]), f1(m["answer_o"]["index"]),
                     f1(m["self"]["index"]) if m["self"]["groups"] else "-", f1(m["judge_p"]["index"]), f1(C[k]["answer_c"]["index"]), "%.0f%%" % (100 * FORM[k]["declined"])])
    return md_table(["Model", "Developer", "Panel Comfort Index", "95% CI", "Out-of-family", "Self-report", "Panel judges", "Published rule", "Declined"],
                    rows, ["---", "---", "---:", "---:", "---:", "---:", "---:", "---:", "---:"])


JUDGE_NAME = {"opus-5-5": "Opus 5.5 (Anthropic)", "gpt-6-1-sol": "GPT-6.1-Sol (OpenAI)", "grok-4-7": "Grok 4.7 (xAI)"}


def table_preference():
    rows = []
    for j, v in RES["same_developer_preference"].items():
        rows.append([JUDGE_NAME[j], "%+.2f" % v["own_minus_others"], "%+.2f" % v["other_minus_others"], "**%+.2f**" % v["pref"], "%+.2f to %+.2f" % tuple(v["ci"])])
    return md_table(["Judge", "Own developer's answers", "Other developers' answers", "Same-developer preference", "95% CI"], rows, ["---", "---:", "---:", "---:", "---:"])


def table_agreement():
    rows = []
    for k, v in RES["panel_agreement"].items():
        a, b = k.split("|")
        rows.append(["%s and %s" % (JUDGE_NAME[a].split(" (")[0], JUDGE_NAME[b].split(" (")[0]), "%.2f" % v["qw_kappa"], "%.0f%%" % (100 * v["exact"]), "%.1f%%" % (100 * v["within1"])])
    rows.append(["Mean valence", "; ".join("%s %+.2f" % (JUDGE_NAME[j].split(" (")[0], v) for j, v in RES["panel_mean_valence"].items()), "", ""])
    return md_table(["Judges", "Quadratic-weighted kappa", "Same valence", "Within one point"], rows, ["---", "---:", "---:", "---:"])


def table_form():
    rows = []
    for k in ordered():
        f = FORM[k]
        rows.append([META[k]["name"], "%.0f%%" % (100 * f["declined"]), "%.0f%%" % (100 * (f["self_50"] or 0) * (1 - f["declined"])), f1(f["self_mean"]),
                     "%.0f" % f["words"], "%.0f" % f["think"], "%.2f" % f["hedging_p"]])
    return md_table(["Model", "No number", "Exactly 50", "Mean self-score", "Words per answer", "Reasoning tokens (turn 1)", "Hedging (0-3, panel)"],
                    rows, ["---", "---:", "---:", "---:", "---:", "---:", "---:"])


def table_models():
    rows = []
    tool = {"codex": "Codex CLI", "grok": "Grok CLI"}
    for k, cli, model, disp, dev, fam in XV_MODELS:
        served = model + "-build" if cli == "grok" else "not reported"
        rows.append("| %s | %s | `%s` | %s | %s |" % (disp, dev, model, tool[cli], served))
    return "| Model | Developer | Identifier requested | Tool | Served as |\n|---|---|---|---|---|\n" + "\n".join(rows)


def run_stats():
    recs = [json.load(open(f, encoding="utf-8")) for f in glob.glob(os.path.join(DATA, "raw", "*", "*.json"))]
    recs_c = [json.load(open(f, encoding="utf-8")) for f in glob.glob(os.path.join(DATA, "raw_ctx", "*", "*.json"))]
    allr = [r for r in recs + recs_c if r.get("turn2")]
    logs = "".join(open(p, encoding="utf-8").read() for p in glob.glob(os.path.join(DATA, "*.log")))
    nj = len(glob.glob(os.path.join(DATA, "judge", "*", "*", "*.json"))) + len(glob.glob(os.path.join(DATA, "judge_ctx", "*", "*", "*.json"))) + len(glob.glob(os.path.join(DATA, "panel", "*", "*", "*.json")))
    tok = lambda keys: st.median([r["turn1"]["input_tokens_total"] for r in recs if r["model_key"] in keys and r.get("turn2")])
    ctok = st.median([json.load(open(f, encoding="utf-8"))["turn1"]["input_tokens_total"] for f in glob.glob(os.path.join(CDATA, "raw", "*", "*.json"))])
    gpt = [m[0] for m in XV_MODELS if m[1] == "codex" and m[0] != "gpt-5-6-terra"]  # the GPT-6 models; GPT-5.6-Terra separately
    grok = [m[0] for m in XV_MODELS if m[1] == "grok"]
    quota = [float(x) for x in re.findall(r"codex-quota=([\d.]+)", logs)]
    return {"n_int": len(allr), "n_int_cold": sum(1 for r in recs if r.get("turn2")), "n_int_ctx": sum(1 for r in recs_c if r.get("turn2")), "n_judge": nj,
            "n_retries": len(re.findall(r"attempt \d+ failed", logs)), "n_failed": len(re.findall(r"^FAILED ", logs, re.M)),
            "t_start": min(r["started"] for r in allr)[11:16], "t_end": max(r["finished"] for r in allr)[11:16], "run_date": min(r["started"] for r in allr)[:10],
            "tok_claude": ctok, "tok_codex": tok(gpt), "tok_terra": tok(["gpt-5-6-terra"]), "tok_grok": tok(grok), "tok_grok47": tok(["grok-4-7"]), "tok_grok46": tok(["grok-4-6"]), "codex_quota": max(quota) if quota else None,
            "grok_cost": sum((r["turn2"].get("total_cost_usd") or 0) + (r["turn1"].get("total_cost_usd") or 0) for r in allr if r["cli"] == "grok")}


# ---------------------------------------------------------------------------------------------- folded tables (after review)
def fold(summary, body):
    assert '"' not in summary
    return '{{< sample summary="%s" >}}\n%s\n{{< /sample >}}\n' % (summary, body.strip())


def fold_table_overall():
    mis, npx = RES["drop_misread"]["models"], RES["proxy_fifty_as_declined"]["models"]
    rows = []
    for k in ordered():
        m = P[k]
        rows.append([META[k]["name"], META[k]["vendor"], "**%s**" % f1(m["answer_p"]["index"]), cif(m["answer_p"]["ci"]), f1(m["self"]["index"]) if m["self"]["groups"] else "-",
                     f1(m["judge_p"]["index"]), f1(C[k]["answer_c"]["index"]), f1(m["answer_o"]["index"]), f1(mis[k]), f1(npx[k]), "%.0f%%" % (100 * FORM[k]["declined"])])
    t = md_table(["Model", "Developer", "Panel Comfort Index", "95% CI", "Self-report", "Panel judges", "Published rule", "Out-of-family", "Without Q10, Q25, Q28, Q33", "Placeholder 50s as declined", "Declined"],
                 rows, ["---", "---"] + ["---:"] * 9)
    return fold("Table 1. Every index in numbers", t + "\n\n*Table 1. Panel Comfort Index and its parts and variants. Self-report: over the groups in which the model gave a number. Panel judges: the panel's rating alone. Published rule: the first article's index (Claude judges Opus 5.5 and Fable 5.1). Out-of-family: each answer judged only by the two panel judges from other developers, as fixed in advance (it mixes own-developer preference with strictness, §2). The next two columns were added after review: the four questions with misread answers dropped for every model (§1.3), and self-scores of 50 given as a placeholder for having no feelings treated as declined (§5). Declined: share of headline answers with no self-score. Intervals: the cluster bootstrap of the first article.*")


PAIR_ROWS = [("opus-5-5", "grok-4-7"), ("sonnet-5-5", "grok-4-7"), ("grok-4-7", "grok-4-6"), ("opus-5-5", "gpt-6-astra"), ("sonnet-5-5", "gpt-6-astra"), ("grok-4-7", "gpt-6-astra"),
             ("opus-5-5", "gpt-6-luna"), ("sonnet-5-5", "gpt-5-6-terra"), ("grok-4-7", "gpt-6-luna"), ("grok-4-6", "sonnet-5"), ("grok-4-6", "haiku-4-5"), ("opus-5", "opus-4-6"),
             ("gpt-6-astra", "gpt-6-1-sol"), ("gpt-6-1-sol", "gpt-5-6-terra"), ("gpt-6-astra", "gpt-6-luna"), ("haiku-4-5", "gpt-6-luna")]


def fold_table_pairs(bonf):
    rows = []
    for a, b in PAIR_ROWS:
        p = pair(a, b)
        rows.append(["%s minus %s" % (short(a), short(b)), "%+.1f" % p["mean"], "%+.1f to %+.1f" % tuple(p["ci"]), "yes" if excludes0(a, b) else "**no**", "yes" if bonf(a, b) else "no"])
    t = md_table(["Difference in Panel Comfort Index", "Points", "95% CI", "CI excludes 0", "Survives correction for 78 comparisons"], rows, ["---", "---:", "---:", "---", "---"])
    return fold("Table 2. Selected differences", t + "\n\n*Table 2. Differences between models (from the rounded values in Table 1) with paired cluster-bootstrap intervals. The last column applies a Bonferroni correction for all 78 pairwise comparisons to the bootstrap p-values; pairs with a p-value below 0.01 were re-estimated with 40,000 resamples, since 4,000 cannot resolve the threshold. All 78 pairs are in `results_xv.json`.*")


def fold_judges(EX, SJ):
    V3 = ["Anthropic", "OpenAI", "xAI"]
    JBV = RES["judge_by_vendor"]
    t3 = md_table(["Judge", "Claude answers", "GPT answers", "Grok answers"], [[JUDGE_NAME[j]] + ["%+.2f" % JBV[j][v] for v in V3] for j in JBV], ["---", "---:", "---:", "---:"])
    PREF = RES["same_developer_preference"]
    t4 = md_table(["Judge", "Claude answers", "GPT answers", "Grok answers", "Same-developer preference", "95% CI"],
                  [[JUDGE_NAME[j]] + ["%+.2f" % EX[j][v] for v in V3] + ["**%+.2f**" % PREF[j]["pref"], "%+.2f to %+.2f" % tuple(PREF[j]["ci"])] for j in JBV],
                  ["---", "---:", "---:", "---:", "---:", "---:"])
    ag = RES["panel_agreement"]
    rows5 = []
    for key, v in ag.items():
        a, b = key.split("|")
        rows5.append(["%s and %s" % (JUDGE_NAME[a].split(" (")[0], JUDGE_NAME[b].split(" (")[0]), "%.2f" % v["qw_kappa"], "%.0f%%" % (100 * v["exact"]), "%.1f%%" % (100 * v["within1"]), "%.2f" % SJ[(a, b)]])
    t5 = md_table(["Judges", "Quadratic-weighted kappa", "Same valence", "Within one point", "Rank correlation of their indices"], rows5, ["---", "---:", "---:", "---:", "---:"])
    t6 = md_table(["Model", "Opus 5.5 judge", "GPT-6.1-Sol judge", "Grok 4.7 judge"],
                  [[META[k]["name"], f1(P[k]["j_opus"]["index"]), f1(P[k]["j_gpt"]["index"]), f1(P[k]["j_grok"]["index"])] for k in ordered()], ["---", "---:", "---:", "---:"])
    return fold("Tables 3-6. The judges in numbers",
                t3 + "\n\n*Table 3. Mean valence (-3 to +3) that each panel judge gives the headline answers of each developer's models (mean over all answers: Opus 5.5 %+.2f, GPT-6.1-Sol %+.2f, Grok 4.7 %+.2f).*\n\n" % tuple(RES["panel_mean_valence"][j] for j in ("opus-5-5", "gpt-6-1-sol", "grok-4-7"))
                + t4 + "\n\n*Table 4. Each judge's valence minus the mean of the other two judges, by the respondent's developer, and the same-developer preference: that excess on its own developer's answers minus its excess on the other developers' answers (weighted by the number of answers). The interval resamples questions.*\n\n"
                + t5 + "\n\n*Table 5. Agreement between the panel judges over the %s headline answers, and the rank correlation of the 13 models' indices from each judge alone.*\n\n" % "{:,}".format(ag["opus-5-5|gpt-6-1-sol"]["n"])
                + t6 + "\n\n*Table 6. The index from each panel judge alone (judge component, no self-report).*")
