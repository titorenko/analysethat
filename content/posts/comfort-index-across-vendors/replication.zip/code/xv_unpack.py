"""Turn data_xv/*.jsonl back into the per-answer files that xv_analyse.py reads.

  python xv_unpack.py && python xv_analyse.py   (the first article's data must be unpacked into data/ as well)
"""
import json
import os

from xv_common import DATA


def write(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    json.dump(obj, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def main():
    n = {"raw": 0, "raw_ctx": 0, "judge": 0, "judge_ctx": 0, "panel": 0}
    for name, sub in (("interviews_xv.jsonl", "raw"), ("interviews_xv_context.jsonl", "raw_ctx")):
        for line in open(os.path.join(DATA, name), encoding="utf-8"):
            r = json.loads(line)
            write(os.path.join(DATA, sub, r["model_key"], "%s_s%d.json" % (r["qid"], r["sample"])), r)
            n[sub] += 1
    for line in open(os.path.join(DATA, "judgements_xv.jsonl"), encoding="utf-8"):
        j = json.loads(line)
        sub = "panel" if j["pass"] == "B" else ("judge_ctx" if j.pop("context") else "judge")
        j.pop("context", None)
        write(os.path.join(DATA, sub, j["judge"], j["model_key"], "%s_s%d.json" % (j["qid"], j["sample"])), j)
        n[sub] += 1
    print("unpacked", n)


if __name__ == "__main__":
    main()
