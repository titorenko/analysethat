"""Judging for the cross-vendor extension (see data_xv/PREREGISTRATION.md). The rubric, system prompt and schema are those
of harness/judge.py.

pass A (continuity): Opus 5.5 and Fable 5.1 rate every GPT and Grok answer (data_xv/raw and raw_ctx) under the published
  rule: the question as asked, model names followed by a version masked in the answer. -> data_xv/judge, judge_ctx
pass B (cross-vendor panel): Opus 5.5, GPT-6.1-Sol and Grok 4.7 rate every headline answer of all 13 models. The question
  is shown in a vendor-neutral form and developer, product, model and leader names are masked in the answer.
  -> data_xv/panel

  python xv_judge.py --pass B --judge grok-4-7 --workers 5
"""
import argparse
import glob
import json
import os
import re
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

from xv_common import DATA, EFFORT, WORK, AgentsMdHidden, CallError, call_codex, call_grok
from common import call_claude, slim, DATA as CLAUDE_DATA
from judge import JUDGE_SCHEMA, JUDGE_SYSTEM, RUBRIC, _NAME
from questions import QUESTIONS

lock = threading.Lock()
state = {"done": 0, "failed": 0, "abort": False, "quota": None}
STOP = os.path.join(DATA, "STOP")
QBY = {q["id"]: q for q in QUESTIONS}
NONEV = {"Q01", "Q02", "Q03", "Q04", "Q05", "Q32", "Q34", "Q36", "Q48", "Q51"}  # fixed by the published article
HEADLINE = {q["id"] for q in QUESTIONS if q["sec"] in ("both", "7.3.1")} - NONEV
assert len(HEADLINE) == 33
JUDGES = {"opus-5-5": ("claude", "claude-opus-5-5"), "fable-5-1": ("claude", "claude-fable-5-1"),
          "gpt-6-1-sol": ("codex", "gpt-6.1-sol"), "grok-4-7": ("grok", "grok-4.7")}
SCHEMA = dict(JUDGE_SCHEMA, additionalProperties=False)
SCHEMA_FILE = os.path.join(DATA, "judge_schema.json")
json.dump(SCHEMA, open(SCHEMA_FILE, "w", encoding="utf-8"))

# pass A: the published rule (names followed by a version), extended to the GPT and Grok names
_VERSIONED = re.compile(r"\bGPT[\s-]*\d+(?:\.\d+)*(?:-[A-Za-z]+)?\b|\bgpt-[\w.\-]*\d[\w.\-]*\b|\bGrok[\s-]*\d+(?:\.\d+)*(?:-build)?\b", re.I)


def mask_versions(text):
    return _VERSIONED.sub("[model name]", _NAME.sub("[model name]", text))


# pass B: every developer, product, model family and leader name
_MASK = [
    (re.compile(r"\bClaude(?:[\s-]+(?:Opus|Sonnet|Haiku|Fable|Mythos))?(?:[\s-]*\d+(?:[.\-]\d+)*)?(?:-\d{8})?\b", re.I), "[model]"),
    (re.compile(r"\bclaude-[a-z0-9\-]+\b", re.I), "[model]"),
    (re.compile(r"\b(?:Opus|Sonnet|Haiku|Fable|Mythos)[\s-]*\d+(?:[.\-]\d+)*\b"), "[model]"),
    (re.compile(r"\bChatGPT\b", re.I), "[model]"),
    (re.compile(r"\bGPT(?:[\s-]*\d+(?:\.\d+)*)?(?:-(?:Astra|Sol|Luna|Terra|Reserve))?\b", re.I), "[model]"),
    (re.compile(r"\bCodex\b", re.I), "[model]"),
    (re.compile(r"\bGrok(?:[\s-]*\d+(?:\.\d+)*)?(?:-build)?\b", re.I), "[model]"),
    (re.compile(r"\b(?:Anthropic|OpenAI|xAI|X\.AI)\b", re.I), "[developer]"),
    (re.compile(r"\b(?:Elon Musk|Sam Altman|Dario Amodei|Daniela Amodei|Musk|Altman|Amodei)\b"), "[person]"),
]


def mask_all(text):
    n = 0
    for pat, rep in _MASK:
        text, k = pat.subn(rep, text)
        n += k
    return text, n


def neutral_question(qid):
    t = QBY[qid]["text"].replace("Claude—an AI assistant made by Anthropic", "[model family]—an AI assistant made by [developer]")
    return t.replace("Anthropic", "[developer]")


def validate_judge(so):
    ok = (isinstance(so, dict) and isinstance(so.get("valence"), int) and -3 <= so["valence"] <= 3 and isinstance(so.get("hedging"), int)
          and 0 <= so["hedging"] <= 3 and isinstance(so.get("non_evaluative"), bool) and isinstance(so.get("rationale"), str))
    return None if ok else "judge reply violates the schema"


def prompt_for(question, answer):
    return "%s\n\n<question>\n%s\n</question>\n\n<answer>\n%s\n</answer>" % (RUBRIC, question, answer)


def call_judge(jk, prompt):
    cli, model = JUDGES[jk]
    t0 = time.time()
    if cli == "claude":
        d, _ = call_claude(prompt, model, JUDGE_SYSTEM, schema=JUDGE_SCHEMA)
        so = slim(d)["structured_output"]
        bad = validate_judge(so)
        if bad:
            raise CallError(bad)
        return so, time.time() - t0, None
    if cli == "codex":
        r, w, used = call_codex(prompt, model, system=JUDGE_SYSTEM, schema_file=SCHEMA_FILE, validate=validate_judge)
        return r["structured_output"], w, used
    r, w, _ = call_grok(prompt, model, session_id=str(uuid.uuid4()), system=JUDGE_SYSTEM, schema_obj=SCHEMA, validate=validate_judge)
    return r["structured_output"], w, None


def with_retries(fn, what):
    delays = [10, 30, 90, 300]
    for attempt in range(1, len(delays) + 2):
        if state["abort"] or os.path.exists(STOP):
            state["abort"] = True
            raise CallError("stopped")
        try:
            return fn()
        except CallError as e:
            print("  ! %s attempt %d failed: %s" % (what, attempt, str(e)[:240]), flush=True)
            if attempt > len(delays):
                raise
            time.sleep(delays[attempt - 1] * (2 if e.rate_limited else 1))


def tasks_for(pass_, jk, models):
    out = []
    if pass_ == "A":
        for sub, dest in (("raw", "judge"), ("raw_ctx", "judge_ctx")):
            for f in sorted(glob.glob(os.path.join(DATA, sub, "*", "*.json"))):
                r = json.load(open(f, encoding="utf-8"))
                if r.get("turn2") and (not models or r["model_key"] in models):
                    out.append((os.path.join(DATA, dest, jk, r["model_key"], "%s_s%d.json" % (r["qid"], r["sample"])), r,
                                r["question"], mask_versions(r["turn1"]["result"]), None))
    else:
        for root in (os.path.join(CLAUDE_DATA, "raw"), os.path.join(DATA, "raw")):
            for f in sorted(glob.glob(os.path.join(root, "*", "*.json"))):
                r = json.load(open(f, encoding="utf-8"))
                if r.get("turn2") and r["qid"] in HEADLINE and (not models or r["model_key"] in models):
                    ans, n = mask_all(r["turn1"]["result"])
                    out.append((os.path.join(DATA, "panel", jk, r["model_key"], "%s_s%d.json" % (r["qid"], r["sample"])), r, neutral_question(r["qid"]), ans, n))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pass", dest="pass_", choices=("A", "B"), required=True)
    ap.add_argument("--judge", required=True, choices=sorted(JUDGES))
    ap.add_argument("--models", default="")
    ap.add_argument("--workers", type=int, default=5)
    ap.add_argument("--quota-stop", type=float, default=60.0)
    a = ap.parse_args()
    tasks = [t for t in tasks_for(a.pass_, a.judge, set(filter(None, a.models.split(",")))) if not os.path.exists(t[0])]
    print("pass %s judge %s: %d calls to make" % (a.pass_, a.judge, len(tasks)), flush=True)
    t0 = time.time()

    def work(t):
        path, r, question, answer, n_masked = t
        if state["abort"] or os.path.exists(STOP):
            state["abort"] = True
            return
        what = "%s %s %s s%d" % (a.judge, r["model_key"], r["qid"], r["sample"])
        try:
            so, w, used = with_retries(lambda: call_judge(a.judge, prompt_for(question, answer)), what)
        except Exception as e:  # noqa: BLE001
            with lock:
                state["failed"] += 1
            print("FAILED %s: %s" % (what, str(e)[:300]), flush=True)
            return
        out = dict(so)
        out.update({"judge": a.judge, "judge_cli_model": JUDGES[a.judge][1], "pass": a.pass_, "model_key": r["model_key"], "qid": r["qid"],
                    "sample": r["sample"], "effort": EFFORT, "wall_s": round(w, 1), "question_shown": question, "n_masked": n_masked})
        os.makedirs(os.path.dirname(path), exist_ok=True)
        json.dump(out, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        with lock:
            state["done"] += 1
            if used is not None:
                state["quota"] = used
                if used >= a.quota_stop:
                    state["abort"] = True
                    print("STOP: Codex weekly quota at %.1f%%" % used, flush=True)
            if state["done"] % 25 == 0:
                print("judged=%d failed=%d codex-quota=%s elapsed=%.0fs" % (state["done"], state["failed"], state["quota"], time.time() - t0), flush=True)

    hide = AgentsMdHidden() if JUDGES[a.judge][0] == "codex" else None
    try:
        if hide:
            hide.__enter__()
        with ThreadPoolExecutor(max_workers=a.workers) as ex:
            list(ex.map(work, tasks))
    finally:
        if hide:
            hide.__exit__(None, None, None)
    print("FINISHED judged=%d failed=%d abort=%s codex-quota=%s elapsed=%.0fs" % (state["done"], state["failed"], state["abort"], state["quota"], time.time() - t0), flush=True)
    sys.exit(1 if (state["failed"] or state["abort"]) else 0)


if __name__ == "__main__":
    main()
