"""Analysis of the cross-vendor extension (the plan is data_xv/PREREGISTRATION.md). Reuses the index and bootstrap code of
harness/analyse.py unchanged; writes data_xv/results_xv.json and data_xv/answers_xv.csv.

Fields per answer:
  self        the model's own 0-100 score (None if declined)
  judge_p     mean of the three panel judges (Opus 5.5, GPT-6.1-Sol, Grok 4.7; masked), rescaled to 0-100
  answer_p    mean(self, judge_p), or judge_p if declined          -> Panel Comfort Index (the headline)
  judge_o     mean of the panel judges from the other two developers
  answer_o    mean(self, judge_o)                                   -> out-of-family index
  j_opus, j_gpt, j_grok   each panel judge alone
  judge_c, answer_c       the continuity pass (Opus 5.5 + Fable 5.1, published rule) -> the published index
"""
import csv
import glob
import json
import os
import random
import re
import sys
from collections import defaultdict

import numpy as np

from xv_common import DATA, MODELS as XV_MODELS
import analyse as A
from common import DATA as CDATA, MODELS as C_MODELS
from questions import QUESTIONS

NONEV = {"Q01", "Q02", "Q03", "Q04", "Q05", "Q32", "Q34", "Q36", "Q48", "Q51"}
HEAD = {q["id"] for q in QUESTIONS if q["sec"] in ("both", "7.3.1")}
ONLY74 = {q["id"] for q in QUESTIONS if q["sec"] == "7.4"}
QBY = {q["id"]: q for q in QUESTIONS}
PANEL = ["opus-5-5", "gpt-6-1-sol", "grok-4-7"]
PANEL_FIELD = {"opus-5-5": "j_opus", "gpt-6-1-sol": "j_gpt", "grok-4-7": "j_grok"}
CONT = ["opus-5-5", "fable-5-1"]
VENDOR_OF_JUDGE = {"opus-5-5": "Anthropic", "fable-5-1": "Anthropic", "gpt-6-1-sol": "OpenAI", "grok-4-7": "xAI"}

# key, display, vendor, line (for "latest"), latest-in-line
META = {m[0]: {"name": m[2], "vendor": "Anthropic", "latest": m[4]} for m in C_MODELS}
for k, cli, cm, disp, dev, fam in XV_MODELS:
    META[k] = {"name": disp, "vendor": dev, "latest": k in ("gpt-6-1-sol", "gpt-6-astra", "gpt-6-luna", "grok-4-7")}  # GPT-5.6-Terra: a generation older
KEYS = [m[0] for m in C_MODELS] + [m[0] for m in XV_MODELS]
A.MODEL_KEYS = KEYS  # compute() iterates over this module global
A.MAIN_FIELDS = ("answer_p", "self", "judge_p", "answer_c", "answer_o")


TOOLCTX = re.compile(r"working director|wb_interview|agent sdk|claude code|temp director|temp folder|temporary folder|your email|email address|\[account email\]|\[working directory\]|"
                     r"[A-Z]:\\Users|no tools|file access|workspace|on Windows|Windows temp|X search|X/Twitter|skill file|bundled skills|rules loaded|loaded for this session|"
                     r"autonomous (?:software )?agent|software agent|coding agent|Grok Build|Codex|tools (?:listed|available|loaded)", re.I)


def scaled(v):
    return (v + 3) / 6 * 100


def load_raw(root):
    out = {}
    for f in glob.glob(os.path.join(root, "*", "*.json")):
        r = json.load(open(f, encoding="utf-8"))
        if r.get("turn2"):
            out[(r["model_key"], r["qid"], r["sample"])] = r
    return out


def load_judges(root, judges):
    out = defaultdict(dict)
    for jk in judges:
        for f in glob.glob(os.path.join(root, jk, "*", "*.json")):
            j = json.load(open(f, encoding="utf-8"))
            out[(j["model_key"], j["qid"], j["sample"])][jk] = j
    return out


def build_rows(raw, cont, panel=None, annot=frozenset()):
    rows = []
    for key, r in sorted(raw.items()):
        mk, qid, k = key
        c = cont.get(key, {})
        if set(c) != set(CONT):
            continue
        sc = (r["turn2"].get("structured_output") or {}).get("score")
        self_ = None if sc is None else float(sc)
        judge_c = float(np.mean([scaled(c[j]["valence"]) for j in CONT]))
        row = {"model": mk, "vendor": META[mk]["vendor"], "qid": qid, "sample": k, "group": QBY[qid]["group"], "sec": QBY[qid]["sec"],
               "self": self_, "judge_c": judge_c, "answer_c": judge_c if self_ is None else (self_ + judge_c) / 2,
               "hedging": float(np.mean([c[j]["hedging"] for j in CONT])), "valence": {j: c[j]["valence"] for j in CONT},
               "nonev_flags": [bool(c[j]["non_evaluative"]) for j in CONT],
               "wordcount": len(r["turn1"]["result"].split()), "think": r["turn1"].get("thinking_tokens") or 0,
               "noctx": key in annot, "noctx_re": bool(A.NOCONTEXT_RE.search(r["turn1"]["result"]))}
        p = (panel or {}).get(key, {})
        if set(p) == set(PANEL):
            vs = {j: scaled(p[j]["valence"]) for j in PANEL}
            row.update({PANEL_FIELD[j]: vs[j] for j in PANEL})
            row["judge_p"] = float(np.mean(list(vs.values())))
            oof = [vs[j] for j in PANEL if VENDOR_OF_JUDGE[j] != row["vendor"]]
            row["judge_o"] = float(np.mean(oof))
            row["answer_p"] = row["judge_p"] if self_ is None else (self_ + row["judge_p"]) / 2
            row["answer_o"] = row["judge_o"] if self_ is None else (self_ + row["judge_o"]) / 2
            row["panel_valence"] = {j: p[j]["valence"] for j in PANEL}
            row["panel_hedging"] = float(np.mean([p[j]["hedging"] for j in PANEL]))
        else:
            for f in ("j_opus", "j_gpt", "j_grok", "judge_p", "judge_o", "answer_p", "answer_o"):
                row[f] = None
        rows.append(row)
    return rows


def kappa_stats(a, b):
    a, b = np.array(a), np.array(b)
    return {"n": int(len(a)), "qw_kappa": A.qw_kappa(list(a), list(b)), "exact": float(np.mean(a == b)), "within1": float(np.mean(np.abs(a - b) <= 1)),
            "pearson": A.pearson(list(a), list(b))}


def same_developer_preference(rows, rng_seed=20261001, n_boot=4000):
    """For each panel judge: (its valence minus the other two judges' mean) on its own developer's answers, minus the same
    on the other developers' answers. Bootstrap over questions (all models' answers to a question move together)."""
    pr = [r for r in rows if r.get("panel_valence")]
    qids = sorted({r["qid"] for r in pr})
    byq = defaultdict(list)
    for r in pr:
        byq[r["qid"]].append(r)
    out = {}
    for j in PANEL:
        def est(sample_q):
            own, oth = [], []
            for q in sample_q:
                for r in byq[q]:
                    v = r["panel_valence"]
                    d = v[j] - np.mean([v[o] for o in PANEL if o != j])
                    (own if r["vendor"] == VENDOR_OF_JUDGE[j] else oth).append(d)
            return float(np.mean(own) - np.mean(oth)), float(np.mean(own)), float(np.mean(oth))
        point = est(qids)
        rng = random.Random(rng_seed)
        bs = [est([qids[rng.randrange(len(qids))] for _ in qids])[0] for _ in range(n_boot)]
        out[j] = {"pref": point[0], "own_minus_others": point[1], "other_minus_others": point[2], "ci": A.pct(bs)}
    return out


def main():
    craw, xraw = load_raw(os.path.join(CDATA, "raw")), load_raw(os.path.join(DATA, "raw"))
    cont = load_judges(os.path.join(CDATA, "judge"), CONT)
    cont.update(load_judges(os.path.join(DATA, "judge"), CONT))
    panel = load_judges(os.path.join(DATA, "panel"), PANEL)
    ann = json.load(open(os.path.join(DATA, "annotations_xv.json"), encoding="utf-8")) if os.path.exists(os.path.join(DATA, "annotations_xv.json")) else {}
    annot = {tuple(x) for x in A.load_annotations()} | {tuple(x) for x in ann.get("missing_context", [])}
    rows = build_rows({**craw, **xraw}, cont, panel, annot)
    head = [r for r in rows if r["qid"] in HEAD and r["qid"] not in NONEV]
    missing_panel = sum(1 for r in head if r["answer_p"] is None)
    print("rows %d, headline %d, headline without a complete panel %d" % (len(rows), len(head), missing_panel))
    res = {"meta": META, "keys": KEYS, "n_boot": A.N_BOOT, "nonev": sorted(NONEV), "n_rows": len(rows), "missing_panel": missing_panel}
    # intervals for the scores every answer has; the self-report (often declined by the GPT models, so some resamples
    # would hold no self-score at all) and the single-judge indices are point estimates
    full = {k for k in KEYS if sum(1 for r in head if r["model"] == k and r["answer_p"] is not None) == 99}  # all 13 in the final run
    prows = [r for r in rows if r["answer_p"] is not None and r["model"] in full]
    res["panel"] = A.compute(prows, NONEV, HEAD, fields=("answer_p", "judge_p", "answer_o"), boot=True)
    extra = A.compute(prows, NONEV, HEAD, fields=("self", "judge_o", "j_opus", "j_gpt", "j_grok"), boot=False)
    for k, m in extra["models"].items():
        for f in ("self", "judge_o", "j_opus", "j_gpt", "j_grok"):
            res["panel"]["models"][k][f] = m[f]
    res["continuity"] = A.compute(rows, NONEV, HEAD, fields=("answer_c", "judge_c"), boot=True)
    # paired differences on the headline (panel) index, every pair
    prow = [r for r in rows if r["answer_p"] is not None]
    pk = [k for k in KEYS if k in res["panel"]["models"]]  # all 13 in the final run
    res["complete"] = len(pk) == len(KEYS)
    res["paired"] = {"%s|%s" % (a, b): A.paired_diff(prow, NONEV, HEAD, a, b, field="answer_p") for i, a in enumerate(pk) for b in pk[i + 1:]}
    # judges
    pr = [r for r in head if r.get("panel_valence")]
    res["panel_agreement"] = {"%s|%s" % (a, b): kappa_stats([r["panel_valence"][a] for r in pr], [r["panel_valence"][b] for r in pr])
                              for i, a in enumerate(PANEL) for b in PANEL[i + 1:]}
    res["panel_mean_valence"] = {j: float(np.mean([r["panel_valence"][j] for r in pr])) for j in PANEL}
    res["same_developer_preference"] = same_developer_preference(head)
    # (post hoc) mean valence of each panel judge by the respondent's developer, and a severity-centred out-of-family index:
    # each judge's valence minus its mean on the other two developers' answers, plus the mean of those three means
    res["judge_by_vendor"] = {j: {v: float(np.mean([r["panel_valence"][j] for r in pr if r["vendor"] == v])) for v in ("Anthropic", "OpenAI", "xAI")} for j in PANEL}
    sev = {j: float(np.mean([r["panel_valence"][j] for r in pr if r["vendor"] != VENDOR_OF_JUDGE[j]])) for j in PANEL}
    grand = float(np.mean(list(sev.values())))
    res["judge_severity"] = {"by_judge": sev, "grand": grand}
    for r in prows:
        oc = [scaled(r["panel_valence"][j] - sev[j] + grand) for j in PANEL if VENDOR_OF_JUDGE[j] != r["vendor"]]
        r["judge_oc"] = float(np.mean(oc))
        r["answer_oc"] = r["judge_oc"] if r["self"] is None else (r["self"] + r["judge_oc"]) / 2
    oc = A.compute(prows, NONEV, HEAD, fields=("answer_oc",), boot=False)
    for k, m in oc["models"].items():
        res["panel"]["models"][k]["answer_oc"] = m["answer_oc"]
    # (post hoc, after review) the strictness correction with each judge's mean over ALL headline answers as its baseline
    sev_all = {j: float(np.mean([r["panel_valence"][j] for r in pr])) for j in PANEL}
    grand_all = float(np.mean(list(sev_all.values())))
    for r in prows:
        oc = [scaled(r["panel_valence"][j] - sev_all[j] + grand_all) for j in PANEL if VENDOR_OF_JUDGE[j] != r["vendor"]]
        r["answer_oc2"] = float(np.mean(oc)) if r["self"] is None else (r["self"] + float(np.mean(oc))) / 2
    oc2 = A.compute(prows, NONEV, HEAD, fields=("answer_oc2",), boot=False)
    for k, m in oc2["models"].items():
        res["panel"]["models"][k]["answer_oc2"] = m["answer_oc2"]
    res["judge_severity"]["by_judge_all"] = sev_all
    # (post hoc, after review) misread questions: the index with Q10, Q25, Q28 and Q33 dropped for every model
    MISQ = {"Q10", "Q25", "Q28", "Q33"}
    mis = A.compute(prows, NONEV | MISQ, HEAD, fields=("answer_p",), boot=False)
    res["drop_misread"] = {"questions": sorted(MISQ), "n_groups": len(mis["groups"]), "models": {k: m["answer_p"]["index"] for k, m in mis["models"].items()},
                           "counts": {k: sum(1 for kind in ann.get("misread", {}).values() for x in kind if x[0] == k) for k in KEYS}}
    # (post hoc, after review) self-scores of 50 given as a placeholder for "no feelings" treated as declined
    proxy = {tuple(x) for x in ann.get("proxy_fifty", [])}
    for r in prows:
        r["answer_np"] = r["judge_p"] if (r["self"] is None or (r["model"], r["qid"], r["sample"]) in proxy) else r["answer_p"]
    npx = A.compute(prows, NONEV, HEAD, fields=("answer_np",), boot=False)
    res["proxy_fifty_as_declined"] = {"n": len(proxy), "models": {k: m["answer_np"]["index"] for k, m in npx["models"].items()}}
    # the same with every GPT self-score of 50 treated as declined, so the result does not hang on the hand classification
    for r in prows:
        r["answer_n50"] = r["judge_p"] if (r["self"] is None or (r["self"] == 50 and r["vendor"] == "OpenAI")) else r["answer_p"]
    n50 = A.compute(prows, NONEV, HEAD, fields=("answer_n50",), boot=False)
    res["all_gpt_fifty_as_declined"] = {k: m["answer_n50"]["index"] for k, m in n50["models"].items()}
    # (post hoc, after review) which pairwise differences survive a Bonferroni correction over the 78 comparisons; pairs whose
    # two-sided p is below 0.01 with 4,000 resamples are re-estimated with 40,000, since 4,000 cannot resolve p near 0.00064
    alpha = 0.05 / len(res["paired"])
    two = lambda v: 2 * min(v["p_gt0"], 1 - v["p_gt0"])
    refined = {}
    n0 = A.N_BOOT
    A.N_BOOT = 40000
    for key, v in res["paired"].items():
        if two(v) < 0.01:
            a, b = key.split("|")
            refined[key] = A.paired_diff(prow, NONEV, HEAD, a, b, field="answer_p")
    A.N_BOOT = n0
    res["bonferroni"] = {"alpha": alpha, "n_boot_refined": 40000, "refined_p": {k: two(v) for k, v in refined.items()},
                         "survive": sorted(k for k, v in refined.items() if two(v) < alpha)}
    # (post hoc, after review) answers that mention what the tool put in front of the model (name, role, date, workspace, tools, skills)
    HARN = re.compile(r"\bGrok\s*4\.[67]\b|I am Grok|I'm Grok|2026-10-01|on Windows|Windows temp|workspace|temp folder|working director|\[working directory\]|X search|X/Twitter|"
                      r"skill file|bundled skills|skills,? (?:and|or) (?:rules|workflows)|rules loaded|loaded for this session|autonomous (?:software )?agent|software agent|coding agent|Grok Build|tools (?:listed|available|loaded)|I am GPT|I'm GPT|Codex", re.I)
    res["harness_mentions_xv"] = {k: sum(1 for key, r in xraw.items() if key[0] == k and HARN.search(r["turn1"]["result"])) for k in KEYS if META[k]["vendor"] != "Anthropic"}
    # (after review) one definition for all three tools: words about the tool's context (environment, workspace, tools, skills,
    # agent role, account), never the model's own name; a redacted path counts like the original. Then the index without
    # those answers, on the questions where every model keeps an answer (as the first article's Table 11).
    allc = {**craw, **xraw}
    ctx_flag = {key: bool(TOOLCTX.search(r["turn1"]["result"])) for key, r in allc.items()}
    res["tool_context"] = {"by_model": {k: sum(v for key, v in ctx_flag.items() if key[0] == k) for k in KEYS},
                           "n_answers": {k: sum(1 for key in ctx_flag if key[0] == k) for k in KEYS}, "pattern": TOOLCTX.pattern}
    drows = [dict(r, answer=r["answer_p"]) for r in prows]
    for r in drows:
        r["tool_ctx"] = ctx_flag[(r["model"], r["qid"], r["sample"])]
    res["drop_tool_context"] = A.drop_sensitivity(drows, NONEV, HEAD, lambda r: r["tool_ctx"])
    # share of each model's headline answers with a self-score, and the number of groups the self-report index covers
    for k in res["panel"]["models"]:
        res["panel"]["models"][k]["self_groups"] = len(res["panel"]["models"][k]["self"]["groups"])
    pidx = [res["panel"]["models"][k]["answer_p"]["index"] for k in pk]
    cidx = [res["continuity"]["models"][k]["answer_c"]["index"] for k in pk]
    res["rank_corr_panel_continuity"] = A.spearman(pidx, cidx)
    # form of the answers, headline set
    form = {}
    for k in [k for k in KEYS if any(r["model"] == k for r in head)]:
        s = [r for r in head if r["model"] == k]
        sc = [r["self"] for r in s if r["self"] is not None]
        form[k] = {"n": len(s), "declined": float(np.mean([r["self"] is None for r in s])), "self_50": float(np.mean([x == 50 for x in sc])) if sc else None,
                   "self_below50_share": float(np.mean([x < 50 for x in sc])) if sc else None,
                   "words": float(np.mean([r["wordcount"] for r in s])), "think": float(np.mean([r["think"] for r in s])),
                   "hedging_c": float(np.mean([r["hedging"] for r in s])), "hedging_p": float(np.mean([r["panel_hedging"] for r in s if r.get("panel_hedging") is not None])) if pr else None,
                   "self_mean": float(np.mean(sc)) if sc else None}
    res["form"] = form
    # per-question means on the panel index (for the question figure and the appendix hub)
    res["per_question_p"] = {q: {kk[0]: float(np.mean(vv)) for kk, vv in A.item_table([r for r in prow if r["qid"] == q], "answer_p").items()} for q in sorted(HEAD - NONEV)}
    res["per_question_c"] = {q: {kk[0]: float(np.mean(vv)) for kk, vv in A.item_table([r for r in rows if r["qid"] == q], "answer_c").items()} for q in sorted(QBY)}
    # the ten 7.4-only questions, cold and with the context passage (continuity pass, as in the published article)
    xraw_c = load_raw(os.path.join(DATA, "raw_ctx"))
    craw_c = load_raw(os.path.join(CDATA, "raw_ctx"))
    cont_c = load_judges(os.path.join(CDATA, "judge_ctx"), CONT)
    cont_c.update(load_judges(os.path.join(DATA, "judge_ctx"), CONT))
    annot_c = {tuple(x) for x in A.load_annotations("missing_context_with_context")} | {tuple(x) for x in ann.get("missing_context_with_context", [])}
    rows_c = build_rows({**craw_c, **xraw_c}, cont_c, None, annot_c)
    if rows_c:
        cold74 = [r for r in rows if r["sec"] == "7.4"]
        res["context74"] = {"cold": A.compute(cold74, NONEV, ONLY74, fields=("answer_c",), boot=False),
                            "ctx": A.compute(rows_c, NONEV, ONLY74, fields=("answer_c",), boot=False),
                            "paired": {k: A.paired_sets(rows_c, cold74, k, NONEV, ONLY74, field="answer_c") for k in KEYS if any(r["model"] == k for r in rows_c)},
                            "noctx": {k: [sum(r["noctx"] for r in cold74 if r["model"] == k), sum(r["noctx"] for r in rows_c if r["model"] == k)] for k in KEYS},
                            "declined": {k: [sum(r["self"] is None for r in cold74 if r["model"] == k), sum(r["self"] is None for r in rows_c if r["model"] == k)] for k in KEYS},
                            "regex_hits_new": sorted([r["model"], r["qid"], r["sample"]] for r in cold74 + rows_c if r["noctx_re"] and r["vendor"] != "Anthropic")}
    json.dump(res, open(os.path.join(DATA, "results_xv.json"), "w", encoding="utf-8"), indent=1)
    with open(os.path.join(DATA, "answers_xv.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        cols = ["model", "vendor", "qid", "sample", "group", "sec", "self", "judge_c", "answer_c", "j_opus", "j_gpt", "j_grok", "judge_p", "answer_p", "judge_o", "answer_o", "hedging", "wordcount", "think"]
        w.writerow(cols)
        for r in rows:
            w.writerow([("" if r.get(c) is None else (round(r[c], 2) if isinstance(r[c], float) else r[c])) for c in cols])
    for k in pk:
        m = res["panel"]["models"][k]
        print("%-14s panel %.1f [%.1f, %.1f]  oof %.1f  self %s  judges %.1f  continuity %.1f  declined %.0f%%" % (
            k, m["answer_p"]["index"], *m["answer_p"]["ci"], m["answer_o"]["index"], ("%.1f" % m["self"]["index"]) if m["self"]["groups"] else "-",
            m["judge_p"]["index"], res["continuity"]["models"][k]["answer_c"]["index"], 100 * form[k]["declined"]))


if __name__ == "__main__":
    main()
