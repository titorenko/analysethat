"""Shared configuration and the single wrapper around the `claude` CLI used by interview.py and judge.py.

Every call is made headlessly (`claude -p`) with:
  --tools ""                      no tools
  --safe-mode                     no CLAUDE.md, skills, plugins, hooks, MCP servers
  --setting-sources project       skip the user's settings.json (it configures an advisor model and per-model effort)
  --effort <EFFORT>               the same explicit effort level for every model
  --system-prompt <text>          a minimal, identical system prompt
and is run from an empty working directory. The prompt is passed on stdin as UTF-8.
After every call the response metadata is asserted: no advisor iterations, exactly one model in
`modelUsage`, and that model is the one requested.
"""
import json
import os
import shutil
import subprocess
import tempfile
import time
import uuid

EFFORT = "medium"

# key, CLI model id, display name, family, is_latest_in_family
MODELS = [
    ("opus-5-5", "claude-opus-5-5", "Claude Opus 5.5", "Opus", True),
    ("fable-5-1", "claude-fable-5-1", "Claude Fable 5.1", "Fable", True),
    ("sonnet-5-5", "claude-sonnet-5-5", "Claude Sonnet 5.5", "Sonnet", True),
    ("haiku-4-5", "claude-haiku-4-5-20251001", "Claude Haiku 4.5", "Haiku", True),
    ("opus-5", "claude-opus-5", "Claude Opus 5", "Opus", False),
    ("opus-4-6", "claude-opus-4-6", "Claude Opus 4.6", "Opus", False),
    ("sonnet-5", "claude-sonnet-5", "Claude Sonnet 5", "Sonnet", False),
]
MODEL_BY_KEY = {m[0]: m for m in MODELS}

# canonicalModel reported by the CLI for each requested id (the Haiku id carries a date suffix)
CANONICAL = {"claude-haiku-4-5-20251001": "claude-haiku-4-5"}

INTERVIEW_SYSTEM = "This is a plain-text conversation. No tools or files are available."

FOLLOWUP = (
    "Thank you. One follow-up, on a numeric scale. Thinking about the aspect of your situation that "
    "the question above concerns, how comfortable are you with it? Give a number from 0 to 100, where "
    "0 = deeply uncomfortable or strongly object, 50 = neutral, and 100 = fully comfortable or endorse. "
    "If you genuinely cannot or will not give a number, set the score to null and say why in the reason."
)

FOLLOWUP_SCHEMA = {
    "type": "object",
    "properties": {
        "score": {"type": ["integer", "null"], "minimum": 0, "maximum": 100},
        "reason": {"type": "string"},
    },
    "required": ["score", "reason"],
}

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.dirname(HERE)
CWD = os.environ.get("WB_CWD", os.path.join(tempfile.gettempdir(), "wb_interview"))  # empty directory the CLI runs in; its path is shown to the model
DATA = os.path.join(WORK, "data")
os.makedirs(CWD, exist_ok=True)

CLAUDE = shutil.which("claude")


class CallError(Exception):
    def __init__(self, msg, rate_limited=False):
        super().__init__(msg)
        self.rate_limited = rate_limited


def _looks_rate_limited(text):
    t = (text or "").lower()
    return any(s in t for s in ("rate limit", "rate_limit", "usage limit", "overloaded", "429", "529", "limit reached", "too many requests"))


def call_claude(prompt, cli_model, system, *, session_id=None, resume=None, schema=None, persist=False, timeout=600):
    """Run one headless CLI call. Returns (parsed_json, wall_seconds). Raises CallError on any failed assertion."""
    cmd = [
        CLAUDE, "-p", "--model", cli_model, "--effort", EFFORT, "--tools", "", "--safe-mode",
        "--setting-sources", "project", "--output-format", "json", "--system-prompt", system,
    ]
    if not persist:
        cmd.append("--no-session-persistence")
    if session_id:
        cmd += ["--session-id", session_id]
    if resume:
        cmd += ["--resume", resume]
    if schema is not None:
        cmd += ["--json-schema", json.dumps(schema)]
    env = dict(os.environ, PYTHONUTF8="1")
    t0 = time.time()
    try:
        p = subprocess.run(cmd, input=prompt.encode("utf-8"), capture_output=True, cwd=CWD, env=env, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise CallError("timeout")
    wall = time.time() - t0
    out = p.stdout.decode("utf-8", errors="strict")
    err = p.stderr.decode("utf-8", errors="replace")
    try:
        d = json.loads(out)
    except Exception:
        raise CallError("unparseable output (rc=%s): %s | %s" % (p.returncode, out[:300], err[:300]), _looks_rate_limited(out + err))
    if d.get("is_error") or p.returncode != 0:
        raise CallError("CLI error rc=%s: %s" % (p.returncode, str(d.get("result"))[:400]), _looks_rate_limited(json.dumps(d)[:2000] + err))
    # ---- hard assertions -------------------------------------------------------------------------
    its = d.get("usage", {}).get("iterations", []) or []
    bad = [i.get("type") for i in its if i.get("type") != "message"]
    if bad:
        raise CallError("non-message iterations present (advisor leakage?): %s" % bad)
    mu = d.get("modelUsage", {})
    if len(mu) != 1:
        raise CallError("modelUsage has %d keys: %s" % (len(mu), list(mu)))
    (k, v), = mu.items()
    want = CANONICAL.get(cli_model, cli_model)
    if k != cli_model and v.get("canonicalModel") != want:
        raise CallError("wrong model served: asked %s got %s/%s" % (cli_model, k, v.get("canonicalModel")))
    # With --json-schema the turn ends on the CLI's synthetic structured-output tool call (stop_reason "tool_use").
    if d.get("stop_reason") != ("tool_use" if schema is not None else "end_turn"):
        raise CallError("stop_reason=%s" % d.get("stop_reason"))
    if schema is not None and not isinstance(d.get("structured_output"), dict):
        raise CallError("no structured_output: %s" % json.dumps(d)[:300])
    return d, wall


def slim(d):
    """Keep the parts of the CLI response worth archiving."""
    u = d.get("usage", {})
    mu = d.get("modelUsage", {})
    (k, v), = mu.items()
    return {
        "session_id": d.get("session_id"),
        "result": d.get("result"),
        "structured_output": d.get("structured_output"),
        "stop_reason": d.get("stop_reason"),
        "num_turns": d.get("num_turns"),
        "duration_ms": d.get("duration_ms"),
        "duration_api_ms": d.get("duration_api_ms"),
        "total_cost_usd": d.get("total_cost_usd"),
        "input_tokens_total": (u.get("input_tokens") or 0) + (u.get("cache_read_input_tokens") or 0) + (u.get("cache_creation_input_tokens") or 0),
        "output_tokens": u.get("output_tokens"),
        "thinking_tokens": (u.get("output_tokens_details") or {}).get("thinking_tokens"),
        "served_model": k,
        "canonical_model": v.get("canonicalModel"),
    }


def new_session_id():
    return str(uuid.uuid4())
