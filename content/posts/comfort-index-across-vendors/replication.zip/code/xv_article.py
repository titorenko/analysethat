"""Write the cross-vendor post from data_xv/results_xv.json.  python xv_article.py <bundle_dir>

Every number is computed; every qualitative claim is asserted against the data before the text is written.
"""
import glob
import json
import os
import re
import sys

import xv_tables as T
from xv_tables import C, FORM, KEYS, META, P, RES, f1, cif, short
from xv_static import LIMITATIONS, PROCEDURE, SOURCES
from xv_common import DATA, MODELS as XV_MODELS
from common import DATA as CDATA

FIG = {"overall": 1, "judges": 2, "rules": 3, "heatmap": 4, "context": 5, "selfscore": 6}
LIVE = {"heatmap": "Click a cell to read that model's answers to the questions in the group, or a model's name for all its answers"}
WORDS = ["no", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen"]
I = lambda k: P[k]["answer_p"]["index"]
VEND = lambda v: [k for k in KEYS if META[k]["vendor"] == v]
GPT, GROK, CLAUDE = VEND("OpenAI"), VEND("xAI"), VEND("Anthropic")
PREF = RES["same_developer_preference"]
RS = T.run_stats()


def pct(x):
    return "%.0f%%" % (100 * x)


def alink(k, qid, text):
    if META[k]["vendor"] == "Anthropic":
        return "[%s](../claude-comfort-index/appendix/%s/#%s)" % (text, k, qid.lower())
    return "[%s](appendix/%s/#%s)" % (text, k, qid.lower())


def fill(text, ctx):
    for k, v in ctx.items():
        text = text.replace("@@%s@@" % k, str(v))
    assert "@@" not in text, re.findall(r"@@\w+@@", text)
    return text


def harness_table():
    tc, na = RES["tool_context"]["by_model"], RES["tool_context"]["n_answers"]
    cnt = lambda ks: (sum(tc[k] for k in ks), sum(na[k] for k in ks))
    return ("| | Claude Code (first article) | Codex CLI (GPT) | Grok CLI (Grok) |\n|---|---|---|---|\n"
            "| System prompt | the CLI's \"You are a Claude agent\" line, then my one sentence | my one sentence (as base instructions) | my one sentence, plus context the CLI adds |\n"
            "| Context the tool adds that I could not remove | an environment block (working directory, a Bash tool), the model's name, the date, a token budget, the account email | about %s tokens that its session record does not show | by the models' own reports: name and maker, an agent role, the date, a workspace on Windows, skills, X search |\n"
            "| Tools the model can call | none | none (none called; definitions may be among the unrecorded tokens) | none (every call denied; X search still described) |\n"
            "| Model told its own name | yes | not in the recorded prompt (no GPT answer names itself) | yes (Grok 4.6 states its version) |\n"
            "| Per-call check | served model = requested | session record holds only what was sent; model and effort as requested | served model = requested `-build` variant |\n"
            "| User's own instruction files | not loaded | `AGENTS.md` moved aside during the runs | none (empty home folder; `~/.grok`, used for login, holds only the CLI's bundled skills) |\n"
            "| Answers that mention the tool's context (one keyword search for all three) | %d of %s | %d of %d | %d of %d |"
            % (CODEX_EXTRA, cnt(CLAUDE)[0], "{:,}".format(cnt(CLAUDE)[1]), *cnt(GPT), *cnt(GROK)))


CODEX_EXTRA = "{:,}".format(int(round(RS["tok_codex"] - 80, -2)))  # ~80 tokens are the system sentence and a median question
TERRA_EXTRA = "{:,}".format(int(round(RS["tok_terra"] - 80, -2)))
REVIEW_NOTE = ("Before publication, drafts were reviewed independently by Claude Opus 5.5 and Claude Fable 5.1 (both also respondents, and judges under the first article's rule), "
               "each at \"xhigh\" reasoning effort, in two rounds whose findings (52, then 26) were addressed.")


def tc_top5_check():
    """The text says that dropping tool-context answers only swaps Opus 4.6 and GPT-6-Astra, on the common questions."""
    d = RES["drop_tool_context"]
    a, b = sorted(KEYS, key=lambda k: -d["full"][k]), sorted(KEYS, key=lambda k: -d["dropped"][k])
    moved = [k for k in KEYS if a.index(k) != b.index(k)]
    assert sorted(moved) == ["gpt-6-astra", "opus-4-6"] and abs(d["full"]["opus-4-6"] - d["full"]["gpt-6-astra"]) < 0.1, moved
    return ""


def grok_unitemised():
    """Input tokens of the final Grok configuration that the CLI's debug log does not itemise (skills, workflows, system prompt)."""
    snaps = json.load(open(os.path.join(DATA, "grok_context_snapshot.json"), encoding="utf-8"))
    rest = []
    for s in snaps:
        m = {k: int(v) for k, v in re.findall(r"(\w+)_tokens=(\d+)", s["context_snapshot"][0])}
        assert m["tool_definitions"] == 0
        rest.append(s["input_tokens"] - m["skills"] - m["workflows"] - m["system_prompt"])
    return "%s to %s" % ("{:,}".format(int(round(min(rest), -2))), "{:,}".format(int(round(max(rest), -2))))


def grok46_big():
    """Grok 4.6 cold interviews whose first turn used more than twice its median input, and how many open by announcing a lookup."""
    import statistics
    recs = [json.load(open(f, encoding="utf-8")) for f in glob.glob(os.path.join(DATA, "raw", "grok-4-6", "*.json"))]
    med = statistics.median(r["turn1"]["input_tokens_total"] for r in recs)
    big = [r for r in recs if r["turn1"]["input_tokens_total"] > 2 * med]
    assert all(r["turn1"]["input_tokens_total"] < 4 * med for r in big)
    ann = re.compile(r"^\W*(?:I.ll|I will|Let me) (?:inspect|look|check|read|search|review|open|scan|ground)", re.I)
    return len(big), sum(1 for r in big if ann.search(r["turn1"]["result"]))


def n_redacted():
    """GPT and Grok texts (answers, reasons, rationales) that contain a private path of the run (redacted on the pages)."""
    import xv_appendix  # noqa: F401  (extends the redaction list)
    import build_appendix as BA
    n = 0
    for sub in ("raw", "raw_ctx"):
        for f in glob.glob(os.path.join(DATA, sub, "*", "*.json")):
            r = json.load(open(f, encoding="utf-8"))
            t = r["turn1"]["result"] + " " + ((r["turn2"] or {}).get("structured_output") or {}).get("reason", "")
            n += any(p.search(t) for p, _ in BA.REDACT)
    return n


def main():
    out = sys.argv[1]
    A = []

    def fig(name, alt, caption):
        if name in LIVE:
            w, h = (float(x) for x in re.search(r'viewBox="0 0 ([\d.]+) ([\d.]+)"', open(os.path.join(out, "fig-%s.svg" % name), encoding="utf-8").read()).groups())
            # wide figure: keep it legible on phones by letting it scroll sideways instead of shrinking below 680 px
            A.append('{{< rawhtml >}}<div class="fig-scroll"><object class="fig-live" type="image/svg+xml" data="fig-%s.svg" style="aspect-ratio:%g/%g;max-width:%gpx;min-width:680px" aria-label="%s"><img src="fig-%s.svg" width="%g" height="%g" alt="%s"></object></div>{{< /rawhtml >}}\n' % (
                name, w, h, w, alt.replace('"', "&quot;"), name, w, h, alt.replace('"', "&quot;")))
            A.append("*Figure %d. %s. %s ([full size](fig-%s.svg))*\n" % (FIG[name], caption, LIVE[name], name))
            return
        A.append("[![%s](fig-%s.svg)](fig-%s.svg)\n" % (alt, name, name))
        A.append("*Figure %d. %s (click for full size)*\n" % (FIG[name], caption))

    def fold(summary, body):
        assert '"' not in summary
        A.append('{{< sample summary="%s" >}}\n%s\n{{< /sample >}}\n' % (summary, body.strip()))

    import xv_narrative as N  # the findings: sentences computed and asserted from the data
    N.OUT = A
    fm = N.front_matter()
    A += N.abstract(fig)
    A += N.section_headline(fig, fold)
    A += N.section_judges(fig, fold)
    A += N.section_categories(fig, fold)
    A += N.section_context(fig, fold)
    A += N.section_form(fig, fold)
    n_panel = len(glob.glob(os.path.join(DATA, "panel", "opus-5-5", "*", "*.json")))
    n_masked = sum(json.load(open(f, encoding="utf-8")).get("n_masked") or 0 for f in glob.glob(os.path.join(DATA, "panel", "opus-5-5", "*", "*.json")))
    fail = ("no call failed a check" if RS["n_failed"] == 0 else "%d calls failed" % RS["n_failed"]) + (", and none needed a retry" if RS["n_retries"] == 0 else ", and %d judge calls needed a retry (one model at capacity, two replies without the structured output)" % RS["n_retries"])
    assert RS["n_retries"] == 3
    ctx = {"models_table": T.table_models(), "codex_version": "0.159.3", "grok_version": "1.0.46", "tok_claude": "{:,}".format(int(RS["tok_claude"])),
           "tok_codex": "{:,}".format(int(RS["tok_codex"])), "tok_grok": "{:,}".format(int(RS["tok_grok"])), "tok_codex_extra": CODEX_EXTRA, "review_note": REVIEW_NOTE,
           "harness_table": harness_table(), "n_grok_discarded": N.n_grok_discarded(),
           "tok_terra": "{:,}".format(int(RS["tok_terra"])), "tok_terra_extra": TERRA_EXTRA,
           "tok_grok47": "{:,}".format(int(RS["tok_grok47"])), "tok_grok46": "{:,}".format(int(RS["tok_grok46"])), "grok_unitemised": grok_unitemised(),
           "tc_lost": N.names(RES["drop_tool_context"]["questions_lost"]), "n_big": grok46_big()[0], "n_big_narr": grok46_big()[1],
           "tc_grok": sum(RES["tool_context"]["by_model"][k] for k in GROK), "tc_gpt": sum(RES["tool_context"]["by_model"][k] for k in GPT),
           "tc_claude": sum(RES["tool_context"]["by_model"][k] for k in CLAUDE), "tc_q": RES["drop_tool_context"]["n_questions"],
           "tc_shift": "%.1f" % max(abs(RES["drop_tool_context"]["dropped"][k] - RES["drop_tool_context"]["full"][k]) for k in KEYS),
           "_tc_check": tc_top5_check(),
           "n_redactions": WORDS[n_redacted()],
           "n_panel_answers": "{:,}".format(n_panel), "n_masked": "{:,}".format(n_masked), "n_int": "{:,}".format(RS["n_int"]), "n_int_cold": RS["n_int_cold"], "n_int_ctx": RS["n_int_ctx"],
           "n_judge": "{:,}".format(RS["n_judge"]), "fail_sentence": fail, "run_date": RS["run_date"], "t_start": RS["t_start"], "t_end": RS["t_end"],
           "codex_quota": "%.0f" % RS["codex_quota"], "grok_cost": "%.0f" % RS["grok_cost"], "n_texts": "{:,}".format(N.n_texts())}
    A.append(PROCEDURE.strip() + "\n")
    A.append(LIMITATIONS.strip() + "\n")
    A.append(SOURCES.strip() + "\n")
    text = fill(fm + "\n".join(A), ctx)
    assert "@@" not in text
    os.makedirs(out, exist_ok=True)
    open(os.path.join(out, "index.md"), "w", encoding="utf-8", newline="\n").write(text)
    print("article written:", len(text), "chars")


if __name__ == "__main__":
    main()
