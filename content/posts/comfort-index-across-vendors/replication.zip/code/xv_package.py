"""Replication archive of the cross-vendor post.  python xv_package.py <bundle_dir>

Writes replication.zip (code + the GPT and Grok interviews, both judging passes, results) and answers_xv.csv into the
bundle. The Claude answers and their first-article judgements are in the first article's replication.zip.
"""
import glob
import json
import os
import shutil
import sys
import zipfile

from xv_common import DATA, HERE, WORK
import xv_appendix  # noqa: F401  (adds the cross-vendor working directories to the redaction list)
from build_appendix import REDACTION_COUNT, redact

CODE_XV = ["xv_common.py", "xv_interview.py", "xv_judge.py", "xv_analyse.py", "xv_figures.py", "xv_appendix.py", "xv_static.py", "xv_tables.py",
           "xv_narrative.py", "xv_article.py", "xv_package.py", "xv_unpack.py"]
CODE_HARNESS = ["common.py", "questions.py", "interview.py", "judge.py", "analyse.py", "build_appendix.py", "make_figures.py"]

README = """Replication archive for "How Comfortable Are GPT and Grok Models With Their Circumstances?" (cross-vendor follow-up).

data_xv/interviews_xv.jsonl        the GPT and Grok interviews (51 questions x 3 samples x 6 models), both turns
data_xv/interviews_xv_context.jsonl  the ten 7.4-only questions again, with the context passage (data_xv/context_74_xv.txt)
data_xv/judgements_xv.jsonl        every judge rating: "pass": "A" = the first article's rule (Opus 5.5, Fable 5.1) on the
                                  GPT and Grok answers ("context": true for the re-run); "B" = the cross-vendor panel
                                  (Opus 5.5, GPT-6.1-Sol, Grok 4.7) on every headline answer of all 13 models
data_xv/answers_xv.csv            one row per answer of all 13 models with every score
data_xv/results_xv.json           every statistic in the post
data_xv/annotations_xv.json        hand-read lists, each with its rule: answers that say the question's referent is missing
                                  (missing_context, missing_context_with_context; GPT and Grok), misread questions (misread;
                                  all 13 models), and self-scores of 50 given as a placeholder or as a neutral view (proxy_fifty,
                                  neutral_fifty; GPT)
data_xv/recall_probe.json         GPT-6.1-Sol and Grok 4.7 asked to reproduce what precedes the question (both declined)
data_xv/PREREGISTRATION.md        the analysis plan, written after a 30-interview pilot and before any GPT or Grok answer was judged
code/                             the cross-vendor harness and writing pipeline (xv_*.py) and the first article's modules
                                  they import

To recompute results_xv.json you also need the Claude data: unpack the first article's replication.zip
(https://titorenko.github.io/analysethat/posts/claude-comfort-index/replication.zip) into the same folder as this one, so that its
data/raw, data/judge, data/raw_ctx and data/judge_ctx exist (its code/unpack.py creates them), then
  cd code && python xv_unpack.py && python xv_analyse.py
This reproduces results_xv.json exactly except for 5 values, all caused by the redaction: 4 word counts of two Claude
answers that contain the redacted strings (the same cause as the 13 differences noted for the first archive), and
harness_mentions_xv for Grok 4.6 (26 instead of 25), because "[working directory]" in one redacted answer matches
that search; the post does not use this count.
Re-collecting the data needs the Codex and Grok CLIs, logged in; see xv_common.py for every flag and check. Importing
xv_common.py creates a few working folders in the temp directory and writes the system prompt and schema files into data_xv/.
data_xv/grok_context_snapshot.json holds the Grok CLI's own breakdown of the model's context for the final configuration.
Private paths of the machine the runs used are replaced by "[working directory]"; nothing else is altered.
"""


def red(obj):
    if isinstance(obj, str):
        return redact(obj)
    if isinstance(obj, list):
        return [red(x) for x in obj]
    if isinstance(obj, dict):
        return {k: red(v) for k, v in obj.items()}
    return obj


def jsonl(path, recs):
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        for r in recs:
            f.write(json.dumps(red(r), ensure_ascii=False) + "\n")


def load(pattern):
    return [json.load(open(f, encoding="utf-8")) for f in sorted(glob.glob(pattern))]


def main():
    out = sys.argv[1]
    tmp = os.path.join(DATA, "_pkg")
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    ints = [r for r in load(os.path.join(DATA, "raw", "*", "*.json")) if r.get("turn2")]
    ints_c = [r for r in load(os.path.join(DATA, "raw_ctx", "*", "*.json")) if r.get("turn2")]
    jud = [dict(j, context=False) for j in load(os.path.join(DATA, "judge", "*", "*", "*.json"))]
    jud += [dict(j, context=True) for j in load(os.path.join(DATA, "judge_ctx", "*", "*", "*.json"))]
    jud += [dict(j, context=False) for j in load(os.path.join(DATA, "panel", "*", "*", "*.json"))]
    jsonl(os.path.join(tmp, "interviews_xv.jsonl"), ints)
    jsonl(os.path.join(tmp, "interviews_xv_context.jsonl"), ints_c)
    jsonl(os.path.join(tmp, "judgements_xv.jsonl"), jud)
    names = ["interviews_xv.jsonl", "interviews_xv_context.jsonl", "judgements_xv.jsonl"]
    shutil.copy(os.path.join(DATA, "private", "recall_probe.json"), os.path.join(tmp, "recall_probe.json"))
    names.append("recall_probe.json")
    for n in ("answers_xv.csv", "results_xv.json", "annotations_xv.json", "context_74_xv.txt", "PREREGISTRATION.md", "grok_context_snapshot.json"):
        if os.path.exists(os.path.join(DATA, n)):
            shutil.copy(os.path.join(DATA, n), os.path.join(tmp, n))
            names.append(n)
    shutil.copy(os.path.join(DATA, "answers_xv.csv"), os.path.join(out, "answers_xv.csv"))
    zp = os.path.join(out, "replication.zip")
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("README_cross_vendor.txt", README)  # the first article's archive has README.txt
        for n in names:
            z.write(os.path.join(tmp, n), "data_xv/" + n)
        for n in CODE_XV:
            z.write(os.path.join(HERE, n), "code/" + n)
        for n in CODE_HARNESS:
            z.write(os.path.join(WORK, "harness", n), "code/" + n)
    shutil.rmtree(tmp, ignore_errors=True)
    print("interviews %d + %d, judgements %d, redactions %d -> %s (%.1f MB)" % (len(ints), len(ints_c), len(jud), REDACTION_COUNT["n"], zp, os.path.getsize(zp) / 1e6))


if __name__ == "__main__":
    main()
