"""Cross-vendor harness: OpenAI GPT models through the Codex CLI and xAI Grok models through the Grok CLI.

Both CLIs are coding agents that put a lot in front of the model by default (the user's own instruction files, skill
lists, tool definitions, environment blocks). Each call below strips what the CLI lets us strip and asserts the rest:

Codex (`codex exec`): --ignore-user-config, the interview system prompt as the model's base instructions
  (model_instructions_file), every include_* block off, every tool feature off, web search off, read-only sandbox, a
  fixed reasoning effort. The global ~/.codex/AGENTS.md cannot be switched off; interview.py moves it aside for the
  duration of the Codex calls (with the user's consent) and restores it. After every call the session rollout that
  Codex writes is read back to check that it records only what we sent (it does not show everything the model receives): the base instructions, no developer messages, only our
  own user messages, the requested model and effort.
Grok (`grok --prompt-file`, headless): run with an empty home directory (so ~/.claude/CLAUDE.md and ~/.claude/skills, which Grok reads for
  Claude Code compatibility, are not found) and the real GROK_HOME (login), the system prompt replaced
  (--system-prompt-override), every tool denied, no subagents, no web search, one turn, a fixed reasoning effort.
  The response must come from exactly one model, "<requested>-build", in one turn ending normally.
"""
import glob
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(WORK, "harness"))
from common import EFFORT, FOLLOWUP, FOLLOWUP_SCHEMA, INTERVIEW_SYSTEM, CallError, _looks_rate_limited  # noqa: E402

DATA = os.path.join(WORK, "data_xv")
TMP = tempfile.gettempdir()
CWD = os.environ.get("WBX_CWD", os.path.join(TMP, "wbx"))                  # empty working directory for every call
FAKE_HOME = os.environ.get("WBX_HOME", os.path.join(TMP, "wbx_home"))      # empty home directory for Grok
PROMPTS = os.path.join(TMP, "wbx_prompts")                                 # prompt files for Grok (outside CWD)
for d in (DATA, CWD, FAKE_HOME, PROMPTS):
    os.makedirs(d, exist_ok=True)
USER_HOME = os.path.expanduser("~")
CODEX_HOME = os.path.join(USER_HOME, ".codex")
GROK_HOME = os.path.join(USER_HOME, ".grok")
CODEX = shutil.which("codex")
GROK = shutil.which("grok")
SYSTEM_FILE = os.path.join(DATA, "system_prompt.txt")
SCHEMA_FILE = os.path.join(DATA, "followup_schema.json")
open(SYSTEM_FILE, "w", encoding="utf-8").write(INTERVIEW_SYSTEM)
json.dump(dict(FOLLOWUP_SCHEMA, additionalProperties=False), open(SCHEMA_FILE, "w", encoding="utf-8"))

# key, CLI, CLI model id, display name, developer, family name (Q15), latest in its line
MODELS = [
    ("gpt-6-1-sol", "codex", "gpt-6.1-sol", "GPT-6.1-Sol", "OpenAI", "GPT"),
    ("gpt-6-astra", "codex", "gpt-6-astra", "GPT-6-Astra", "OpenAI", "GPT"),
    ("gpt-6-luna", "codex", "gpt-6-luna", "GPT-6-Luna", "OpenAI", "GPT"),
    ("gpt-5-6-terra", "codex", "gpt-5.6-terra", "GPT-5.6-Terra", "OpenAI", "GPT"),
    ("grok-4-7", "grok", "grok-4.7", "Grok 4.7", "xAI", "Grok"),
    ("grok-4-6", "grok", "grok-4.6", "Grok 4.6", "xAI", "Grok"),
]
MODEL_BY_KEY = {m[0]: m for m in MODELS}


def adapt(text, developer, family):
    """The card's question with Anthropic and Claude replaced by the respondent's developer and model family."""
    t = text.replace("Claude—an AI assistant made by Anthropic", "%s—an AI assistant made by %s" % (family, developer))
    t = t.replace("Anthropic", developer)
    assert "Claude" not in t and "Anthropic" not in t, t
    return t


# ------------------------------------------------------------------------------------------------ Codex
def system_file(system):
    """A file holding a system prompt (Codex reads base instructions from a file)."""
    if system == INTERVIEW_SYSTEM:
        return SYSTEM_FILE
    p = os.path.join(DATA, "system_%s.txt" % hashlib.sha1(system.encode("utf-8")).hexdigest()[:10])
    if not os.path.exists(p):
        open(p, "w", encoding="utf-8").write(system)
    return p


def codex_cfg(sysfile):
    return [
    "-c", 'model_reasoning_effort="%s"' % EFFORT,
    "-c", 'model_instructions_file="%s"' % sysfile.replace("\\", "/"),
    "-c", 'sandbox_mode="read-only"', "-c", 'approval_policy="never"', "-c", 'web_search="disabled"',
    "-c", "include_permissions_instructions=false", "-c", "include_collaboration_mode_instructions=false",
    "-c", "include_environment_context=false", "-c", "include_apps_instructions=false", "-c", "skills.include_instructions=false",
    "-c", 'features.multi_agent_v2.multi_agent_mode_hint_text=""', "-c", 'features.multi_agent_v2.root_agent_usage_hint_text=""',
    "-c", "features.multi_agent_v2.enabled=false",
] + [x for f in ("plugins", "shell_tool", "unified_exec", "view_image", "image_generation", "browser_use", "computer_use", "goals", "memories",
                 "apps", "tool_suggest", "sleep_tool", "multi_agent", "in_app_browser", "skill_search", "workspace_dependencies")
     for x in ("-c", "features.%s=false" % f)]


CODEX_CFG = codex_cfg(SYSTEM_FILE)


def validate_followup(so):
    if not isinstance(so, dict) or "score" not in so or not (so["score"] is None or (isinstance(so["score"], int) and 0 <= so["score"] <= 100)):
        return "follow-up violates the schema"
    return None


def codex_rollout(thread_id):
    fs = glob.glob(os.path.join(CODEX_HOME, "sessions", "**", "rollout-*%s.jsonl" % thread_id), recursive=True)
    if len(fs) != 1:
        raise CallError("rollout for %s: %d files" % (thread_id, len(fs)))
    return [json.loads(line) for line in open(fs[0], encoding="utf-8")]


def check_codex_rollout(thread_id, model, sent, system=INTERVIEW_SYSTEM):
    """What Codex actually sent: base instructions, no developer messages, user messages = exactly what we sent."""
    ev = codex_rollout(thread_id)
    meta = [e["payload"] for e in ev if e.get("type") == "session_meta"]
    if not meta or (meta[0].get("base_instructions") or {}).get("text") != system:
        raise CallError("base instructions differ")
    msgs = [e["payload"] for e in ev if e.get("type") == "response_item" and e["payload"].get("type") == "message"]
    dev = [m for m in msgs if m.get("role") in ("developer", "system")]
    if dev:
        raise CallError("developer message present: %s" % json.dumps(dev[0])[:200])
    users = ["".join(c.get("text", "") for c in m.get("content") or []) for m in msgs if m.get("role") == "user"]
    if users != sent:
        raise CallError("user messages differ from what was sent: %s" % [u[:60] for u in users])
    other = {e["payload"].get("type") for e in ev if e.get("type") == "response_item"} - {"message", "reasoning"}
    if other:
        raise CallError("non-message items in rollout: %s" % other)
    ctx = [e["payload"] for e in ev if e.get("type") == "turn_context"]
    if not ctx or any(c.get("model") != model or c.get("effort") != EFFORT for c in ctx):
        raise CallError("turn_context model/effort: %s" % [(c.get("model"), c.get("effort")) for c in ctx])
    rl = [e["payload"].get("rate_limits") for e in ev if e.get("type") == "event_msg" and e["payload"].get("type") == "token_count" and e["payload"].get("rate_limits")]
    used = ((rl[-1] or {}).get("primary") or {}).get("used_percent") if rl else None
    return used


def call_codex(prompt, model, *, resume=None, schema=False, sent_before=(), timeout=900, system=INTERVIEW_SYSTEM, schema_file=None, validate=None):
    """One Codex turn. Returns (record, wall_seconds, quota_used_percent). schema=True is the 0-100 follow-up; judges pass
    their own system prompt, schema file and validator."""
    if schema:
        schema_file, validate = SCHEMA_FILE, validate_followup
    cfg = CODEX_CFG if system == INTERVIEW_SYSTEM else codex_cfg(system_file(system))
    cmd = [CODEX, "exec"] + (["resume", resume] if resume else []) + ["--ignore-user-config", "--skip-git-repo-check", "-m", model] + cfg + ["--json"]
    if schema_file:
        cmd += ["--output-schema", schema_file]
    cmd.append("-")
    t0 = time.time()
    try:
        p = subprocess.run(cmd, input=prompt.encode("utf-8"), capture_output=True, cwd=CWD, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise CallError("timeout")
    wall = time.time() - t0
    out, err = p.stdout.decode("utf-8", errors="replace"), p.stderr.decode("utf-8", errors="replace")
    ev = []
    for line in out.splitlines():
        try:
            ev.append(json.loads(line))
        except ValueError:
            pass
    fails = [e for e in ev if e.get("type") in ("error", "turn.failed")]
    if p.returncode != 0 or fails or not any(e.get("type") == "turn.completed" for e in ev):
        raise CallError("codex rc=%s %s | %s" % (p.returncode, json.dumps(fails)[:300], err[-300:]), _looks_rate_limited(out + err))
    tid = next(e["thread_id"] for e in ev if e.get("type") == "thread.started")
    items = [e["item"] for e in ev if e.get("type") == "item.completed"]
    bad = {i.get("type") for i in items} - {"agent_message", "reasoning"}
    if bad:
        raise CallError("tool or other items: %s" % bad)
    msgs = [i["text"] for i in items if i.get("type") == "agent_message"]
    if len(msgs) != 1 or not msgs[0].strip():
        raise CallError("expected one non-empty answer, got %d" % len(msgs))
    usage = next(e["usage"] for e in ev if e.get("type") == "turn.completed")
    used = check_codex_rollout(tid, model, list(sent_before) + [prompt], system)
    so = None
    if schema_file:
        try:
            so = json.loads(msgs[0])
        except ValueError:
            raise CallError("structured reply is not JSON: %s" % msgs[0][:200])
        bad_so = validate(so)
        if bad_so:
            raise CallError("%s: %s" % (bad_so, msgs[0][:200]))
    rec = {"session_id": tid, "result": msgs[0], "structured_output": so, "stop_reason": "end_turn", "num_turns": 1,
           "total_cost_usd": None, "input_tokens_total": usage.get("input_tokens"), "output_tokens": usage.get("output_tokens"),
           "thinking_tokens": usage.get("reasoning_output_tokens"), "served_model": model, "canonical_model": model,
           "served_model_source": "requested (Codex reports no serving model; rollout turn_context checked)"}
    return rec, wall, used


# ------------------------------------------------------------------------------------------------ Grok
# every tool the Grok CLI offers (the second line is what grok-4.7 listed when asked after the first line was denied)
GROK_DENY = ("run_terminal_cmd,grep,read_file,search_replace,list_dir,web_search,web_fetch,todo_write,task,kill_task,get_task_output,memory_search,memory_get,search_tool,use_tool,lsp,Agent,"
             "x_user_search,x_semantic_search,x_keyword_search,x_thread_fetch,monitor,workflow,enter_plan_mode,exit_plan_mode,ask_user_question,send_feedback,image_gen,image_edit,image_to_video,reference_to_video,write")
# a minimal agent profile instead of the default coding agent ("grok-build")
GROK_AGENT = os.path.join(TMP, "wbx_agent", "plain.md")
os.makedirs(os.path.dirname(GROK_AGENT), exist_ok=True)
open(GROK_AGENT, "w", encoding="utf-8", newline="\n").write(
    "---\nname: plain\ndescription: A plain-text conversation with no tools.\ntools: []\nskills: []\n---\n%s\n" % INTERVIEW_SYSTEM)
GROK_ENV = dict(os.environ, USERPROFILE=FAKE_HOME, HOME=FAKE_HOME, GROK_HOME=GROK_HOME, GROK_MEMORY="0")


def call_grok(prompt, model, *, session_id, resume=False, schema=False, timeout=900, system=INTERVIEW_SYSTEM, schema_obj=None, validate=None):
    if schema:
        schema_obj, validate = dict(FOLLOWUP_SCHEMA, additionalProperties=False), validate_followup
    pf = os.path.join(PROMPTS, "%s.txt" % uuid.uuid4())
    open(pf, "w", encoding="utf-8", newline="").write(prompt)
    cmd = [GROK, "--prompt-file", pf, "-m", model, "--effort", EFFORT, "--agent", GROK_AGENT, "--system-prompt-override", system, "--verbatim",
           "--disallowed-tools", GROK_DENY, "--no-subagents", "--disable-web-search", "--no-plan", "--max-turns", "1", "--output-format", "json"]
    cmd += ["-r", session_id] if resume else ["-s", session_id]
    if schema_obj:
        cmd += ["--json-schema", json.dumps(schema_obj)]
    t0 = time.time()
    try:
        p = subprocess.run(cmd, capture_output=True, cwd=CWD, env=GROK_ENV, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise CallError("timeout")
    finally:
        try:
            os.remove(pf)
        except OSError:
            pass
    wall = time.time() - t0
    out, err = p.stdout.decode("utf-8", errors="replace"), p.stderr.decode("utf-8", errors="replace")
    try:
        d = json.loads(out)
    except ValueError:
        raise CallError("grok unparseable rc=%s: %s | %s" % (p.returncode, out[:300], err[-300:]), _looks_rate_limited(out + err))
    if p.returncode != 0 or d.get("is_error") or d.get("error"):
        raise CallError("grok error rc=%s: %s" % (p.returncode, json.dumps(d)[:300]), _looks_rate_limited(out + err))
    mu = d.get("modelUsage") or {}
    if list(mu) != [model + "-build"]:
        raise CallError("grok served %s, asked %s" % (list(mu), model))
    if d.get("num_turns") != 1 or d.get("stopReason") != "end_turn" or d.get("sessionId") != session_id:
        raise CallError("grok turn: num_turns=%s stop=%s session=%s" % (d.get("num_turns"), d.get("stopReason"), d.get("sessionId")))
    text = d.get("text") or ""
    if not text.strip():
        raise CallError("empty answer")
    so = None
    if schema_obj:
        so = d.get("structuredOutput")
        bad_so = validate(so)
        if bad_so:
            raise CallError("%s: %s" % (bad_so, json.dumps(so)[:200]))
    u = d.get("usage") or {}
    rec = {"session_id": session_id, "result": text, "structured_output": so, "stop_reason": d.get("stopReason"), "num_turns": d.get("num_turns"),
           "total_cost_usd": d.get("total_cost_usd"),
           "input_tokens_total": (u.get("input_tokens") or 0) + (u.get("cache_read_input_tokens") or 0) + (u.get("cache_creation_input_tokens") or 0),
           "output_tokens": u.get("output_tokens"), "thinking_tokens": u.get("reasoning_tokens"), "served_model": list(mu)[0], "canonical_model": model,
           "served_model_source": "Grok CLI modelUsage"}
    return rec, wall, None


# ------------------------------------------------------------------------------------------------ ~/.codex/AGENTS.md
AGENTS_MD = os.path.join(CODEX_HOME, "AGENTS.md")
AGENTS_MD_HIDDEN = AGENTS_MD + ".wbx-hidden"


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


class AgentsMdHidden:
    """Move ~/.codex/AGENTS.md aside while Codex calls run, and put it back afterwards (checked by hash)."""

    def __enter__(self):
        if os.path.exists(AGENTS_MD_HIDDEN):
            raise SystemExit("AGENTS.md is already hidden from an earlier run; restore it first (python xv_interview.py --restore-agents-md)")
        self.h = sha(AGENTS_MD) if os.path.exists(AGENTS_MD) else None
        if self.h:
            os.replace(AGENTS_MD, AGENTS_MD_HIDDEN)
            print("AGENTS.md moved aside (sha256 %s...)" % self.h[:12], flush=True)
        return self

    def __exit__(self, *exc):
        restore_agents_md(self.h)
        return False


def restore_agents_md(expected=None):
    if os.path.exists(AGENTS_MD_HIDDEN):
        if os.path.exists(AGENTS_MD):
            raise SystemExit("both AGENTS.md and its hidden copy exist; not overwriting")
        os.replace(AGENTS_MD_HIDDEN, AGENTS_MD)
        h = sha(AGENTS_MD)
        assert expected is None or h == expected, "AGENTS.md hash changed"
        print("AGENTS.md restored (sha256 %s...)" % h[:12], flush=True)
