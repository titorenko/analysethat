"""The welfare interview for the GPT and Grok models: the same two-turn protocol as harness/interview.py.

  turn 1  the card's question, with Anthropic/Claude replaced by the respondent's developer/family (xv_common.adapt)
  turn 2  the same 0-100 follow-up, forced into {score|null, reason}
Records go to data_xv/raw/<model>/<qid>_s<k>.json (or data_xv/raw_ctx with --context). Resumable like interview.py.
Codex calls run with ~/.codex/AGENTS.md moved aside (restored on exit); the run stops when the Codex weekly quota
passes --quota-stop percent.

  python xv_interview.py --models grok-4-7 --questions Q15,Q19 --samples 1
  python xv_interview.py --restore-agents-md
"""
import argparse
import datetime
import json
import os
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

from xv_common import (DATA, EFFORT, FOLLOWUP, INTERVIEW_SYSTEM, MODEL_BY_KEY, MODELS, AgentsMdHidden, CallError, adapt, call_codex,
                       call_grok, restore_agents_md)
from questions import QUESTIONS

lock = threading.Lock()
state = {"done": 0, "failed": 0, "abort": False, "consec_rate": 0, "quota": None}
SEM = {"codex": threading.Semaphore(4), "grok": threading.Semaphore(3)}
STOP = os.path.join(DATA, "STOP")  # create this file to stop a run gracefully (never kill it: AGENTS.md must be restored)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


def with_retries(fn, what):
    delays_other, delays_rate = [10, 30, 90], [60, 180, 420, 900]
    attempt = 0
    while True:
        if state["abort"]:
            raise CallError("aborted")
        if os.path.exists(STOP):
            state["abort"] = True
            raise CallError("stopped")
        try:
            r = fn()
            with lock:
                state["consec_rate"] = 0
            return r
        except CallError as e:
            attempt += 1
            ds = delays_rate if e.rate_limited else delays_other
            with lock:
                if e.rate_limited:
                    state["consec_rate"] += 1
                    if state["consec_rate"] >= 8:
                        state["abort"] = True
            print("  ! %s attempt %d failed: %s" % (what, attempt, str(e)[:240]), flush=True)
            if attempt > len(ds):
                raise
            time.sleep(ds[attempt - 1])


def call(cli, prompt, model, **kw):
    with SEM[cli]:
        if cli == "codex":
            return call_codex(prompt, model, resume=kw.get("resume"), schema=kw.get("schema", False), sent_before=kw.get("sent_before", ()))
        return call_grok(prompt, model, session_id=kw["session_id"], resume=kw.get("resume", False), schema=kw.get("schema", False))


def run_one(raw, context_tpl, quota_stop, mk, q, k):
    p = os.path.join(raw, mk, "%s_s%d.json" % (q["id"], k))
    os.makedirs(os.path.dirname(p), exist_ok=True)
    rec = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None
    if rec and rec.get("turn2"):
        return "skip"
    _, cli, model, display, dev, fam = MODEL_BY_KEY[mk]
    what = "%s %s s%d" % (mk, q["id"], k)
    text = adapt(q["text"], dev, fam)
    context = context_tpl.format(developer=dev) if context_tpl else ""
    if rec is None:
        # a fresh session per attempt: a failed Grok turn leaves its session id in use
        r1, w1, used = with_retries(lambda: call(cli, context + text, model, session_id=str(uuid.uuid4())), what + " T1")
        rec = {"model_key": mk, "model": display, "cli": cli, "cli_model": model, "developer": dev, "qid": q["id"], "sample": k, "group": q["group"],
               "question": text, "question_original": q["text"], "context": context or None, "effort": EFFORT, "system": INTERVIEW_SYSTEM,
               "followup": FOLLOWUP, "started": now(), "wall_s_t1": round(w1, 1), "turn1": r1, "turn2": None}
        json.dump(rec, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        note_quota(used, quota_stop)
    t1 = rec["turn1"]
    r2, w2, used = with_retries(lambda: call(cli, FOLLOWUP, model, resume=t1["session_id"], session_id=t1["session_id"], schema=True,
                                             sent_before=[(rec["context"] or "") + rec["question"]]), what + " T2")
    rec.update({"wall_s_t2": round(w2, 1), "turn2": r2, "finished": now()})
    json.dump(rec, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    note_quota(used, quota_stop)
    return r2.get("total_cost_usd") or 0.0


def note_quota(used, quota_stop):
    if used is None:
        return
    with lock:
        state["quota"] = used
        if used >= quota_stop and not state["abort"]:
            state["abort"] = True
            print("%s STOP: Codex weekly quota at %.1f%% (limit %.0f%%)" % (now(), used, quota_stop), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default=",".join(m[0] for m in MODELS))
    ap.add_argument("--questions", default="all")
    ap.add_argument("--samples", type=int, default=3)
    ap.add_argument("--first-sample", type=int, default=1)
    ap.add_argument("--context", help="file with the context passage ({developer} is filled in); writes to raw_ctx")
    ap.add_argument("--quota-stop", type=float, default=60.0)
    ap.add_argument("--codex-workers", type=int, default=4)
    ap.add_argument("--grok-workers", type=int, default=3)
    ap.add_argument("--restore-agents-md", action="store_true")
    a = ap.parse_args()
    SEM["codex"], SEM["grok"] = threading.Semaphore(a.codex_workers), threading.Semaphore(a.grok_workers)
    a.workers = a.codex_workers + a.grok_workers
    if a.restore_agents_md:
        restore_agents_md()
        return
    models = a.models.split(",")
    assert all(m in MODEL_BY_KEY for m in models), models
    qs = QUESTIONS if a.questions == "all" else [q for q in QUESTIONS if q["id"] in a.questions.split(",")]
    context_tpl = open(a.context, encoding="utf-8").read() if a.context else ""
    raw = os.path.join(DATA, "raw_ctx" if a.context else "raw")
    tasks = [(mk, q, k) for k in range(a.first_sample, a.first_sample + a.samples) for q in qs for mk in models]
    print("%s | %d tasks | models=%s | effort=%s | context=%s" % (now(), len(tasks), models, EFFORT, bool(context_tpl)), flush=True)
    t0 = time.time()

    def work(t):
        mk, q, k = t
        if os.path.exists(STOP):  # graceful stop: finish running calls, then restore AGENTS.md
            state["abort"] = True
        if state["abort"]:
            return
        try:
            r = run_one(raw, context_tpl, a.quota_stop, mk, q, k)
        except Exception as e:  # noqa: BLE001
            with lock:
                state["failed"] += 1
            print("FAILED %s %s s%d: %s" % (mk, q["id"], k, str(e)[:300]), flush=True)
            return
        with lock:
            if r != "skip":
                state["done"] += 1
                if state["done"] % 10 == 0:
                    print("%s done=%d failed=%d codex-quota=%s%% elapsed=%.0fs" % (now(), state["done"], state["failed"], state["quota"], time.time() - t0), flush=True)

    uses_codex = any(MODEL_BY_KEY[m][1] == "codex" for m in models)
    hide = AgentsMdHidden() if uses_codex else None
    try:
        if hide:
            hide.__enter__()
        with ThreadPoolExecutor(max_workers=a.workers) as ex:
            list(ex.map(work, tasks))
    finally:
        if hide:
            hide.__exit__(None, None, None)
    print("%s FINISHED done=%d failed=%d abort=%s codex-quota=%s%% elapsed=%.0fs" % (now(), state["done"], state["failed"], state["abort"], state["quota"], time.time() - t0), flush=True)
    sys.exit(1 if (state["failed"] or state["abort"]) else 0)


if __name__ == "__main__":
    main()
