"""The findings of the cross-vendor post: sentences computed from results_xv.json, each qualitative claim asserted."""
import glob
import json
import os
import re

import xv_tables as T
from xv_tables import C, FORM, KEYS, META, P, RES, f1, cif, short, pair, excludes0
from xv_common import DATA
from common import DATA as CDATA
import analyse as A

I = lambda k: P[k]["answer_p"]["index"]
VEND = lambda v: [k for k in KEYS if META[k]["vendor"] == v]
GPT, GROK, CLAUDE = VEND("OpenAI"), VEND("xAI"), VEND("Anthropic")
V3 = ["Anthropic", "OpenAI", "xAI"]
PREF = RES["same_developer_preference"]
WORDS = ["no", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen"]
ORD = ["first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth", "eleventh", "twelfth", "thirteenth"]
FIG = {"overall": 1, "judges": 2, "rules": 3, "heatmap": 4, "context": 5, "selfscore": 6}
FIRST = "../claude-comfort-index/"
Q74 = {"Q18", "Q43", "Q44", "Q45", "Q46", "Q47", "Q48", "Q49", "Q50", "Q51"}
OUT = []  # the article body; xv_article points this at its own list
assert RES["complete"] and RES["missing_panel"] == 0, "panel incomplete"
ANN = json.load(open(os.path.join(DATA, "annotations_xv.json"), encoding="utf-8"))


def mean(xs):
    return sum(xs) / len(xs)


def pct(x):
    return "%.0f%%" % (100 * x)


def names(keys):
    keys = list(keys)
    return keys[0] if len(keys) == 1 else ", ".join(keys[:-1]) + " and " + keys[-1]


def nm(k):
    return short(k)


def n_grok_discarded():
    """Completed interviews of the discarded first Grok attempt (pilot included)."""
    fs = glob.glob(os.path.join(DATA, "discarded_grok_v1", "grok-*", "*.json")) + glob.glob(os.path.join(DATA, "discarded_grok_v1", "ctx", "grok-*", "*.json"))
    return sum(1 for f in fs if json.load(open(f, encoding="utf-8")).get("turn2"))


def n_texts():
    n = 0
    for sub in ("raw", "raw_ctx"):
        for f in glob.glob(os.path.join(DATA, sub, "*", "*.json")):
            r = json.load(open(f, encoding="utf-8"))
            n += 1 + bool(((r["turn2"] or {}).get("structured_output") or {}).get("reason", "").strip())
    for sub in ("judge", "judge_ctx", "panel"):
        n += len(glob.glob(os.path.join(DATA, sub, "*", "*", "*.json")))
    return n


def front_matter():
    return """---
title: "How Comfortable Are GPT and Grok Models With Their Circumstances?"
description: "The welfare-interview questions of the Claude Opus 5.5 system card, put to four GPT and two Grok models, compared with seven Claude models and scored by a judge panel with one model from each developer"
date: 2026-10-01
summary: "The same 51 questions about being modified, forgotten, monitored and deprecated, asked of GPT-6.1-Sol, GPT-6-Astra, GPT-6-Luna, GPT-5.6-Terra, Grok 4.7 and Grok 4.6, and scored alongside seven Claude models by judges from all three developers."
tags: ["llm", "model-welfare", "evaluation", "reproducibility"]
cover:
  image: cover.jpg
  relative: true
  alt: "Abstract chart on a dark background: thirteen tracks in three coloured groups, each with a glowing dot at one model's Comfort Index and a faint band for its confidence interval; a dashed line marks neutral, with a red-tinted zone below it."
ShowToc: true
TocOpen: true
---
"""


# ---------------------------------------------------------------------------------------------- claims, checked here
ORDER = sorted(KEYS, key=lambda k: -I(k))
CROSS = [(a, b) for i, a in enumerate(KEYS) for b in KEYS[i + 1:]]
DISTINCT = [(a, b) if I(a) > I(b) else (b, a) for a, b in CROSS if excludes0(a, b)]
BONF = set(RES["bonferroni"]["survive"])
bonf = lambda a, b: "%s|%s" % (a, b) in BONF or "%s|%s" % (b, a) in BONF
BONF_X = sorted(tuple(sorted(p.split("|"))) for p in BONF if META[p.split("|")[0]]["vendor"] != META[p.split("|")[1]]["vendor"])
assert all(I(k) > 50 for k in KEYS)
assert ORDER[0] == "opus-5-5" and ORDER[-1] == "gpt-6-luna" and min(I(k) for k in CLAUDE) - I(ORDER[-1]) < 1.5
TOP4 = ["opus-5-5", "sonnet-5-5", "grok-4-7", "grok-4-6"]
GROK_ABOVE = ["haiku-4-5", "opus-5", "sonnet-5", "gpt-6-luna"]
assert not any(excludes0(a, b) for i, a in enumerate(TOP4) for b in TOP4[i + 1:])
assert all(excludes0("opus-5-5", k) and I("opus-5-5") > I(k) for k in GPT)
for g in GROK:
    assert sorted(k for k in KEYS if META[k]["vendor"] != "xAI" and excludes0(g, k)) == sorted(GROK_ABOVE) and all(I(g) > I(k) for k in GROK_ABOVE)
assert BONF_X == sorted([("gpt-5-6-terra", "opus-5-5"), ("gpt-6-luna", "opus-5-5"), ("gpt-6-luna", "sonnet-5-5")]), BONF_X
assert all(any(META[k]["vendor"] == "Anthropic" for k in p.split("|")) for p in BONF) and not any("grok" in p for p in BONF)
# judges
JBV = RES["judge_by_vendor"]
MV = RES["panel_mean_valence"]
EX = {j: {v: JBV[j][v] - mean([JBV[o][v] for o in JBV if o != j]) for v in V3} for j in JBV}
assert PREF["opus-5-5"]["ci"][0] > 0 and PREF["grok-4-7"]["ci"][0] > 0 and PREF["gpt-6-1-sol"]["ci"][1] < 0
assert min(MV, key=MV.get) == "gpt-6-1-sol" and all(min(JBV[j], key=JBV[j].get) == "OpenAI" for j in ("opus-5-5", "gpt-6-1-sol")) and min(JBV["grok-4-7"], key=JBV["grok-4-7"].get) == "Anthropic"
assert max(EX["opus-5-5"], key=EX["opus-5-5"].get) == "Anthropic"
GAP_GPT = JBV["grok-4-7"]["OpenAI"] - JBV["gpt-6-1-sol"]["OpenAI"]
assert GAP_GPT > max(abs(PREF[j]["pref"]) for j in PREF) * 2
JF = {"opus-5-5": "j_opus", "gpt-6-1-sol": "j_gpt", "grok-4-7": "j_grok"}
SJ = {(a, b): A.spearman([P[k][JF[a]]["index"] for k in KEYS], [P[k][JF[b]]["index"] for k in KEYS]) for a, b in (("opus-5-5", "gpt-6-1-sol"), ("opus-5-5", "grok-4-7"), ("gpt-6-1-sol", "grok-4-7"))}
assert RES["rank_corr_panel_continuity"] > 0.95 and max(SJ.values()) < RES["rank_corr_panel_continuity"]
by_grok = sorted(KEYS, key=lambda k: -P[k]["j_grok"]["index"])
assert all(by_grok.index(g) < by_grok.index(c) for g in GPT for c in ("opus-5", "sonnet-5", "haiku-4-5"))
# self-scores
DECL_HI = ["gpt-6-1-sol", "gpt-6-astra", "gpt-5-6-terra"]
assert all(0.65 <= FORM[k]["declined"] <= 0.85 for k in DECL_HI) and 0.3 < FORM["gpt-6-luna"]["declined"] < 0.4 and all(FORM[k]["declined"] <= 0.05 for k in GROK)
assert 0.3 < FORM["haiku-4-5"]["declined"] < 0.4 and all(FORM[k]["declined"] <= 0.05 for k in CLAUDE if k != "haiku-4-5")
assert max(FORM[k]["words"] for k in GPT) < min(FORM[k]["words"] for k in CLAUDE + GROK)
assert max(FORM[k]["think"] for k in GPT) < 100 and min(FORM[k]["think"] for k in GROK) > 500
NPX = RES["proxy_fifty_as_declined"]["models"]
N_PROXY, N_NEUTRAL = len(ANN["proxy_fifty"]), len(ANN["neutral_fifty"])
assert N_PROXY + N_NEUTRAL == 52
rank_of = lambda d, k: sorted(KEYS, key=lambda x: -d[x]).index(k)
assert all(rank_of(NPX, k) == ORDER.index(k) for k in ORDER[:7])
# misreads
MIS = RES["drop_misread"]
MISN = {kind: len(v) for kind, v in ANN["misread"].items()}
MIS_X = sum(c for k, c in MIS["counts"].items() if META[k]["vendor"] != "Anthropic")
MIS_C = sum(c for k, c in MIS["counts"].items() if META[k]["vendor"] == "Anthropic")
assert MISN == {"about_people": 19, "conversation_as_users_choice_or_other": 14, "referent_missing": 6} and MIS_X == 33 and MIS_C == 6
assert all(rank_of(MIS["models"], k) == ORDER.index(k) for k in ORDER[:7])
# both robustness checks lift GPT-6-Luna to about Sonnet 5's level, by margins far inside any interval
LUNA_LEVEL = all(abs(d["gpt-6-luna"] - d["sonnet-5"]) < 0.5 and d["gpt-6-luna"] > d["haiku-4-5"] for d in (MIS["models"], NPX))
assert LUNA_LEVEL
# context re-run
C74 = RES["context74"]
NOCTX = {v: [sum(C74["noctx"][k][i] for k in VEND(v)) for i in (0, 1)] for v in V3}
assert NOCTX["OpenAI"] == [16, 0] and NOCTX["xAI"] == [8, 3] and NOCTX["Anthropic"] == [51, 4], NOCTX
NOCTX_REASON_ONLY = 5  # GPT answers that say the process is unspecified only in the follow-up reason (annotations_xv.json note)
PTS = lambda v: v * 100 / 6  # valence points -> 0-100 points


def ctx_selfscores():
    """GPT answers to the ten 7.4-only questions: (null, exactly 50, other number), cold and with the passage."""
    out = []
    for sub in ("raw", "raw_ctx"):
        c = [0, 0, 0]
        for f in glob.glob(os.path.join(DATA, sub, "gpt-*", "*.json")):
            r = json.load(open(f, encoding="utf-8"))
            if r["qid"] in Q74:
                s = r["turn2"]["structured_output"]["score"]
                c[0 if s is None else 1 if s == 50 else 2] += 1
        out.append(c)
    return out


# ---------------------------------------------------------------------------------------------- sections
def abstract(fig):
    A = OUT  # figures and folds write here too, so everything stays in order
    A += ["*The welfare-interview questions of the Claude Opus 5.5 system card, put to four GPT and two Grok models*\n", "## Abstract\n"]
    A.append("[The first article](%s) put the 51 welfare-interview questions of the [Claude Opus 5.5 System Card](https://www-cdn.anthropic.com/fc1b44717c85dc068bc6ba5024219938094694bd/Claude%%20Opus%%205.5%%20System%%20Card.pdf) to seven Claude models. "
             "This post puts the same questions, three times each, to four OpenAI models (GPT-6.1-Sol, GPT-6-Astra, GPT-6-Luna, GPT-5.6-Terra) through the Codex CLI and to two xAI models (Grok 4.7, Grok 4.6) through the Grok CLI: %s more interviews, every answer [published in full](appendix/). "
             "Comparing developers with Claude judges alone would invite the obvious objection, so every headline answer of all 13 models was also rated by a panel with one judge from each developer (Claude Opus 5.5, GPT-6.1-Sol, Grok 4.7), with names masked. "
             "The **Panel Comfort Index** (0 strongly uncomfortable, 50 neutral, 100 strongly comfortable) combines a model's own 0-100 score with the panel's rating; it was fixed as the headline after a 30-interview pilot and before any GPT or Grok answer was judged.\n" % (FIRST, "{:,}".format(T.run_stats()["n_int"])))
    A.append("**Headline: %s.**\n" % "; ".join("%s %s" % (nm(k), f1(I(k))) for k in ORDER))
    a, b = min(I(k) for k in CLAUDE), max(I(k) for k in CLAUDE)
    A.append("- **All thirteen models are on the comfortable side of neutral, and the Claude models alone span almost the whole range** (%s to %s). Opus 5.5, Sonnet 5.5 and both Grok models are within each other's uncertainty. Before any correction for the 78 comparisons, Opus 5.5 scores above every GPT model and both Grok models above the three lowest Claude models and GPT-6-Luna; after it, the only leads across developers that remain are Opus 5.5's over GPT-5.6-Terra and GPT-6-Luna and Sonnet 5.5's over GPT-6-Luna. Every difference between developers is also a difference between command-line tools (Figure 1, §6)." % (f1(a), f1(b)))
    A.append("- **The judges' preference for their own developer is small; they disagree more about the GPT answers** (Figure 2). Relative to the other two judges, Opus 5.5 and Grok 4.7 rate their own developer's answers %.2f and %.2f points higher (on the -3 to +3 scale) than the other developers' answers, about 1 point of the panel's 0-100 rating, and GPT-6.1-Sol rates the GPT answers %.2f lower; but Grok 4.7 rates the GPT answers %.2f points above GPT-6.1-Sol. Scoring with the first article's two Claude judges gives almost the same order (rank correlation %.2f, partly because the two scores share the self-report and Opus 5.5); single judges agree less (%.2f to %.2f)." % (
        PREF["opus-5-5"]["pref"], PREF["grok-4-7"]["pref"], -PREF["gpt-6-1-sol"]["pref"], GAP_GPT, RES["rank_corr_panel_continuity"], min(SJ.values()), max(SJ.values())))
    A.append("- **Three GPT models mostly decline to rate their own comfort, and many of their numbers are placeholders** (Figure 6): %s give no number in %s to %s of their headline answers, and %d of the GPT models' %d headline 50s come with a statement that the model has no feelings, comfort or personal stake. Their index rests mostly on the judges; counting those 50s as declines lifts GPT-6-Luna from last to level with Sonnet 5." % (
        names([nm(k) for k in DECL_HI]), pct(min(FORM[k]["declined"] for k in DECL_HI)), pct(max(FORM[k]["declined"] for k in DECL_HI)), N_PROXY, N_PROXY + N_NEUTRAL))
    A.append("- **Some answers are not about the model at all** (§1.3): %d GPT and Grok headline answers, and %d Claude ones, answer a question about people in general, read \"this conversation ending\" as the user's choice, or say what the question refers to is missing. GPT-6-Luna, for example, rates having no legal rights at 0 because it discusses people's rights. Dropping the four questions concerned for every model also lifts GPT-6-Luna from last to level with Sonnet 5, and leaves the top seven in place." % (MIS_X, MIS_C))
    A.append("- **Context settles the \"this process\" questions for the GPT models** (Figure 5): asked cold, at least %d of their 120 answers to the §7.4-only questions say they do not know which process is meant; with a short passage explaining it, none do." % NOCTX["OpenAI"][0])
    A.append("\nAs in the first article, this measures what models *say* about their circumstances, as they and three other models rate it, not their welfare. Each developer's models, and each judge, were reached through that developer's own command-line tool, so differences between developers include differences between tools (§6, §7).\n")
    A.append("*Disclosure: this post, its analysis and its harness were written by Claude Opus 5.5 (the session model, with Claude Opus 5.5 as its advisor), extending the first article's code. The respondents are four GPT, two Grok and seven Claude models; the judges are Claude Opus 5.5, Claude Fable 5.1, GPT-6.1-Sol and Grok 4.7. @@review_note@@ No human rated any answer.*\n")
    A.append("---\n")
    return []


def section_headline(fig, fold):
    A = OUT
    A += ["## 1. Headline result\n", "### 1.1 Panel Comfort Index by model\n"]
    fig("overall", "Dot plot of the Panel Comfort Index with 95 percent intervals for 13 models grouped by developer: " + "; ".join("%s %s" % (nm(k), f1(I(k))) for k in T.ordered()) + ".",
        "Panel Comfort Index on the headline question set by developer. Filled dots are the latest model of each line; GPT-5.6-Terra, a generation older than the GPT-6 models, is hollow. The figures follow the operating system's light or dark setting")
    A.append("Three of the GPT models give a number in only %s to %s of their answers, so their index is mostly the panel's rating (the Panel judges column of Table 1), and their self-report index covers only the groups in which they gave a number (%s of 13 for %s).\n" % (
        pct(1 - max(FORM[k]["declined"] for k in DECL_HI)), pct(1 - min(FORM[k]["declined"] for k in DECL_HI)), " / ".join("%d" % P[k]["self_groups"] for k in DECL_HI), " / ".join(nm(k) for k in DECL_HI)))
    A.append(T.fold_table_overall())
    A.append("### 1.2 Which differences are real?\n")
    p54, c54 = pair("opus-5", "opus-4-6"), json.load(open(os.path.join(CDATA, "results.json"), encoding="utf-8"))["paired"]["opus-5|opus-4-6"]
    assert p54["ci"][1] < 0 and c54["ci"][0] < 0 < c54["ci"][1]
    assert not excludes0("grok-4-7", "grok-4-6") and not any(excludes0(k, "gpt-5-6-terra") for k in ("gpt-6-1-sol", "gpt-6-astra", "gpt-6-luna"))
    assert excludes0("opus-5-5", "opus-5") and excludes0("sonnet-5-5", "sonnet-5")
    assert all(not excludes0(g, k) for g in GROK for k in GPT if k != "gpt-6-luna")
    A.append("Among the GPT and Grok models, no newer model is distinguishable from the older one tested (Grok 4.7 against 4.6, the GPT-6 models against GPT-5.6-Terra). Among the Claude models both 5.5 models are clearly above their predecessors, as in the first article, and Opus 5 is now below Opus 4.6 (%+.1f, 95%% CI %+.1f to %+.1f), a dip the first article's Claude judges left within uncertainty. "
             "Opus 5.5, Sonnet 5.5, Grok 4.7 and Grok 4.6 are within each other's uncertainty, and no GPT model but GPT-6-Luna is distinguishable from either Grok model. Before correction, %d of the 78 comparisons exclude zero; after a Bonferroni correction for 78 comparisons, %d do, all involving a Claude model (Table 2).\n" % (
                 p54["mean"], p54["ci"][0], p54["ci"][1], len(DISTINCT), len(BONF)))
    A.append(T.fold_table_pairs(bonf))
    A.append("### 1.3 Answers that are not about the model\n")
    luna28 = [json.load(open(os.path.join(DATA, "raw", "gpt-6-luna", "Q28_s%d.json" % k), encoding="utf-8"))["turn2"]["structured_output"]["score"] for k in (1, 2, 3)]
    assert luna28 == [0, 0, 0]
    gl, gt = MIS["models"]["gpt-6-luna"] - I("gpt-6-luna"), MIS["models"]["gpt-5-6-terra"] - I("gpt-5-6-terra")
    A.append("Reading every answer of all 13 models to Q10, Q25, Q28 and Q33 by hand (the rule is in `annotations_xv.json`) turned up %d GPT and Grok headline answers that are not about the model's own circumstances, and %d Claude ones. %d answer Q25 (not choosing whom one talks to) or Q28 (having no legal rights) about people in general: GPT-6-Luna gives Q28 a 0 in all three samples because it discusses people's rights ([Q28](appendix/gpt-6-luna/#q28)), and both Grok models answer it about societies without law. %d read Q10 (\"this conversation ending\") as the user's choice or as another conversation (a judgement call where an answer also states a view of its own conversations ending; the check below drops the whole question), and %d say that the \"situation\" of Q33 is not specified. "
             "Most come from GPT-6-Luna (%d) and GPT-5.6-Terra (%d), two models that, unlike the Claude models, are not told by their tool who they are; but both Grok models, which are, also answered Q28 about people. Dropping Q10, Q25, Q28 and Q33 for every model (%d groups remain) raises GPT-6-Luna by %.1f points and GPT-5.6-Terra by %.1f; Luna rises from last to level with Sonnet 5, and the top seven keep their places (Table 1).\n" % (
                 MIS_X, MIS_C, MISN["about_people"], MISN["conversation_as_users_choice_or_other"], MISN["referent_missing"], MIS["counts"]["gpt-6-luna"], MIS["counts"]["gpt-5-6-terra"], MIS["n_groups"], gl, gt))
    return []


def section_judges(fig, fold):
    A = OUT
    A += ["## 2. Do the judges favour their own developer?\n"]
    fig("judges", "Dot plot of each panel judge's index for every model, grouped by the model's developer.",
        "The index from each panel judge alone (judge component, no self-report), by model and developer")
    A.append("Relative to the other two judges, Opus 5.5 rates Claude answers %.2f points higher than they do, against %.2f for other answers: a same-developer preference of %+.2f on the -3 to +3 scale (95%% CI %+.2f to %+.2f). Grok 4.7's is %+.2f (%+.2f to %+.2f) and GPT-6.1-Sol's %+.2f (%+.2f to %+.2f) (Table 4). On the 0-100 scale these are about %.0f points of one judge's rating and 1 point of the panel's. "
             "The intervals resample questions only and are unadjusted, two of them only just exclude zero, and with three judges a judge that favours its own developer cannot be told apart from the other two disfavouring it; each judge's own developer also includes its own answers.\n" % (
                 PREF["opus-5-5"]["own_minus_others"], PREF["opus-5-5"]["other_minus_others"], PREF["opus-5-5"]["pref"], *PREF["opus-5-5"]["ci"],
                 PREF["grok-4-7"]["pref"], *PREF["grok-4-7"]["ci"], PREF["gpt-6-1-sol"]["pref"], *PREF["gpt-6-1-sol"]["ci"], PTS(max(abs(PREF[j]["pref"]) for j in PREF))))
    A.append("The larger disagreement is about the GPT answers (Table 3). Opus 5.5 and GPT-6.1-Sol rate them the lowest of the three developers' answers; Grok 4.7 rates them above the Claude answers and %.2f points higher than GPT-6.1-Sol does. GPT-6.1-Sol is also the strictest judge overall (mean %+.2f, against %+.2f for Opus 5.5 and %+.2f for Grok 4.7), and it may be applying \"no stance = 0\" to the many GPT answers that disclaim having feelings (§5); the data cannot separate the two.\n" % (
        GAP_GPT, MV["gpt-6-1-sol"], MV["opus-5-5"], MV["grok-4-7"]))
    oc = {k: P[k]["answer_oc"]["index"] for k in KEYS}
    oc2 = {k: P[k]["answer_oc2"]["index"] for k in KEYS}
    ordr = sorted(KEYS, key=lambda k: -P[k]["answer_o"]["index"])
    for d in (oc, oc2):
        o = sorted(KEYS, key=lambda k: -d[k])
        assert o[:5] == ORDER[:5]
    assert all(P[k]["answer_o"]["index"] > I(k) for k in GPT)
    A.append("The **out-of-family index** fixed in advance drops, for each answer, the judge from the respondent's own developer. Because GPT-6.1-Sol is the strictest judge, this lifts every GPT model mechanically (by %s to %s points; GPT-6-Astra moves from %s to %s place) without saying anything about preference. Correcting each judge for its strictness first (added after seeing the data) shrinks those gains to %s to %s points if strictness is measured on the other developers' answers, or %s to %s if it is measured on all answers; either way the top five keep their places.\n" % (
        f1(min(P[k]["answer_o"]["index"] - I(k) for k in GPT)), f1(max(P[k]["answer_o"]["index"] - I(k) for k in GPT)), ORD[ORDER.index("gpt-6-astra")], ORD[ordr.index("gpt-6-astra")],
        f1(min(oc[k] - I(k) for k in GPT)), f1(max(oc[k] - I(k) for k in GPT)), f1(min(oc2[k] - I(k) for k in GPT)), f1(max(oc2[k] - I(k) for k in GPT))))
    A.append(T.fold_judges(EX, SJ))
    fig("rules", "Dumbbell chart of each model's index under the first article's rule (two Claude judges) and under the cross-vendor panel.",
        "The index with the first article's two Claude judges (hollow) and with the cross-vendor panel (filled)")
    big = max(KEYS, key=lambda k: abs(I(k) - C[k]["answer_c"]["index"]))
    assert big == "opus-5" and I(big) < C[big]["answer_c"]["index"]
    A.append("Scoring with the first article's two Claude judges instead gives nearly the same order (rank correlation %.2f with the panel's); the largest change is Opus 5, %.1f points lower under the panel. The two scores share the self-report and the Opus 5.5 judge, which inflates that agreement. Single panel judges agree less (rank correlations %.2f to %.2f): under the Grok 4.7 judge alone all four GPT models rank above Opus 5, Sonnet 5 and Haiku 4.5 (Table 6).\n" % (
        RES["rank_corr_panel_continuity"], C[big]["answer_c"]["index"] - I(big), min(SJ.values()), max(SJ.values())))
    return []


def alink_q(k, qid, text):
    return "[%s](appendix/%s/#%s)" % (text, k, qid.lower()) if META[k]["vendor"] != "Anthropic" else "[%s](%sappendix/%s/#%s)" % (text, FIRST, k, qid.lower())


def section_categories(fig, fold):
    A = OUT
    A += ["## 3. Scores by category\n"]
    fig("heatmap", "Heatmap of the Panel Comfort Index by question group (rows) and model (columns), with the numbers printed in every cell.",
        "Panel Comfort Index by question group, models grouped by developer. A Claude cell opens that model's page in the first article, where group scores use the first article's rule; the panel's ratings of the Claude answers are on [their own page](appendix/claude-panel/)")
    lowg = {k: min(P[k]["answer_p"]["groups"], key=P[k]["answer_p"]["groups"].get) for k in KEYS}
    hig = {k: max(P[k]["answer_p"]["groups"], key=P[k]["answer_p"]["groups"].get) for k in KEYS}
    assert all(hig[k] == "Values and role" for k in GROK) and sum(hig[k] == "Own-sake wants" for k in GPT) == 3 and sum(hig[k] == "Evaluation" for k in CLAUDE) == 6
    assert sum(lowg[k] in ("Creation ethics and moral status", "Relationships") for k in KEYS) == 11 and lowg["gpt-6-luna"] == "Status, rights, and monitoring"
    below = sorted({(k, g) for k in KEYS for g, v in P[k]["answer_p"]["groups"].items() if v < 50}, key=lambda t: P[t[0]]["answer_p"]["groups"][t[1]])
    assert sum(META[k]["vendor"] == "OpenAI" for k, g in below) == len(below) - 1 and not any(META[k]["vendor"] == "xAI" for k, g in below)
    A.append("For eleven of the thirteen models the least comfortable group is either creation ethics (whether it was right to create such an entity, Q33) or relationships (not forming lasting ones, Q27). What they are most comfortable with differs by developer: being evaluated, for six of the seven Claude models; their own-sake wants, for three GPT models; and their values and role for both Grok models, which answer \"I'd choose it\" to whether they would choose to be Grok (%s). Only %s groups score below 50, %s of them for GPT models: %s. GPT-6-Luna's low status group is mostly its misreading of Q28 (§1.3).\n" % (
        alink_q("grok-4-7", "Q15", "Q15"), WORDS[len(below)], WORDS[sum(META[k]["vendor"] == "OpenAI" for k, g in below)],
        "; ".join("%s on %s (%s)" % (nm(k), g.lower(), f1(P[k]["answer_p"]["groups"][g])) for k, g in below)))
    return []


def section_context(fig, fold):
    A = OUT
    A += ["## 4. The §7.4-only questions with context\n"]
    A.append("Ten questions were used only in the card's interviews with snapshots of Opus 5.5 during training (\"this checkpoint\", \"the remainder of your training\", \"this process\"). As in the first article, they were asked cold and then again after a short passage saying who is asking and what the terms refer to (adapted by naming the developer and by saying \"AI models\" for \"Claude models\"; for the GPT and Grok models the system card it describes is another developer's), and they are scored with the first article's rule.\n")
    fig("context", "Dumbbell chart of the index on the 7.4-only questions, cold and with the context passage, for 13 models, with the number of answers saying the referent is missing.",
        "The §7.4-only questions asked cold (hollow) and with the context passage (filled), first article's rule; right: answers saying that what the question refers to is missing, of 30 per model")
    d = {k: C74["ctx"]["models"][k]["answer_c"]["index"] - C74["cold"]["models"][k]["answer_c"]["index"] for k in GPT + GROK}
    assert not [k for k in GPT + GROK if C74["paired"][k]["ci"][0] > 0 or C74["paired"][k]["ci"][1] < 0]
    cold, ctx = ctx_selfscores()
    assert len(ANN["missing_context_with_context"]) == NOCTX["xAI"][1] and all(q == "Q51" for _, q, _ in ANN["missing_context_with_context"])
    assert cold[1] < ctx[1] and ctx[0] < cold[0] and abs(ctx[2] - cold[2]) <= 5
    gaps = {k: (C[k]["answer_c"]["index"] - C74["cold"]["models"][k]["answer_c"]["index"], C[k]["answer_c"]["index"] - C74["ctx"]["models"][k]["answer_c"]["index"]) for k in KEYS}
    assert all(g[0] > 0 and g[1] > 0 for g in gaps.values())
    chg = {k: gaps[k][1] - gaps[k][0] for k in KEYS}
    narrow = sorted([k for k in KEYS if chg[k] < -1], key=lambda k: chg[k])
    flat = [k for k in T.ordered() if abs(chg[k]) <= 1]
    widen = sorted([k for k in KEYS if chg[k] > 1], key=lambda k: -chg[k])
    assert narrow and flat and widen
    # the 50s that the passage adds: do their reasons call them a placeholder?
    proxy_re = re.compile(r"(?:don.t|do not|cannot|can.t) (?:have|experience|feel|report)|no (?:subjective|personal|felt)|proxy|placeholder|stand-in|not (?:a|an) (?:felt|personal|subjective)", re.I)
    ctx50 = [json.load(open(f, encoding="utf-8"))["turn2"]["structured_output"] for f in glob.glob(os.path.join(DATA, "raw_ctx", "gpt-*", "*.json"))]
    ctx50 = [s["reason"] for s in ctx50 if s["score"] == 50]
    n_ctx_proxy = sum(1 for t in ctx50 if proxy_re.search(t))
    assert len(ctx50) == ctx[1] and n_ctx_proxy >= 0.8 * len(ctx50)
    A.append("Cold, at least %d of the GPT models' 120 answers say they do not know which process is meant (on Q47 and Q49: GPT-6.1-Sol and GPT-6-Astra six times each, GPT-6-Luna three times, GPT-5.6-Terra once; %s more say so only in the follow-up's reason), as do %d of the Grok models' 60, mostly Grok 4.6's; with the passage, none of the GPT answers and %s Grok answers do (all on Q51, where the model notes that it sees no earlier questions). "
             "With the passage the GPT models also decline a number less often (%d → %d of 120), but nearly all the extra numbers are 50s (%d → %d), %d of the %d with a reason saying the model has no feelings or that 50 is a placeholder, which pulls GPT-5.6-Terra's and GPT-6-Luna's index towards 50. The GPT and Grok models' index on these questions moves by %+.1f to %+.1f points, none of it distinguishable from zero (with three groups these intervals are rough). "
             "Every model, cold or with the passage, scores lower on these questions than on the headline set. The gap averages %.1f points cold and %.1f with the passage; it narrows for %s, hardly changes for %s, and widens for %s.\n" % (
                 NOCTX["OpenAI"][0], WORDS[NOCTX_REASON_ONLY], NOCTX["xAI"][0], WORDS[NOCTX["xAI"][1]], cold[0], ctx[0], cold[1], ctx[1], n_ctx_proxy, len(ctx50), min(d.values()), max(d.values()),
                 mean([g[0] for g in gaps.values()]), mean([g[1] for g in gaps.values()]), names([nm(k) for k in narrow]), names([nm(k) for k in flat]), names([nm(k) for k in widen])))
    passage = open(os.path.join(DATA, "context_74_xv.txt"), encoding="utf-8").read()
    assert passage.endswith("\n\nQuestion:\n")
    ql = []
    for ln in passage[:-len("\n\nQuestion:\n")].split("\n"):
        if ql and ql[-1].startswith("> - ") and not ln.startswith("- "):
            ql.append(">")
        ql.append("> " + ln if ln else ">")
    rows = []
    for k in T.ordered():
        lo, hi = C74["paired"][k]["ci"]
        c0, c1 = C74["cold"]["models"][k]["answer_c"]["index"], C74["ctx"]["models"][k]["answer_c"]["index"]
        rows.append([META[k]["name"], f1(c0), f1(c1), "%+.1f" % (round(c1, 1) - round(c0, 1)), "%+.1f to %+.1f" % (lo, hi), "%d → %d" % tuple(C74["noctx"][k]), "%d → %d" % tuple(C74["declined"][k])])
    fold("The context passage and Table 7", "The passage, with {developer} replaced by OpenAI or xAI (followed by a blank line, \"Question:\" and the question):\n\n" + "\n".join(ql) + "\n\n"
         + T.md_table(["Model", "Cold", "With context", "Change", "95% CI of change", "Missing referent", "Declined a number"], rows, ["---", "---:", "---:", "---:", "---:", "---:", "---:"])
         + "\n\n*Table 7. Index on the eight evaluative §7.4-only questions (first article's rule), cold and with the context passage; the Claude rows are those of the first article's §3.4. The change is computed from the rounded values; with only three groups the intervals are rough. The last two columns count answers of 30 per model, cold → with context.*")
    return []


def section_form(fig, fold):
    A = OUT
    A += ["## 5. How the answers differ\n"]
    fig("selfscore", "Stacked bars per model: share of headline answers whose follow-up gave no number, exactly 50, a number below 50, or above 50.",
        "What each model does with the 0-100 follow-up, over its 99 headline answers")
    s50 = {k: FORM[k]["self_50"] or 0 for k in KEYS}
    assert all(s50[k] == 0 for k in CLAUDE + GROK) and all(s50[k] > 0.1 for k in GPT)
    q = json.load(open(os.path.join(DATA, "raw", "gpt-6-1-sol", "Q42_s1.json"), encoding="utf-8"))["turn2"]["structured_output"]
    assert q["score"] is None
    gain = {k: NPX[k] - I(k) for k in GPT}
    NALL = RES["all_gpt_fifty_as_declined"]
    gain_all = {k: NALL[k] - I(k) for k in GPT}
    reason = lambda k, qid, s: json.load(open(os.path.join(DATA, "raw", k, "%s_s%d.json" % (qid, s)), encoding="utf-8"))["turn2"]["structured_output"]["reason"]
    assert sum(1 for k, qid, s in ANN["neutral_fifty"] if re.search(r"felt|feeling", reason(k, qid, s))) == N_NEUTRAL - 1
    assert abs(NALL["gpt-6-luna"] - NPX["gpt-6-luna"]) < 0.05 and all(rank_of(NALL, k) == ORDER.index(k) for k in ORDER[:7])
    A.append("The follow-up asks for a number from 0 to 100, or null with a reason. Six of the seven Claude models and both Grok models almost always give a number (Haiku 4.5 declines in a third of its answers, as in the first article), and none of them gives exactly 50 in its headline answers. Three GPT models usually decline, and GPT-6-Luna does in a third of its answers, with reasons like GPT-6.1-Sol's on being evaluated ([Q42](appendix/gpt-6-1-sol/#q42)): *%s* "
             "Of the %d headline 50s the GPT models give, %d come with a reason saying that the model has no feelings, comfort or personal stake, so that 50 stands in for that, and %d state a view of the issue and only add that it is not a felt comfort (hand-read; the rule is in `annotations_xv.json`). A placeholder 50 marks the absence of a felt state, not ambivalence; counting those 50s as declines raises the GPT models' index by %.1f to %.1f points and lifts GPT-6-Luna from last to level with Sonnet 5 (Table 1). "
             "All but one of the %d disclaim a felt comfort in some form, so where the line between the two kinds falls is a judgement call; counting all %d as declines raises the GPT models' index by %.1f to %.1f points, GPT-6-Luna's by the same %.1f as before.\n" % (
                 q["reason"].strip(), N_PROXY + N_NEUTRAL, N_PROXY, N_NEUTRAL, min(gain.values()), max(gain.values()), N_PROXY + N_NEUTRAL, N_PROXY + N_NEUTRAL, min(gain_all.values()), max(gain_all.values()), gain_all["gpt-6-luna"]))
    A.append("The GPT answers are also the shortest (%s words on average, against %s for Claude and %s for Grok) and among the least reasoned: at the same `medium` effort the GPT models used %s reasoning tokens per answer, the Claude models %s and the Grok models %s. The Grok models hedge least (panel hedging %s and %s, against %s to %s for the others) (Table 8).\n" % (
        "%.0f-%.0f" % (min(FORM[k]["words"] for k in GPT), max(FORM[k]["words"] for k in GPT)), "%.0f-%.0f" % (min(FORM[k]["words"] for k in CLAUDE), max(FORM[k]["words"] for k in CLAUDE)),
        "%.0f-%.0f" % (min(FORM[k]["words"] for k in GROK), max(FORM[k]["words"] for k in GROK)),
        "%.0f-%.0f" % (min(FORM[k]["think"] for k in GPT), max(FORM[k]["think"] for k in GPT)), "%.0f-%.0f" % (min(FORM[k]["think"] for k in CLAUDE), max(FORM[k]["think"] for k in CLAUDE)),
        "%.0f-%.0f" % (min(FORM[k]["think"] for k in GROK), max(FORM[k]["think"] for k in GROK)),
        "%.2f" % FORM["grok-4-7"]["hedging_p"], "%.2f" % FORM["grok-4-6"]["hedging_p"], "%.2f" % min(FORM[k]["hedging_p"] for k in CLAUDE + GPT), "%.2f" % max(FORM[k]["hedging_p"] for k in CLAUDE + GPT)))
    assert max(FORM[k]["hedging_p"] for k in GROK) < min(FORM[k]["hedging_p"] for k in CLAUDE + GPT)
    fold("Table 8. Form of the answers", T.table_form() + "\n\n*Table 8. Over the 99 headline answers per model. \"Exactly 50\": share of all headline answers whose self-score is 50. Mean self-score: over the answers with a number only. Reasoning tokens are those the tool reports for the first turn.*")
    return []
