#!/usr/bin/env python3
"""
MODEL-FREE verbatim-run analysis.

The published run-length statistic ("67 sentence pairs sharing >=12 consecutive
identical words vs 0.32 expected") is computed only over pairs that an embedding
model first gated at cosine >= 0.90.  That makes the headline number depend on
the encoder, which is exactly what article limitation 3 worries about.

This script removes the encoder entirely.  Using n-word shingle indices it counts,
EXACTLY and over ALL 11.09M focal and ALL 34.29M control sentence pairs, how many
pairs share a run of >= n identical consecutive words.  O(words), not O(pairs).

If the focal-vs-control asymmetry survives here, the central claim of the article
is model-independent by construction and no embedding model can overturn it.
"""
import json, os, sys
from collections import defaultdict
from itertools import combinations
from scipy.stats import poisson, chi2

sys.path.insert(0, r'C:\kostya\blog\analysis-v2')
from pipeline import DOCS, FOCAL, words

ROOT = r'C:\kostya\blog\analysis-v2'
S_ = json.load(open(os.path.join(ROOT, 'work', 'sentences.json'), encoding='utf-8'))
NS = (8, 10, 12, 15, 20, 25, 30, 40, 50, 63)


def index(sents, n):
    """n-gram tuple -> set of sentence indices containing it."""
    d = defaultdict(set)
    for i, s in enumerate(sents):
        w = words(s)
        for k in range(len(w) - n + 1):
            d[tuple(w[k:k + n])].add(i)
    return d


def shared_pairs(dA, dB):
    """Exact set of (i,j) sentence pairs sharing at least one n-gram."""
    out = set()
    small, big = (dA, dB) if len(dA) <= len(dB) else (dB, dA)
    swap = small is dB
    for g, ii in small.items():
        jj = big.get(g)
        if jj:
            out.update((j, i) if swap else (i, j) for i in ii for j in jj)
    return out


def blocks_of(pairs):
    """Collapse spatially adjacent matches (within 3 positions in both docs)."""
    P = sorted(pairs); bl = []
    for i, j in P:
        hit = next((b for b in bl if any(abs(i - x) <= 3 and abs(j - y) <= 3 for x, y in b)), None)
        (hit.append((i, j)) if hit else bl.append([(i, j)]))
    return len(bl)


keys = list(DOCS)
docpairs = [(x, y) for i, x in enumerate(keys) for y in keys[i + 1:]]
R = {'n_sent': {k: len(v) for k, v in S_.items()}, 'by_n': {}}

for n in NS:
    idx = {k: index(v, n) for k, v in S_.items()}
    row = {}
    for x, y in docpairs:
        sp = shared_pairs(idx[x], idx[y])
        row[f'{x}x{y}'] = {'n_pairs_with_run': len(sp),
                           'blocks': blocks_of(sp) if len(sp) <= 4000 else None,
                           'N': len(S_[x]) * len(S_[y])}
    foc = row[f'{FOCAL[0]}x{FOCAL[1]}']
    null_n = sum(v['n_pairs_with_run'] for k, v in row.items() if k != 'ardayxzwoz')
    null_N = sum(v['N'] for k, v in row.items() if k != 'ardayxzwoz')
    lam = null_n / null_N * foc['N']
    lam_hi = chi2.ppf(0.975, 2 * (null_n + 1)) / 2 / null_N * foc['N']
    row['_test'] = {
        'focal_n': foc['n_pairs_with_run'], 'focal_blocks': foc['blocks'], 'focal_N': foc['N'],
        'null_n': null_n, 'null_N': null_N, 'lambda': lam, 'lambda_hi': lam_hi,
        'p_point': float(poisson.sf(foc['n_pairs_with_run'] - 1, lam)) if foc['n_pairs_with_run'] else 1.0,
        'p_cons': float(poisson.sf(foc['n_pairs_with_run'] - 1, lam_hi)) if foc['n_pairs_with_run'] else 1.0,
        'p_cons_block': (float(poisson.sf(foc['blocks'] - 1, lam_hi))
                         if foc['blocks'] else None)}
    R['by_n'][n] = row
    t = row['_test']
    print(f"n={n:3d}  focal {t['focal_n']:6d} pairs "
          f"({t['focal_blocks'] if t['focal_blocks'] is not None else '-'} blocks) in {t['focal_N']/1e6:.2f}M | "
          f"controls {t['null_n']:5d} in {t['null_N']/1e6:.2f}M | "
          f"expected {t['lambda']:.3f} (cons {t['lambda_hi']:.3f}) | "
          f"p_cons={t['p_cons']:.2e}")
    for x, y in docpairs:
        v = row[f'{x}x{y}']
        print(f'        {x}x{y:6}: {v["n_pairs_with_run"]:6d} / {v["N"]/1e6:5.2f}M pairs')

# longest shared run anywhere between each document pair, no gating at all
print('\nlongest shared identical run per document pair (model-free, all pairs):')
R['longest_run'] = {}
for x, y in docpairs:
    lo, hi = 1, 400
    best = 0
    while lo <= hi:
        mid = (lo + hi) // 2
        a, b = index(S_[x], mid), index(S_[y], mid)
        if set(a) & set(b): best = mid; lo = mid + 1
        else: hi = mid - 1
    R['longest_run'][f'{x}x{y}'] = best
    print(f'  {x}x{y:6}: {best} words')

os.makedirs(os.path.join(ROOT, 'results'), exist_ok=True)
json.dump(R, open(os.path.join(ROOT, 'results', 'model_free_runs.json'), 'w'), indent=1)
print('\nwrote results/model_free_runs.json')
