#!/usr/bin/env python3
"""
An honest cross-model version of the article's section 4.3 table.

The published 4.3 table gates on raw cosine >= 0.90.  Under e5-large and
gte-large, 0.90 falls inside the BULK of the distribution -- 11,599 cross-document
pairs and 37,151 within-Arday pairs clear it, versus 134 and 122 under MiniLM.
The published table cannot be recomputed at a fixed cosine for those models; the
numbers would not mean the same thing.  Two replacements:

(A) MODEL-FREE.  Count sentence pairs sharing a run of >= n identical consecutive
    words, per million pairs, for within-Arday, within-Zwozdiak-Myers (both with
    the published >= 200-sentence separation) and cross-document.  No encoder.
    This tests the substance of the 4.3 claim -- "the two documents phrase shared
    ideas alike more often than either document does when restating itself" --
    with nothing an encoder can influence.

(B) RANK-MATCHED.  Give every model the SAME budget the published table used
    (122 within-Arday, 280 within-Zwoz, 134 cross) and let it choose which pairs
    to spend it on, then measure run/Jaccard structure.  Selection size is held
    constant across models, so the comparison is about which pairs each model
    picks, not about where its cosine scale happens to sit.
"""
import json, os, sys
from collections import defaultdict
import numpy as np

sys.path.insert(0, r'C:\kostya\blog\analysis-v2')
from pipeline import words, longest_run, content
from run_model import MODELS

ROOT = r'C:\kostya\blog\analysis-v2'
RES = os.path.join(ROOT, 'results')
S_ = json.load(open(os.path.join(ROOT, 'work', 'sentences.json'), encoding='utf-8'))
GAP = 200                       # published within-document separation
OUT = {}

# ==========================================================================
print('=' * 78)
print('(A) MODEL-FREE run rates: within-document vs cross-document')
print('=' * 78)


def ngrams(sents, n):
    d = defaultdict(set)
    for i, s in enumerate(sents):
        w = words(s)
        for k in range(len(w) - n + 1):
            d[tuple(w[k:k + n])].add(i)
    return d


def within_run_pairs(sents, n, gap=GAP):
    """Pairs (i,j), j-i >= gap, in ONE document sharing an n-word run."""
    d = ngrams(sents, n)
    out = set()
    for g, ii in d.items():
        if len(ii) > 1:
            L = sorted(ii)
            out.update((a, b) for x, a in enumerate(L) for b in L[x + 1:] if b - a >= gap)
    return out


def cross_run_pairs(sa, sb, n):
    A, B = ngrams(sa, n), ngrams(sb, n)
    out = set()
    for g, ii in A.items():
        jj = B.get(g)
        if jj:
            out.update((i, j) for i in ii for j in jj)
    return out


na, nz = len(S_['arday']), len(S_['zwoz'])
N_wA = sum(1 for i in range(na) for j in range(i + GAP, na)) if False else (na - GAP) * (na - GAP + 1) // 2
N_wZ = (nz - GAP) * (nz - GAP + 1) // 2
N_x = na * nz
rowsA = []
for n in (8, 10, 12, 15, 20):
    wA = within_run_pairs(S_['arday'], n)
    wZ = within_run_pairs(S_['zwoz'], n)
    xx = cross_run_pairs(S_['arday'], S_['zwoz'], n)
    r = {'n': n,
         'within_arday': {'n': len(wA), 'N': N_wA, 'per1M': len(wA) / N_wA * 1e6},
         'within_zwoz': {'n': len(wZ), 'N': N_wZ, 'per1M': len(wZ) / N_wZ * 1e6},
         'cross': {'n': len(xx), 'N': N_x, 'per1M': len(xx) / N_x * 1e6}}
    r['ratio_cross_vs_arday'] = r['cross']['per1M'] / max(1e-12, r['within_arday']['per1M'])
    r['ratio_cross_vs_zwoz'] = r['cross']['per1M'] / max(1e-12, r['within_zwoz']['per1M'])
    rowsA.append(r)
    print(f"  run>={n:2d}  within-Arday {len(wA):5d}/{N_wA/1e6:5.2f}M = {r['within_arday']['per1M']:7.2f}/M | "
          f"within-Zwoz {len(wZ):5d}/{N_wZ/1e6:5.2f}M = {r['within_zwoz']['per1M']:7.2f}/M | "
          f"CROSS {len(xx):5d}/{N_x/1e6:5.2f}M = {r['cross']['per1M']:7.2f}/M  "
          f"(cross/within = {r['ratio_cross_vs_arday']:.1f}x, {r['ratio_cross_vs_zwoz']:.1f}x)")
OUT['model_free_within_vs_cross'] = rowsA
print('\n  READ THIS CAREFULLY -- it does NOT say what the article\'s abstract says.')
print('  UNCONDITIONALLY, the cross-document verbatim run rate beats within-Arday')
print('  at every length (2-3x) but is FAR BELOW within-Zwozdiak-Myers (0.1-0.4x).')
print('  Zwozdiak-Myers restates herself verbatim a great deal -- 239 of her own')
print('  sentence pairs, 200+ sentences apart, share a 12-word run (her definition')
print('  of reflective practice, quotations from Moore and LaBoskey re-used across')
print('  chapters).  The published 4.3 statistic is CONDITIONAL on high similarity')
print('  and survives (see B below); the abstract\'s unconditional gloss -- "the two')
print('  documents phrase shared ideas alike more often than either document does')
print('  when restating itself" -- does not hold for Zwozdiak-Myers.')
print('  This does not touch the central claim, which rests on the cross-document')
print('  CONTROL rate of 0.029/M, not on the within-document baseline.')

# ==========================================================================
print('\n' + '=' * 78)
print('(B) RANK-MATCHED 4.3 table: same pair budget for every model')
print('=' * 78)
BUDGET = {'within_arday': 122, 'within_zwoz': 280, 'cross': 134}   # published counts
ORDER = ['minilm', 'mpnet', 'bge', 'e5', 'gte']
ORDER = [k for k in ORDER if os.path.exists(os.path.join(RES, f'{k}.json'))]
import torch
from sentence_transformers import SentenceTransformer
dev = 'cuda' if torch.cuda.is_available() else 'cpu'


def topk_within(E, k, gap=GAP):
    S = E @ E.T
    i, j = np.triu_indices(S.shape[0], k=gap)
    v = S[i, j]
    sel = np.argpartition(-v, k)[:k]
    sel = sel[np.argsort(-v[sel])]
    return [(int(i[t]), int(j[t]), float(v[t])) for t in sel]


def topk_cross(E1, E2, k):
    S = E1 @ E2.T
    fl = S.ravel()
    sel = np.argpartition(-fl, k)[:k]
    sel = sel[np.argsort(-fl[sel])]
    return [(int(t // S.shape[1]), int(t % S.shape[1]), float(fl[t])) for t in sel]


def score(idx, sa, sb):
    runs = np.array([longest_run(sa[i], sb[j]) for i, j, _ in idx])
    jacs = np.array([len(content(sa[i]) & content(sb[j])) /
                     max(1, len(content(sa[i]) | content(sb[j]))) for i, j, _ in idx])
    return {'n': len(idx), 'jac_med': float(np.median(jacs)), 'run_med': float(np.median(runs)),
            'run_max': int(runs.max()), 'pct_run12': float((runs >= 12).mean() * 100),
            'cos_min': float(min(c for _, _, c in idx))}


tab = {}
print(f"\n{'model':8} {'population':16} {'n':>5} {'med Jaccard':>12} {'med run':>9} "
      f"{'max run':>8} {'% run>=12':>10} {'min cos':>8}")
for k in ORDER:
    spec = MODELS[k]
    kw = dict(trust_remote_code=True) if spec['trc'] else {}
    m = SentenceTransformer(spec['id'], device=dev, **kw)
    p = spec['prefix']
    E = {d: m.encode([p + s for s in S_[d]], batch_size=spec.get('bs', 64),
                     normalize_embeddings=True, show_progress_bar=False).astype('float32')
         for d in ('arday', 'zwoz')}
    del m
    rows = {'within_arday': score(topk_within(E['arday'], BUDGET['within_arday']),
                                  S_['arday'], S_['arday']),
            'within_zwoz': score(topk_within(E['zwoz'], BUDGET['within_zwoz']),
                                 S_['zwoz'], S_['zwoz']),
            'cross': score(topk_cross(E['arday'], E['zwoz'], BUDGET['cross']),
                           S_['arday'], S_['zwoz'])}
    tab[k] = rows
    for nm, r in rows.items():
        print(f"{k:8} {nm:16} {r['n']:5d} {r['jac_med']:12.3f} {r['run_med']:9.1f} "
              f"{r['run_max']:8d} {r['pct_run12']:9.1f}% {r['cos_min']:8.3f}")
    print()
OUT['rank_matched_4_3'] = {'budget': BUDGET, 'table': tab}
print('published 4.3 (MiniLM @ raw cos>=0.90):')
print('  within Arday  122  jac 0.292  run 4.0   16.4%')
print('  within Zwoz   280  jac 0.471  run 7.5   32.1%')
print('  cross         134  jac 0.631  run 11.5  50.0%')

json.dump(OUT, open(os.path.join(RES, 'lex_matched.json'), 'w'), indent=1)
print('\nwrote results/lex_matched.json')
