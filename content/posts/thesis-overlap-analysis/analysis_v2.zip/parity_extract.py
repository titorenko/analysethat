#!/usr/bin/env python3
"""Extraction gate: reproduce the published corpus sizes exactly, before any GPU work.

Published targets (article Table in section 2):
    arday 146,201 raw words -> 4,259 sentences
    zwoz  134,983            -> 2,605
    ctrl1  79,455            -> 1,837
    ctrl2  85,674            -> 2,492
and derived: focal pairs 11,094,695 (11.09M); control pairs 34,292,060 (34.29M).
"""
import json, sys, subprocess
sys.path.insert(0, r'C:\kostya\blog\analysis-v2')
from pipeline import DOCS, FOCAL, prepare, raw_wordcount

TARGET = {'arday': (146201, 4259), 'zwoz': (134983, 2605),
          'ctrl1': (79455, 1837), 'ctrl2': (85674, 2492)}

print('pdftotext:', subprocess.run(['pdftotext', '-v'], capture_output=True,
                                   text=True).stderr.splitlines()[0])
print()
S, ok = {}, True
for k in DOCS:
    rw = raw_wordcount(k)
    S[k] = prepare(k, verbose=False)
    tw, ts = TARGET[k]
    dw, ds = rw - tw, len(S[k]) - ts
    flag = 'OK ' if (dw == 0 and ds == 0) else 'DIFF'
    ok &= (dw == 0 and ds == 0)
    print(f'  {flag} {k:6} words {rw:>7,} (target {tw:>7,}, d={dw:+d})   '
          f'sentences {len(S[k]):>5,} (target {ts:>5,}, d={ds:+d})')

n = {k: len(v) for k, v in S.items()}
focal_pairs = n['arday'] * n['zwoz']
keys = list(DOCS)
pairs = [(x, y) for i, x in enumerate(keys) for y in keys[i + 1:]]
ctrl_pairs = sum(n[x] * n[y] for x, y in pairs if (x, y) != FOCAL)
print(f'\n  focal pairs   {focal_pairs:>12,}  (published 11,094,695 = 11.09M)')
print(f'  control pairs {ctrl_pairs:>12,}  (published 34,292,060 = 34.29M)')
print(f'\nEXTRACTION PARITY: {"PASS" if ok else "FAIL"}')

json.dump({k: v for k, v in S.items()}, open('sentences.json', 'w', encoding='utf-8'))
print('wrote sentences.json')
