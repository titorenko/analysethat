#!/usr/bin/env python3
"""Content-level extraction gate.

Sentence COUNTS matching is necessary but not sufficient. This checks that the
actual sentence STRINGS match what the published article used, by parsing the
185 matched pairs out of the published appendix and requiring every one of them
to appear verbatim in our extracted corpora.

Read-only against the published site (never writes there).
"""
import json, re, sys

APPENDIX = r'C:\kostya\blog\analysethat\content\posts\thesis-overlap-appendix.md'
S = json.load(open(r'C:\kostya\blog\analysis-v2\work\sentences.json', encoding='utf-8'))

txt = open(APPENDIX, encoding='utf-8').read()

# entries look like:  ### 12. cos=0.9971  jac=0.94  [--]
#                     **Arday 2015:** <sentence>
#                     **Zwozdiak-Myers 2009:** <sentence>
ent = re.findall(
    r'### \d+\. cos=([\d.]+)\s+jac=([\d.]+)\s+\[(..)\]\s*\n+'
    r'\*\*Arday 2015:\*\* (.+?)\n+'
    r'\*\*Zwozdiak-Myers 2009:\*\* (.+?)\n', txt)
print(f'parsed {len(ent)} published pairs from appendix (expect 185)')

A = {s: i for i, s in enumerate(S['arday'])}
Z = {s: i for i, s in enumerate(S['zwoz'])}

miss_a = [e[3] for e in ent if e[3] not in A]
miss_z = [e[4] for e in ent if e[4] not in Z]
print(f'  Arday sentences found verbatim in our corpus: {len(ent)-len(miss_a)}/{len(ent)}')
print(f'  Zwoz  sentences found verbatim in our corpus: {len(ent)-len(miss_z)}/{len(ent)}')
for m in miss_a[:5]: print('   MISS-A:', m[:160])
for m in miss_z[:5]: print('   MISS-Z:', m[:160])

pairs = [{'cos_pub': float(c), 'jac_pub': float(j), 'flags': f,
          'a': a, 'z': z, 'ai': A.get(a, -1), 'zi': Z.get(z, -1)}
         for c, j, f, a, z in ent]
json.dump(pairs, open(r'C:\kostya\blog\analysis-v2\work\published_185.json', 'w',
                      encoding='utf-8'), indent=1)
print(f'\nwrote published_185.json ({len(pairs)} pairs)')
ok = not miss_a and not miss_z and len(ent) == 185
print(f'CONTENT PARITY: {"PASS" if ok else "FAIL"}')
