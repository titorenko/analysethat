#!/usr/bin/env python3
"""
Extraction / segmentation / similarity primitives.

Copied VERBATIM from C:\\kostya\\blog\\brief\\overlap_analysis.py (the published
pipeline) except that fetch() never downloads -- the four PDFs are mirrored
locally as arday.pdf / zwoz.pdf / ctrl1.pdf / ctrl2.pdf in the working dir.

Freezing this file is the point: across the whole v2 study the ONLY variable is
the sentence encoder. Do not tidy anything here.
"""

import os, re, subprocess, unicodedata

DOCS = {
    'arday': ('local', 'Arday 2015, PhD, Liverpool John Moores'),
    'zwoz':  ('local', 'Zwozdiak-Myers 2009, PhD, Brunel'),
    'ctrl1': ('local', 'Kushkiev 2022, EdD, Sheffield (near control)'),
    'ctrl2': ('local', 'Alhumaidan 2025, PhD, York (far control)'),
}
FOCAL = ('arday', 'zwoz')

STOP = set('''a an the and or but if of to in on at by for with from as is are was were be been
being it its this that these those which who whom whose what when where how why not no nor so
than then there here their they them he she his her you your we our us i me my can could will
would shall should may might must do does did done have has had having also more most such some
any all each other into within between during through about over under further'''.split())

ABBREV = {'e.g','i.e','cf','et al','etc','vs','pp','ed','eds','vol','no','fig',
          'dr','prof','mr','mrs','ms','st','ch','p','al','ibid','viz','esp'}


# --------------------------------------------------------------------------
# 1. Acquire and extract   (fetch() de-networked; pdftotext call identical)
# --------------------------------------------------------------------------
def fetch(key):
    url, label = DOCS[key]
    pdf, txt = f'{key}.pdf', f'{key}.txt'
    if not os.path.exists(txt):
        if not os.path.exists(pdf):
            raise FileNotFoundError(f'{pdf} missing -- mirrors must be copied in, no downloads')
        subprocess.run(['pdftotext', pdf, txt], check=True)
    return open(txt, encoding='utf-8', errors='ignore').read()


def clean(t):
    """Strip TOC, bibliography, page furniture; de-hyphenate; reflow."""
    t = unicodedata.normalize('NFKD', t).replace('\x0c', '\n')
    t = re.sub(r'[\u2018\u2019]', "'", t)
    t = re.sub(r'[\u201c\u201d]', '"', t)
    t = re.sub(r'[\u2013\u2014]', '-', t)
    t = '\n'.join(l for l in t.split('\n') if not re.search(r'\.{4,}', l))  # TOC
    cut = None
    for m in re.finditer(r'\n\s*(References|Bibliography|REFERENCES|BIBLIOGRAPHY)\s*\n', t):
        if m.start() > len(t) * 0.55:
            cut = m.start(); break
    if cut: t = t[:cut]
    keep = [l.strip() for l in t.split('\n')
            if not re.fullmatch(r'[\divxlcIVXLC\s\-\.]{0,8}', l.strip())]
    t = '\n'.join(keep)
    t = re.sub(r'(\w)-\n(\w)', r'\1\2', t)      # de-hyphenate line breaks
    t = re.sub(r'\n(?=[a-z,;])', ' ', t)        # continuation lines
    return re.sub(r'[ \t]+', ' ', t)


def sentences(t):
    t = re.sub(r'\n+', ' ', t)
    out, buf = [], []
    for tok in re.split(r'(?<=[.!?])\s+', t):
        buf.append(tok)
        last = tok.rstrip().split()
        w = re.sub(r'[^A-Za-z\.]', '', last[-1]).lower().rstrip('.') if last else ''
        if w in ABBREV or re.fullmatch(r'[A-Z]', w or ''):
            continue
        out.append(' '.join(buf).strip()); buf = []
    if buf: out.append(' '.join(buf).strip())
    return out


def prepare(key, verbose=True):
    raw = fetch(key)
    sents = sentences(clean(raw))
    keep, seen = [], set()
    for s in sents:
        wc = len(s.split())
        if wc < 10 or wc > 120: continue
        if sum(c.isalpha() or c.isspace() for c in s) / max(len(s), 1) < 0.80: continue
        k = re.sub(r'\W+', '', s.lower())
        if k in seen: continue
        seen.add(k); keep.append(s)
    if verbose:
        print(f'  {DOCS[key][1]}: {len(raw.split()):,} words -> {len(keep):,} sentences')
    return keep


def raw_wordcount(key):
    return len(fetch(key).split())


# --------------------------------------------------------------------------
# 2. Similarity primitives
# --------------------------------------------------------------------------
def words(s):   return re.findall(r"[a-z']+", s.lower().replace('\u201f', "'"))
def content(s): return set(w for w in re.findall(r'[a-z]+', s.lower())
                           if w not in STOP and len(w) > 2)


def longest_run(a, b):
    """Longest run of identical consecutive words. Topic-immune; the key statistic."""
    A_, B_ = words(a), words(b)
    best, prev = 0, [0] * (len(B_) + 1)
    for i in range(1, len(A_) + 1):
        cur, ai = [0] * (len(B_) + 1), A_[i - 1]
        for j in range(1, len(B_) + 1):
            if ai == B_[j - 1]:
                cur[j] = prev[j - 1] + 1
                best = max(best, cur[j])
        prev = cur
    return best
