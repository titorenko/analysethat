#!/usr/bin/env python3
"""Dump the exact focal sentence pairs sharing >=12 identical consecutive words,
found WITHOUT any embedding model, and mark which ones the published MiniLM
cos>=0.90 gate would have caught.  Writes results/free_runs_12.json + .csv"""
import csv, json, os, sys
from collections import defaultdict
sys.path.insert(0, r'C:\kostya\blog\analysis-v2')
from pipeline import words, longest_run, content

ROOT = r'C:\kostya\blog\analysis-v2'
S_ = json.load(open(os.path.join(ROOT, 'work', 'sentences.json'), encoding='utf-8'))
pub = json.load(open(os.path.join(ROOT, 'work', 'published_185.json'), encoding='utf-8'))
pub_set = {(p['ai'], p['zi']) for p in pub}

N = 12
def index(sents, n):
    d = defaultdict(set)
    for i, s in enumerate(sents):
        w = words(s)
        for k in range(len(w) - n + 1):
            d[tuple(w[k:k + n])].add(i)
    return d

A, Z = index(S_['arday'], N), index(S_['zwoz'], N)
pairs = set()
for g, ii in A.items():
    jj = Z.get(g)
    if jj:
        pairs.update((i, j) for i in ii for j in jj)

rows = []
for i, j in sorted(pairs):
    a, z = S_['arday'][i], S_['zwoz'][j]
    r = longest_run(a, z)
    jac = len(content(a) & content(z)) / max(1, len(content(a) | content(z)))
    rows.append({'ai': i, 'zi': j, 'run': r, 'jac': round(jac, 3),
                 'in_published_185': (i, j) in pub_set,
                 'arday': a, 'zwoz': z})
rows.sort(key=lambda r: -r['run'])
json.dump(rows, open(os.path.join(ROOT, 'results', 'free_runs_12.json'), 'w',
                     encoding='utf-8'), indent=1)
with open(os.path.join(ROOT, 'results', 'free_runs_12.csv'), 'w', newline='',
          encoding='utf-8') as f:
    w_ = csv.DictWriter(f, fieldnames=list(rows[0]))
    w_.writeheader(); w_.writerows(rows)

print(f'{len(rows)} focal pairs share a run of >= {N} identical consecutive words')
print(f'  of these, {sum(r["in_published_185"] for r in rows)} appear in the published 185 list')
print(f'  run>=20: {sum(r["run"]>=20 for r in rows)}   run>=30: {sum(r["run"]>=30 for r in rows)}')
import numpy as np
na = len(S_['arday'])
d = [0]*10
for r in rows: d[min(9, int(10*r['ai']/na))] += 1
print('  by Arday decile:', d)
print('\nTop 12 by run length:')
for r in rows[:12]:
    print(f"  run={r['run']:3d} jac={r['jac']:.2f} pub185={r['in_published_185']}")
    print(f"    A: {r['arday'][:190]}")
    print(f"    Z: {r['zwoz'][:190]}")
print('\nwrote results/free_runs_12.json / .csv')
