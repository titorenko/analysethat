#!/usr/bin/env python3
"""
Cross-model consensus / divergence analysis.

The one thing you must NOT do when comparing encoders is compare them at a fixed
raw cosine.  Each model has its own similarity calibration -- bge-large's mean
cross-document cosine is 0.52 where MiniLM's is 0.28 -- so "cos >= 0.85" is a
different event under each model.  Everything here is therefore matched on one
of two model-independent scales:

  RANK-MATCHED  take each model's top-N deduplicated focal pairs (N = 185, the
                published count).  Immune to calibration entirely.
  RATE-MATCHED  take each model's own threshold at a fixed control false-positive
                rate, read off the 34.29M known-independent control pairs.

Raw-threshold numbers are printed once, explicitly labelled, to show why they
cannot be used.

Also scores every model against the 179-pair MODEL-FREE gold set (focal pairs
sharing >= 12 identical consecutive words, found with no encoder at all).
"""
import csv, json, os, re, sys
import numpy as np
from scipy.stats import poisson, chi2

sys.path.insert(0, r'C:\kostya\blog\analysis-v2')
from pipeline import longest_run, content

ROOT = r'C:\kostya\blog\analysis-v2'
RES = os.path.join(ROOT, 'results')
ORDER = ['minilm', 'mpnet', 'bge', 'e5', 'gte']          # e5np handled separately
M = {k: json.load(open(os.path.join(RES, f'{k}.json'))) for k in ORDER
     if os.path.exists(os.path.join(RES, f'{k}.json'))}
ORDER = [k for k in ORDER if k in M]
S_ = json.load(open(os.path.join(ROOT, 'work', 'sentences.json'), encoding='utf-8'))
pub = json.load(open(os.path.join(ROOT, 'work', 'published_185.json'), encoding='utf-8'))
gold = json.load(open(os.path.join(RES, 'free_runs_12.json'), encoding='utf-8'))
free = json.load(open(os.path.join(RES, 'model_free_runs.json')))
PUB = {(p['ai'], p['zi']) for p in pub}
GOLD = {(g['ai'], g['zi']) for g in gold}
OUT = {}

hr = lambda s: print('\n' + '=' * 78 + f'\n{s}\n' + '=' * 78)

# --------------------------------------------------------------------------
hr('0. MODEL INVENTORY')
print(f"{'model':8} {'id':38} {'dim':>5} {'prefix':10} {'enc_s':>6} {'tot_s':>7}")
for k in ORDER:
    m = M[k]
    print(f"{k:8} {m['model_id']:38} {m['dim']:5d} {repr(m['prefix']):10} "
          f"{m['encode_seconds']:6.1f} {m['total_seconds']:7.1f}")
OUT['inventory'] = {k: {f: M[k][f] for f in
                        ('model_id', 'dim', 'prefix', 'device', 'encode_seconds',
                         'total_seconds', 'identity_gate_cos')} for k in ORDER}

# --------------------------------------------------------------------------
hr('1. WHY RAW THRESHOLDS DO NOT TRANSFER  (do not read these as a comparison)')
print(f"{'model':8} {'within-A mean':>13} {'cross mean':>11} {'cross p99.99':>13} "
      f"{'n>=.85 dedup':>13} {'hi_n@.90':>9} {'run12_n@.90':>12}")
for k in ORDER:
    m = M[k]
    print(f"{k:8} {m['within']['arday']['mean']:13.3f} {m['cross_focal_dist']['mean']:11.3f} "
          f"{m['cross_focal_dist']['p99.99']:13.3f} {m['n_dedup>=0.85']:13d} "
          f"{m['pairs']['ardayxzwoz']['hi_n']:9d} "
          f"{m['pairs']['ardayxzwoz']['run12_n']:12.0f}")
print('\nThe mean cosine moves by ~0.53 across these models.  A fixed 0.85 or 0.90')
print('cut therefore selects a different quantile of each model and the counts')
print('above are NOT comparable.  Everything below is rank- or rate-matched.')
OUT['raw_incomparable'] = {k: {'within_arday_mean': M[k]['within']['arday']['mean'],
                               'cross_mean': M[k]['cross_focal_dist']['mean'],
                               'cross_p99.99': M[k]['cross_focal_dist']['p99.99'],
                               'n_dedup>=0.85': M[k]['n_dedup>=0.85'],
                               'hi_n_at_raw_0.90': M[k]['pairs']['ardayxzwoz']['hi_n'],
                               'run12_n_at_raw_0.90': M[k]['pairs']['ardayxzwoz']['run12_n'],
                               'within_lex_capped': {d: M[k]['within_lex'][d]['capped']
                                                     for d in M[k]['within_lex']},
                               'focal_hi_capped': M[k]['pairs']['ardayxzwoz']['hi_capped']}
                          for k in ORDER}

# --------------------------------------------------------------------------
hr('2. RANK-MATCHED CONSENSUS  (each model\'s top-185 deduplicated focal pairs)')
N = 185
top = {k: [(d['ai'], d['zi']) for d in M[k]['dedup_top'][:N]] for k in ORDER}
tops = {k: set(v) for k, v in top.items()}
print(f'  overlap with the PUBLISHED 185 list:')
for k in ORDER:
    ov = len(tops[k] & PUB)
    print(f'    {k:8} {ov:3d}/185  ({100*ov/185:.1f}%)')
print(f'\n  pairwise overlap (|A n B| out of 185):')
print('           ' + ' '.join(f'{k:>8}' for k in ORDER))
for a in ORDER:
    print(f'    {a:8} ' + ' '.join(f'{len(tops[a] & tops[b]):8d}' for b in ORDER))
core = set.intersection(*tops.values())
anym = set.union(*tops.values())
print(f'\n  in ALL {len(ORDER)} models\' top-185: {len(core)}')
print(f'  in AT LEAST ONE model\'s top-185: {len(anym)}')
print(f'  core pairs also in the published 185: {len(core & PUB)}')
print(f'  published pairs in NO model\'s top-185: {len(PUB - anym)}')
OUT['rank_matched'] = {
    'N': N,
    'overlap_with_published': {k: len(tops[k] & PUB) for k in ORDER},
    'pairwise': {a: {b: len(tops[a] & tops[b]) for b in ORDER} for a in ORDER},
    'n_core_all_models': len(core), 'n_union': len(anym),
    'core_in_published': len(core & PUB),
    'published_in_no_model': len(PUB - anym)}

# --------------------------------------------------------------------------
hr('3. RATE-MATCHED CONSENSUS  (each model at its own control-FP-rate threshold)')
print('  top1 is degenerate: the largest control similarity is the thesis')
print('  declaration boilerplate, a GENUINE duplicate, not a false positive.')
print('  Lead with top3 / top10.\n')
print(f"{'model':8} {'top3 thr':>9} {'n focal':>8} {'enrich':>8} | "
      f"{'top10 thr':>10} {'n focal':>8} {'enrich':>8} | {'top ctrl pair cos':>17}")
for k in ORDER:
    m = M[k]; r3 = m['rate_matched']['top3']; r10 = m['rate_matched']['top10']
    tc = m.get('top_control_pair', {})
    print(f"{k:8} {r3['threshold']:9.4f} {r3['focal_n']:8d} {r3['enrichment']:8.0f} | "
          f"{r10['threshold']:10.4f} {r10['focal_n']:8d} {r10['enrichment']:8.0f} | "
          f"{tc.get('cos', float('nan')):17.4f}")
print('\n  top control pair under each model (the null validating itself):')
for k in ORDER:
    tc = M[k].get('top_control_pair')
    if tc:
        print(f"    {k:8} [{tc['pair']}] cos={tc['cos']:.4f}: {tc['a'][:88]}")

rm_sets = {}
for k in ORDER:
    t = M[k]['rate_matched']['top10']['threshold']
    rm_sets[k] = {(d['ai'], d['zi']) for d in M[k]['dedup_top'] if d['cos'] >= t}
print(f'\n  deduplicated pairs above each model\'s top10 (0.29 FP/M) threshold:')
for k in ORDER:
    print(f'    {k:8} {len(rm_sets[k]):5d} dedup pairs   '
          f'({len(rm_sets[k] & PUB):3d} of them in the published 185)')
core_rm = set.intersection(*rm_sets.values())
any_rm = set.union(*rm_sets.values())
print(f'\n  in ALL models at matched FP rate: {len(core_rm)}  '
      f'(of which {len(core_rm & PUB)} published)')
print(f'  in AT LEAST ONE: {len(any_rm)}  (of which {len(any_rm & PUB)} published)')
OUT['rate_matched'] = {
    'per_model': {k: {'top3': M[k]['rate_matched']['top3'],
                      'top10': M[k]['rate_matched']['top10'],
                      'top30': M[k]['rate_matched']['top30'],
                      'top_control_pair': M[k].get('top_control_pair'),
                      'n_dedup_above_top10': len(rm_sets[k]),
                      'n_dedup_above_top10_published': len(rm_sets[k] & PUB)}
                  for k in ORDER},
    'n_core': len(core_rm), 'n_core_published': len(core_rm & PUB),
    'n_union': len(any_rm), 'n_union_published': len(any_rm & PUB)}

# --------------------------------------------------------------------------
hr('4. SURVIVAL OF THE PUBLISHED 185')
print(f"{'model':8} {'mean cos':>9} {'min cos':>8} | "
      f"{'>= top3 thr':>12} {'>= top10 thr':>13} {'>= top30 thr':>13} | {'in top-185':>11}")
surv = {}
for k in ORDER:
    m = M[k]; c = np.array(m['published185']['cos']); rm = m['rate_matched']
    row = {t: int((c >= rm[t]['threshold']).sum()) for t in ('top3', 'top10', 'top30')}
    row['mean'] = float(c.mean()); row['min'] = float(c.min())
    row['in_top185'] = len(tops[k] & PUB)
    surv[k] = row
    print(f"{k:8} {row['mean']:9.3f} {row['min']:8.3f} | {row['top3']:12d} "
          f"{row['top10']:13d} {row['top30']:13d} | {row['in_top185']:11d}")
allc = np.array([M[k]['published185']['cos'] for k in ORDER])
rmthr = np.array([[M[k]['rate_matched']['top10']['threshold']] for k in ORDER])
n_all = int((allc >= rmthr).all(axis=0).sum())
n_none = int((allc < rmthr).all(axis=0).sum())
print(f'\n  published pairs above the top10 rate-matched threshold in ALL models : {n_all}/185')
print(f'  published pairs above it in NO model                                : {n_none}/185')
OUT['published185_survival'] = {'per_model': surv, 'all_models': n_all, 'no_model': n_none}
# which published pairs are weakest -- most likely to be topical noise
weak = np.argsort(allc.mean(axis=0))[:12]
OUT['published185_weakest'] = [
    {'rank': int(i), 'mean_cos_across_models': float(allc[:, i].mean()),
     'cos_published_minilm': pub[i]['cos_pub'], 'jac_published': pub[i]['jac_pub'],
     'run': longest_run(pub[i]['a'], pub[i]['z']),
     'arday': pub[i]['a'][:220], 'zwoz': pub[i]['z'][:220]} for i in weak]
print('\n  12 weakest published pairs by mean cosine across models (candidates for')
print('  "topical only" -- the published classification put 39 pairs in that band):')
for e in OUT['published185_weakest'][:6]:
    print(f"    mean={e['mean_cos_across_models']:.3f} minilm={e['cos_published_minilm']:.3f} "
          f"run={e['run']:2d} jac={e['jac_published']:.2f}")

# --------------------------------------------------------------------------
hr('5. RECALL AGAINST THE MODEL-FREE GOLD SET (179 pairs, run >= 12 words)')
print('  This set was built with no encoder, so no model can influence it.')
print('  It is verbatim-biased -- it measures VERBATIM recall, not paraphrase recall.\n')
print(f"{'model':8} {'mean cos':>9} {'min':>7} | {'@raw .85':>9} {'@top3':>7} "
      f"{'@top10':>7} {'@top30':>7} | {'% @top10':>9}")
for k in ORDER:
    g = M[k].get('gold_recall')
    if not g: print(f'{k:8} (no gold_recall block)'); continue
    print(f"{k:8} {g['mean_cos']:9.3f} {g['min_cos']:7.3f} | {g['recall>=0.85']:9d} "
          f"{g['recall_ratematched_top3']:7d} {g['recall_ratematched_top10']:7d} "
          f"{g['recall_ratematched_top30']:7d} | "
          f"{100*g['recall_ratematched_top10']/g['n_gold']:8.1f}%")
OUT['gold_recall'] = {k: M[k].get('gold_recall') and
                      {f: M[k]['gold_recall'][f] for f in M[k]['gold_recall'] if f != 'cos'}
                      for k in ORDER}

# --- e5 prefix decided by measurement, not by reading the model card ------
p1 = os.path.join(RES, 'e5.json'); p0 = os.path.join(RES, 'e5np.json')
if os.path.exists(p1) and os.path.exists(p0):
    A, B = json.load(open(p1)), json.load(open(p0))
    print('\n  e5-large-v2 PREFIX TEST (same weights, prefix is the only difference):')
    print(f"{'variant':22} {'gold mean cos':>13} {'gold@top10':>11} {'pub185 mean':>12} "
          f"{'top3 enrich':>12}")
    for nm, X in [("'query: ' both sides", A), ("no prefix", B)]:
        print(f"{nm:22} {X['gold_recall']['mean_cos']:13.3f} "
              f"{X['gold_recall']['recall_ratematched_top10']:11d} "
              f"{X['published185']['mean']:12.3f} "
              f"{X['rate_matched']['top3']['enrichment']:12.0f}")
    OUT['e5_prefix_test'] = {
        'query_prefix': {'gold_mean_cos': A['gold_recall']['mean_cos'],
                         'gold_at_top10': A['gold_recall']['recall_ratematched_top10'],
                         'pub185_mean': A['published185']['mean'],
                         'top3_enrichment': A['rate_matched']['top3']['enrichment']},
        'no_prefix': {'gold_mean_cos': B['gold_recall']['mean_cos'],
                      'gold_at_top10': B['gold_recall']['recall_ratematched_top10'],
                      'pub185_mean': B['published185']['mean'],
                      'top3_enrichment': B['rate_matched']['top3']['enrichment']}}

# --------------------------------------------------------------------------
hr('6. NEAR-IDENTITY AND THE POISSON TEST, PER MODEL')
print(f"{'model':8} {'focal n@.999':>12} {'blocks':>7} {'ctrl n':>7} {'lambda':>8} "
      f"{'lam_hi':>8} {'log10 p_cons_block':>19}")
for k in ORDER:
    p = M[k]['poisson_raw999']
    print(f"{k:8} {p['focal_n']:12d} {p['blocks']:7d} {p['null_n']:7d} {p['lambda']:8.3f} "
          f"{p['lambda_hi']:8.3f} {p['log10p_cons_block']:19.2f}")
print('\n  same test at each model\'s rate-matched top3 threshold:')
for k in ORDER:
    p = M[k]['poisson_ratematched']
    print(f"    {k:8} thr={p['threshold']:.4f} focal={p['focal_n']:5d} "
          f"blocks={p['blocks']:4d} lam_hi={p['lambda_hi']:.3f} "
          f"p_cons_block={p['p_cons_block']:.2e}")
OUT['poisson'] = {k: {'raw999': M[k]['poisson_raw999'],
                      'ratematched': M[k]['poisson_ratematched']} for k in ORDER}

# --------------------------------------------------------------------------
hr('7. THE MODEL-FREE RESULT  (no encoder anywhere in this section)')
f12 = free['by_n']['12']['_test']
lam_hi = f12['lambda_hi']
p_block = float(poisson.sf(f12['focal_blocks'] - 1, lam_hi))
log10_block = float(poisson.logsf(f12['focal_blocks'] - 1, lam_hi) / np.log(10))
log10_point = float(poisson.logsf(f12['focal_n'] - 1, f12['lambda']) / np.log(10))
# and the published, MiniLM-GATED version of the same statistic, for comparison
pub67 = M['minilm']['pairs']['ardayxzwoz']['run12_n']
print(f"  published (MiniLM-gated at cos>=0.90) : {pub67:.0f} focal pairs with run >= 12")
print(f"  exact, unconditional, all 11.09M pairs: {f12['focal_n']} focal pairs "
      f"({f12['focal_blocks']} spatially independent blocks)")
print(f"  controls, all 34.29M pairs            : {f12['null_n']} "
      f"(the declaration boilerplate, run 16)")
print(f"  expected in focal under the null      : {f12['lambda']:.3f} "
      f"(upper 95% CI {lam_hi:.3f})")
print(f"  log10 p, point estimate               : {log10_point:.1f}")
print(f"  log10 p, upper CI + block-corrected   : {log10_block:.1f}   "
      f"(p = {p_block:.2e})")
print(f"\n  longest identical run per document pair (model-free): {free['longest_run']}")
print('\n  by run length:')
print(f"    {'n':>4} {'focal pairs':>12} {'blocks':>7} {'controls':>9} {'log10 p (cons,block)':>21}")
mfree = {}
for n, row in free['by_n'].items():
    t = row['_test']
    lp = (float(poisson.logsf(t['focal_blocks'] - 1, t['lambda_hi']) / np.log(10))
          if t['focal_blocks'] else 0.0)
    print(f"    {n:>4} {t['focal_n']:12d} {t['focal_blocks']:7d} {t['null_n']:9d} {lp:21.1f}")
    mfree[n] = {'focal_n': t['focal_n'], 'blocks': t['focal_blocks'],
                'ctrl_n': t['null_n'], 'lambda': t['lambda'],
                'lambda_hi': t['lambda_hi'], 'log10p_cons_block': lp}
OUT['model_free'] = {'by_n': mfree, 'longest_run': free['longest_run'],
                     'published_gated_run12': pub67,
                     'exact_run12': f12['focal_n'], 'exact_run12_blocks': f12['focal_blocks'],
                     'log10p_point': log10_point, 'log10p_cons_block': log10_block}

# --------------------------------------------------------------------------
hr('8. EXTENT ACROSS MODELS')
print('  (a) published estimator, published raw thresholds -- NOT comparable across models')
print(f"    {'model':8} " + ' '.join(f'{t:>8}' for t in ('0.75', '0.80', '0.85', '0.90', '0.95')))
for k in ORDER:
    print(f"    {k:8} " + ' '.join(f"{e['words']:8.0f}" for e in M[k]['extent'][:5]))
print('\n  (b) EXACT best-match (no subsampling), same raw thresholds')
for k in ORDER:
    if 'extent_exact' in M[k]:
        print(f"    {k:8} " + ' '.join(f"{e['words']:8.0f}" for e in M[k]['extent_exact'][:5]))
print('\n  (c) RATE-MATCHED: threshold set so the control baseline is a fixed number')
print('      of false-positive Arday sentences.  This IS comparable across models.')
print(f"    {'model':8} " + ' '.join(f'{"base~"+str(int(b)):>10}'
                                     for b in (5, 10, 25, 50)))
for k in ORDER:
    src = M[k].get('extent_exact_ratematched') or M[k]['extent_ratematched']
    print(f"    {k:8} " + ' '.join(f"{e['words']:10.0f}" for e in src))
print(f"\n    {'model':8} " + ' '.join(f'{"thr@"+str(int(b)):>10}' for b in (5, 10, 25, 50)))
for k in ORDER:
    src = M[k].get('extent_exact_ratematched') or M[k]['extent_ratematched']
    print(f"    {k:8} " + ' '.join(f"{e['thr']:10.4f}" for e in src))
OUT['extent'] = {k: {'published_estimator': M[k]['extent'],
                     'exact': M[k].get('extent_exact'),
                     'rate_matched_subsampled': M[k]['extent_ratematched'],
                     'rate_matched_exact': M[k].get('extent_exact_ratematched')}
                 for k in ORDER}

# --------------------------------------------------------------------------
hr('9. SECTION CONCENTRATION ACROSS MODELS (rate-matched)')
print(f"    {'model':8} {'thr':>7} {'dec 1-2':>18} {'dec 9-10':>18} {'dec 3-8':>18}")
for k in ORDER:
    s = M[k]['sections_ratematched']
    print(f"    {k:8} {s['thr']:7.4f} "
          + ' '.join(f"{s[d]['n']:5d}/{s[d]['of']:<5d}{s[d]['pct']:6.1f}%"
                     for d in ('deciles_1_2', 'deciles_9_10', 'deciles_3_8')))
print('\n  published (MiniLM @0.80): 177/852 = 20.8% | 60/851 = 7.1% | 29/2556 = 1.1%')
OUT['sections'] = {k: {'published_raw_0.80': M[k]['sections'],
                       'rate_matched': M[k]['sections_ratematched']} for k in ORDER}

# --------------------------------------------------------------------------
hr('10. WHAT STRONGER MODELS FIND THAT MiniLM MISSED')
CIT = re.compile(r'\(\s*[A-Z][A-Za-z\'\-]+[^()]{0,80}?(19|20)\d\d[a-z]?\s*[,;:)]|'
                 r'[A-Z][A-Za-z\'\-]+\s+\(\s*(19|20)\d\d')
QUO = re.compile(r'["\u201c\u201d\u2018\u2019]')
strong = [k for k in ORDER if k != 'minilm']
mini_rm = rm_sets['minilm']
# candidate = above the rate-matched top10 threshold in EVERY stronger model,
# but not in MiniLM's rate-matched set and not in the published 185
cand = set.intersection(*[rm_sets[k] for k in strong]) - mini_rm - PUB
rows = []
for a, z in cand:
    sa, sz = S_['arday'][a], S_['zwoz'][z]
    r = longest_run(sa, sz)
    j = len(content(sa) & content(sz)) / max(1, len(content(sa) | content(sz)))
    cos = {k: next((d['cos'] for d in M[k]['dedup_top'] if d['ai'] == a and d['zi'] == z), None)
           for k in ORDER}
    rows.append({'ai': a, 'zi': z, 'run': r, 'jac': round(j, 3),
                 'arday_has_citation': bool(CIT.search(sa)),
                 'arday_has_quote': bool(QUO.search(sa)),
                 'in_gold_run12': (a, z) in GOLD,
                 'cos': {k: (round(v, 4) if v is not None else None) for k, v in cos.items()},
                 'arday': sa, 'zwoz': sz})
rows.sort(key=lambda r: (-r['run'], -r['jac']))
print(f'  {len(cand)} focal pairs clear the matched FP-rate bar in ALL {len(strong)} stronger')
print(f'  models but not in MiniLM, and are not among the published 185.')
print(f"    with run >= 8 identical consecutive words : "
      f"{sum(r['run'] >= 8 for r in rows)}")
print(f"    with run >= 12 (i.e. in the model-free gold set): "
      f"{sum(r['in_gold_run12'] for r in rows)}")
print(f"    run <= 3 and jaccard < 0.40 (topical noise)     : "
      f"{sum(r['run'] <= 3 and r['jac'] < 0.40 for r in rows)}")
print(f"    Arday sentence carries no citation and no quote : "
      f"{sum(not r['arday_has_citation'] and not r['arday_has_quote'] for r in rows)}")
OUT['new_pairs'] = {'n_candidates': len(cand),
                    'n_run_ge_8': sum(r['run'] >= 8 for r in rows),
                    'n_in_gold': sum(r['in_gold_run12'] for r in rows),
                    'n_noise': sum(r['run'] <= 3 and r['jac'] < 0.40 for r in rows),
                    'n_uncited_unquoted': sum(not r['arday_has_citation']
                                              and not r['arday_has_quote'] for r in rows),
                    'rows': rows}
print('\n  --- TOP 8 BY SHARED RUN (the real finds) ---')
for r in rows[:8]:
    print(f"  run={r['run']:3d} jac={r['jac']:.2f} cite={r['arday_has_citation']} "
          f"quote={r['arday_has_quote']} cos={r['cos']}")
    print(f"    Z: {r['zwoz'][:230]}")
    print(f"    A: {r['arday'][:230]}")
print('\n  --- BOTTOM 5 BY SHARED RUN (topical noise, for honesty) ---')
for r in rows[-5:]:
    print(f"  run={r['run']:3d} jac={r['jac']:.2f} cos={r['cos']}")
    print(f"    Z: {r['zwoz'][:180]}")
    print(f"    A: {r['arday'][:180]}")

# also: what MiniLM found that the stronger models drop
lost = (mini_rm & PUB) - set.union(*[rm_sets[k] for k in strong])
OUT['published_dropped_by_all_strong'] = []
for a, z in lost:
    sa, sz = S_['arday'][a], S_['zwoz'][z]
    OUT['published_dropped_by_all_strong'].append(
        {'ai': a, 'zi': z, 'run': longest_run(sa, sz),
         'jac': round(len(content(sa) & content(sz)) /
                      max(1, len(content(sa) | content(sz))), 3),
         'arday': sa, 'zwoz': sz})
print(f'\n  published pairs MiniLM keeps at matched FP rate but ALL stronger models drop: '
      f'{len(lost)}')
for e in sorted(OUT['published_dropped_by_all_strong'], key=lambda r: -r['run'])[:4]:
    print(f"    run={e['run']:3d} jac={e['jac']:.2f}")
    print(f"      Z: {e['zwoz'][:170]}")
    print(f"      A: {e['arday'][:170]}")

# --------------------------------------------------------------------------
json.dump(OUT, open(os.path.join(RES, 'consensus.json'), 'w', encoding='utf-8'), indent=1)
if rows:
    with open(os.path.join(RES, 'new_pairs.csv'), 'w', newline='', encoding='utf-8') as fh:
        w_ = csv.writer(fh)
        w_.writerow(['ai', 'zi', 'run', 'jac', 'arday_has_citation', 'arday_has_quote',
                     'in_gold_run12'] + [f'cos_{k}' for k in ORDER] + ['arday', 'zwoz'])
        for r in rows:
            w_.writerow([r['ai'], r['zi'], r['run'], r['jac'], r['arday_has_citation'],
                         r['arday_has_quote'], r['in_gold_run12']]
                        + [r['cos'][k] for k in ORDER] + [r['arday'], r['zwoz']])
print('\nwrote results/consensus.json and results/new_pairs.csv')
