#!/usr/bin/env python3
"""
Per-model re-run of the full statistic suite from the published article.

Usage:  python run_model.py <model_key>

Extraction and segmentation are FROZEN (pipeline.py, copied verbatim from the
published script). The encoder is the only variable.

Writes results/<model_key>.json  with everything needed for the cross-model
consensus step, including the cosine of all 185 published pairs under this model.
"""
import json, os, sys, time
import numpy as np
from scipy.stats import poisson, chi2

sys.path.insert(0, r'C:\kostya\blog\analysis-v2')
from pipeline import DOCS, FOCAL, longest_run, content

ROOT = r'C:\kostya\blog\analysis-v2'
WORK = os.path.join(ROOT, 'work')
OUT = os.path.join(ROOT, 'results')
os.makedirs(OUT, exist_ok=True)

# --------------------------------------------------------------------------
# Model registry.  `prefix` is applied to BOTH sides -- this is a SYMMETRIC
# sentence-similarity task, so asymmetric query/passage prefixes are wrong here.
#   MiniLM / mpnet  : trained with no prefix at all.
#   bge-*-en-v1.5   : BGE docs say the retrieval instruction is for QUERIES in
#                     asymmetric retrieval only; for s2s similarity use no prefix.
#   e5-*            : prefixes are MANDATORY (the model saw none without them).
#                     The e5 card prescribes "query: " on both sides for
#                     symmetric tasks (STS / s2s).
#   gte-*           : trained without prefixes.
# --------------------------------------------------------------------------
MODELS = {
    'minilm':  dict(id='sentence-transformers/all-MiniLM-L6-v2',   prefix='',        dim=384,  trc=False),
    'mpnet':   dict(id='sentence-transformers/all-mpnet-base-v2',  prefix='',        dim=768,  trc=False),
    'bge':     dict(id='BAAI/bge-large-en-v1.5',                   prefix='',        dim=1024, trc=False),
    'e5':      dict(id='intfloat/e5-large-v2',                     prefix='query: ', dim=1024, trc=False),
    # e5np: SAME model, prefix deliberately removed.  Run as a control so the
    # prefix choice is settled by measurement (recall against the 179-pair
    # model-free gold set) rather than by reading the model card.
    'e5np':    dict(id='intfloat/e5-large-v2',                     prefix='',        dim=1024, trc=False),
    'gte':     dict(id='thenlper/gte-large',                       prefix='',        dim=1024, trc=False),
    'gtev15':  dict(id='Alibaba-NLP/gte-large-en-v1.5',            prefix='',        dim=1024, trc=True),
    # Scale stress-test.  1.5B params, last-token pooling.  No instruction on
    # either side: the model card's instruct template is for the QUERY side of
    # asymmetric retrieval, and applying an instruction to only one of two
    # symmetric sentences would break the symmetry this task requires.
    'qwen':    dict(id='Alibaba-NLP/gte-Qwen2-1.5B-instruct',      prefix='',        dim=1536, trc=True, bs=8),
    # Substitute scale/recency stress-test after gte-Qwen2-1.5B failed on a
    # transformers-5 incompatibility in its trust_remote_code modelling file.
    # Qwen3-Embedding is natively supported -- no custom code -- and is a much
    # newer recipe than the 2023-era 335M models.  No instruction on either
    # side, for the same symmetry reason as above.
    'qwen3':   dict(id='Qwen/Qwen3-Embedding-0.6B',                prefix='',        dim=1024, trc=False, bs=16),
}

THRESH = (0.75, 0.80, 0.85, 0.90, 0.95, 0.98, 0.99, 0.999)


def encode_all(spec, sents_by_doc, device):
    from sentence_transformers import SentenceTransformer
    kw = dict(trust_remote_code=True) if spec['trc'] else {}
    m = SentenceTransformer(spec['id'], device=device, **kw)
    print(f"  loaded {spec['id']}  max_seq_len={m.max_seq_length}  dim={m.get_sentence_embedding_dimension()}")
    p = spec['prefix']
    E, t0 = {}, time.time()
    for k, v in sents_by_doc.items():
        E[k] = m.encode([p + s for s in v], batch_size=spec.get('bs', 64), normalize_embeddings=True,
                        show_progress_bar=False).astype('float32')
    enc_s = time.time() - t0

    # --- correctness gate: identical text must score ~1.0 -------------------
    probe = ['This thesis is divided into six chapters.',
             'Replication in other subject areas can also add validity to these findings.']
    pe = m.encode([p + s for s in probe + probe], batch_size=8,
                  normalize_embeddings=True).astype('float32')
    self_cos = [float(pe[i] @ pe[i + len(probe)]) for i in range(len(probe))]
    print(f'  identity gate (cos of a sentence with itself): {["%.5f" % c for c in self_cos]}')
    del m
    return E, enc_s, self_cos, {k: 0 for k in sents_by_doc}


def within_baseline(e, gap=200):
    S = e @ e.T
    i, j = np.triu_indices(S.shape[0], k=gap)
    v = S[i, j]
    return {'mean': float(v.mean()),
            'p99': float(np.percentile(v, 99)),
            'p99.9': float(np.percentile(v, 99.9)),
            'p99.99': float(np.percentile(v, 99.99)),
            'max': float(v.max()),
            'n>=0.999': int((v >= 0.999).sum()),
            'n_pairs': int(v.size)}


def within_lexical(e, sents, thr=0.90, gap=200, cap=1200, seed=0):
    """Section 4.3 row: run/Jaccard structure of high-cos pairs WITHIN one doc."""
    S = e @ e.T
    i, j = np.triu_indices(S.shape[0], k=gap)
    m = S[i, j] >= thr
    idx = list(zip(i[m].tolist(), j[m].tolist()))
    n = len(idx)
    if not n:
        return dict(n=0, jac_med=0.0, run_med=0.0, pct_run12=0.0, capped=False)
    rng = np.random.default_rng(seed)
    capped = n > cap
    if capped:
        idx = [idx[k] for k in rng.choice(n, cap, replace=False)]
    runs = np.array([longest_run(sents[a], sents[b]) for a, b in idx])
    jacs = np.array([len(content(sents[a]) & content(sents[b])) /
                     max(1, len(content(sents[a]) | content(sents[b]))) for a, b in idx])
    return dict(n=n, jac_med=float(np.median(jacs)), run_med=float(np.median(runs)),
                run_max=int(runs.max()), pct_run12=float((runs >= 12).mean() * 100),
                capped=capped, n_scored=len(idx))


def pair_stats(S, D1, D2, thr=0.90, cap=1500, seed=0):
    flat = S.ravel(); n = S.size
    out = {'n_pairs': int(n), 'mean': float(flat.mean()), 'max': float(flat.max())}
    for t in THRESH:
        out[f'n>={t}'] = int((flat >= t).sum())
        out[f'per1M>={t}'] = float((flat >= t).sum()) / n * 1e6
    ii, jj = np.where(S >= thr)
    idx = list(zip(ii.tolist(), jj.tolist())); out['hi_n'] = len(idx)
    out['hi_capped'] = len(idx) > cap
    if idx:
        rng = np.random.default_rng(seed)
        if len(idx) > cap:
            idx = [idx[k] for k in rng.choice(len(idx), cap, replace=False)]
        out['hi_n_scored'] = len(idx)
        runs = np.array([longest_run(D1[i], D2[j]) for i, j in idx])
        jacs = np.array([len(content(D1[i]) & content(D2[j])) /
                         max(1, len(content(D1[i]) | content(D2[j]))) for i, j in idx])
        out.update(run_med=float(np.median(runs)), run_max=int(runs.max()),
                   jac_med=float(np.median(jacs)),
                   pct_run12=float((runs >= 12).mean() * 100),
                   run12_n=float((runs >= 12).mean()) * out['hi_n'],
                   run12_per1M=float((runs >= 12).mean()) * out['hi_n'] / n * 1e6)
    else:
        out.update(run_med=0.0, run_max=0, jac_med=0.0, pct_run12=0.0,
                   run12_n=0.0, run12_per1M=0.0, hi_n_scored=0)
    return out


def greedy_dedup(S, thr):
    """Each sentence used at most once, highest cosine first (as published)."""
    ii, jj = np.where(S >= thr)
    if not len(ii): return []
    v = S[ii, jj]
    order = np.argsort(-v)
    ua, uz, keep = set(), set(), []
    for k in order:
        a, z = int(ii[k]), int(jj[k])
        if a in ua or z in uz: continue
        ua.add(a); uz.add(z); keep.append((a, z, float(v[k])))
    return keep


def main():
    key = sys.argv[1]
    spec = MODELS[key]
    import torch
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f'=== {key}: {spec["id"]} on {device} ===')
    if device == 'cuda':
        print(f'  {torch.cuda.get_device_name(0)}  cc={torch.cuda.get_device_capability()}  '
              f'torch={torch.__version__} cuda={torch.version.cuda}')

    S_ = json.load(open(os.path.join(WORK, 'sentences.json'), encoding='utf-8'))
    pub = json.load(open(os.path.join(WORK, 'published_185.json'), encoding='utf-8'))
    t_all = time.time()

    E_, enc_s, self_cos, _ = encode_all(spec, S_, device)
    print(f'  encoded {sum(len(v) for v in S_.values()):,} sentences in {enc_s:.1f}s')

    R = {'model_key': key, 'model_id': spec['id'], 'prefix': spec['prefix'],
         'device': device, 'encode_seconds': enc_s, 'identity_gate_cos': self_cos,
         'dim': int(E_['arday'].shape[1]),
         'n_sent': {k: len(v) for k, v in S_.items()}}

    # ---- within-document baselines (4.1) ---------------------------------
    R['within'] = {k: within_baseline(E_[k]) for k in FOCAL}
    R['within_lex'] = {k: within_lexical(E_[k], S_[k]) for k in FOCAL}
    for k in FOCAL:
        b = R['within'][k]
        print(f"  within-{k:6} mean={b['mean']:.3f} p99.99={b['p99.99']:.3f} "
              f"max={b['max']:.3f} n>=.999={b['n>=0.999']}")

    # ---- all six document pairs (4.2) ------------------------------------
    keys = list(DOCS)
    pairs = [(x, y) for i, x in enumerate(keys) for y in keys[i + 1:]]
    R['pairs'] = {}
    ctrl_sims = []
    for x, y in pairs:
        S = E_[x] @ E_[y].T
        # focal pair scored UNCAPPED so its run stats stay exact and comparable
        # with MiniLM's exact 134; controls capped (they are tiny anyway).
        r = pair_stats(S, S_[x], S_[y], cap=(200000 if (x, y) == FOCAL else 1500))
        R['pairs'][f'{x}x{y}'] = r
        print(f"  {x[:5]}x{y[:5]:6} mean={r['mean']:.3f} max={r['max']:.4f} "
              f"hi_n={r['hi_n']:5d} run_med={r['run_med']:.1f} run_max={r['run_max']:3d} "
              f"run12_n={r['run12_n']:.0f}")
        if (x, y) != FOCAL:
            ctrl_sims.append(S.ravel())

    # ---- cross-doc (focal) aggregate percentiles for the 4.1 table -------
    S_focal = E_[FOCAL[0]] @ E_[FOCAL[1]].T
    f = S_focal.ravel()
    R['cross_focal_dist'] = {'mean': float(f.mean()),
                             'p99': float(np.percentile(f, 99)),
                             'p99.9': float(np.percentile(f, 99.9)),
                             'p99.99': float(np.percentile(f, 99.99)),
                             'max': float(f.max())}

    # ---- rate-matched thresholds from the control corpus (order stats) ---
    ctrl = np.concatenate(ctrl_sims); del ctrl_sims
    Nc = ctrl.size
    top = np.sort(ctrl)[-30:][::-1]          # 30 largest control similarities
    # which control PAIR tops the list?  Under MiniLM it is the thesis
    # declaration boilerplate (a genuine duplicate).  If a model puts something
    # else on top, the rate-matched threshold means something different.
    tp = None
    for x, y in pairs:
        if (x, y) == FOCAL: continue
        Sxy = E_[x] @ E_[y].T
        m_ = float(Sxy.max())
        if tp is None or m_ > tp[0]:
            a_, z_ = np.unravel_index(int(Sxy.argmax()), Sxy.shape)
            tp = (m_, f'{x}x{y}', S_[x][int(a_)][:150], S_[y][int(z_)][:150])
    R['top_control_pair'] = {'cos': tp[0], 'pair': tp[1], 'a': tp[2], 'b': tp[3]}
    print(f'  top control pair ({tp[1]}, cos={tp[0]:.4f}): {tp[2][:90]}')
    R['control_order_stats'] = {'n_control_pairs': int(Nc),
                                'top30': [float(t) for t in top]}
    rm = {}
    for k_ in (1, 3, 10, 30):
        thr = float(top[k_ - 1])
        n_f = int((f >= thr).sum())
        rm[f'top{k_}'] = {'threshold': thr,
                          'control_rate_per_M': k_ / Nc * 1e6,
                          'focal_n': n_f,
                          'focal_per_M': n_f / f.size * 1e6,
                          'expected_focal': k_ / Nc * f.size,
                          'enrichment': (n_f / f.size) / (k_ / Nc)}
        print(f'  rate-matched top{k_:<2} thr={thr:.4f}  focal n={n_f:5d} '
              f'(expected {k_/Nc*f.size:.2f}, enrichment {(n_f/f.size)/(k_/Nc):.0f}x)')
    R['rate_matched'] = rm
    del ctrl

    # ---- Poisson tests at the published raw 0.999 cutoff ------------------
    foc_n = int((S_focal >= 0.999).sum()); foc_N = int(S_focal.size)
    null_n = sum(R['pairs'][f'{x}x{y}']['n>=0.999'] for x, y in pairs if (x, y) != FOCAL)
    null_N = sum(R['pairs'][f'{x}x{y}']['n_pairs'] for x, y in pairs if (x, y) != FOCAL)
    lam = null_n / null_N * foc_N
    lam_hi = chi2.ppf(0.975, 2 * (null_n + 1)) / 2 / null_N * foc_N
    ii, jj = np.where(S_focal >= 0.999)
    blocks = []
    for i, j in sorted(zip(ii.tolist(), jj.tolist())):
        hit = next((b for b in blocks if any(abs(i-x) <= 3 and abs(j-y) <= 3 for x, y in b)), None)
        (hit.append((i, j)) if hit else blocks.append([(i, j)]))
    R['poisson_raw999'] = {
        'focal_n': foc_n, 'focal_N': foc_N, 'null_n': null_n, 'null_N': null_N,
        'lambda': lam, 'lambda_hi': lam_hi, 'blocks': len(blocks),
        'p_point': float(poisson.sf(foc_n - 1, lam)) if foc_n else 1.0,
        'p_cons': float(poisson.sf(foc_n - 1, lam_hi)) if foc_n else 1.0,
        'p_cons_block': float(poisson.sf(len(blocks) - 1, lam_hi)) if blocks else 1.0,
        # log10 versions so extreme rows do not print a bare 0.0 on underflow
        'log10p_point': float(poisson.logsf(foc_n - 1, lam) / np.log(10)) if foc_n else 0.0,
        'log10p_cons_block': float(poisson.logsf(len(blocks) - 1, lam_hi) / np.log(10)) if blocks else 0.0}
    print(f"  Poisson@0.999: focal {foc_n} ({len(blocks)} blocks) vs expected {lam:.3f} "
          f"(cons {lam_hi:.3f})  p_cons_block={R['poisson_raw999']['p_cons_block']:.2e}")

    # ---- Poisson at the rate-matched top-3 threshold ----------------------
    thr_rm = rm['top3']['threshold']
    fn = int((S_focal >= thr_rm).sum())
    ii, jj = np.where(S_focal >= thr_rm)
    bl = []
    for i, j in sorted(zip(ii.tolist(), jj.tolist())):
        hit = next((b for b in bl if any(abs(i-x) <= 3 and abs(j-y) <= 3 for x, y in b)), None)
        (hit.append((i, j)) if hit else bl.append([(i, j)]))
    lam3 = 3 / null_N * foc_N
    lam3_hi = chi2.ppf(0.975, 2 * (3 + 1)) / 2 / null_N * foc_N
    R['poisson_ratematched'] = {'threshold': thr_rm, 'focal_n': fn, 'blocks': len(bl),
                                'lambda': lam3, 'lambda_hi': lam3_hi,
                                'p_cons_block': float(poisson.sf(len(bl) - 1, lam3_hi)) if bl else 1.0}

    # ---- extent (4.8) -- published estimator reproduced verbatim ----------
    rng = np.random.default_rng(0)
    def best(q, r, nsub=1800, reps=5):
        return np.mean([(E_[q] @ E_[r][rng.choice(E_[r].shape[0],
                        min(nsub, E_[r].shape[0]), replace=False)].T).max(axis=1)
                        for _ in range(reps)], axis=0)
    bZ, bK, bH = best('arday', 'zwoz'), best('arday', 'ctrl1'), best('arday', 'ctrl2')
    w = np.array([len(s.split()) for s in S_['arday']]); tot = int(w.sum())
    R['arday_body_words'] = tot
    ext = []
    for t in (0.75, 0.80, 0.85, 0.90, 0.95, 0.99):
        nZ = int((bZ >= t).sum()); base = (int((bK >= t).sum()) + int((bH >= t).sum())) / 2
        exc = max(0.0, nZ - base); sel = w[bZ >= t]
        wx = exc * (sel.mean() if len(sel) else 0)
        ext.append({'thr': t, 'n_vs_zwoz': nZ, 'baseline': base, 'excess': exc,
                    'words': float(wx), 'pct': 100 * wx / tot})
    R['extent'] = ext
    print('  extent  thr   nZ   base  excess   words     %')
    for e in ext:
        print(f"          {e['thr']:.2f} {e['n_vs_zwoz']:5d} {e['baseline']:6.1f} "
              f"{e['excess']:7.1f} {e['words']:7.0f} {e['pct']:5.2f}%")

    # ---- extent, EXACT (no subsampling) ----------------------------------
    # The published estimator averages 5 draws of max-over-1800-sentences.  That
    # under-states every max, and unevenly: zwoz is 69% sampled, ctrl1 98%, ctrl2
    # 72% -- so the focal column is attenuated more than one baseline column and
    # about the same as the other.  The full matrices are a trivial matmul here,
    # so compute the unbiased version too and report both.
    xZ = (E_['arday'] @ E_['zwoz'].T).max(axis=1)
    xK = (E_['arday'] @ E_['ctrl1'].T).max(axis=1)
    xH = (E_['arday'] @ E_['ctrl2'].T).max(axis=1)
    ext_x = []
    for t in (0.75, 0.80, 0.85, 0.90, 0.95, 0.99):
        nZ = int((xZ >= t).sum()); base = (int((xK >= t).sum()) + int((xH >= t).sum())) / 2
        exc = max(0.0, nZ - base); sel = w[xZ >= t]
        wx = exc * (sel.mean() if len(sel) else 0)
        ext_x.append({'thr': t, 'n_vs_zwoz': nZ, 'baseline': base, 'excess': exc,
                      'words': float(wx), 'pct': 100 * wx / tot})
    R['extent_exact'] = ext_x
    print('  extent EXACT (no subsampling):')
    for e in ext_x:
        print(f"          {e['thr']:.2f} {e['n_vs_zwoz']:5d} {e['baseline']:6.1f} "
              f"{e['excess']:7.1f} {e['words']:7.0f} {e['pct']:5.2f}%")

    R['extent_exact_ratematched'] = []
    for target_base in (5.0, 10.0, 25.0, 50.0):
        lo, hi = 0.0, 1.0
        for _ in range(60):
            mid = (lo + hi) / 2
            b = (int((xK >= mid).sum()) + int((xH >= mid).sum())) / 2
            if b > target_base: lo = mid
            else: hi = mid
        t = (lo + hi) / 2
        nZ = int((xZ >= t).sum()); base = (int((xK >= t).sum()) + int((xH >= t).sum())) / 2
        exc = max(0.0, nZ - base); sel = w[xZ >= t]
        wx = exc * (sel.mean() if len(sel) else 0)
        R['extent_exact_ratematched'].append(
            {'target_baseline': target_base, 'thr': float(t), 'n_vs_zwoz': nZ,
             'baseline': base, 'excess': exc, 'words': float(wx), 'pct': 100 * wx / tot})
    print('  rate-matched EXACT extent:')
    for e in R['extent_exact_ratematched']:
        print(f"    base~{e['target_baseline']:.0f} thr={e['thr']:.4f} nZ={e['n_vs_zwoz']:4d} "
              f"excess={e['excess']:6.1f} words={e['words']:6.0f} ({e['pct']:.2f}%)")
    R['best_match_exact'] = {'vs_zwoz': [float(x) for x in xZ],
                             'vs_ctrl1': [float(x) for x in xK],
                             'vs_ctrl2': [float(x) for x in xH]}

    # save the raw best-match vectors so every extent variant is recomputable
    # post-hoc without re-embedding
    R['best_match'] = {'vs_zwoz': [float(x) for x in bZ],
                       'vs_ctrl1': [float(x) for x in bK],
                       'vs_ctrl2': [float(x) for x in bH],
                       'arday_words': [int(x) for x in w]}

    # ---- extent, RATE-MATCHED: anchor on a fixed number of control false
    #      positives rather than a fixed cosine, so the comparison across models
    #      holds the false-positive rate constant instead of the (model-specific,
    #      non-transferable) cosine value.
    R['extent_ratematched'] = []
    for target_base in (5.0, 10.0, 25.0, 50.0):
        lo, hi = 0.0, 1.0
        for _ in range(60):
            mid = (lo + hi) / 2
            b = (int((bK >= mid).sum()) + int((bH >= mid).sum())) / 2
            if b > target_base: lo = mid
            else: hi = mid
        t = (lo + hi) / 2
        nZ = int((bZ >= t).sum()); base = (int((bK >= t).sum()) + int((bH >= t).sum())) / 2
        exc = max(0.0, nZ - base); sel = w[bZ >= t]
        wx = exc * (sel.mean() if len(sel) else 0)
        R['extent_ratematched'].append({'target_baseline': target_base, 'thr': float(t),
                                        'n_vs_zwoz': nZ, 'baseline': base, 'excess': exc,
                                        'words': float(wx), 'pct': 100 * wx / tot})
    print('  rate-matched extent (equal control false positives):')
    for e in R['extent_ratematched']:
        print(f"    base~{e['target_baseline']:.0f} thr={e['thr']:.4f} nZ={e['n_vs_zwoz']:4d} "
              f"excess={e['excess']:6.1f} words={e['words']:6.0f} ({e['pct']:.2f}%)")

    # ---- section concentration (4.8) -------------------------------------
    pos = np.arange(len(S_['arday'])) / len(S_['arday'])
    sec = {}
    for nm, m in [('deciles_1_2', pos < 0.2), ('deciles_9_10', pos >= 0.8),
                  ('deciles_3_8', (pos >= 0.2) & (pos < 0.8))]:
        c = int(((bZ >= 0.80) & m).sum())
        sec[nm] = {'n': c, 'of': int(m.sum()), 'pct': 100 * c / int(m.sum()),
                   'words': int(w[(bZ >= 0.80) & m].sum())}
    # and at each model's own rate-matched threshold with ~10 control false
    # positives -- the closest analogue of the published 0.80 cutoff, whose
    # MiniLM control baseline was 9.0
    t_rm = R['extent_ratematched'][1]['thr']
    sec_rm = {}
    for nm, m in [('deciles_1_2', pos < 0.2), ('deciles_9_10', pos >= 0.8),
                  ('deciles_3_8', (pos >= 0.2) & (pos < 0.8))]:
        c = int(((bZ >= t_rm) & m).sum())
        sec_rm[nm] = {'n': c, 'of': int(m.sum()), 'pct': 100 * c / int(m.sum()),
                      'words': int(w[(bZ >= t_rm) & m].sum())}
    R['sections'] = sec; R['sections_ratematched'] = {'thr': float(t_rm), **sec_rm}
    R['deciles'] = [{'d': d + 1,
                     'pct': float(100 * ((bZ >= 0.80) & ((pos >= d/10) & (pos < (d+1)/10))).sum()
                                  / max(1, ((pos >= d/10) & (pos < (d+1)/10)).sum()))}
                    for d in range(10)]

    # ---- the published 185 pairs, scored under THIS model -----------------
    ai = np.array([p['ai'] for p in pub]); zi = np.array([p['zi'] for p in pub])
    cos185 = (E_['arday'][ai] * E_['zwoz'][zi]).sum(axis=1)
    R['published185'] = {'cos': [float(c) for c in cos185],
                         'mean': float(cos185.mean()),
                         'min': float(cos185.min()),
                         'n>=0.85': int((cos185 >= 0.85).sum()),
                         'n>=0.80': int((cos185 >= 0.80).sum()),
                         'n>=0.75': int((cos185 >= 0.75).sum())}
    print(f"  published-185 under this model: mean cos {cos185.mean():.3f}, "
          f"{int((cos185>=0.85).sum())}/185 still >=0.85")

    # ---- recall against the MODEL-FREE gold standard ---------------------
    # The 179 focal pairs sharing >=12 identical consecutive words are found
    # without any encoder, so they are ground truth no model can influence.
    # Caveat: they are verbatim-biased, so this measures VERBATIM recall only.
    gs_path = os.path.join(OUT, 'free_runs_12.json')
    if os.path.exists(gs_path):
        gs = json.load(open(gs_path, encoding='utf-8'))
        gi = np.array([g['ai'] for g in gs]); gj = np.array([g['zi'] for g in gs])
        gcos = (E_['arday'][gi] * E_['zwoz'][gj]).sum(axis=1)
        rec = {'n_gold': len(gs), 'mean_cos': float(gcos.mean()),
               'min_cos': float(gcos.min())}
        for t in (0.75, 0.80, 0.85, 0.90, 0.95):
            rec[f'recall>={t}'] = int((gcos >= t).sum())
        for k_ in (3, 10, 30):
            rec[f'recall_ratematched_top{k_}'] = int((gcos >= rm[f'top{k_}']['threshold']).sum())
        rec['cos'] = [float(c) for c in gcos]
        R['gold_recall'] = rec
        print(f"  model-free gold standard (179 pairs w/ run>=12): mean cos {gcos.mean():.3f}; "
              f"recall @0.85 = {int((gcos>=0.85).sum())}/{len(gs)}")

    # ---- this model's own deduplicated top list (for consensus) ----------
    # keep a generous pool so the consensus step can threshold consistently
    dd = greedy_dedup(S_focal, 0.70)
    R['dedup_top'] = [{'ai': a, 'zi': z, 'cos': c} for a, z, c in dd[:2500]]
    R['n_dedup>=0.85'] = int(sum(1 for _, _, c in dd if c >= 0.85))
    R['total_seconds'] = time.time() - t_all
    json.dump(R, open(os.path.join(OUT, f'{key}.json'), 'w'), indent=1)
    print(f'  wrote results/{key}.json  ({R["total_seconds"]:.0f}s total)')


if __name__ == '__main__':
    main()
