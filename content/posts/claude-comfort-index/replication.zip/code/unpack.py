"""Turn data/interviews.jsonl and data/judgements.jsonl back into the per-answer files that analyse.py reads.

  python unpack.py && python analyse.py

Writes data/raw/<model>/<qid>_s<k>.json and data/judge/<judge>/<model>/<qid>_s<k>.json, then analyse.py recomputes
data/results.json and data/answers.csv from them (the bootstrap uses a fixed seed).
"""
import json
import os

from common import DATA


def main():
    n = m = 0
    for line in open(os.path.join(DATA, "interviews.jsonl"), encoding="utf-8"):
        r = json.loads(line)
        p = os.path.join(DATA, "raw", r["model_key"], "%s_s%d.json" % (r["qid"], r["sample"]))
        os.makedirs(os.path.dirname(p), exist_ok=True)
        json.dump(r, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        n += 1
    for line in open(os.path.join(DATA, "judgements.jsonl"), encoding="utf-8"):
        j = json.loads(line)
        p = os.path.join(DATA, "judge", j["judge"], j["model_key"], "%s_s%d.json" % (j["qid"], j["sample"]))
        os.makedirs(os.path.dirname(p), exist_ok=True)
        json.dump(j, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        m += 1
    print("unpacked %d interviews and %d judgements" % (n, m))


if __name__ == "__main__":
    main()
