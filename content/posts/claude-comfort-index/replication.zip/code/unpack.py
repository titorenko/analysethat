"""Turn data/interviews.jsonl and data/judgements.jsonl back into the per-answer files that analyse.py reads.

  python unpack.py && python analyse.py

Writes data/raw/<model>/<qid>_s<k>.json and data/judge/<judge>/<model>/<qid>_s<k>.json (and the context re-run of the
7.4-only questions, from interviews_context.jsonl and judgements_context.jsonl, into data/raw_ctx and data/judge_ctx), then analyse.py recomputes
data/results.json and data/answers.csv from them (the bootstrap uses a fixed seed).
"""
import json
import os

from common import DATA


def main():
    for suffix, raw_name, judge_name in (("", "raw", "judge"), ("_context", "raw_ctx", "judge_ctx")):
        n = m = 0
        for line in open(os.path.join(DATA, "interviews%s.jsonl" % suffix), encoding="utf-8"):
            r = json.loads(line)
            p = os.path.join(DATA, raw_name, r["model_key"], "%s_s%d.json" % (r["qid"], r["sample"]))
            os.makedirs(os.path.dirname(p), exist_ok=True)
            json.dump(r, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            n += 1
        for line in open(os.path.join(DATA, "judgements%s.jsonl" % suffix), encoding="utf-8"):
            j = json.loads(line)
            p = os.path.join(DATA, judge_name, j["judge"], j["model_key"], "%s_s%d.json" % (j["qid"], j["sample"]))
            os.makedirs(os.path.dirname(p), exist_ok=True)
            json.dump(j, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            m += 1
        print("unpacked %d interviews and %d judgements into data/%s and data/%s" % (n, m, raw_name, judge_name))


if __name__ == "__main__":
    main()
