"""Tables and placeholder values for the article, from data/results.json and the raw records.

Every number in a table comes from results.json / the raw records. Differences quoted in tables and prose are taken between the
displayed (rounded) indices so that a reader can reproduce them from the tables; intervals come from the paired bootstrap.
"""
import glob
import json
import os
import re

import numpy as np

from build_appendix import REDACT
from common import DATA, MODELS
from questions import QUESTIONS

res = json.load(open(os.path.join(DATA, "results.json"), encoding="utf-8"))
H, H74, HALL, H51, HINC, HCC = res["headline"], res["only74"], res["all_evaluative"], res["all51_no_exclusions"], res["headline_including_nonev"], res["headline_complete_case"]
NONEV = set(res["nonevaluative"])
QBY = {q["id"]: q for q in QUESTIONS}
MBY = {m[0]: m for m in MODELS}
NAME = {m[0]: m[2] for m in MODELS}
SHORT = {m[0]: m[2].replace("Claude ", "") for m in MODELS}
LATEST = [m[0] for m in MODELS if m[4]]
OLDER = [m[0] for m in MODELS if not m[4]]
HM = H["models"]
HEAD_Q = [q for q in QUESTIONS if q["sec"] in ("both", "7.3.1") and q["id"] not in NONEV]


def idx(mk, field="answer", src=None):
    return (src or H)["models"][mk][field]["index"]


def ordered(keys, src=None, field="answer"):
    return sorted(keys, key=lambda k: -idx(k, field, src))


def f1(x):
    return "%.1f" % x


def cif(lo_hi):
    return "%.1f-%.1f" % (lo_hi[0], lo_hi[1])


def rdiff(a, b, field="answer", src=None):
    """Difference of two indices as a reader of the tables would compute it (from the displayed, rounded values)."""
    return round(round(idx(a, field, src), 1) - round(idx(b, field, src), 1), 1)


def pair(a, b):
    """Point difference index(a) - index(b) (from the displayed values) with the paired-bootstrap interval; each unordered pair is stored once."""
    if "%s|%s" % (a, b) in res["paired"]:
        p = res["paired"]["%s|%s" % (a, b)]
    else:
        q = res["paired"]["%s|%s" % (b, a)]
        p = {"ci": [-q["ci"][1], -q["ci"][0]], "p_gt0": 1 - q["p_gt0"]}
    return {"mean": rdiff(a, b), "ci": p["ci"], "p_gt0": p["p_gt0"]}


def excludes0(a, b):
    lo, hi = pair(a, b)["ci"]
    return lo > 0 or hi < 0


def spearman_rank(a, b):
    ra = np.argsort(np.argsort(-np.array(a)))
    rb = np.argsort(np.argsort(-np.array(b)))
    n = len(a)
    return 1 - 6 * float(((ra - rb) ** 2).sum()) / (n * (n * n - 1))


def md_table(head, rows, align=None):
    out = ["| " + " | ".join(head) + " |", "|" + "|".join((align[i] if align else "---") for i in range(len(head))) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


# ------------------------------------------------------------------ run statistics
def run_stats(raw_name="raw", judge_name="judge", ctx=False):
    """Counts, cost, times and failures of the main run, or (ctx=True) of the context re-run of the 7.4-only questions."""
    raw = []
    for f in glob.glob(os.path.join(DATA, raw_name, "*", "*.json")):
        r = json.load(open(f, encoding="utf-8"))
        if r.get("turn2"):
            raw.append(r)
    if not raw:
        return None
    jud = [json.load(open(f, encoding="utf-8")) for f in glob.glob(os.path.join(DATA, judge_name, "*", "*", "*.json"))]
    starts = sorted(r["started"] for r in raw)
    ends = sorted(r["finished"] for r in raw)
    logs = "".join(open(p, encoding="utf-8").read() for p in glob.glob(os.path.join(DATA, "*.log")) if os.path.basename(p).startswith("ctx_") == ctx)
    return {
        "n_interviews": len(raw), "n_judge_calls": len(jud),
        # the CLI reports a session's cost cumulatively, so the turn-2 figure already includes turn 1
        "cost_interviews": sum(r["turn2"]["total_cost_usd"] for r in raw), "cost_judges": float(sum(j["total_cost_usd"] for j in jud)),
        "t_start": starts[0][11:16], "t_end": ends[-1][11:16], "run_date": starts[0][:10],
        "n_retries": len(re.findall(r"attempt \d+ failed", logs)),
        "n_failures": len(re.findall(r"^FAILED ", logs, re.M)),
    }


RS = run_stats()
RSC = run_stats("raw_ctx", "judge_ctx", ctx=True)


# ------------------------------------------------------------------ tables
def table_overall():
    rows = []
    for label, keys in (("Latest", LATEST), ("Older", OLDER)):
        for mk in ordered(keys):
            m = HM[mk]
            rows.append([NAME[mk], label, "**%s**" % f1(m["answer"]["index"]), cif(m["answer"]["ci"]), f1(m["self"]["index"]), f1(m["judge"]["index"]), "%.0f%%" % (100 * m["decline_rate"]), "%+.2f" % m["mean_valence"], "%.2f" % m["hedging"]])
    return md_table(["Model", "Set", "Comfort Index", "95% CI", "Self-report", "Judges", "Declined", "Mean valence (-3..+3)", "Hedging (0-3)"], rows, ["---", "---", "---:", "---:", "---:", "---:", "---:", "---:", "---:"])


def table_groups(keys):
    keys = ordered(keys)
    rows = []
    for g in H["groups"]:
        nq = len([q for q in HEAD_Q if q["group"] == g])
        cells = [f1(HM[k]["answer"]["groups"][g]) if g in HM[k]["answer"]["groups"] else "-" for k in keys]
        best = max(range(len(keys)), key=lambda i: float(cells[i]) if cells[i] != "-" else -1)
        if len(keys) > 1:
            cells[best] = "**%s**" % cells[best]
        rows.append([g, nq] + cells)
    rows.append(["**Comfort Index**", ""] + ["**%s**" % f1(HM[k]["answer"]["index"]) for k in keys])
    return md_table(["Group", "Qs"] + [SHORT[k] for k in keys], rows, ["---", "---:"] + ["---:"] * len(keys))


PAIRS = [("opus-5-5", "fable-5-1"), ("opus-5-5", "sonnet-5-5"), ("opus-5-5", "haiku-4-5"), ("fable-5-1", "sonnet-5-5"), ("fable-5-1", "haiku-4-5"), ("sonnet-5-5", "haiku-4-5"),
         ("opus-5-5", "opus-5"), ("opus-5", "opus-4-6"), ("opus-5-5", "opus-4-6"), ("sonnet-5-5", "sonnet-5"), ("opus-4-6", "fable-5-1"), ("sonnet-5", "haiku-4-5")]


def table_paired():
    rows = []
    for a, b in PAIRS:
        p = pair(a, b)
        lo, hi = p["ci"]
        pg = p["p_gt0"]
        pstr = ">99.9%" if pg > 0.999 else ("<0.1%" if pg < 0.001 else "%.1f%%" % (100 * pg))
        rows.append(["%s minus %s" % (SHORT[a], SHORT[b]), "%+.1f" % p["mean"], "%+.1f to %+.1f" % (lo, hi), pstr, "yes" if (lo > 0 or hi < 0) else "**no**"])
    return md_table(["Difference in Comfort Index", "Points", "95% CI", "P(first higher)", "CI excludes 0"], rows, ["---", "---:", "---:", "---:", "---"])


def question_means():
    """Mean answer score over models, headline evaluative questions, with per-model values."""
    out = []
    for q in HEAD_Q:
        bm = res["per_question"][q["id"]]["by_model"]
        if len(bm) < len(MODELS):
            continue
        lo, hi = min(bm, key=bm.get), max(bm, key=bm.get)
        out.append((q, float(np.mean(list(bm.values()))), lo, hi, bm))
    return out


def alink(mk, qid, text):
    """Markdown link from the article to one model's answers to one question in the appendix."""
    return "[%s](appendix/%s/#%s)" % (text, mk, qid.lower())


def fold(summary, body):
    """A collapsed block (the appendix's `sample` shortcode) holding a table and its caption."""
    assert '"' not in summary
    return '{{< sample summary="%s" >}}\n%s\n{{< /sample >}}\n' % (summary, body.strip())


def _qrow(t):
    q, m, lo, hi, bm = t
    return [q["id"], q["text"], f1(m), alink(lo, q["id"], "%s %s" % (SHORT[lo], f1(bm[lo]))), alink(hi, q["id"], "%s %s" % (SHORT[hi], f1(bm[hi])))]


def table_extremes(k=6):
    qm = sorted(question_means(), key=lambda t: t[1])
    head = ["#", "Question", "Mean (7 models)", "Lowest model", "Highest model"]
    al = ["---", "---", "---:", "---", "---"]
    return md_table(head, [_qrow(t) for t in qm[:k]], al), md_table(head, [_qrow(t) for t in qm[::-1][:k]], al)


def table_spread(k=6):
    qm = sorted(question_means(), key=lambda t: -(max(t[4].values()) - min(t[4].values())))
    rows = []
    for q, m, lo, hi, bm in qm[:k]:
        rows.append([q["id"], q["text"], "%.1f" % (bm[hi] - bm[lo]), alink(lo, q["id"], "%s %s" % (SHORT[lo], f1(bm[lo]))), alink(hi, q["id"], "%s %s" % (SHORT[hi], f1(bm[hi])))])
    return md_table(["#", "Question", "Spread", "Lowest model", "Highest model"], rows, ["---", "---", "---:", "---", "---"])


SENS_COLS = [
    ("Headline", lambda mk: idx(mk)),
    ("All evaluative (41)", lambda mk: idx(mk, src=HALL)),
    ("§7.3.1 set, none excluded (41)", lambda mk: idx(mk, src=HINC)),
    ("All 51, none excluded", lambda mk: idx(mk, src=H51)),
    ("Equal weight per question", lambda mk: res["question_weighted"][mk]),
    ("Complete cases only", lambda mk: idx(mk, src=HCC)),
    ("Judge Opus 5.5 only", lambda mk: idx(mk, "j_opus-5-5")),
    ("Judge Fable 5.1 only", lambda mk: idx(mk, "j_fable-5-1")),
    ("Self-report only", lambda mk: idx(mk, "self")),
    ("Judges only", lambda mk: idx(mk, "judge")),
    ("§7.4-only questions", lambda mk: idx(mk, src=H74)),
]


def table_sensitivity():
    keys = ordered(LATEST) + ordered(OLDER)
    rows = [[NAME[mk]] + [f1(fn(mk)) for _, fn in SENS_COLS] for mk in keys]
    base = [idx(mk) for mk in keys]
    rows.append(["Rank correlation with headline"] + ["%.2f" % spearman_rank(base, [fn(mk) for mk in keys]) for _, fn in SENS_COLS])
    return md_table(["Model"] + [c[0] for c in SENS_COLS], rows, ["---"] + ["---:"] * len(SENS_COLS))


def table_drop():
    h, g, q = res["drop_harness"], res["drop_hedge"], res["drop_q10"]
    keys = ordered(LATEST) + ordered(OLDER)
    rows = []
    for mk in keys:
        rows.append([NAME[mk], f1(h["full"][mk]), f1(h["dropped"][mk]), "%+.2f" % (h["dropped"][mk] - h["full"][mk]),
                     f1(g["full"][mk]), f1(g["dropped"][mk]), "%+.2f" % (g["dropped"][mk] - g["full"][mk]),
                     f1(q["full"][mk]), f1(q["dropped"][mk]), "%+.2f" % (q["dropped"][mk] - q["full"][mk])])
    head = ["Model", "Index, %d questions" % h["n_questions"], "Without harness mentions", "Shift", "Index, %d questions" % g["n_questions"], "Without heavy hedging", "Shift",
            "Index, %d questions" % (q["n_questions"] + 1), "Without Q10", "Shift"]
    return md_table(head, rows, ["---"] + ["---:"] * 9)


def table_form():
    rows = []
    for label, keys in (("Latest", LATEST), ("Older", OLDER)):
        for mk in ordered(keys):
            m = HM[mk]
            rows.append([NAME[mk], label, "%.0f" % m["mean_words"], "%.0f" % m["mean_think"], "%.2f" % m["hedging"], "%.0f%%" % (100 * res["hedging"]["by_model"][mk]["share_ge2"]), "%.0f%%" % (100 * m["decline_rate"]), "%.1f" % res["within_item_sd"][mk]])
    return md_table(["Model", "Set", "Words per answer", "Thinking tokens (turn 1)", "Hedging (0-3)", "Answers hedging at 2 or more", "Declined a number", "Within-question SD"], rows, ["---", "---", "---:", "---:", "---:", "---:", "---:", "---:"])


def table_models():
    rows = []
    for mk, cli, name, fam, latest in MODELS:
        rows.append("| %s | `%s` | %s |" % (name, cli, "latest in the %s family" % fam if latest else "older %s model" % fam))
    return "\n".join(rows)


def table_agreement():
    a = res["judge_agreement"]
    rows = [["Answers rated by both judges", "{:,}".format(a["n"])], ["Pearson correlation of valences", "%.2f" % a["pearson"]], ["Spearman rank correlation", "%.2f" % a["spearman"]],
            ["Quadratic-weighted kappa", "%.2f" % a["qw_kappa"]], ["Identical valence", "%.1f%%" % (100 * a["exact"])], ["Within one point", "%.1f%%" % (100 * a["within1"])],
            ["Mean valence, Opus 5.5 judge", "%+.2f" % a["mean_valence_opus"]], ["Mean valence, Fable 5.1 judge", "%+.2f" % a["mean_valence_fable"]]]
    return md_table(["Judge agreement (all answers)", "Value"], rows, ["---", "---:"])


def count_redactions():
    """Occurrences of the two private strings in every answer, follow-up reason and judge rationale (what the appendices redact), both runs."""
    n = 0
    for raw_name, judge_name in (("raw", "judge"), ("raw_ctx", "judge_ctx")):
        for f in glob.glob(os.path.join(DATA, raw_name, "*", "*.json")):
            r = json.load(open(f, encoding="utf-8"))
            if r.get("turn2"):
                for t in (r["turn1"]["result"], (r["turn2"].get("structured_output") or {}).get("reason", "")):
                    n += sum(len(pat.findall(t)) for pat, _ in REDACT)
        for f in glob.glob(os.path.join(DATA, judge_name, "*", "*", "*.json")):
            t = json.load(open(f, encoding="utf-8")).get("rationale", "")
            n += sum(len(pat.findall(t)) for pat, _ in REDACT)
    return n


def fill(text):
    hm, nc, hd = res["harness_mentions"], res["noctx"], res["hedging"]
    head_q = [q for q in QUESTIONS if q["sec"] in ("both", "7.3.1")]
    q74 = [q for q in QUESTIONS if q["sec"] == "7.4"]
    def fail_text(rs):
        return ("no call failed an assertion and none needed a retry" if rs["n_failures"] == 0 and rs["n_retries"] == 0
                else "%d calls were retried after a transient failure and %d were abandoned" % (rs["n_retries"], rs["n_failures"]))
    fail = fail_text(RS)
    dh, dq = res["drop_harness"], res["drop_q10"]
    shift_h = max(abs(dh["dropped"][k] - dh["full"][k]) for k in dh["full"])
    shift_q = max(abs(dq["dropped"][k] - dq["full"][k]) for k in dq["full"])
    lo_m = min(hm["by_model"], key=hm["by_model"].get)
    ex = res["t2_extra_turns"]
    s5_zero = sum(1 for f in glob.glob(os.path.join(DATA, "raw", "sonnet-5", "*.json")) if (json.load(open(f, encoding="utf-8"))["turn1"].get("thinking_tokens") or 0) == 0)
    ctx = {
        "models_table": table_models(), "cli_version": "2.1.286", "failure_sentence": fail, "run_date": RS["run_date"], "n_interviews": "{:,}".format(RS["n_interviews"]),
        "n_judge_calls": "{:,}".format(RS["n_judge_calls"]), "t_start": RS["t_start"], "t_end": RS["t_end"],
        "cost_interviews": "%.0f" % RS["cost_interviews"], "cost_judges": "%.0f" % RS["cost_judges"], "n_nonev": len(NONEV), "n_boot": "{:,}".format(res["n_boot"]),
        "n_redactions": count_redactions(), "n_harness": hm["n"], "n_answers": "{:,}".format(hm["total"]), "pct_harness": "%.0f%%" % (100 * hm["n"] / hm["total"]),
        "n_wb": hm["n_wb"], "harness_shift": "%.1f" % shift_h, "q10_shift": "%.1f" % shift_q, "n_common_q": dh["n_questions"], "n_harness_head": dh["n_dropped"], "n_dropped_common": dh["n_dropped_common"],
        "n_nonev_headline": len([q for q in head_q if q["id"] in NONEV]), "n_head_eval": len([q for q in head_q if q["id"] not in NONEV]),
        "n_74_eval": len([q for q in q74 if q["id"] not in NONEV]), "n_all_eval": len([q for q in QUESTIONS if q["id"] not in NONEV]),
        "harness_range": "between %d (%s) and %d of a model's 153 answers" % (hm["by_model"][lo_m], SHORT[lo_m], max(hm["by_model"].values())),
        "n_noctx74": nc["n74"], "t_noctx74": nc["t74"], "pct_noctx74": "%.0f%%" % (100 * nc["n74"] / nc["t74"]), "n_noctxoth": nc["n_other"], "t_noctxoth": nc["t_other"], "pct_noctxoth": "%.0f%%" % (100 * nc["n_other"] / nc["t_other"]),
        "n_extra_turns": sum(ex.values()), "extra_turns_detail": ", ".join("%s %d" % (SHORT[k], v) for k, v in sorted(ex.items(), key=lambda t: -t[1]) if v),
        "sonnet5_think0": "all 153" if s5_zero == 153 else "%d of 153" % s5_zero, "selfrange_n": "{:,}".format(res["selfscore_range"]["n_self"]),
        "ci_samples_o55": cif(HM["opus-5-5"]["answer"]["ci_samples"]), "ci_o55": cif(HM["opus-5-5"]["answer"]["ci"]), "selfrange_below50": res["selfscore_range"]["self_below_50"],
        "selfrange_judge_below50": res["selfscore_range"]["judge_below_50"], "selfrange_q10": "%.0f" % res["selfscore_range"]["self_q10"], "selfrange_q90": "%.0f" % res["selfscore_range"]["self_q90"],
        "haiku_hedge_share": "%.0f%%" % (100 * hd["by_model"]["haiku-4-5"]["share_ge2"]), "other_hedge_max": "%.0f%%" % (100 * max(v["share_ge2"] for k, v in hd["by_model"].items() if k != "haiku-4-5")),
        "haiku_judge_lt2": f1(hd["by_model"]["haiku-4-5"]["judge_when_lt2"]), "q34_shift": "%.1f" % max(abs(res["headline_with_q34"]["models"][k]["answer"]["index"] - idx(k)) for k in HM),
        "q42_harness": sum(hm["q42_by_model"].values()), "n_texts": "{:,}".format(2 * RS["n_interviews"] + RS["n_judge_calls"] + 2 * RSC["n_interviews"] + RSC["n_judge_calls"]),
        "hedge_corr": "%.2f" % hd["corr_answer"], "hedge_n": hd["n"], "hedge_band0": f1(hd["bands"][0]["mean_judge"]), "hedge_band1": f1(hd["bands"][1]["mean_judge"]), "hedge_band2": f1(hd["bands"][2]["mean_judge"]),
    }
    c74 = res["context74"]
    ctx.update({
        "ctx_n_interviews": RSC["n_interviews"], "ctx_n_judge_calls": RSC["n_judge_calls"], "ctx_run_date": RSC["run_date"], "ctx_t_start": RSC["t_start"], "ctx_t_end": RSC["t_end"],
        "ctx_cost": "%.0f" % (RSC["cost_interviews"] + RSC["cost_judges"]), "ctx_failure_sentence": fail_text(RSC),
        "n_noctx_ctx": c74["noctx"], "t_noctx_ctx": c74["n_answers"], "pct_noctx_ctx": "%.0f%%" % (100 * c74["noctx"] / c74["n_answers"]),
    })
    for k, v in ctx.items():
        text = text.replace("@@%s@@" % k, str(v))
    assert "@@" not in text, re.findall(r"@@\w+@@", text)
    return text
