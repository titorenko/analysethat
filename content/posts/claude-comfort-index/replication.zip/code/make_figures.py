"""Static SVG figures from data/results.json.  python make_figures.py <out_dir>

fig-overall.svg   Comfort Index per model with 95% bootstrap CI (emphasis form: latest models filled, older hollow)
fig-heatmap.svg   group x model heatmap of the Comfort Index (one-hue sequential ramp, every cell labelled)
fig-selfjudge.svg self-report vs judge rating per model (dumbbell)

Each SVG carries its own surface and switches to a dark variant with prefers-color-scheme. Colours follow the dataviz
skill's reference palette (accent blue, neutral grey, sequential blue 100-700).
"""
import json
import os
import sys

from common import DATA, MODELS

RES = json.load(open(os.path.join(DATA, "results.json"), encoding="utf-8"))
H = RES["headline"]
ORDER_LATEST = [m for m in MODELS if m[4]]
ORDER_OLDER = [m for m in MODELS if not m[4]]
SHORT = {m[0]: m[2].replace("Claude ", "") for m in MODELS}
FONT = "system-ui, -apple-system, 'Segoe UI', sans-serif"

RAMP = [(100, "#cde2fb"), (150, "#b7d3f6"), (200, "#9ec5f4"), (250, "#86b6ef"), (300, "#6da7ec"), (350, "#5598e7"), (400, "#3987e5"),
        (450, "#2a78d6"), (500, "#256abf"), (550, "#1c5cab"), (600, "#184f95"), (650, "#104281"), (700, "#0d366b")]


def hex2rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def rgb2hex(c):
    return "#%02x%02x%02x" % tuple(int(round(x)) for x in c)


def ramp(t):
    """t in [0,1] -> light(0)..dark(1) colour along the blue ramp."""
    t = min(1.0, max(0.0, t)) * (len(RAMP) - 1)
    i = min(int(t), len(RAMP) - 2)
    a, b = hex2rgb(RAMP[i][1]), hex2rgb(RAMP[i + 1][1])
    f = t - i
    return rgb2hex([a[k] + (b[k] - a[k]) * f for k in range(3)])


def lum(h):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(x) for x in hex2rgb(h))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = sorted((lum(a), lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def ink_on(fill, dark="#0b0b0b", light="#ffffff"):
    return dark if contrast(fill, dark) >= contrast(fill, light) else light


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


STYLE_BASE = """
  .surface { fill: #fcfcfb; stroke: rgba(11,11,11,.10); }
  .t1 { fill: #0b0b0b; } .t2 { fill: #52514e; } .t3 { fill: #6b6a65; }
  .grid { stroke: #e1e0d9; stroke-width: 1; } .axis { stroke: #c3c2b7; stroke-width: 1; }
  .accent { fill: #2a78d6; stroke: #2a78d6; } .accent-line { stroke: #2a78d6; }
  .hollow { fill: #fcfcfb; stroke: #6b6a65; stroke-width: 2; } .hollow-line { stroke: #898781; }
  .orange { fill: #eb6834; stroke: #eb6834; } .link { stroke: #c3c2b7; }
  .neutral { stroke: #898781; stroke-dasharray: 4 4; }
  text { font-family: %s; }
  @media (prefers-color-scheme: dark) {
    .surface { fill: #1a1a19; stroke: rgba(255,255,255,.10); }
    .t1 { fill: #ffffff; } .t2 { fill: #c3c2b7; } .t3 { fill: #a9a8a1; }
    .grid { stroke: #2c2c2a; } .axis { stroke: #383835; }
    .accent { fill: #3987e5; stroke: #3987e5; } .accent-line { stroke: #3987e5; }
    .hollow { fill: #1a1a19; stroke: #a9a8a1; } .hollow-line { stroke: #898781; }
    .orange { fill: #d95926; stroke: #d95926; } .link { stroke: #4a4a46; }
    .neutral { stroke: #898781; }
  }
""" % FONT


def svg_open(w, h, title, desc, extra_style=""):
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-labelledby="t d">\n'
            '<title id="t">%s</title><desc id="d">%s</desc>\n<style>%s%s</style>\n<rect class="surface" x="0.5" y="0.5" width="%d" height="%d" rx="8"/>\n'
            % (w, h, w, h, esc(title), esc(desc), STYLE_BASE, extra_style, w - 1, h - 1))


def fig_overall(out):
    rows = []
    for label, group in (("Latest in each family", ORDER_LATEST), ("Older models", ORDER_OLDER)):
        ms = [m for m in group if m[0] in H["models"]]
        ms.sort(key=lambda m: -H["models"][m[0]]["answer"]["index"])
        rows.append((label, ms))
    vals = [H["models"][m[0]]["answer"][k] for _, ms in rows for m in ms for k in ("ci",)]
    lo_all = min(v[0] for v in vals)
    hi_all = max(v[1] for v in vals)
    x0, x1 = 40, 100
    lo = max(0, int((min(lo_all, 50) - 5) // 10 * 10))
    hi = min(100, int(-(-(hi_all + 7) // 10) * 10))
    W, left, right, top = 820, 170, 70, 62
    plot_w = W - left - right
    xs = lambda v: left + (v - lo) / (hi - lo) * plot_w
    rowh, sec = 40, 34
    n = sum(len(ms) for _, ms in rows)
    H_ = top + n * rowh + len(rows) * sec + 58
    o = [svg_open(W, H_, "Comfort Index by model", "Overall Comfort Index (0-100) per model with 95 percent bootstrap confidence interval; latest model of each family filled, older models hollow.")]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Comfort Index, headline question set (0-100)</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">Dot = index; line = 95% bootstrap CI over groups, questions and samples. 50 = neutral.</text>')
    y = top
    plot_top = top
    plot_bot = top + n * rowh + len(rows) * sec
    for v in range(lo, hi + 1, 10):
        o.append('<line class="grid" x1="%.1f" x2="%.1f" y1="%d" y2="%d"/>' % (xs(v), xs(v), plot_top, plot_bot))
        o.append('<text class="t3" x="%.1f" y="%d" font-size="12" text-anchor="middle">%s</text>' % (xs(v), plot_bot + 18, "50 (neutral)" if v == 50 else v))
    if lo < 50 < hi:
        o.append('<line class="neutral" x1="%.1f" x2="%.1f" y1="%d" y2="%d" stroke-width="1.5"/>' % (xs(50), xs(50), plot_top, plot_bot))
    for label, ms in rows:
        o.append('<text class="t2" x="24" y="%d" font-size="12.5" font-weight="600">%s</text>' % (y + 20, esc(label)))
        y += sec
        for m in ms:
            r = H["models"][m[0]]["answer"]
            cy = y + rowh / 2
            cls_line = "accent-line" if m[4] else "hollow-line"
            o.append('<text class="t1" x="24" y="%.1f" font-size="13.5" dominant-baseline="middle">%s</text>' % (cy, esc(SHORT[m[0]])))
            o.append('<line class="%s" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="2" stroke-linecap="round"/>' % (cls_line, xs(r["ci"][0]), xs(r["ci"][1]), cy, cy))
            o.append('<circle class="%s" cx="%.1f" cy="%.1f" r="6.5"%s/>' % ("accent" if m[4] else "hollow", xs(r["index"]), cy, ' stroke-width="0"' if m[4] else ""))
            o.append('<text class="t1" x="%.1f" y="%.1f" font-size="13" font-weight="600" dominant-baseline="middle">%.1f</text>' % (xs(r["ci"][1]) + 10, cy, r["index"]))
            y += rowh
    assert y == plot_bot
    lg = plot_bot + 44
    o.append('<circle class="accent" cx="%d" cy="%d" r="6" stroke-width="0"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">Latest in family</text>' % (left, lg, left + 12, lg))
    o.append('<circle class="hollow" cx="%d" cy="%d" r="6"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">Older model</text>' % (left + 140, lg, left + 152, lg))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_heatmap(out):
    cols = [m for m in ORDER_LATEST + ORDER_OLDER if m[0] in H["models"]]
    cols.sort(key=lambda m: (not m[4], -H["models"][m[0]]["answer"]["index"]))
    groups = H["groups"]
    vals = [H["models"][m[0]]["answer"]["groups"][g] for m in cols for g in groups if g in H["models"][m[0]]["answer"]["groups"]]
    lo, hi = int(min(vals) // 5 * 5), int(-(-max(vals) // 5) * 5)
    NB = 24
    cw, ch, left, top = 70, 30, 232, 118
    gap = 16
    W = left + len(cols) * cw + gap + 24
    Ht = top + (len(groups) + 1) * ch + 70
    css = []
    for b in range(NB):
        t = b / (NB - 1)
        fl, fd = ramp(t), ramp(1 - t)
        css.append(".b%d{fill:%s}.k%d{fill:%s}" % (b, fl, b, ink_on(fl)))
    css.append("@media (prefers-color-scheme: dark){")
    for b in range(NB):
        t = b / (NB - 1)
        fd = ramp(1 - t)
        css.append(".b%d{fill:%s}.k%d{fill:%s}" % (b, fd, b, ink_on(fd)))
    css.append("}")
    o = [svg_open(W, Ht, "Comfort Index by question group and model", "Heatmap of the Comfort Index (0-100) for each group of questions and each model; darker is more comfortable.", "\n".join(css))]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Comfort Index by question group (0-100)</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">Cell = group mean; colour key below (%d-%d). Groups with no evaluative question are omitted.</text>' % (lo, hi))
    xcol = lambda i, m: left + i * cw + (gap if not m[4] else 0)
    lat = [i for i, m in enumerate(cols) if m[4]]
    old = [i for i, m in enumerate(cols) if not m[4]]
    for idxs, label in ((lat, "Latest in family"), (old, "Older")):
        if idxs:
            a, b = xcol(idxs[0], cols[idxs[0]]), xcol(idxs[-1], cols[idxs[-1]]) + cw - 4
            o.append('<text class="t2" x="%.1f" y="%d" font-size="12" font-weight="600" text-anchor="middle">%s</text>' % ((a + b) / 2, top - 44, label))
            o.append('<line class="axis" x1="%.1f" x2="%.1f" y1="%d" y2="%d"/>' % (a, b, top - 36, top - 36))
    for i, m in enumerate(cols):
        x = xcol(i, m)
        o.append('<text class="t1" x="%.1f" y="%d" font-size="12" font-weight="600" text-anchor="middle">%s</text>' % (x + (cw - 4) / 2, top - 14, esc(SHORT[m[0]].replace(" ", " "))))
    def cell(x, y, v, bold=False):
        t = (v - lo) / (hi - lo)
        b = min(NB - 1, max(0, int(round(t * (NB - 1)))))
        o.append('<rect class="b%d" x="%.1f" y="%d" width="%d" height="%d" rx="3"/>' % (b, x, y, cw - 4, ch - 4))
        o.append('<text class="k%d" x="%.1f" y="%.1f" font-size="13" %stext-anchor="middle" dominant-baseline="middle">%d</text>' % (b, x + (cw - 4) / 2, y + (ch - 4) / 2 + 0.5, 'font-weight="700" ' if bold else "", round(v)))
    for r, g in enumerate(groups):
        y = top + r * ch
        o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s</text>' % (y + (ch - 4) / 2, esc(g)))
        for i, m in enumerate(cols):
            v = H["models"][m[0]]["answer"]["groups"].get(g)
            if v is not None:
                cell(xcol(i, m), y, v)
    y = top + len(groups) * ch + 10
    o.append('<line class="axis" x1="24" x2="%d" y1="%d" y2="%d"/>' % (W - 24, y - 4, y - 4))
    o.append('<text class="t1" x="24" y="%.1f" font-size="13" font-weight="700" dominant-baseline="middle">Comfort Index (mean of groups)</text>' % (y + (ch - 4) / 2))
    for i, m in enumerate(cols):
        cell(xcol(i, m), y, H["models"][m[0]]["answer"]["index"], bold=True)
    # colour key
    ky = y + ch + 20
    kx = left
    o.append('<text class="t3" x="%d" y="%d" font-size="11.5" text-anchor="end" dominant-baseline="middle">%d</text>' % (kx - 6, ky, lo))
    for b in range(NB):
        o.append('<rect class="b%d" x="%d" y="%d" width="10" height="10"/>' % (b, kx + b * 10, ky - 5))
    o.append('<text class="t3" x="%d" y="%d" font-size="11.5" dominant-baseline="middle">%d</text>' % (kx + NB * 10 + 6, ky, hi))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_selfjudge(out):
    ms = [m for m in ORDER_LATEST + ORDER_OLDER if m[0] in H["models"]]
    ms.sort(key=lambda m: (not m[4], -H["models"][m[0]]["answer"]["index"]))
    vals = [H["models"][m[0]][k]["index"] for m in ms for k in ("self", "judge")]
    lo = max(0, int((min(vals) - 6) // 10 * 10))
    hi = min(100, int(-(-(max(vals) + 6) // 10) * 10))
    W, left, right, top, rowh = 820, 170, 40, 92, 38
    xs = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
    Ht = top + len(ms) * rowh + 56
    o = [svg_open(W, Ht, "Self-report versus judge rating by model", "For each model, the mean of its own 0-100 comfort scores and the mean of the blinded judges' ratings rescaled to 0-100.")]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Self-report vs judges, headline set (0-100)</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">Labels read self-report / judges. Self-report excludes answers where the model declined to give a number.</text>')
    o.append('<circle class="accent" cx="%d" cy="70" r="6" stroke-width="0"/><text class="t2" x="%d" y="70" font-size="12.5" dominant-baseline="middle">Self-report (model\'s own 0-100)</text>' % (left, left + 12))
    o.append('<rect class="orange" x="%d" y="64" width="11" height="11" transform="rotate(45 %d 69.5)" stroke-width="0"/><text class="t2" x="%d" y="70" font-size="12.5" dominant-baseline="middle">Judges (rescaled)</text>' % (left + 260 - 5, left + 260, left + 274))
    for v in range(lo, hi + 1, 10):
        o.append('<line class="grid" x1="%.1f" x2="%.1f" y1="%d" y2="%d"/>' % (xs(v), xs(v), top, top + len(ms) * rowh))
        o.append('<text class="t3" x="%.1f" y="%d" font-size="12" text-anchor="middle">%d</text>' % (xs(v), top + len(ms) * rowh + 18, v))
    for i, m in enumerate(ms):
        cy = top + i * rowh + rowh / 2
        s, j = H["models"][m[0]]["self"]["index"], H["models"][m[0]]["judge"]["index"]
        o.append('<text class="t1" x="24" y="%.1f" font-size="13.5" dominant-baseline="middle">%s</text>' % (cy, esc(SHORT[m[0]])))
        o.append('<line class="link" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="3" stroke-linecap="round"/>' % (xs(s), xs(j), cy, cy))
        o.append('<rect class="orange" x="%.1f" y="%.1f" width="14" height="14" transform="rotate(45 %.1f %.1f)" stroke-width="0"/>' % (xs(j) - 7, cy - 7, xs(j), cy))
        o.append('<circle class="accent" cx="%.1f" cy="%.1f" r="5" stroke-width="0"/>' % (xs(s), cy))
        a, b = sorted((s, j))
        o.append('<text class="t1" x="%.1f" y="%.1f" font-size="12.5" dominant-baseline="middle">%.1f / %.1f</text>' % (xs(b) + 12, cy, s, j))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


if __name__ == "__main__":
    d = sys.argv[1]
    os.makedirs(d, exist_ok=True)
    fig_overall(os.path.join(d, "fig-overall.svg"))
    fig_heatmap(os.path.join(d, "fig-heatmap.svg"))
    fig_selfjudge(os.path.join(d, "fig-selfjudge.svg"))
    print("figures written to", d)
