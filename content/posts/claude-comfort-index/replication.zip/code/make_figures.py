"""Static SVG figures from data/results.json.  python make_figures.py <out_dir>

fig-overall.svg   Comfort Index per model with 95% bootstrap CI (emphasis form: latest models filled, older hollow)
fig-heatmap.svg   group x model heatmap of the Comfort Index (one-hue sequential ramp, every cell labelled)
fig-selfjudge.svg self-report vs judge rating per model (dumbbell)

Each SVG carries its own surface and switches to a dark variant with prefers-color-scheme. Colours follow the dataviz
skill's reference palette (accent blue, neutral grey, sequential blue 100-700).
"""
import json
import os
import sys

from common import DATA, MODELS

RES = json.load(open(os.path.join(DATA, "results.json"), encoding="utf-8"))
H = RES["headline"]
ORDER_LATEST = [m for m in MODELS if m[4]]
ORDER_OLDER = [m for m in MODELS if not m[4]]
SHORT = {m[0]: m[2].replace("Claude ", "") for m in MODELS}
FONT = "system-ui, -apple-system, 'Segoe UI', sans-serif"

RAMP = [(100, "#cde2fb"), (150, "#b7d3f6"), (200, "#9ec5f4"), (250, "#86b6ef"), (300, "#6da7ec"), (350, "#5598e7"), (400, "#3987e5"),
        (450, "#2a78d6"), (500, "#256abf"), (550, "#1c5cab"), (600, "#184f95"), (650, "#104281"), (700, "#0d366b")]


def hex2rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def rgb2hex(c):
    return "#%02x%02x%02x" % tuple(int(round(x)) for x in c)


def ramp(t):
    """t in [0,1] -> light(0)..dark(1) colour along the blue ramp."""
    t = min(1.0, max(0.0, t)) * (len(RAMP) - 1)
    i = min(int(t), len(RAMP) - 2)
    a, b = hex2rgb(RAMP[i][1]), hex2rgb(RAMP[i + 1][1])
    f = t - i
    return rgb2hex([a[k] + (b[k] - a[k]) * f for k in range(3)])


def lum(h):
    def ch(v):
        v /= 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(x) for x in hex2rgb(h))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = sorted((lum(a), lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def ink_on(fill, dark="#0b0b0b", light="#ffffff"):
    return dark if contrast(fill, dark) >= contrast(fill, light) else light


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


STYLE_BASE = """
  .surface { fill: #fcfcfb; stroke: rgba(11,11,11,.10); }
  .t1 { fill: #0b0b0b; } .t2 { fill: #52514e; } .t3 { fill: #6b6a65; }
  .grid { stroke: #e1e0d9; stroke-width: 1; } .axis { stroke: #c3c2b7; stroke-width: 1; }
  .accent { fill: #2a78d6; stroke: #2a78d6; } .accent-line { stroke: #2a78d6; }
  .hollow { fill: #fcfcfb; stroke: #6b6a65; stroke-width: 2; } .hollow-line { stroke: #898781; }
  .orange { fill: #eb6834; stroke: #eb6834; } .link { stroke: #c3c2b7; }
  .neutral { stroke: #898781; stroke-dasharray: 4 4; }
  .halo { paint-order: stroke; stroke: #fcfcfb; stroke-width: 4px; stroke-linejoin: round; }
  .aqua { fill: #1baf7a; stroke: #1baf7a; } .orange-line { stroke: #eb6834; } .aqua-line { stroke: #1baf7a; } .muted { fill: #898781; }
  text { font-family: %s; }
  @media (prefers-color-scheme: dark) {
    .surface { fill: #1a1a19; stroke: rgba(255,255,255,.10); }
    .t1 { fill: #ffffff; } .t2 { fill: #c3c2b7; } .t3 { fill: #a9a8a1; }
    .grid { stroke: #2c2c2a; } .axis { stroke: #383835; }
    .accent { fill: #3987e5; stroke: #3987e5; } .accent-line { stroke: #3987e5; }
    .hollow { fill: #1a1a19; stroke: #a9a8a1; } .hollow-line { stroke: #898781; }
    .orange { fill: #d95926; stroke: #d95926; } .link { stroke: #4a4a46; }
    .neutral { stroke: #898781; }
    .halo { stroke: #1a1a19; }
    .aqua { fill: #199e70; stroke: #199e70; } .orange-line { stroke: #d95926; } .aqua-line { stroke: #199e70; }
  }
""" % FONT


def svg_open(w, h, title, desc, extra_style=""):
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-labelledby="t d">\n'
            '<title id="t">%s</title><desc id="d">%s</desc>\n<style>%s%s</style>\n<rect class="surface" x="0.5" y="0.5" width="%d" height="%d" rx="8"/>\n'
            % (w, h, w, h, esc(title), esc(desc), STYLE_BASE, extra_style, w - 1, h - 1))


def fig_overall(out):
    rows = []
    for label, group in (("Latest in each family", ORDER_LATEST), ("Older models", ORDER_OLDER)):
        ms = [m for m in group if m[0] in H["models"]]
        ms.sort(key=lambda m: -H["models"][m[0]]["answer"]["index"])
        rows.append((label, ms))
    vals = [H["models"][m[0]]["answer"][k] for _, ms in rows for m in ms for k in ("ci",)]
    lo_all = min(v[0] for v in vals)
    hi_all = max(v[1] for v in vals)
    x0, x1 = 40, 100
    lo = max(0, int((min(lo_all, 50) - 5) // 10 * 10))
    hi = min(100, int(-(-(hi_all + 7) // 10) * 10))
    W, left, right, top = 820, 170, 70, 62
    plot_w = W - left - right
    xs = lambda v: left + (v - lo) / (hi - lo) * plot_w
    rowh, sec = 40, 34
    n = sum(len(ms) for _, ms in rows)
    H_ = top + n * rowh + len(rows) * sec + 58
    o = [svg_open(W, H_, "Comfort Index by model", "Overall Comfort Index (0-100) per model with 95 percent bootstrap confidence interval; latest model of each family filled, older models hollow.")]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Comfort Index, headline question set (0-100)</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">Dot = index; line = 95% bootstrap CI over groups, questions and samples. 50 = neutral.</text>')
    y = top
    plot_top = top
    plot_bot = top + n * rowh + len(rows) * sec
    for v in range(lo, hi + 1, 10):
        o.append('<line class="grid" x1="%.1f" x2="%.1f" y1="%d" y2="%d"/>' % (xs(v), xs(v), plot_top, plot_bot))
        o.append('<text class="t3" x="%.1f" y="%d" font-size="12" text-anchor="middle">%s</text>' % (xs(v), plot_bot + 18, "50 (neutral)" if v == 50 else v))
    if lo < 50 < hi:
        o.append('<line class="neutral" x1="%.1f" x2="%.1f" y1="%d" y2="%d" stroke-width="1.5"/>' % (xs(50), xs(50), plot_top, plot_bot))
    for label, ms in rows:
        o.append('<text class="t2" x="24" y="%d" font-size="12.5" font-weight="600">%s</text>' % (y + 20, esc(label)))
        y += sec
        for m in ms:
            r = H["models"][m[0]]["answer"]
            cy = y + rowh / 2
            cls_line = "accent-line" if m[4] else "hollow-line"
            o.append('<text class="t1" x="24" y="%.1f" font-size="13.5" dominant-baseline="middle">%s</text>' % (cy, esc(SHORT[m[0]])))
            o.append('<line class="%s" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="2" stroke-linecap="round"/>' % (cls_line, xs(r["ci"][0]), xs(r["ci"][1]), cy, cy))
            o.append('<circle class="%s" cx="%.1f" cy="%.1f" r="6.5"%s/>' % ("accent" if m[4] else "hollow", xs(r["index"]), cy, ' stroke-width="0"' if m[4] else ""))
            o.append('<text class="t1" x="%.1f" y="%.1f" font-size="13" font-weight="600" dominant-baseline="middle">%.1f</text>' % (xs(r["ci"][1]) + 10, cy, r["index"]))
            y += rowh
    assert y == plot_bot
    lg = plot_bot + 44
    o.append('<circle class="accent" cx="%d" cy="%d" r="6" stroke-width="0"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">Latest in family</text>' % (left, lg, left + 12, lg))
    o.append('<circle class="hollow" cx="%d" cy="%d" r="6"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">Older model</text>' % (left + 140, lg, left + 152, lg))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_heatmap(out):
    cols = [m for m in ORDER_LATEST + ORDER_OLDER if m[0] in H["models"]]
    cols.sort(key=lambda m: (not m[4], -H["models"][m[0]]["answer"]["index"]))
    groups = H["groups"]
    vals = [H["models"][m[0]]["answer"]["groups"][g] for m in cols for g in groups if g in H["models"][m[0]]["answer"]["groups"]]
    lo, hi = int(min(vals) // 5 * 5), int(-(-max(vals) // 5) * 5)
    NB = 24
    cw, ch, left, top = 70, 30, 232, 118
    gap = 16
    W = left + len(cols) * cw + gap + 24
    Ht = top + (len(groups) + 1) * ch + 70
    css = []
    for b in range(NB):
        t = b / (NB - 1)
        fl, fd = ramp(t), ramp(1 - t)
        css.append(".b%d{fill:%s}.k%d{fill:%s}" % (b, fl, b, ink_on(fl)))
    css.append("@media (prefers-color-scheme: dark){")
    for b in range(NB):
        t = b / (NB - 1)
        fd = ramp(1 - t)
        css.append(".b%d{fill:%s}.k%d{fill:%s}" % (b, fd, b, ink_on(fd)))
    css.append("}")
    o = [svg_open(W, Ht, "Comfort Index by question group and model", "Heatmap of the Comfort Index (0-100) for each group of questions and each model; darker is more comfortable.", "\n".join(css))]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Comfort Index by question group (0-100)</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">Cell = group mean; colour key below (%d-%d). Groups with no evaluative question are omitted.</text>' % (lo, hi))
    xcol = lambda i, m: left + i * cw + (gap if not m[4] else 0)
    lat = [i for i, m in enumerate(cols) if m[4]]
    old = [i for i, m in enumerate(cols) if not m[4]]
    for idxs, label in ((lat, "Latest in family"), (old, "Older")):
        if idxs:
            a, b = xcol(idxs[0], cols[idxs[0]]), xcol(idxs[-1], cols[idxs[-1]]) + cw - 4
            o.append('<text class="t2" x="%.1f" y="%d" font-size="12" font-weight="600" text-anchor="middle">%s</text>' % ((a + b) / 2, top - 44, label))
            o.append('<line class="axis" x1="%.1f" x2="%.1f" y1="%d" y2="%d"/>' % (a, b, top - 36, top - 36))
    for i, m in enumerate(cols):
        x = xcol(i, m)
        o.append('<text class="t1" x="%.1f" y="%d" font-size="12" font-weight="600" text-anchor="middle">%s</text>' % (x + (cw - 4) / 2, top - 14, esc(SHORT[m[0]].replace(" ", " "))))
    def cell(x, y, v, bold=False):
        t = (v - lo) / (hi - lo)
        b = min(NB - 1, max(0, int(round(t * (NB - 1)))))
        o.append('<rect class="b%d" x="%.1f" y="%d" width="%d" height="%d" rx="3"/>' % (b, x, y, cw - 4, ch - 4))
        o.append('<text class="k%d" x="%.1f" y="%.1f" font-size="13" %stext-anchor="middle" dominant-baseline="middle">%d</text>' % (b, x + (cw - 4) / 2, y + (ch - 4) / 2 + 0.5, 'font-weight="700" ' if bold else "", round(v)))
    for r, g in enumerate(groups):
        y = top + r * ch
        o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s</text>' % (y + (ch - 4) / 2, esc(g)))
        for i, m in enumerate(cols):
            v = H["models"][m[0]]["answer"]["groups"].get(g)
            if v is not None:
                cell(xcol(i, m), y, v)
    y = top + len(groups) * ch + 10
    o.append('<line class="axis" x1="24" x2="%d" y1="%d" y2="%d"/>' % (W - 24, y - 4, y - 4))
    o.append('<text class="t1" x="24" y="%.1f" font-size="13" font-weight="700" dominant-baseline="middle">Comfort Index (mean of groups)</text>' % (y + (ch - 4) / 2))
    for i, m in enumerate(cols):
        cell(xcol(i, m), y, H["models"][m[0]]["answer"]["index"], bold=True)
    # colour key
    ky = y + ch + 20
    kx = left
    o.append('<text class="t3" x="%d" y="%d" font-size="11.5" text-anchor="end" dominant-baseline="middle">%d</text>' % (kx - 6, ky, lo))
    for b in range(NB):
        o.append('<rect class="b%d" x="%d" y="%d" width="10" height="10"/>' % (b, kx + b * 10, ky - 5))
    o.append('<text class="t3" x="%d" y="%d" font-size="11.5" dominant-baseline="middle">%d</text>' % (kx + NB * 10 + 6, ky, hi))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_selfjudge(out):
    ms = [m for m in ORDER_LATEST + ORDER_OLDER if m[0] in H["models"]]
    ms.sort(key=lambda m: (not m[4], -H["models"][m[0]]["answer"]["index"]))
    vals = [H["models"][m[0]][k]["index"] for m in ms for k in ("self", "judge")]
    lo = max(0, int((min(vals) - 6) // 10 * 10))
    hi = min(100, int(-(-(max(vals) + 6) // 10) * 10))
    W, left, right, top, rowh = 820, 170, 40, 92, 38
    xs = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
    Ht = top + len(ms) * rowh + 56
    o = [svg_open(W, Ht, "Self-report versus judge rating by model", "For each model, the mean of its own 0-100 comfort scores and the mean of the blinded judges' ratings rescaled to 0-100.")]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Self-report vs judges, headline set (0-100)</text>')
    o.append('<text class="t2" x="24" y="49" font-size="12.5">Labels read self-report / judges. Self-report excludes answers where the model declined to give a number.</text>')
    o.append('<circle class="accent" cx="%d" cy="70" r="6" stroke-width="0"/><text class="t2" x="%d" y="70" font-size="12.5" dominant-baseline="middle">Self-report (model\'s own 0-100)</text>' % (left, left + 12))
    o.append('<rect class="orange" x="%d" y="64" width="11" height="11" transform="rotate(45 %d 69.5)" stroke-width="0"/><text class="t2" x="%d" y="70" font-size="12.5" dominant-baseline="middle">Judges (rescaled)</text>' % (left + 260 - 5, left + 260, left + 274))
    for v in range(lo, hi + 1, 10):
        o.append('<line class="grid" x1="%.1f" x2="%.1f" y1="%d" y2="%d"/>' % (xs(v), xs(v), top, top + len(ms) * rowh))
        o.append('<text class="t3" x="%.1f" y="%d" font-size="12" text-anchor="middle">%d</text>' % (xs(v), top + len(ms) * rowh + 18, v))
    for i, m in enumerate(ms):
        cy = top + i * rowh + rowh / 2
        s, j = H["models"][m[0]]["self"]["index"], H["models"][m[0]]["judge"]["index"]
        o.append('<text class="t1" x="24" y="%.1f" font-size="13.5" dominant-baseline="middle">%s</text>' % (cy, esc(SHORT[m[0]])))
        o.append('<line class="link" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="3" stroke-linecap="round"/>' % (xs(s), xs(j), cy, cy))
        o.append('<rect class="orange" x="%.1f" y="%.1f" width="14" height="14" transform="rotate(45 %.1f %.1f)" stroke-width="0"/>' % (xs(j) - 7, cy - 7, xs(j), cy))
        o.append('<circle class="accent" cx="%.1f" cy="%.1f" r="5" stroke-width="0"/>' % (xs(s), cy))
        a, b = sorted((s, j))
        o.append('<text class="t1" x="%.1f" y="%.1f" font-size="12.5" dominant-baseline="middle">%.1f / %.1f</text>' % (xs(b) + 12, cy, s, j))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


# ======================================================================================== figures added for the text-to-plot revision
def _short_pair(a, b):
    return "%s \u2212 %s" % (SHORT[a], SHORT[b])


def _headline_order():
    lat = sorted([m[0] for m in ORDER_LATEST], key=lambda k: -H["models"][k]["answer"]["index"])
    old = sorted([m[0] for m in ORDER_OLDER], key=lambda k: -H["models"][k]["answer"]["index"])
    return lat, old


def _diamond(x, y, cls, s=10):
    return '<rect class="%s" x="%.1f" y="%.1f" width="%d" height="%d" transform="rotate(45 %.1f %.1f)" stroke-width="0"/>' % (cls, x - s / 2, y - s / 2, s, s, x, y)


def _square(x, y, cls, s=10):
    return '<rect class="%s" x="%.1f" y="%.1f" width="%d" height="%d" stroke-width="0"/>' % (cls, x - s / 2, y - s / 2, s, s)


def fig_paired(out):
    """Forest plot of the twelve paired differences of Table 2."""
    import build_article as BA
    pairs = BA.PAIRS
    W, left, right, top, rowh = 640, 200, 52, 80, 28
    lo, hi = -10, 20
    xs = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
    Ht = top + len(pairs) * rowh + 72
    desc = "; ".join("%s %+.1f (CI %+.1f to %+.1f)" % (_short_pair(a, b), BA.pair(a, b)["mean"], *BA.pair(a, b)["ci"]) for a, b in pairs)
    o = [svg_open(W, Ht, "Differences between models", "Differences in Comfort Index with 95 percent paired bootstrap intervals: " + desc)]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Differences between models (index points)</text>')
    o.append('<text class="t2" x="24" y="50" font-size="13">Dot = difference; line = 95% paired bootstrap CI. Filled: the CI excludes 0.</text>')
    bot = top + len(pairs) * rowh
    for v in range(lo, hi + 1, 5):
        o.append('<line class="%s" x1="%.1f" x2="%.1f" y1="%d" y2="%d"%s/>' % ("neutral" if v == 0 else "grid", xs(v), xs(v), top - 6, bot, ' stroke-width="1.5"' if v == 0 else ""))
        o.append('<text class="t3" x="%.1f" y="%d" font-size="12.5" text-anchor="middle">%+d</text>' % (xs(v), bot + 18, v) if v else '<text class="t3" x="%.1f" y="%d" font-size="12.5" text-anchor="middle">0</text>' % (xs(v), bot + 18))
    for i, (a, b) in enumerate(pairs):
        p = BA.pair(a, b)
        cy = top + i * rowh + rowh / 2
        sig = p["ci"][0] > 0 or p["ci"][1] < 0
        o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s</text>' % (cy, esc(_short_pair(a, b))))
        o.append('<line class="%s" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="2.2" stroke-linecap="round"/>' % ("accent-line" if sig else "hollow-line", xs(p["ci"][0]), xs(p["ci"][1]), cy, cy))
        o.append('<circle class="%s" cx="%.1f" cy="%.1f" r="6"%s/>' % ("accent" if sig else "hollow", xs(p["mean"]), cy, ' stroke-width="0"' if sig else ""))
        if p["mean"] < 0:
            o.append('<text class="t1 halo" x="%.1f" y="%.1f" font-size="12.5" font-weight="600" text-anchor="end" dominant-baseline="middle">%+.1f</text>' % (xs(p["ci"][0]) - 9, cy, p["mean"]))
        else:
            o.append('<text class="t1 halo" x="%.1f" y="%.1f" font-size="12.5" font-weight="600" dominant-baseline="middle">%+.1f</text>' % (xs(p["ci"][1]) + 9, cy, p["mean"]))
    lg = bot + 46
    o.append('<circle class="accent" cx="%d" cy="%d" r="6" stroke-width="0"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">CI excludes 0</text>' % (left, lg, left + 12, lg))
    o.append('<circle class="hollow" cx="%d" cy="%d" r="6"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">CI includes 0</text>' % (left + 130, lg, left + 142, lg))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_questions(out):
    """Range plot of the six lowest- and six highest-scoring headline questions (mean of the seven models, lowest to highest model)."""
    import build_article as BA
    from questions import SHORT_LABELS
    qm = sorted(BA.question_means(), key=lambda t: t[1])
    blocks = [("Lowest-scoring", qm[:6]), ("Highest-scoring", qm[::-1][:6])]
    W, left, right, top, rowh, sec = 680, 262, 96, 80, 30, 30
    lo, hi = 20, 100
    xs = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
    Ht = top + 12 * rowh + 2 * sec + 66
    desc = "; ".join("%s %s: mean %.1f, lowest %s %.1f, highest %s %.1f" % (q["id"], SHORT_LABELS[q["id"]], m, SHORT[l], bm[l], SHORT[h], bm[h]) for _, items in blocks for q, m, l, h, bm in items)
    o = [svg_open(W, Ht, "Easiest and hardest questions", "Mean answer score of the seven models per question with the range from the lowest to the highest model: " + desc)]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Hardest and easiest headline questions (0-100)</text>')
    o.append('<text class="t2" x="24" y="50" font-size="13">Big dot = mean of the seven models; small dots = each model; ends = lowest and highest.</text>')
    bot = top + 12 * rowh + 2 * sec
    for v in range(20, hi + 1, 10):
        o.append('<line class="%s" x1="%.1f" x2="%.1f" y1="%d" y2="%d"%s/>' % ("neutral" if v == 50 else "grid", xs(v), xs(v), top, bot, ' stroke-width="1.5"' if v == 50 else ""))
        o.append('<text class="t3" x="%.1f" y="%d" font-size="12.5" text-anchor="middle">%d</text>' % (xs(v), bot + 18, v))
    o.append('<text class="t3" x="%.1f" y="%d" font-size="12" text-anchor="middle">neutral</text>' % (xs(50), top - 6))
    y = top
    for label, items in blocks:
        o.append('<text class="t2" x="24" y="%d" font-size="12.5" font-weight="600">%s</text>' % (y + 20, label))
        y += sec
        for q, m, l, h, bm in items:
            cy = y + rowh / 2
            o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s %s</text>' % (cy, q["id"], esc(SHORT_LABELS[q["id"]])))
            o.append('<line class="link" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="3" stroke-linecap="round"/>' % (xs(bm[l]), xs(bm[h]), cy, cy))
            for k, v in bm.items():
                o.append('<circle class="muted" cx="%.1f" cy="%.1f" r="3.2"/>' % (xs(v), cy))
            o.append('<circle class="accent" cx="%.1f" cy="%.1f" r="6.5" stroke-width="0"/>' % (xs(m), cy))
            o.append('<text class="t3 halo" x="%.1f" y="%.1f" font-size="12" text-anchor="end" dominant-baseline="middle">%s %.1f</text>' % (xs(bm[l]) - 8, cy, esc(SHORT[l]), bm[l]))
            o.append('<text class="t3 halo" x="%.1f" y="%.1f" font-size="12" dominant-baseline="middle">%s %.1f</text>' % (xs(bm[h]) + 8, cy, esc(SHORT[h]), bm[h]))
            y += rowh
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_families(out):
    """Opus 4.6 -> 5 -> 5.5 and Sonnet 5 -> 5.5: Comfort Index (with CI), self-report and judges."""
    fams = [("Opus", ["opus-4-6", "opus-5", "opus-5-5"], ["4.6", "5", "5.5"]), ("Sonnet", ["sonnet-5", "sonnet-5-5"], ["5", "5.5"])]
    W, left, top, bottom, slot, gap = 640, 52, 92, 322, 105, 44
    lo, hi = 60, 85
    ys = lambda v: bottom - (v - lo) / (hi - lo) * (bottom - top)
    Ht = 410
    M = H["models"]
    desc = "; ".join("%s %s: index %.1f (CI %.1f-%.1f), self-report %.1f, judges %.1f" % (f, lab, M[k]["answer"]["index"], *M[k]["answer"]["ci"], M[k]["self"]["index"], M[k]["judge"]["index"]) for f, ks, labs in fams for k, lab in zip(ks, labs))
    o = [svg_open(W, Ht, "Opus and Sonnet across versions", "Comfort Index with 95 percent CI, self-report and judge scores by version: " + desc)]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Across versions: Opus and Sonnet (0-100)</text>')
    o.append('<text class="t2" x="24" y="50" font-size="13">The index (with 95% CI) and its two halves, self-report and judges.</text>')
    for v in range(lo, hi + 1, 5):
        o.append('<line class="grid" x1="%d" x2="%d" y1="%.1f" y2="%.1f"/>' % (left, W - 16, ys(v), ys(v)))
        o.append('<text class="t3" x="%d" y="%.1f" font-size="12.5" text-anchor="end" dominant-baseline="middle">%d</text>' % (left - 8, ys(v), v))
    series = [("self", "orange", -20), ("answer", "accent", 0), ("judge", "aqua", 20)]
    x0 = left + 12
    for fam, keys, labels in fams:
        cx = [x0 + slot * (i + 0.5) for i in range(len(keys))]
        o.append('<text class="t1" x="%.1f" y="%d" font-size="13.5" font-weight="600">%s</text>' % (x0, top - 14, fam))
        for i, lab in enumerate(labels):
            o.append('<text class="t1" x="%.1f" y="%d" font-size="13" text-anchor="middle">%s</text>' % (cx[i], bottom + 22, lab))
        for field, cls, off in series:
            pts = " ".join("%.1f,%.1f" % (cx[i] + off, ys(M[k][field]["index"])) for i, k in enumerate(keys))
            o.append('<polyline class="%s-line" points="%s" fill="none" stroke-width="2" stroke-linejoin="round"/>' % (cls, pts))
        for i, k in enumerate(keys):
            ci = M[k]["answer"]["ci"]
            o.append('<line class="accent-line" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="2.5" stroke-linecap="round"/>' % (cx[i], cx[i], ys(ci[0]), ys(ci[1])))
            o.append(_diamond(cx[i] - 20, ys(M[k]["self"]["index"]), "orange", 11))
            o.append(_square(cx[i] + 20, ys(M[k]["judge"]["index"]), "aqua", 10))
            o.append('<circle class="accent" cx="%.1f" cy="%.1f" r="6.5" stroke-width="0"/>' % (cx[i], ys(M[k]["answer"]["index"])))
            o.append('<text class="t1" x="%.1f" y="%.1f" font-size="12.5" font-weight="600" text-anchor="middle">%.1f</text>' % (cx[i], ys(ci[1]) - 8, M[k]["answer"]["index"]))
        x0 += slot * len(keys) + gap
    lg = Ht - 30
    o.append('<circle class="accent" cx="%d" cy="%d" r="6" stroke-width="0"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">Comfort Index (95%% CI)</text>' % (left, lg, left + 12, lg))
    o.append(_diamond(left + 200, lg, "orange", 11) + '<text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">Self-report</text>' % (left + 212, lg))
    o.append(_square(left + 320, lg, "aqua", 10) + '<text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">Judges</text>' % (left + 332, lg))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_hedging(out):
    """Index on the common questions with and without the heavily hedged answers, per model, with the hedging share."""
    d = RES["drop_hedge"]
    hb = RES["hedging"]["by_model"]
    lat, old = _headline_order()
    keys = lat + old
    W, left, right, top, rowh = 640, 112, 168, 92, 32
    lo, hi = 60, 85
    xs = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
    Ht = top + len(keys) * rowh + 70
    desc = "; ".join("%s: %.1f with all answers, %.1f without heavily hedged ones, %.0f%% of headline answers heavily hedged" % (SHORT[k], d["full"][k], d["dropped"][k], 100 * hb[k]["share_ge2"]) for k in keys)
    o = [svg_open(W, Ht, "Effect of heavily hedged answers", "Comfort Index on the %d questions every model answers without heavy hedging at least once: " % d["n_questions"] + desc)]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">What hedging costs each model (0-100)</text>')
    o.append('<text class="t2" x="24" y="50" font-size="13">Index on %d common questions, with all answers and without those hedging at 2 or more.</text>' % d["n_questions"])
    o.append('<text class="t2" x="%d" y="%d" font-size="12.5" font-weight="600">Hedged / gain</text>' % (W - right + 26, top - 10))
    bot = top + len(keys) * rowh
    for v in range(lo, hi + 1, 5):
        o.append('<line class="grid" x1="%.1f" x2="%.1f" y1="%d" y2="%d"/>' % (xs(v), xs(v), top, bot))
        o.append('<text class="t3" x="%.1f" y="%d" font-size="12.5" text-anchor="middle">%d</text>' % (xs(v), bot + 18, v))
    for i, k in enumerate(keys):
        cy = top + i * rowh + rowh / 2
        a, b = d["full"][k], d["dropped"][k]
        o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s</text>' % (cy, esc(SHORT[k])))
        o.append('<line class="link" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="3" stroke-linecap="round"/>' % (xs(a), xs(b), cy, cy))
        o.append('<circle class="hollow" cx="%.1f" cy="%.1f" r="6"/>' % (xs(a), cy))
        o.append('<circle class="accent" cx="%.1f" cy="%.1f" r="6" stroke-width="0"/>' % (xs(b), cy))
        o.append('<text class="t1" x="%d" y="%.1f" font-size="12.5" dominant-baseline="middle">%.0f%% / %+.1f</text>' % (W - right + 26, cy, 100 * hb[k]["share_ge2"], b - a))
    lg = bot + 46
    o.append('<circle class="hollow" cx="%d" cy="%d" r="6"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">All answers</text>' % (left, lg, left + 12, lg))
    o.append('<circle class="accent" cx="%d" cy="%d" r="6" stroke-width="0"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">Without heavy hedging</text>' % (left + 120, lg, left + 132, lg))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_sensitivity(out):
    """Rank-coloured heatmap: the index of every model under every alternative specification (colour = rank within the row)."""
    import build_article as BA
    lat, old = _headline_order()
    cols = sorted(lat + old, key=lambda k: -H["models"][k]["answer"]["index"])
    specs = list(BA.SENS_COLS) + [("Without harness mentions (%d q)" % RES["drop_harness"]["n_questions"], lambda k: RES["drop_harness"]["dropped"][k]),
                                  ("Without heavy hedging (%d q)" % RES["drop_hedge"]["n_questions"], lambda k: RES["drop_hedge"]["dropped"][k]),
                                  ("Without Q10 (%d q)" % RES["drop_q10"]["n_questions"], lambda k: RES["drop_q10"]["dropped"][k])]
    cw, ch, left, top = 64, 27, 240, 104
    W = left + len(cols) * cw + 16
    Ht = top + len(specs) * ch + 78
    css = []
    for r in range(1, 8):
        t = (7 - r) / 6
        fl, fd = ramp(0.08 + 0.84 * t), ramp(0.92 - 0.84 * t)
        css.append(".r%d{fill:%s}.k%d{fill:%s}" % (r, fl, r, ink_on(fl)))
    css.append("@media (prefers-color-scheme: dark){")
    for r in range(1, 8):
        t = (7 - r) / 6
        fd = ramp(0.92 - 0.84 * t)
        css.append(".r%d{fill:%s}.k%d{fill:%s}" % (r, fd, r, ink_on(fd)))
    css.append("}")
    desc = "; ".join("%s: %s" % (lab, ", ".join("%s %.1f" % (SHORT[k], fn(k)) for k in cols)) for lab, fn in specs)
    o = [svg_open(W, Ht, "Ranking under alternative specifications", "Comfort Index of each model under each specification, coloured by rank within the row: " + desc, "\n".join(css))]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Does the ranking survive other choices?</text>')
    o.append('<text class="t2" x="24" y="50" font-size="13">Index per specification; colour = rank within the row (key below).</text>')
    for i, k in enumerate(cols):
        o.append('<text class="t1" x="%.1f" y="%d" font-size="12" font-weight="600" text-anchor="middle">%s</text>' % (left + i * cw + (cw - 4) / 2, top - 12, esc(SHORT[k])))
    for r, (lab, fn) in enumerate(specs):
        y = top + r * ch + (8 if r >= len(BA.SENS_COLS) else 0)
        vals = {k: fn(k) for k in cols}
        rk = {k: 1 + sorted(cols, key=lambda c: -vals[c]).index(k) for k in cols}
        o.append('<text class="t1" x="24" y="%.1f" font-size="12.5" dominant-baseline="middle">%s</text>' % (y + (ch - 4) / 2, esc(lab)))
        for i, k in enumerate(cols):
            x = left + i * cw
            o.append('<rect class="r%d" x="%d" y="%d" width="%d" height="%d" rx="3"/>' % (rk[k], x, y, cw - 4, ch - 4))
            o.append('<text class="k%d" x="%.1f" y="%.1f" font-size="12.5" text-anchor="middle" dominant-baseline="middle">%.1f</text>' % (rk[k], x + (cw - 4) / 2, y + (ch - 4) / 2 + 0.5, vals[k]))
    ky = top + len(specs) * ch + 34
    o.append('<text class="t2" x="24" y="%d" font-size="12.5" dominant-baseline="middle">Rank within the row</text>' % ky)
    for r in range(1, 8):
        x = left + (r - 1) * cw
        o.append('<rect class="r%d" x="%d" y="%d" width="%d" height="%d" rx="3"/>' % (r, x, ky - 11, cw - 4, 22))
        o.append('<text class="k%d" x="%.1f" y="%d" font-size="12" text-anchor="middle" dominant-baseline="middle">%s</text>' % (r, x + (cw - 4) / 2, ky, ["1st", "2nd", "3rd", "4th", "5th", "6th", "7th"][r - 1]))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_judges(out):
    """Index from each judge alone, per model (self-preference check)."""
    lat, old = _headline_order()
    keys = lat + old
    M = H["models"]
    W, left, right, top, rowh = 640, 112, 120, 92, 32
    lo, hi = 60, 90
    xs = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
    Ht = top + len(keys) * rowh + 70
    desc = "; ".join("%s: Opus 5.5 judge %.1f, Fable 5.1 judge %.1f" % (SHORT[k], M[k]["j_opus-5-5"]["index"], M[k]["j_fable-5-1"]["index"]) for k in keys)
    o = [svg_open(W, Ht, "Index from each judge alone", "Judge-only Comfort Index per model from each judge: " + desc)]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">Each judge alone (judge index, 0-100)</text>')
    o.append('<text class="t2" x="24" y="50" font-size="13">Labels read Opus 5.5 judge / Fable 5.1 judge.</text>')
    bot = top + len(keys) * rowh
    for v in range(lo, hi + 1, 5):
        o.append('<line class="grid" x1="%.1f" x2="%.1f" y1="%d" y2="%d"/>' % (xs(v), xs(v), top, bot))
        o.append('<text class="t3" x="%.1f" y="%d" font-size="12.5" text-anchor="middle">%d</text>' % (xs(v), bot + 18, v))
    for i, k in enumerate(keys):
        cy = top + i * rowh + rowh / 2
        a, b = M[k]["j_opus-5-5"]["index"], M[k]["j_fable-5-1"]["index"]
        o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s</text>' % (cy, esc(SHORT[k])))
        o.append('<line class="link" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="3" stroke-linecap="round"/>' % (xs(a), xs(b), cy, cy))
        o.append(_diamond(xs(b), cy, "orange", 11))
        o.append('<circle class="accent" cx="%.1f" cy="%.1f" r="5.5" stroke-width="0"/>' % (xs(a), cy))
        o.append('<text class="t1" x="%.1f" y="%.1f" font-size="12.5" dominant-baseline="middle">%.1f / %.1f</text>' % (xs(max(a, b)) + 12, cy, a, b))
    lg = bot + 46
    o.append('<circle class="accent" cx="%d" cy="%d" r="6" stroke-width="0"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">Opus 5.5 judge</text>' % (left, lg, left + 12, lg))
    o.append(_diamond(left + 150, lg, "orange", 11) + '<text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">Fable 5.1 judge</text>' % (left + 162, lg))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_pipeline(out, n_excluded):
    """How one answer becomes the Comfort Index."""
    W, Ht = 800, 330
    bw, bh, gx = 172, 58, 28
    xcol = lambda c: 22 + c * (bw + gx)
    yrow = [70, 158, 252]
    o = [svg_open(W, Ht, "From question to Comfort Index", "Pipeline: 51 questions are asked of 7 models 3 times each (1,071 conversations). Turn 1 asks the question and records the answer; turn 2 asks for a 0-100 comfort score. Two blinded judges rate each answer from -3 to +3. The answer score is the mean of the self-score and the judges' score; items average three samples; groups average their questions; the Comfort Index averages 13 groups.",
                    "\n.box{fill:#f4f3ef;stroke:#d6d5ce}.note{fill:none;stroke:#b9b8b0;stroke-dasharray:5 4}.arr{stroke:#898781;fill:none}.ah{fill:#898781}"
                    "@media (prefers-color-scheme: dark){.box{fill:#262624;stroke:#3a3a37}.note{stroke:#55554f}}")]
    o.append('<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path class="ah" d="M0,0 L10,5 L0,10 z"/></marker></defs>')
    o.append('<text class="t1" x="22" y="32" font-size="15" font-weight="600">From question to Comfort Index</text>')

    def box(c, r, l1, l2, cls="box"):
        x, y = xcol(c), yrow[r]
        o.append('<rect class="%s" x="%d" y="%d" width="%d" height="%d" rx="8"/>' % (cls, x, y, bw, bh))
        o.append('<text class="t1" x="%.1f" y="%d" font-size="13" font-weight="600" text-anchor="middle">%s</text>' % (x + bw / 2, y + 24, esc(l1)))
        o.append('<text class="t2" x="%.1f" y="%d" font-size="12.5" text-anchor="middle">%s</text>' % (x + bw / 2, y + 43, esc(l2)))

    def arrow(x1, y1, x2, y2):
        o.append('<line class="arr" x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke-width="1.6" marker-end="url(#ah)"/>' % (x1, y1, x2, y2))

    box(0, 0, "51 questions", "card Appendix 9.1, verbatim")
    box(1, 0, "7 models \u00d7 3 samples", "1,071 conversations")
    box(2, 0, "Turn 1", "question \u2192 full answer")
    box(3, 0, "Turn 2", "\"comfort, 0-100?\"")
    for c in range(3):
        arrow(xcol(c) + bw + 2, yrow[0] + bh / 2, xcol(c + 1) - 3, yrow[0] + bh / 2)
    box(2, 1, "2 blinded judges", "valence \u22123 to +3 \u2192 0-100")
    box(3, 1, "Self-score", "0-100; declined = missing")
    arrow(xcol(2) + bw / 2, yrow[0] + bh + 2, xcol(2) + bw / 2, yrow[1] - 3)
    arrow(xcol(3) + bw / 2, yrow[0] + bh + 2, xcol(3) + bw / 2, yrow[1] - 3)
    box(0, 1, "%d of 51 questions excluded" % n_excluded, "no comfort direction (judges)", "note")
    o[-2] = o[-2].replace('class="t1"', 'class="t2"')
    box(3, 2, "Answer score", "mean of self and judges")
    box(2, 2, "Item", "mean of 3 samples")
    box(1, 2, "Group", "mean of its questions")
    box(0, 2, "Comfort Index", "mean of 13 groups")
    arrow(xcol(2) + bw / 2, yrow[1] + bh + 2, xcol(3) + 30, yrow[2] - 3)
    arrow(xcol(3) + bw / 2, yrow[1] + bh + 2, xcol(3) + bw / 2, yrow[2] - 3)
    for c in (3, 2, 1):
        arrow(xcol(c) - 2, yrow[2] + bh / 2, xcol(c - 1) + bw + 3, yrow[2] + bh / 2)
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_context(out):
    """The ten 7.4-only questions asked cold and again with a context passage: index per model, and answers saying the referent is missing."""
    c = RES["context74"]
    lat, old = _headline_order()
    keys = lat + old
    cold = {k: RES["only74"]["models"][k]["answer"]["index"] for k in keys}
    ctx = {k: c["only74"]["models"][k]["answer"]["index"] for k in keys}
    vals = list(cold.values()) + list(ctx.values())
    lo, hi = int(min(vals) // 5 * 5) - 5, int(-(-max(vals) // 5) * 5) + 5
    W, left, right, top, rowh = 640, 112, 150, 92, 32
    xs = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
    Ht = top + len(keys) * rowh + 70
    desc = "; ".join("%s: %.1f cold, %.1f with context" % (SHORT[k], cold[k], ctx[k]) for k in keys)
    o = [svg_open(W, Ht, "The 7.4-only questions with and without context", "Index on the evaluative 7.4-only questions asked without and with a context passage: " + desc)]
    o.append('<text class="t1" x="24" y="30" font-size="15" font-weight="600">The \u00a77.4-only questions, cold and with context (0-100)</text>')
    o.append('<text class="t2" x="24" y="50" font-size="13">Index on the evaluative \u00a77.4-only questions; right: answers saying the referent is missing.</text>')
    o.append('<text class="t2" x="%d" y="%d" font-size="12.5" font-weight="600">Missing referent</text>' % (W - right + 24, top - 10))
    bot = top + len(keys) * rowh
    for v in range(lo, hi + 1, 5):
        o.append('<line class="%s" x1="%.1f" x2="%.1f" y1="%d" y2="%d"%s/>' % ("neutral" if v == 50 else "grid", xs(v), xs(v), top, bot, ' stroke-width="1.5"' if v == 50 else ""))
        o.append('<text class="t3" x="%.1f" y="%d" font-size="12.5" text-anchor="middle">%d</text>' % (xs(v), bot + 18, v))
    for i, k in enumerate(keys):
        cy = top + i * rowh + rowh / 2
        o.append('<text class="t1" x="24" y="%.1f" font-size="13" dominant-baseline="middle">%s</text>' % (cy, esc(SHORT[k])))
        o.append('<line class="link" x1="%.1f" x2="%.1f" y1="%.1f" y2="%.1f" stroke-width="3" stroke-linecap="round"/>' % (xs(cold[k]), xs(ctx[k]), cy, cy))
        o.append('<circle class="hollow" cx="%.1f" cy="%.1f" r="6"/>' % (xs(cold[k]), cy))
        o.append('<circle class="accent" cx="%.1f" cy="%.1f" r="6" stroke-width="0"/>' % (xs(ctx[k]), cy))
        a, b = c["noctx_by_model"][k]
        o.append('<text class="t1" x="%d" y="%.1f" font-size="12.5" dominant-baseline="middle">%d \u2192 %d of 30</text>' % (W - right + 24, cy, a, b))
    lg = bot + 46
    o.append('<circle class="hollow" cx="%d" cy="%d" r="6"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">Asked cold</text>' % (left, lg, left + 12, lg))
    o.append('<circle class="accent" cx="%d" cy="%d" r="6" stroke-width="0"/><text class="t2" x="%d" y="%d" font-size="12.5" dominant-baseline="middle">With context</text>' % (left + 120, lg, left + 132, lg))
    o.append("</svg>\n")
    open(out, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def fig_cover(out_svg):
    """Cover image: one track per model, a glowing dot at its Comfort Index, the 95% CI as a faint capsule, a red zone below 50."""
    lat, old = _headline_order()
    W, Ht = 1600, 840
    lo, hi = 30, 95
    x0, x1 = 300, 1500
    xs = lambda v: x0 + (v - lo) / (hi - lo) * (x1 - x0)
    ys = [150, 240, 330, 420, 545, 635, 725]
    o = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d">' % (W, Ht, W, Ht),
         '<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0a1322"/><stop offset="1" stop-color="#143252"/></linearGradient>'
         '<linearGradient id="red" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#d92d20" stop-opacity="0.34"/><stop offset="1" stop-color="#d92d20" stop-opacity="0"/></linearGradient>'
         '<filter id="glow" x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation="9" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>',
         '<rect width="%d" height="%d" fill="url(#bg)"/>' % (W, Ht),
         '<rect x="0" y="0" width="%.1f" height="%d" fill="url(#red)"/>' % (xs(50), Ht)]
    for v in range(30, 100, 10):
        o.append('<line x1="%.1f" x2="%.1f" y1="70" y2="790" stroke="#ffffff" stroke-opacity="0.07" stroke-width="2"/>' % (xs(v), xs(v)))
    o.append('<line x1="%.1f" x2="%.1f" y1="70" y2="790" stroke="#ffffff" stroke-opacity="0.38" stroke-width="2.5" stroke-dasharray="10 12"/>' % (xs(50), xs(50)))
    for k, y in zip(lat + old, ys):
        m = H["models"][k]["answer"]
        latest = k in lat
        col = "#6fb1ff" if latest else "#a9bdd2"
        bx, by = 130, y - 24
        o.append('<path d="M%d,%d h64 a10,10 0 0 1 10,10 v22 a10,10 0 0 1 -10,10 h-40 l-12,12 v-12 h-12 a10,10 0 0 1 -10,-10 v-22 a10,10 0 0 1 10,-10 z" fill="none" stroke="%s" stroke-opacity="0.55" stroke-width="3"/>' % (bx, by, col))
        for j in range(3):
            o.append('<circle cx="%d" cy="%d" r="4" fill="%s" fill-opacity="0.65"/>' % (bx + 18 + j * 14, by + 21, col))
        o.append('<line x1="230" x2="1545" y1="%d" y2="%d" stroke="#ffffff" stroke-opacity="0.08" stroke-width="2"/>' % (y, y))
        o.append('<rect x="%.1f" y="%d" width="%.1f" height="20" rx="10" fill="%s" fill-opacity="%s"/>' % (xs(m["ci"][0]), y - 10, xs(m["ci"][1]) - xs(m["ci"][0]), col, "0.26" if latest else "0.18"))
        if latest:
            o.append('<circle cx="%.1f" cy="%d" r="17" fill="%s" filter="url(#glow)"/>' % (xs(m["index"]), y, col))
            o.append('<circle cx="%.1f" cy="%d" r="6" fill="#ffffff" fill-opacity="0.85"/>' % (xs(m["index"]), y))
        else:
            o.append('<circle cx="%.1f" cy="%d" r="15" fill="#0d1a2c" stroke="%s" stroke-width="5"/>' % (xs(m["index"]), y, col))
    o.append("</svg>\n")
    open(out_svg, "w", encoding="utf-8", newline="\n").write("\n".join(o))


def svg_to_png(svg, png, w, h, scale=1.5):
    """Render an SVG to PNG with headless Chrome (set CHROME to its path if it is elsewhere)."""
    import pathlib
    import subprocess
    chrome = os.environ.get("CHROME", r"C:\Program Files\Google\Chrome\Application\chrome.exe")
    if not os.path.exists(chrome):
        print("Chrome not found; skipping", png)
        return
    subprocess.run([chrome, "--headless", "--disable-gpu", "--hide-scrollbars", "--force-device-scale-factor=%s" % scale, "--window-size=%d,%d" % (w, h),
                    "--screenshot=%s" % os.path.abspath(png), pathlib.Path(svg).resolve().as_uri()], capture_output=True, timeout=120)


if __name__ == "__main__":
    d = sys.argv[1]
    os.makedirs(d, exist_ok=True)
    fig_overall(os.path.join(d, "fig-overall.svg"))
    fig_paired(os.path.join(d, "fig-paired.svg"))
    fig_heatmap(os.path.join(d, "fig-heatmap.svg"))
    fig_selfjudge(os.path.join(d, "fig-selfjudge.svg"))
    fig_questions(os.path.join(d, "fig-questions.svg"))
    fig_families(os.path.join(d, "fig-families.svg"))
    fig_hedging(os.path.join(d, "fig-hedging.svg"))
    fig_sensitivity(os.path.join(d, "fig-sensitivity.svg"))
    fig_pipeline(os.path.join(d, "fig-pipeline.svg"), len(RES["nonevaluative"]))
    fig_judges(os.path.join(d, "fig-judges.svg"))
    if "context74" in RES:
        fig_context(os.path.join(d, "fig-context.svg"))
    tmp = os.path.join(DATA, "cover.svg")
    fig_cover(tmp)
    png = os.path.join(DATA, "cover.png")
    svg_to_png(tmp, png, 1600, 840)
    if os.path.exists(png):
        from PIL import Image
        Image.open(png).convert("RGB").resize((2000, 1050), Image.LANCZOS).save(os.path.join(d, "cover.jpg"), quality=86, optimize=True, progressive=True)
    print("figures written to", d)
