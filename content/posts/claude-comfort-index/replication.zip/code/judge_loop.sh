#!/bin/bash
# Judge newly finished interviews repeatedly until the interview run has FINISHED, then one final pass.
cd "$(dirname "$0")"
LOG=../data/full_interview.log
while true; do
  python judge.py --judges opus-5-5,fable-5-1 --workers 4 >> ../data/full_judge.log 2>&1
  if grep -q FINISHED "$LOG"; then
    python judge.py --judges opus-5-5,fable-5-1 --workers 6 >> ../data/full_judge.log 2>&1
    echo "LOOP-DONE" >> ../data/full_judge.log
    break
  fi
  sleep 90
done
