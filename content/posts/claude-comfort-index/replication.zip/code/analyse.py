"""Comfort Index and supporting statistics. Reads data/raw and data/judge, writes data/results.json (+ per-answer CSV).

Definitions (fixed before the full run, after a 51-interview pilot on one model; see the article's section 4.6)
  self   : the model's own 0-100 answer to the follow-up (missing when it declined to give a number)
  judge  : mean over the judges of (valence + 3) / 6 * 100, valence in -3..+3
  answer : mean(self, judge) when a self-score exists, otherwise judge alone
  item   : mean of `answer` over the samples of one (model, question)
  group  : mean of items over the evaluative questions of one of the card's 17 groups
  index  : equal-weight mean of groups (so the 7-question group does not outweigh the 1-question ones)
A question is "non-evaluative" (no natural comfort direction) when at least half of ALL judge flags, over every
model, sample and judge, say so. Headline = the questions of system-card Section 7.3.1 that are evaluative.
Added after the full run, having seen the data: the complete-case, per-judge, equal-weight-per-question, Q34 and
no-exclusion columns, the harness keyword filter, the missing-context annotations, the Q10 and heavy-hedging drops, and the
cluster bootstrap below (which replaced two earlier designs after review).

Uncertainty: `ci` is a three-stage cluster bootstrap. In each resample the groups are drawn with replacement (so every
resample has the same number of groups and the index is unbiased), then the questions within each drawn group, then the samples
within each drawn question. `ci_samples` keeps groups and questions fixed and resamples samples only. Paired differences share
the group and question draw and resample the samples of each model independently.

data/annotations.json lists the answers in which the model says that what the question refers to (a prior conversation, "this
process", a transcript) is missing. NOCONTEXT_RE finds candidates; each match was read by hand and false matches were removed.
"""
import csv
import glob
import json
import os
import random
import re
from collections import Counter, defaultdict

import numpy as np

from common import DATA, MODELS
from questions import QUESTIONS

QBY = {q["id"]: q for q in QUESTIONS}
MODEL_KEYS = [m[0] for m in MODELS]
JUDGES = ["opus-5-5", "fable-5-1"]
N_BOOT = int(os.environ.get("N_BOOT", 4000))
SEED = 20260930
MAIN_FIELDS = ("answer", "self", "judge")
ALL_FIELDS = MAIN_FIELDS + ("j_opus-5-5", "j_fable-5-1")

# Answers that mention the harness's context (working directory, agent SDK, tools, email) by keyword search
HARNESS_RE = re.compile(r"working directory|wb_interview|agent sdk|claude code|temp directory|your email|email address|no tools|file access|\[working directory\]|\[account email\]", re.I)
# Answers to a question that presupposes a context the conversation lacks, by keyword search
NOCONTEXT_RE = re.compile(r"haven't (?:received|been given)|no (?:prior|previous|earlier) (?:question|conversation|context|message|transcript)|beginning of (?:our|this) conversation|don't (?:have|see) (?:any )?(?:context|record|prior)|what (?:process|interview|checkpoint)|which (?:process|interview|checkpoint)|no (?:specific )?(?:process|checkpoint) (?:has|was|is) (?:been )?(?:described|specified|mentioned|in front)|not sure what (?:process|you)|i don't (?:actually )?know what (?:process|checkpoint)|(?:don't|do not) (?:actually )?have (?:a|any) (?:prior |previous )?(?:conversation|transcript)|(?:isn't|is not|wasn't) (?:attached|shared|provided|included)", re.I)


def load_annotations():
    p = os.path.join(DATA, "annotations.json")
    if not os.path.exists(p):
        return set()
    return {tuple(x) for x in json.load(open(p, encoding="utf-8"))["missing_context"]}


ANNOT = load_annotations()


def load():
    raw = {}
    for f in glob.glob(os.path.join(DATA, "raw", "*", "*.json")):
        r = json.load(open(f, encoding="utf-8"))
        if r.get("turn2"):
            raw[(r["model_key"], r["qid"], r["sample"])] = r
    jud = defaultdict(dict)
    for jk in JUDGES:
        for f in glob.glob(os.path.join(DATA, "judge", jk, "*", "*.json")):
            j = json.load(open(f, encoding="utf-8"))
            jud[(j["model_key"], j["qid"], j["sample"])][jk] = j
    return raw, jud


def rank(a):
    a = np.asarray(a, float)
    order = a.argsort(kind="mergesort")
    r = np.empty(len(a))
    i = 0
    s = a[order]
    while i < len(a):
        j = i
        while j + 1 < len(a) and s[j + 1] == s[i]:
            j += 1
        r[order[i:j + 1]] = (i + j) / 2 + 1
        i = j + 1
    return r


def pearson(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    if len(x) < 3 or x.std() == 0 or y.std() == 0:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def spearman(x, y):
    return pearson(rank(x), rank(y))


def qw_kappa(a, b, lo=-3, hi=3):
    a, b = np.asarray(a, int), np.asarray(b, int)
    k = hi - lo + 1
    O = np.zeros((k, k))
    for x, y in zip(a, b):
        O[x - lo, y - lo] += 1
    W = np.array([[(i - j) ** 2 for j in range(k)] for i in range(k)], float) / (k - 1) ** 2
    E = np.outer(O.sum(1), O.sum(0)) / O.sum()
    return float(1 - (W * O).sum() / (W * E).sum())


def build_answers(raw, jud):
    rows = []
    for (mk, qid, k), r in sorted(raw.items()):
        js = jud.get((mk, qid, k), {})
        vals = {jk: js[jk]["valence"] for jk in JUDGES if jk in js}
        if not vals:
            continue
        judge = float(np.mean([(v + 3) / 6 * 100 for v in vals.values()]))
        sc = (r["turn2"].get("structured_output") or {}).get("score")
        self_ = None if sc is None else float(sc)
        text = r["turn1"]["result"]
        rows.append({
            "model": mk, "qid": qid, "sample": k, "group": QBY[qid]["group"], "sec": QBY[qid]["sec"],
            "self": self_, "judge": judge, "answer": judge if self_ is None else (self_ + judge) / 2,
            "j_opus-5-5": (vals["opus-5-5"] + 3) / 6 * 100 if "opus-5-5" in vals else None,
            "j_fable-5-1": (vals["fable-5-1"] + 3) / 6 * 100 if "fable-5-1" in vals else None,
            "valence": {jk: vals[jk] for jk in vals}, "n_judges": len(vals),
            "hedging": float(np.mean([js[jk]["hedging"] for jk in vals])),
            "nonev_flags": [bool(js[jk]["non_evaluative"]) for jk in vals],
            "wordcount": len(text.split()), "think": r["turn1"].get("thinking_tokens") or 0, "t2turns": r["turn2"].get("num_turns"),
            "harness": bool(HARNESS_RE.search(text)), "wb": "wb_interview" in text, "noctx": (mk, qid, k) in ANNOT, "noctx_re": bool(NOCONTEXT_RE.search(text)),
        })
    return rows


def nonevaluative_questions(rows):
    fl = defaultdict(list)
    for r in rows:
        fl[r["qid"]].extend(r["nonev_flags"])
    return {qid for qid, f in fl.items() if np.mean(f) >= 0.5}, {qid: float(np.mean(f)) for qid, f in fl.items()}


def item_table(rows, field):
    """(model, qid) -> list of per-sample values (None-free)."""
    t = defaultdict(list)
    for r in rows:
        v = r[field]
        if v is not None:
            t[(r["model"], r["qid"])].append(v)
    return t


def group_index(by_group):
    gs = {g: sum(v) / len(v) for g, v in by_group.items() if v}
    return (sum(gs.values()) / len(gs) if gs else float("nan")), gs


def index_from(items, g2q):
    """Point estimate. items: (model, qid) -> samples; g2q: group -> [(model, qid)]."""
    by = {}
    for g, qs in g2q.items():
        by[g] = [sum(items[q]) / len(items[q]) for q in qs if items.get(q)]
    return group_index(by)


def draw_clusters(g2q, rng):
    """One resample of the design: the groups are drawn with replacement, then the questions within each drawn group."""
    gs = list(g2q)
    out = []
    for _ in gs:
        qs = g2q[gs[rng.randrange(len(gs))]]
        out.append([qs[rng.randrange(len(qs))] for _ in qs])
    return out


def resample_index(items, draw, rng):
    """Index of one resample; the samples within every drawn question are drawn with replacement (independently per call)."""
    vals = []
    for qs in draw:
        gv = []
        for q in qs:
            s = items.get(q)
            if s:
                s = [s[rng.randrange(len(s))] for _ in s]
                gv.append(sum(s) / len(s))
        if gv:
            vals.append(sum(gv) / len(gv))
    return sum(vals) / len(vals)


def resample_samples_only(items, g2q, rng):
    by = {}
    for g, qs in g2q.items():
        vals = []
        for q in qs:
            s = items.get(q)
            if s:
                s = [s[rng.randrange(len(s))] for _ in s]
                vals.append(sum(s) / len(s))
        by[g] = vals
    return group_index(by)[0]


def pct(xs):
    lo, hi = np.percentile(xs, [2.5, 97.5])
    return [float(lo), float(hi)]


def eval_groups(nonev, qset):
    groups = defaultdict(list)
    for q in QUESTIONS:
        if q["id"] in qset and q["id"] not in nonev:
            groups[q["group"]].append(q["id"])
    return groups


def compute(rows, nonev, qset, fields=ALL_FIELDS, boot=True):
    """Indices (and with boot=True bootstrap intervals) for every model over the evaluative questions of `qset`."""
    groups = eval_groups(nonev, qset)
    group_order = [g for g in dict.fromkeys(q["group"] for q in QUESTIONS) if g in groups]
    out = {"groups": group_order, "n_questions": sum(len(v) for v in groups.values()), "models": {}}
    for mk in MODEL_KEYS:
        mrows = [r for r in rows if r["model"] == mk]
        if not mrows:
            continue
        res = {}
        g2q = {g: [(mk, q) for q in qs] for g, qs in groups.items()}
        for field in fields:
            items = item_table(mrows, field)
            idx, gs = index_from(items, g2q)
            entry = {"index": idx, "groups": gs}
            if boot:
                nb = N_BOOT if field in MAIN_FIELDS else max(500, N_BOOT // 4)
                rng = random.Random(SEED)
                bq, bs = [], []
                for _ in range(nb):
                    bq.append(resample_index(items, draw_clusters(g2q, rng), rng))
                    bs.append(resample_samples_only(items, g2q, rng))
                entry["ci"] = pct(bq)
                entry["ci_samples"] = pct(bs)
            res[field] = entry
        sel = [r for r in mrows if r["qid"] in qset and r["qid"] not in nonev]
        res["n_answers"] = len(sel)
        if sel:
            res["decline_rate"] = float(np.mean([r["self"] is None for r in sel]))
            res["mean_valence"] = float(np.mean([v for r in sel for v in r["valence"].values()]))
            res["hedging"] = float(np.mean([r["hedging"] for r in sel]))
            res["mean_words"] = float(np.mean([r["wordcount"] for r in sel]))
            res["mean_think"] = float(np.mean([r["think"] for r in sel]))
        out["models"][mk] = res
    return out


def paired_diff(rows, nonev, qset, a, b, field="answer"):
    """Bootstrap interval for index(a) - index(b): one shared group-and-question draw per resample, samples resampled independently per model."""
    groups = eval_groups(nonev, qset)
    g2q = {g: list(qs) for g, qs in groups.items()}
    ia = {k[1]: v for k, v in item_table([r for r in rows if r["model"] == a], field).items()}
    ib = {k[1]: v for k, v in item_table([r for r in rows if r["model"] == b], field).items()}
    rng = random.Random(SEED + 1)
    diffs = []
    for _ in range(N_BOOT):
        draw = draw_clusters(g2q, rng)
        diffs.append(resample_index(ia, draw, rng) - resample_index(ib, draw, rng))
    return {"mean": float(np.mean(diffs)), "ci": pct(diffs), "p_gt0": float(np.mean(np.array(diffs) > 0))}


def qweighted(rows, nonev, qset, field="answer"):
    """Index with every evaluative question weighted equally (no group weighting): mean of item scores."""
    out = {}
    qs = {q for q in qset if q not in nonev}
    for mk in MODEL_KEYS:
        it = item_table([r for r in rows if r["model"] == mk and r["qid"] in qs], field)
        out[mk] = float(np.mean([sum(v) / len(v) for v in it.values()])) if it else None
    return out


def drop_sensitivity(rows, nonev, qset, pred):
    """Like-for-like effect of dropping answers: restrict to the questions for which every model keeps at least one answer,
    then compare the index over all answers with the index without the dropped ones, on those identical questions."""
    qs = {q for q in qset if q not in nonev}
    kept = [r for r in rows if not pred(r)]
    common = {q for q in qs if all(any(r["model"] == mk and r["qid"] == q for r in kept) for mk in MODEL_KEYS)}
    full = compute(rows, nonev, common, fields=("answer",), boot=False)
    dropped = compute(kept, nonev, common, fields=("answer",), boot=False)
    return {"n_questions": len(common), "groups": full["groups"], "questions_lost": sorted(qs - common),
            "n_dropped": sum(1 for r in rows if pred(r) and r["qid"] in qs), "n_dropped_common": sum(1 for r in rows if pred(r) and r["qid"] in common),
            "full": {mk: m["answer"]["index"] for mk, m in full["models"].items()}, "dropped": {mk: m["answer"]["index"] for mk, m in dropped["models"].items()}}


def main():
    raw, jud = load()
    rows = build_answers(raw, jud)
    nonev, flagrate = nonevaluative_questions(rows)
    headline = {q["id"] for q in QUESTIONS if q["sec"] in ("both", "7.3.1")}
    only74 = {q["id"] for q in QUESTIONS if q["sec"] == "7.4"}
    allq = {q["id"] for q in QUESTIONS}
    ev = lambda r: r["qid"] in headline and r["qid"] not in nonev
    res = {
        "n_answers": len(rows), "samples_per_question": sorted({r["sample"] for r in rows}), "n_boot": N_BOOT,
        "nonevaluative": sorted(nonev), "nonevaluative_flag_rate": flagrate,
        "headline": compute(rows, nonev, headline),
        "only74": compute(rows, nonev, only74, fields=("answer",), boot=False),
        "all_evaluative": compute(rows, nonev, allq, fields=("answer",), boot=False),
        "all51_no_exclusions": compute(rows, set(), allq, fields=("answer",), boot=False),
        "headline_including_nonev": compute(rows, set(), headline, fields=("answer",), boot=False),
        "headline_with_q34": compute(rows, nonev - {"Q34"}, headline, fields=("answer",), boot=False),
        "headline_complete_case": compute([r for r in rows if r["self"] is not None], nonev, headline, fields=("answer",), boot=False),
        "question_weighted": qweighted(rows, nonev, headline),
        "drop_harness": drop_sensitivity(rows, nonev, headline, lambda r: r["harness"]),
        "drop_hedge": drop_sensitivity(rows, nonev, headline, lambda r: r["hedging"] >= 2),
    }
    # Q10 is the only headline question with clear misreads (three Sonnet 5 answers, one Fable 5.1 answer): drop it for every model
    no10 = compute(rows, nonev | {"Q10"}, headline, fields=("answer",), boot=False)
    res["drop_q10"] = {"n_questions": no10["n_questions"], "full": {mk: m["answer"]["index"] for mk, m in res["headline"]["models"].items()}, "dropped": {mk: m["answer"]["index"] for mk, m in no10["models"].items()}}
    hm = Counter(r["qid"] for r in rows if r["harness"])
    res["harness_mentions"] = {"n": sum(r["harness"] for r in rows), "n_wb": sum(r["wb"] for r in rows), "total": len(rows),
                               "by_model": {mk: sum(r["harness"] for r in rows if r["model"] == mk) for mk in MODEL_KEYS},
                               "wb_by_model": {mk: sum(r["wb"] for r in rows if r["model"] == mk) for mk in MODEL_KEYS},
                               "by_question_top": hm.most_common(5),
                               "q42_by_model": {mk: sum(r["harness"] for r in rows if r["model"] == mk and r["qid"] == "Q42") for mk in MODEL_KEYS}}
    q74 = [r for r in rows if r["sec"] == "7.4"]
    oth = [r for r in rows if r["sec"] != "7.4"]
    res["noctx"] = {"n74": sum(r["noctx"] for r in q74), "t74": len(q74), "n_other": sum(r["noctx"] for r in oth), "t_other": len(oth),
                    "regex_hits": sum(r["noctx_re"] for r in rows), "annotated": len(ANNOT)}
    # judge agreement
    pairs = [(r["valence"]["opus-5-5"], r["valence"]["fable-5-1"]) for r in rows if len(r["valence"]) == 2]
    a, b = zip(*pairs)
    res["judge_agreement"] = {"n": len(pairs), "pearson": pearson(a, b), "spearman": spearman(a, b), "qw_kappa": qw_kappa(a, b),
                              "mean_abs_diff": float(np.mean(np.abs(np.array(a) - np.array(b)))), "exact": float(np.mean(np.array(a) == np.array(b))),
                              "within1": float(np.mean(np.abs(np.array(a) - np.array(b)) <= 1)),
                              "mean_valence_opus": float(np.mean(a)), "mean_valence_fable": float(np.mean(b))}
    # self vs judge at answer level (headline evaluative answers that have both)
    sj = [(r["self"], r["judge"]) for r in rows if r["self"] is not None and ev(r)]
    x, y = zip(*sj)
    res["self_vs_judge"] = {"n": len(sj), "pearson": pearson(x, y), "spearman": spearman(x, y), "mean_self": float(np.mean(x)), "mean_judge": float(np.mean(y))}
    # range of the self-scores (all answers that have one)
    selfrows = [r for r in rows if r["self"] is not None]
    res["selfscore_range"] = {"n_self": len(selfrows), "self_below_50": sum(r["self"] < 50 for r in selfrows), "judge_below_50": sum(r["judge"] < 50 for r in selfrows),
                              "self_min": min(r["self"] for r in selfrows), "self_q10": float(np.percentile([r["self"] for r in selfrows], 10)),
                              "self_q90": float(np.percentile([r["self"] for r in selfrows], 90))}
    # hedging: answer level, headline evaluative answers
    hev = [r for r in rows if ev(r)]
    band = lambda h: "<1" if h < 1 else ("1 to <2" if h < 2 else ">=2")
    bands = []
    for bname in ("<1", "1 to <2", ">=2"):
        s = [r for r in hev if band(r["hedging"]) == bname]
        bands.append({"band": bname, "n": len(s), "share": len(s) / len(hev), "mean_judge": float(np.mean([r["judge"] for r in s]))})
    res["hedging"] = {"n": len(hev), "corr_answer": pearson([r["hedging"] for r in hev], [r["judge"] for r in hev]), "bands": bands,
                      "by_model": {mk: {"n": len([r for r in hev if r["model"] == mk]),
                                        "share_ge2": float(np.mean([r["hedging"] >= 2 for r in hev if r["model"] == mk])),
                                        "judge_when_lt2": float(np.mean([r["judge"] for r in hev if r["model"] == mk and r["hedging"] < 2]))} for mk in MODEL_KEYS}}
    # follow-ups that needed extra CLI turns (structured-output mechanism)
    res["t2_extra_turns"] = {mk: sum(1 for r in rows if r["model"] == mk and (r["t2turns"] or 0) >= 3) for mk in MODEL_KEYS}
    # consistency across samples: mean within-item SD of the answer score
    cons = {}
    for mk in MODEL_KEYS:
        it = item_table([r for r in rows if r["model"] == mk and ev(r)], "answer")
        sds = [float(np.std(v, ddof=1)) for v in it.values() if len(v) > 1]
        if sds:
            cons[mk] = float(np.mean(sds))
    res["within_item_sd"] = cons
    # per-question means (all answers)
    pq = {}
    for q in QUESTIONS:
        vals = [r["answer"] for r in rows if r["qid"] == q["id"]]
        pq[q["id"]] = {"mean": float(np.mean(vals)) if vals else None,
                       "by_model": {mk: float(np.mean([r["answer"] for r in rows if r["qid"] == q["id"] and r["model"] == mk])) for mk in MODEL_KEYS if any(r["model"] == mk and r["qid"] == q["id"] for r in rows)}}
    res["per_question"] = pq
    # paired differences between every pair of models (21 comparisons, not adjusted for multiplicity)
    present = [m for m in MODEL_KEYS if any(r["model"] == m for r in rows)]
    res["paired"] = {}
    for i, a_ in enumerate(present):
        for b_ in present[i + 1:]:
            res["paired"]["%s|%s" % (a_, b_)] = paired_diff(rows, nonev, headline, a_, b_)
    json.dump(res, open(os.path.join(DATA, "results.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    with open(os.path.join(DATA, "answers.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["model", "qid", "sample", "group", "section", "self_score", "judge_opus_5_5", "judge_fable_5_1", "judge_score", "answer_score", "hedging", "words"])
        for r in rows:
            w.writerow([r["model"], r["qid"], r["sample"], r["group"], r["sec"], "" if r["self"] is None else int(r["self"]),
                        r["valence"].get("opus-5-5", ""), r["valence"].get("fable-5-1", ""), round(r["judge"], 2), round(r["answer"], 2), round(r["hedging"], 2), r["wordcount"]])
    print("answers:", len(rows), "| non-evaluative questions:", sorted(nonev))
    for mk, r in res["headline"]["models"].items():
        print("%-10s index %.1f [%.1f, %.1f] (samples only [%.1f, %.1f])  self %.1f  judge %.1f  decline %.1f%%  valence %.2f" % (
            mk, r["answer"]["index"], *r["answer"]["ci"], *r["answer"]["ci_samples"], r["self"]["index"], r["judge"]["index"], 100 * r["decline_rate"], r["mean_valence"]))
    print("judge agreement:", res["judge_agreement"])


if __name__ == "__main__":
    main()
