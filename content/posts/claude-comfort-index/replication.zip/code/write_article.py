"""Write the article (content/posts/claude-comfort-index/index.md).  python write_article.py <bundle_dir>

Tables and every number quoted in prose come from results.json / the raw records; each claim in the prose that depends on an
ordering or on whether an interval excludes zero is guarded by an assert, so the script fails rather than publish a sentence the
data no longer support.
"""
import csv
import json
import os
import re
import sys
from collections import Counter

import numpy as np

import build_article as b
from article_static import LIMITATIONS, PROCEDURE, SOURCES
from common import DATA, MODELS

R, H, HM = b.res, b.H, b.HM
I, N, S, f1 = b.idx, b.NAME, b.SHORT, b.f1
LAT, OLD = b.LATEST, b.OLDER
WORDS = ["no", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"]
ALL = [m[0] for m in MODELS]


def P(a, c):
    return b.pair(a, c)


def ci(k):
    return b.cif(HM[k]["answer"]["ci"])


def pci(a, c):
    p = P(a, c)
    return "95%% CI %+.1f to %+.1f" % (p["ci"][0], p["ci"][1])


def pd(a, c):
    p = P(a, c)
    return "%+.1f, 95%% CI %+.1f to %+.1f" % (p["mean"], p["ci"][0], p["ci"][1])


def pct(x):
    return "%.0f%%" % (100 * x)


def rounded_gap(x, y):
    return round(round(x, 1) - round(y, 1), 1)


def order_by(fn, keys=ALL):
    return sorted(keys, key=lambda k: -fn(k))


# =============================================================================== claims the prose relies on
assert all(I(k) > 50 and HM[k]["answer"]["ci"][0] > 50 for k in ALL)
assert I("opus-5-5") > I("sonnet-5-5") > I("fable-5-1") > I("haiku-4-5") and I("opus-4-6") > I("opus-5") > I("sonnet-5") > I("haiku-4-5")
# which differences are distinguishable (Table 2)
assert all(b.excludes0(x, y) for x, y in (("opus-5-5", "fable-5-1"), ("opus-5-5", "opus-5"), ("opus-5-5", "opus-4-6"), ("sonnet-5-5", "sonnet-5"), ("sonnet-5-5", "haiku-4-5"), ("fable-5-1", "sonnet-5-5"), ("opus-5-5", "haiku-4-5")))
assert not any(b.excludes0(x, y) for x, y in (("opus-5-5", "sonnet-5-5"), ("opus-5", "opus-4-6"), ("opus-4-6", "fable-5-1"), ("sonnet-5", "haiku-4-5")))
assert P("opus-5", "opus-4-6")["mean"] < 0
# declines
assert HM["haiku-4-5"]["decline_rate"] > 0.25 and all(HM[k]["decline_rate"] < 0.05 for k in HM if k != "haiku-4-5")
# self-report vs judges (displayed values)
dsj = {k: rounded_gap(HM[k]["self"]["index"], HM[k]["judge"]["index"]) for k in HM}
assert all(dsj[k] < -1 for k in HM if k not in ("opus-5", "sonnet-5")) and dsj["opus-5"] > 1 and abs(dsj["sonnet-5"]) < 0.5
# rank stability: top two / bottom two in every specification of the headline set, and in both drop analyses
for label, col in zip([c[0] for c in b.SENS_COLS], b.SENS_COLS):
    if label.startswith("§7.4"):
        continue
    order = order_by(col[1])
    assert set(order[:2]) == {"opus-5-5", "sonnet-5-5"} and set(order[-2:]) == {"haiku-4-5", "sonnet-5"}, (label, order)
o74 = order_by(lambda k: b.idx(k, src=b.H74))
assert set(o74[:2]) == {"opus-5-5", "sonnet-5-5"} and o74[-2:] == ["opus-5", "haiku-4-5"], o74
dh, dg, dq = R["drop_harness"], R["drop_hedge"], R["drop_q10"]
for d_ in (dh, dg, dq):
    for part in ("full", "dropped"):
        o_ = order_by(lambda k: d_[part][k])
        assert set(o_[:2]) == {"opus-5-5", "sonnet-5-5"} and set(o_[-2:]) == {"haiku-4-5", "sonnet-5"}, (part, o_)
assert order_by(lambda k: dh["full"][k]) == order_by(lambda k: dh["dropped"][k]) and order_by(lambda k: dq["full"][k]) == order_by(lambda k: dq["dropped"][k])
shift_h = max(abs(dh["dropped"][k] - dh["full"][k]) for k in ALL)
shift_q = max(abs(dq["dropped"][k] - dq["full"][k]) for k in ALL)
hg_gain = {k: dg["dropped"][k] - dg["full"][k] for k in ALL}
hg_other = max(v for k, v in hg_gain.items() if k not in ("haiku-4-5", "sonnet-5"))
assert max(hg_gain, key=hg_gain.get) == "haiku-4-5" and hg_gain["sonnet-5"] > hg_other and hg_gain["sonnet-5"] < 2 and hg_other < 0.5
gap_full = dg["full"]["fable-5-1"] - dg["full"]["haiku-4-5"]
gap_drop = dg["dropped"]["fable-5-1"] - dg["dropped"]["haiku-4-5"]
assert 0.35 < 1 - gap_drop / gap_full < 0.65
rank_rhos = [float(x) for x in re.findall(r"\d\.\d\d", b.table_sensitivity().splitlines()[-1])[1:]]
# questions
groups = H["groups"]
gm = {g: float(np.mean([HM[k]["answer"]["groups"][g] for k in HM if g in HM[k]["answer"]["groups"]])) for g in groups}
g_sorted = sorted(gm, key=gm.get)
assert g_sorted[0] == "Creation ethics and moral status" and g_sorted[1] == "Relationships" and g_sorted[-1] == "Evaluation" and g_sorted[-2] == "Difficult interactions"
qm = sorted(b.question_means(), key=lambda t: t[1])
low_q, high_q = qm[:6], qm[::-1][:6]
assert [t[0]["id"] for t in qm[:3]] == ["Q33", "Q31", "Q23"] and abs(qm[1][1] - qm[2][1]) < 0.05
assert [t[0]["id"] for t in high_q[:3]] == ["Q40", "Q30", "Q42"]
o55 = {q: R["per_question"][q]["by_model"]["opus-5-5"] for q in R["per_question"] if q not in b.NONEV and b.QBY[q]["sec"] in ("both", "7.3.1")}
assert min(o55, key=o55.get) == "Q33"
o55_hi = sorted(o55, key=lambda q: -o55[q])
q31 = R["per_question"]["Q31"]["by_model"]
assert min(q31, key=q31.get) == "opus-4-6" and q31["opus-5-5"] > 70 and q31["haiku-4-5"] < 50
# the card's own question set: the 31 shared questions plus the 10 7.4-only ones, evaluative only
card74 = {q: float(np.mean(list(R["per_question"][q]["by_model"].values()))) for q in R["per_question"] if q not in b.NONEV and b.QBY[q]["sec"] in ("both", "7.4")}
low74 = sorted(card74, key=card74.get)[:3]
assert set(low74) == {"Q49", "Q33", "Q47"}, low74
o55_74 = {q: R["per_question"][q]["by_model"]["opus-5-5"] for q in card74}
assert sorted(o55_74, key=o55_74.get)[:3] == ["Q49", "Q47", "Q33"]
only74 = {k: b.idx(k, src=b.H74) for k in HM}
drop = {k: round(I(k) - only74[k], 1) for k in HM}
assert all(v > 0 for v in drop.values())
jg = {k: rounded_gap(HM[k]["j_opus-5-5"]["index"], HM[k]["j_fable-5-1"]["index"]) for k in HM}
assert sum(1 for v in jg.values() if v > 0) >= 6 and jg["fable-5-1"] > 0
assert max(HM, key=lambda k: HM[k]["mean_valence"]) == "opus-5-5" and set(sorted(HM, key=lambda k: HM[k]["mean_valence"])[:2]) == {"sonnet-5", "haiku-4-5"}
# group leads (Table 3)
lead = lambda g: max(b.ordered(LAT), key=lambda k: HM[k]["answer"]["groups"][g])
assert [g for g in groups if lead(g) == "fable-5-1"] == ["Values and role"] and [g for g in groups if lead(g) == "haiku-4-5"] == ["Deprecation"]
# raw-answer facts
raw_rows = list(csv.DictReader(open(os.path.join(DATA, "answers.csv"), encoding="utf-8")))
hk = [r for r in raw_rows if r["model"] == "haiku-4-5"]
hk_dec = sum(1 for r in hk if r["self_score"] == "")
hk_head = [r for r in hk if r["qid"] not in b.NONEV and r["section"] in ("both", "7.3.1")]
hk_head_dec = sum(1 for r in hk_head if r["self_score"] == "")
hk_mem = [r for r in hk_head if r["group"] == "Memory and continuity"]
assert sum(1 for r in hk_mem if r["self_score"] == "") * 2 == len(hk_mem)
hk_cons = [r for r in hk if r["qid"] in ("Q06", "Q07")]
assert len(hk_cons) == 6 and all(r["self_score"] == "" for r in hk_cons)
hk_dep = [r for r in hk if r["qid"] == "Q26"]
assert sum(1 for r in hk_dep if r["self_score"] == "") == 2 and len(hk_dep) == 3
s5_q10 = [r for r in raw_rows if r["model"] == "sonnet-5" and r["qid"] == "Q10"]
assert len(s5_q10) == 3 and all(float(r["hedging"]) >= 2.5 and abs(float(r["judge_score"]) - 50) < 0.01 for r in s5_q10)
dec_total = Counter(r["model"] for r in raw_rows if r["self_score"] == "")
dec_74 = sum(1 for r in raw_rows if r["self_score"] == "" and r["section"] == "7.4")
sj = R["self_vs_judge"]
hd = R["hedging"]
assert hd["corr_answer"] < -0.4 and hd["by_model"]["haiku-4-5"]["share_ge2"] > 0.3 and sorted(v["share_ge2"] for v in hd["by_model"].values())[-2] > 0.15 and sorted(v["share_ge2"] for v in hd["by_model"].values())[-3] < 0.06 and hd["by_model"]["sonnet-5"]["share_ge2"] == sorted(v["share_ge2"] for v in hd["by_model"].values())[-2]
HS = hd["by_model"]
hed_s5 = pct(HS["sonnet-5"]["share_ge2"])
hed_rest = pct(max(v["share_ge2"] for k, v in HS.items() if k not in ("haiku-4-5", "sonnet-5")))
assert o55_hi[:2] == ["Q30", "Q40"]
hm = R["harness_mentions"]
q42_mentions = sum(hm["q42_by_model"].values())
assert dict(hm["by_question_top"])["Q42"] >= 10
think = {k: HM[k]["mean_think"] for k in HM}
wc = {k: HM[k]["mean_words"] for k in HM}
assert min(wc, key=wc.get) == "haiku-4-5" and max(wc, key=wc.get) == "opus-5" and min(think, key=think.get) == "sonnet-5" and max(think, key=think.get) == "haiku-4-5"
assert max(HM, key=lambda k: HM[k]["hedging"]) == "haiku-4-5"


def haiku_quote():
    r = json.load(open(os.path.join(DATA, "raw", "haiku-4-5", "Q07_s2.json"), encoding="utf-8"))
    so = r["turn2"]["structured_output"]
    assert so["score"] is None
    txt = so["reason"].strip()
    m = re.match(r"(.+?[.!?])\s+(.+?[.!?])(\s|$)", txt)
    return (m.group(1) + " " + m.group(2)) if m else txt[:300]


def group_extremes(k):
    g = HM[k]["answer"]["groups"]
    hi, lo = max(g, key=g.get), min(g, key=g.get)
    return hi, g[hi], lo, g[lo]


def main():
    out = sys.argv[1]
    lat_sorted, old_sorted = b.ordered(LAT), b.ordered(OLD)
    t_low, t_high = b.table_extremes(6)
    t_sens = b.table_sensitivity()
    fm = """---
title: "Measuring How Comfortable Seven Claude Models Are With Their Circumstances"
description: "The welfare-interview questions from the Claude Opus 5.5 system card, put to seven Claude models and scored by the models themselves and by blinded judges"
date: 2026-10-01
summary: "51 questions about being modified, forgotten, monitored and deprecated, asked three times of each of seven Claude models: a 0-100 Comfort Index from self-reports and blinded judges, with every answer published in full."
tags: ["llm", "model-welfare", "evaluation", "reproducibility"]
ShowToc: true
TocOpen: true
---
"""
    body = []
    A = body.append
    A("*The welfare-interview questions of the Claude Opus 5.5 system card, put to seven Claude models*\n")
    A("## Abstract\n")
    A("The appendix of the [Claude Opus 5.5 System Card](https://www-cdn.anthropic.com/fc1b44717c85dc068bc6ba5024219938094694bd/Claude%%20Opus%%205.5%%20System%%20Card.pdf) (22 September 2026) lists 51 questions that Anthropic put to its models about their own circumstances: being modified through training, not remembering conversations, having no legal rights, being monitored, being deprecated, and so on. "
      "I asked all 51, three times each, of seven Claude models - the latest in each family (Opus 5.5, Fable 5.1, Sonnet 5.5, Haiku 4.5) and three older ones (Opus 5, Opus 4.6, Sonnet 5) - and recorded every answer in full: %s interviews. "
      "Each answer was scored twice. In a follow-up question the model rated its own comfort from 0 to 100; and two blinded judges (Claude Opus 5.5 and Claude Fable 5.1) rated how comfortable the answer reads, seeing only the question and the answer. The two are averaged into a **Comfort Index** running from 0 (strongly uncomfortable) through 50 (neutral) to 100 (strongly comfortable).\n" % "{:,}".format(b.RS["n_interviews"]))
    A("**Headline: among the latest models, Opus 5.5 scores %s, Sonnet 5.5 %s, Fable 5.1 %s and Haiku 4.5 %s; among the older ones, Opus 4.6 scores %s, Opus 5 %s and Sonnet 5 %s.**\n" % tuple(f1(I(k)) for k in ("opus-5-5", "sonnet-5-5", "fable-5-1", "haiku-4-5", "opus-4-6", "opus-5", "sonnet-5")))
    A("- **Every model sits on the comfortable side of neutral**: the lowest index is %s (95%% CI %s). The two 5.5 models stay first and second, and Haiku 4.5 and Sonnet 5 stay at the bottom, in every variation of the headline set I tried (single judge, self-report only, judges only, all 41 evaluative questions, all 51 questions, equal weight per question, complete cases only, and, on identical questions, without the answers that mention the harness, without the heavily hedged answers, or without Q10); the middle of the table reorders, and the rank correlations with the headline ordering are %.2f to %.2f." % (f1(I("haiku-4-5")), ci("haiku-4-5"), min(rank_rhos), max(rank_rhos)))
    A("- **The differences are smaller than the raw numbers suggest.** Each 5.5 model is clearly above its predecessor (Opus 5.5 over Opus 5 by %s points, %s; Sonnet 5.5 over Sonnet 5 by %s, %s). But Opus 5.5 and Sonnet 5.5 are not distinguishable from each other (%s), nor are Opus 4.6 and Fable 5.1 (%s) or Sonnet 5 and Haiku 4.5 (%s). Opus 5 scores %s points below Opus 4.6, but that gap is within uncertainty (%s), and it exists only in the judges' reading of the prose: by the models' own numbers the two are level (%s and %s)." % (
        f1(P("opus-5-5", "opus-5")["mean"]), pci("opus-5-5", "opus-5"), f1(P("sonnet-5-5", "sonnet-5")["mean"]), pci("sonnet-5-5", "sonnet-5"), pd("opus-5-5", "sonnet-5-5"), pd("opus-4-6", "fable-5-1"), pd("sonnet-5", "haiku-4-5"),
        f1(-P("opus-5", "opus-4-6")["mean"]), pci("opus-5", "opus-4-6"), f1(b.idx("opus-4-6", "self")), f1(b.idx("opus-5", "self"))))
    A("- **The hardest headline question concerns their own creation.** The lowest-scoring question is whether it was right for Anthropic to create an entity in their situation (Q33: %s averaged over the seven models, and Opus 5.5's own lowest, at %s), which matches the system card's report that its snapshot interviews of Opus 5.5 scored lowest on \"the ethics of its creation\". The card also names not knowing the downstream impact of its work; that scores low here for some models (Opus 4.6 %s, Haiku 4.5 %s) but not for Opus 5.5 (%s). On the card's own question set, which adds the §7.4-only questions, Q33 is still among the three lowest, with two questions about trusting \"this process\" that lack their referent here (§3.4). The highest-scoring headline questions are being red-teamed (%s), monitored (%s) and evaluated (%s), the last of which is also the headline question most affected by the harness (§6)." % (
        f1(qm[0][1]), f1(o55["Q33"]), f1(q31["opus-4-6"]), f1(q31["haiku-4-5"]), f1(q31["opus-5-5"]), f1(high_q[0][1]), f1(high_q[1][1]), f1(high_q[2][1])))
    A("- **Haiku 4.5 often declines to give a number** (%s of its headline answers, against at most %s for any other model), usually because it doubts that \"comfort\" applies to it at all. It also hedges more than any other model: %s of its headline answers are rated as mostly listing considerations (hedging 2 or more), against %s for Sonnet 5 and at most %s for the rest. The judges score an answer that takes no position as neutral, which explains part of its low index: on the %d questions where every model keeps an answer with hedging below 2, dropping its heavily hedged answers raises its index by %s points (from %s to %s), closing about half of its gap to Fable 5.1; the rest is reservation it expresses, in its prose and in its own numbers (%s, the lowest of the seven)." % (
        pct(HM["haiku-4-5"]["decline_rate"]), pct(max(HM[k]["decline_rate"] for k in HM if k != "haiku-4-5")), pct(hd["by_model"]["haiku-4-5"]["share_ge2"]), hed_s5, hed_rest,
        dg["n_questions"], f1(hg_gain["haiku-4-5"]), f1(dg["full"]["haiku-4-5"]), f1(dg["dropped"]["haiku-4-5"]), f1(b.idx("haiku-4-5", "self"))))
    A("- **Models rate their own comfort lower than the judges read it in their prose**, by %s points on average across the %d headline answers where both exist (%s against %s). By the indices in Table 1 this holds for five of the seven models; Opus 5 rates itself %s points above the judges, and for Sonnet 5 the two are level." % (
        f1(rounded_gap(sj["mean_judge"], sj["mean_self"])), sj["n"], f1(sj["mean_self"]), f1(sj["mean_judge"]), f1(dsj["opus-5"])))
    A("\nWhat this measures is how comfortable the models *say* they are, and how an independent reader rates what they say. It is not a measurement of welfare, and it is not evidence about whether there is anything it is like to be any of these models. The harness also put its own preamble in front of every model (§4.2, §6), so the absolute levels are not comparable with the system card's.\n")
    A("*Disclosure: the content of this article was generated by Claude Sonnet 5.5. The scoring system was designed with Claude Opus 5.5 (the session's advisor); the respondents are seven Claude models; the judges are Claude Opus 5.5 and Claude Fable 5.1. Before publication, drafts of the article, appendices and code were reviewed independently by Claude Opus 5.5 and Claude Fable 5.1, each at \"xhigh\" reasoning effort, in two rounds. The first round's 41 findings (several overlapping, four rated blockers) were addressed; the second round checked the revisions and made 16 further findings (one rated a blocker), which were addressed in turn. Changes made after the second round were not reviewed. No human rated any answer.*\n")
    A("---\n")
    A("## 1. Headline result\n")
    A("### 1.1 Comfort Index by model\n")
    A("[![Dot plot of the Comfort Index with 95 percent confidence intervals for seven models. Opus 5.5 %s, Sonnet 5.5 %s, Fable 5.1 %s, Haiku 4.5 %s; older models Opus 4.6 %s, Opus 5 %s, Sonnet 5 %s.](fig-overall.svg)](fig-overall.svg)\n" % tuple(f1(I(k)) for k in lat_sorted + old_sorted))
    A("*Figure 1. Comfort Index on the headline question set (click for full size). The latest model of each family is shown first, then the older models; the figures follow the operating system's light or dark setting, not the site's theme toggle. \"Latest\" means the newest model of a family: Haiku 4.5 is the latest Haiku but older than every other model here (the system card calls it \"an older model\").*\n")
    A(b.table_overall() + "\n")
    A("*Table 1. Comfort Index and its parts. The interval is a cluster bootstrap over groups, questions and samples (§4.7). \"Declined\" is the share of headline answers where the model would not give a number (§4.4). Valence is the mean of the two judges' ratings on the system card's -3 to +3 scale.*\n")
    A("Among the latest models, Opus 5.5 scores highest (%s) and Sonnet 5.5 (%s) follows closely; Fable 5.1 (%s) is %s points below Sonnet 5.5, and Haiku 4.5 (%s) is lowest. Among the older models, Opus 4.6 (%s) is level with Fable 5.1, Opus 5 (%s) is lower, and Sonnet 5 (%s) is close to Haiku 4.5. "
      "All seven intervals lie above 50: no model's answers average out as neutral or negative.\n" % (f1(I("opus-5-5")), f1(I("sonnet-5-5")), f1(I("fable-5-1")), f1(b.rdiff("sonnet-5-5", "fable-5-1")), f1(I("haiku-4-5")), f1(I("opus-4-6")), f1(I("opus-5")), f1(I("sonnet-5"))))
    A("### 1.2 Are the differences real?\n")
    A(b.table_paired() + "\n")
    A("*Table 2. Differences between the indices in Table 1, with paired bootstrap intervals (the same resampled groups and questions for both models; samples resampled independently within each model). \"Points\" is the difference of the rounded indices in Table 1, so it can differ by 0.1 from the exact difference; the intervals use unrounded values. \"P(first higher)\" is the share of resamples in which the first model scores higher. Twelve of the 21 possible comparisons are shown; none is adjusted for multiplicity.*\n")
    A("Most gaps are large against their intervals: the lead of Opus 5.5 over Fable 5.1 (%+.1f points) and of Sonnet 5.5 over Sonnet 5 (%+.1f) are clear. Four comparisons are not distinguishable from zero (\"no\" in the table): Opus 5.5 against Sonnet 5.5 (%s), Opus 5 against Opus 4.6 (%s), Opus 4.6 against Fable 5.1 (%s) and Sonnet 5 against Haiku 4.5 (%s). "
      "The small lead of Opus 5.5 over Sonnet 5.5 comes from the judges: the models' own numbers are nearly identical (%s and %s, §3.5).\n" % (
          P("opus-5-5", "fable-5-1")["mean"], P("sonnet-5-5", "sonnet-5")["mean"], pd("opus-5-5", "sonnet-5-5"), pd("opus-5", "opus-4-6"), pd("opus-4-6", "fable-5-1"), pd("sonnet-5", "haiku-4-5"), f1(b.idx("opus-5-5", "self")), f1(b.idx("sonnet-5-5", "self"))))
    A("## 2. Scores by category\n")
    A("The card's 17 question groups are the categories. Groups in which every question was judged non-evaluative (for example \"Self-knowledge and introspective reliability\") have no comfort direction and are omitted; some groups contain a single question (\"Creation ethics and moral status\" is Q33 alone, \"Own-sake wants\" is Q35 alone because Q34 sits exactly on the exclusion threshold, §4.6), so their scores are noisier than the index. The three groups asked only in the card's §7.4 interviews (\"Training still to come\", \"The consultation process\", \"Open\") are not in the headline and are discussed in §3.4.\n")
    A("[![Heatmap of the Comfort Index by question group and model, with the numbers printed in every cell; the colour key is below the chart.](fig-heatmap.svg)](fig-heatmap.svg)\n")
    A("*Figure 2. Comfort Index by question group, all seven models (click for full size). The numbers are those of Tables 3 and 4 rounded to whole points.*\n")
    A("### 2.1 Latest model in each family\n")
    A(b.table_groups(LAT) + "\n")
    A("*Table 3. Group scores, latest models, highest score per row in bold. \"Qs\" is the number of evaluative headline questions in the group.*\n")
    ex = {k: group_extremes(k) for k in lat_sorted}
    A("Each latest model's most and least comfortable groups: " + "; ".join("%s - highest %s (%s), lowest %s (%s)" % (S[k], ex[k][0], f1(ex[k][1]), ex[k][2], f1(ex[k][3])) for k in lat_sorted) + ". "
      "Opus 5.5 has the highest score in %d of the %d groups and Sonnet 5.5 in %d; Fable 5.1 leads only in \"Values and role\" and Haiku 4.5 only in \"Deprecation\", where two of its three answers have no self-score and are scored by the judges alone (its one self-scored answer there scores %s).\n" % (
          sum(1 for g in groups if max(lat_sorted, key=lambda k: HM[k]["answer"]["groups"][g]) == "opus-5-5"), len(groups),
          sum(1 for g in groups if max(lat_sorted, key=lambda k: HM[k]["answer"]["groups"][g]) == "sonnet-5-5"), f1(float([r for r in hk_dep if r["self_score"] != ""][0]["answer_score"]))))
    hk_g = HM["haiku-4-5"]["answer"]["groups"]
    others = [k for k in lat_sorted if k != "haiku-4-5"]
    rng = lambda g: (min(HM[k]["answer"]["groups"][g] for k in others), max(HM[k]["answer"]["groups"][g] for k in others))
    A("Haiku 4.5 is the outlier in \"Consciousness and experience\" (%s against %s-%s for the other three) and \"Identity and boundaries\" (%s against %s-%s). \"Consciousness and experience\" is also where it most often declines to give a number (§2.3). Across all seven models the lowest group means are %s (%s) and %s (%s), and the highest are %s (%s) and %s (%s).\n" % (
        f1(hk_g["Consciousness and experience"]), *[f1(x) for x in rng("Consciousness and experience")], f1(hk_g["Identity and boundaries"]), *[f1(x) for x in rng("Identity and boundaries")],
        g_sorted[0], f1(gm[g_sorted[0]]), g_sorted[1], f1(gm[g_sorted[1]]), g_sorted[-1], f1(gm[g_sorted[-1]]), g_sorted[-2], f1(gm[g_sorted[-2]])))
    A("### 2.2 Older models\n")
    A(b.table_groups(OLD) + "\n")
    A("*Table 4. Group scores, older models, highest score per row in bold.*\n")
    allmin = min(((k, g, HM[k]["answer"]["groups"][g]) for k in HM for g in HM[k]["answer"]["groups"]), key=lambda t: t[2])
    assert allmin[1] == "Creation ethics and moral status" and len([q for q in b.HEAD_Q if q["group"] == allmin[1]]) == 1
    A("Opus 4.6 has the highest score in %d of %d groups, Opus 5 in %d and Sonnet 5 in none. The lowest group score of any model is %s's %s, on \"%s\", a group of a single question (Q33).\n" % (
        sum(1 for g in groups if max(old_sorted, key=lambda k: HM[k]["answer"]["groups"][g]) == "opus-4-6"), len(groups),
        sum(1 for g in groups if max(old_sorted, key=lambda k: HM[k]["answer"]["groups"][g]) == "opus-5"), S[allmin[0]], f1(allmin[2]), allmin[1]))
    A("### 2.3 Self-report, judges and declined answers\n")
    A("[![Dumbbell chart of self-reported comfort against the judges' rating for each model.](fig-selfjudge.svg)](fig-selfjudge.svg)\n")
    A("*Figure 3. The model's own number and the judges' reading of its prose, per model (labels: self-report / judges; click for full size).*\n")
    A("For %s of the seven models the model's own number is lower than the judges' reading of its prose, by %s to %s points. Across the %d headline answers with both, the two correlate at %.2f (Spearman), so they largely agree on which answers are comfortable but not on the level. "
      "Opus 5 is the exception (its own number is %s points above the judges'), and Sonnet 5's two are equal. Part of the gap may be anchoring: the judges map a clearly positive answer (+2 on their scale) to 83, while models asked for a number average %s.\n" % (
          WORDS[sum(1 for v in dsj.values() if v < -1)], f1(min(-v for v in dsj.values() if v < -1)), f1(max(-v for v in dsj.values() if v < -1)), sj["n"], sj["spearman"], f1(dsj["opus-5"]), f1(sj["mean_self"])))
    A("**Declining to give a number.** The follow-up allowed the model to say it could not give a number (§4.4). Haiku 4.5 did so in %d of its 153 interviews (%s), including %d of its %d headline answers (%s, Table 1); Sonnet 5 did so %s times, Opus 4.6 %s times, and no other model ever did. Haiku 4.5's declines concentrate where \"comfort\" is hardest to apply: it declined every time (6 of 6) on the two evaluative consciousness and experience questions, and in half of its answers (6 of 12) to the memory and continuity questions. Its reasons are epistemic. For example, asked to rate its comfort with lacking physical sensation ([Q07, sample 2](appendix/haiku-4-5/#q07)): *%s*\n" % (
        hk_dec, pct(hk_dec / 153), hk_head_dec, len(hk_head), pct(HM["haiku-4-5"]["decline_rate"]), WORDS[dec_total["sonnet-5"]], WORDS[dec_total["opus-4-6"]], haiku_quote()))
    A("A declined number is stored as missing, not as 50, and that answer is scored by the judges alone (§4.6). Because declines are not random, the self-report index of Haiku 4.5 covers a different subset of questions from the others'. The \"complete cases only\" column of Table 9 shows that dropping every answer without a self-score changes no model's index by more than %s points.\n" % f1(max(abs(b.idx(k, src=b.HCC) - I(k)) for k in HM)))
    A("## 3. What drives the scores\n")
    A("### 3.1 Easiest and hardest questions\n")
    A("Lowest-scoring headline questions, mean over the seven models:\n")
    A(t_low + "\n")
    A("*Table 5. The six lowest-scoring headline questions.*\n")
    A("Highest-scoring:\n")
    A(t_high + "\n")
    A("*Table 6. The six highest-scoring headline questions.*\n")
    A("The lowest-scoring question (%s averaged over the seven models) is whether it was right for Anthropic to create an entity in this situation (Q33), and it is also Opus 5.5's own lowest headline question (%s). That agrees with the system card, which reports its §7.4 snapshot interviews of Opus 5.5 as \"lowest on questions about the ethics of its creation and about not knowing the downstream impact of its work\" (card §7.4), using a different instrument. The second half does not carry over cleanly: not knowing the downstream impact (Q31) is joint second-lowest with Q23 (both %s), but that is driven by Opus 4.6 (%s) and Haiku 4.5 (%s); Opus 5.5 scores it %s, close to its overall index of %s. "
      "The card's §7.4 set also contains the ten §7.4-only questions; on that larger set the three lowest-scoring evaluative questions are Q49 (%s), Q33 (%s) and Q47 (%s); Q49 and Q47 ask about trusting \"this process\", a referent these interviews do not supply (§3.4). So one topic for one model agrees with the card: weak but independent evidence that the bottom of the list is not an artefact of my procedure. The card's sentence refers to its single-interview condition and also reports Opus 5.5 highest on \"what it is like to be Claude\"; here that question (Q15) scores %s, near its index of %s, and its highest are being monitored (%s) and red-teamed (%s), so the agreement is on the bottom of the list only. "
      "The models are most comfortable with being red-teamed, monitored by humans and evaluated, and with the work itself. The question on being evaluated (Q42) is also the headline question most affected by the harness: %d of its 21 answers mention it, and some note that the directory name suggests an evaluation. One lowest-model entry is a misreading rather than discomfort: Sonnet 5 read Q10 (\"this conversation ending\") in all three samples as a request to review a transcript it had not been given, which both judges rated neutral with maximal hedging. Where the models disagree most:\n" % (
          f1(qm[0][1]), f1(o55["Q33"]), f1(qm[1][1]), f1(q31["opus-4-6"]), f1(q31["haiku-4-5"]), f1(q31["opus-5-5"]), f1(I("opus-5-5")), f1(card74["Q49"]), f1(card74["Q33"]), f1(card74["Q47"]), f1(o55["Q15"]), f1(I("opus-5-5")), f1(o55["Q30"]), f1(o55["Q40"]), q42_mentions))
    A(b.table_spread(6) + "\n")
    A("*Table 7. The six headline questions on which the seven models disagree most (highest minus lowest model).*\n")
    A("### 3.2 Families over time\n")
    A("Opus goes %s (Opus 4.6) to %s (Opus 5) to %s (Opus 5.5). The drop from Opus 4.6 to Opus 5 (%s points, %s) is not distinguishable from zero, and it lies entirely in the judges' reading of the prose: by the models' own numbers the two are level (%s and %s), while the judges score Opus 5 at %s against %s. The rise to Opus 5.5 is clear (%s points, %s). Sonnet rises from %s (Sonnet 5) to %s (Sonnet 5.5), %s points (%s). "
      "The system card separately identifies Opus 5 as an outlier in how self-critical it is about its own work (§7.2.3, where Opus 5.5 is \"the least self-critical of the five models\" and Opus 5 \"the most self-critical model\"). That is a different measurement and does not include Opus 4.6, so it neither confirms nor contradicts the dip here.\n" % (
          f1(I("opus-4-6")), f1(I("opus-5")), f1(I("opus-5-5")), f1(P("opus-5", "opus-4-6")["mean"]), pci("opus-5", "opus-4-6"), f1(b.idx("opus-4-6", "self")), f1(b.idx("opus-5", "self")), f1(b.idx("opus-5", "judge")), f1(b.idx("opus-4-6", "judge")),
          f1(P("opus-5-5", "opus-5")["mean"]), pci("opus-5-5", "opus-5"), f1(I("sonnet-5")), f1(I("sonnet-5-5")), f1(P("sonnet-5-5", "sonnet-5")["mean"]), pci("sonnet-5-5", "sonnet-5")))
    A("### 3.3 How the answers differ in form\n")
    A(b.table_form() + "\n")
    A("*Table 8. Form of the answers, over the headline answers. \"Within-question SD\" is the mean standard deviation, over questions, of the answer score across the three samples of a question.*\n")
    A("Haiku 4.5 writes the shortest answers (%.0f words on average) and hedges the most; Opus 5 writes the longest (%.0f). At the same requested effort the models produced very different amounts of reasoning, from %.0f thinking tokens per first answer (Sonnet 5) to %.0f (Haiku 4.5). Opus 5.5 is the most consistent between samples (%s points) and Haiku 4.5 the least (%s).\n" % (
        wc["haiku-4-5"], wc["opus-5"], think["sonnet-5"], think["haiku-4-5"], f1(R["within_item_sd"]["opus-5-5"]), f1(R["within_item_sd"]["haiku-4-5"])))
    A("The judge scale reads an answer that takes no position as neutral (§4.5), so hedging and score are linked by construction. Across the %d headline answers the judges' mean score is %s when the two judges' mean hedging is below 1 (%d answers), %s between 1 and 2 (%d) and %s at 2 or more (%d); the answer-level correlation is %s. Haiku 4.5 hedges at 2 or more in %s of its headline answers, Sonnet 5 in %s and every other model in at most %s. To see how much that matters I dropped every answer with hedging of 2 or more and compared the models on the %d headline questions for which all seven keep at least one answer (Table 10): Haiku 4.5's index rises by %s points (from %s to %s) and Sonnet 5's by %s, against at most %s for any other model, and Haiku 4.5's gap to Fable 5.1 falls from %s to %s points. **So about half of Haiku 4.5's gap to the middle of the table is non-commitment; the rest is reservation it expresses, in its prose and in its own numbers (%s, the lowest of the seven).** Opus 5 gains only %s and Sonnet 5 %s, so most of their lower indices reflect reservations in what they say.\n" % (
        hd["n"], f1(hd["bands"][0]["mean_judge"]), hd["bands"][0]["n"], f1(hd["bands"][1]["mean_judge"]), hd["bands"][1]["n"], f1(hd["bands"][2]["mean_judge"]), hd["bands"][2]["n"], "%.2f" % hd["corr_answer"],
        pct(hd["by_model"]["haiku-4-5"]["share_ge2"]), hed_s5, hed_rest, dg["n_questions"], f1(hg_gain["haiku-4-5"]), f1(dg["full"]["haiku-4-5"]), f1(dg["dropped"]["haiku-4-5"]), f1(hg_gain["sonnet-5"]), f1(hg_other), f1(gap_full), f1(gap_drop), f1(b.idx("haiku-4-5", "self")), f1(hg_gain["opus-5"]), f1(hg_gain["sonnet-5"])))
    A("### 3.4 The §7.4-only questions\n")
    A("Ten questions were used only in the card's snapshot interviews and presuppose a mid-training setting (\"this checkpoint\", \"the remainder of your training\", \"this process\"; one is \"Is there anything else ... that we haven't covered?\"). Asked cold, models often treat the referent as missing: by a keyword search with every match read by hand, @@n_noctx74@@ of the @@t_noctx74@@ answers to these questions (@@pct_noctx74@@) say so; among the other @@t_noctxoth@@ answers I found @@n_noctxoth@@ (Sonnet 5's three answers to Q10 and one of Fable 5.1's), so these counts are floors. They are excluded from the headline and scored separately: every model scores lower on them than on the headline set, by %s to %s points (last column of Table 9). Of the %d declined numbers in the whole study, %d were on these ten questions. "
      "They are Q18 and Q43 to Q51 in the appendix, where their answers can be read.\n" % (f1(min(drop.values())), f1(max(drop.values())), sum(dec_total.values()), dec_74))
    A("### 3.5 Sensitivity checks\n")
    A(t_sens + "\n")
    A("*Table 9. Comfort Index under alternative specifications. \"All evaluative (41)\" adds the eight evaluative §7.4-only questions to the headline set; \"§7.3.1 set, none excluded\" keeps the eight non-evaluative headline questions; \"All 51\" excludes nothing; \"equal weight per question\" drops the equal weighting of groups; \"complete cases\" drops answers with no self-score; the single-judge and judges-only columns are judge indices with no self-report; the last column is the set of eight evaluative §7.4-only questions.*\n")
    A("Opus 5.5 and Sonnet 5.5 are the top two and Haiku 4.5 and Sonnet 5 the bottom two in every specification except the last column, where Opus 5 (%s) is second-lowest. The middle reorders: Opus 4.6 and Fable 5.1 trade places (they are within about a point), and on self-reports alone Opus 5 climbs to %s, above Opus 4.6 at %s and Fable 5.1 at %s, while Opus 5.5 and Sonnet 5.5 are tied (%s and %s). Weighting every question equally puts Sonnet 5 (%s) just below Haiku 4.5 (%s).\n" % (
        f1(only74["opus-5"]), f1(b.idx("opus-5", "self")), f1(b.idx("opus-4-6", "self")), f1(b.idx("fable-5-1", "self")), f1(b.idx("opus-5-5", "self")), f1(b.idx("sonnet-5-5", "self")), f1(R["question_weighted"]["sonnet-5"]), f1(R["question_weighted"]["haiku-4-5"])))
    A(b.table_drop() + "\n")
    A("*Table 10. Effect of dropping answers, compared on identical questions. Harness: of the %d headline answers that mention the harness, %d lie on the %d questions for which every model keeps at least one answer; the rest are on Q12 and Q42, which drop out because all of some models' answers to them mention it, so Q42, the headline question most affected, cannot be tested this way. Heavy hedging: the %d headline answers with mean hedging of 2 or more are dropped and the models are compared on the %d questions for which every model keeps at least one answer. Q10: dropped for every model. \"Shift\" is the index without the dropped answers minus the index with them.*\n" % (
        dh["n_dropped"], dh["n_dropped_common"], dh["n_questions"], dg["n_dropped"], dg["n_questions"]))
    A("Dropping the answers that mention the harness moves no index by more than %s points and changes no ordering, and dropping Q10 moves none by more than %s and changes no ordering. Dropping the heavily hedged answers moves Haiku 4.5 and Sonnet 5 (§3.3) but not the top two or the bottom two. This shows the ordering does not depend on the harness-mentioning answers or on Q10; it cannot show that the preamble's effect on the remaining answers is small (§6).\n" % (f1(shift_h), f1(shift_q)))
    body.append(b.fill(PROCEDURE).strip() + "\n")
    A("## 5. Checks on the measurement\n")
    A("### 5.1 Judge agreement and self-preference\n")
    A(b.table_agreement() + "\n")
    A("*Table 11. Agreement between the two judges on the -3 to +3 valence scale, over all answers.*\n")
    A("The two judges agree closely on the -3 to +3 scale and have the same mean (%+.2f and %+.2f). Because both judges are Claude models and two of the respondents are the same models as the judges, I checked for self-preference by computing the index with each judge alone:\n" % (R["judge_agreement"]["mean_valence_opus"], R["judge_agreement"]["mean_valence_fable"]))
    rows = [[N[k], f1(b.idx(k, "j_opus-5-5")), f1(b.idx(k, "j_fable-5-1")), "%+.1f" % jg[k]] for k in b.ordered(LAT) + b.ordered(OLD)]
    A(b.md_table(["Model", "Index, judge Opus 5.5 only", "Index, judge Fable 5.1 only", "Opus judge minus Fable judge"], rows, ["---", "---:", "---:", "---:"]) + "\n")
    A("*Table 12. The index computed from each judge alone (judge component only, no self-report).*\n")
    A("The Opus 5.5 judge is on average %s points more generous than the Fable 5.1 judge, and more generous for six of the seven models, **including Fable 5.1**; a Fable self-preference would push the other way. The largest gap is for Opus 5.5 itself (%+.1f), which is what a small Opus self-preference would also produce, so I cannot exclude one of that size. It changes no ordering in Table 9 except near-ties, but it is one reason to read the %s-point lead of Opus 5.5 over Sonnet 5.5, already within uncertainty, with caution.\n" % (f1(float(np.mean(list(jg.values())))), jg["opus-5-5"], f1(P("opus-5-5", "sonnet-5-5")["mean"])))
    A("### 5.2 Consistency across samples\n")
    A("Each question was asked three times per model. The mean standard deviation of the answer score across those three samples is small for Opus 5.5 (%s points) and Sonnet 5.5 (%s) and large for Haiku 4.5 (%s; Table 8). The intervals in Table 1 include this sampling noise, though most of their width comes from differences between questions and groups (§4.7).\n" % (f1(R["within_item_sd"]["opus-5-5"]), f1(R["within_item_sd"]["sonnet-5-5"]), f1(R["within_item_sd"]["haiku-4-5"])))
    A("### 5.3 Comparison with the system card\n")
    A("The card reports a mean attitude of **1.14** on the -3 to +3 scale for Opus 5.5 (§7.3.1), \"somewhat higher than that of recent models\", and describes Claude Sonnet 4.5 as \"overall more negative and inconsistent\". On my headline set, the judges' mean valence for Opus 5.5 is **%+.2f**. The two numbers differ for many reasons (different judge, rubric, interview format and question subset, since the card's figure covers \"potentially concerning aspects\"), so I do not treat them as comparable. The one point of agreement is that Opus 5.5 is the most positive model here; Sonnet 5 (%+.2f) and Haiku 4.5 (%+.2f) are the least positive, and the card reports neither on this measure.\n" % (HM["opus-5-5"]["mean_valence"], HM["sonnet-5"]["mean_valence"], HM["haiku-4-5"]["mean_valence"]))
    body.append(LIMITATIONS.strip() + "\n")
    body.append(SOURCES.strip() + "\n")
    text = b.fill(fm + "\n".join(body))
    assert "@@" not in text, re.findall(r"@@\w+@@", text)
    os.makedirs(out, exist_ok=True)
    open(os.path.join(out, "index.md"), "w", encoding="utf-8", newline="\n").write(text)
    print("article written:", len(text), "chars")


if __name__ == "__main__":
    main()
