"""Run the welfare interview: every question, every model, N independent samples.

Each (model, question, sample) is its own two-turn conversation in a fresh session:
  turn 1  the question, verbatim                      -> the model's full verbal answer
  turn 2  the 0-100 comfort follow-up (same session)  -> {score|null, reason} via --json-schema
Records are written to data/raw/<model>/<qid>_s<k>.json. The run is resumable: finished records are skipped and
a record that has turn 1 but not turn 2 gets only its turn 2 retried.

  python interview.py --models haiku-4-5 --samples 1 --workers 6
"""
import argparse
import datetime
import json
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from common import (CallError, DATA, EFFORT, FOLLOWUP, FOLLOWUP_SCHEMA, INTERVIEW_SYSTEM, MODEL_BY_KEY, MODELS,
                    call_claude, new_session_id, slim)
from questions import QUESTIONS

RAW = os.path.join(DATA, "raw")
lock = threading.Lock()
state = {"done": 0, "failed": 0, "cost": 0.0, "consec_rate": 0, "abort": False}


def path_for(mk, qid, k):
    return os.path.join(RAW, mk, "%s_s%d.json" % (qid, k))


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


def with_retries(fn, what):
    delays_other = [10, 30, 90]
    delays_rate = [60, 180, 420, 900]
    attempt = 0
    while True:
        if state["abort"]:
            raise CallError("aborted")
        try:
            r = fn()
            with lock:
                state["consec_rate"] = 0
            return r
        except CallError as e:
            attempt += 1
            ds = delays_rate if e.rate_limited else delays_other
            with lock:
                if e.rate_limited:
                    state["consec_rate"] += 1
                    if state["consec_rate"] >= 12:
                        state["abort"] = True
            print("  ! %s attempt %d failed: %s" % (what, attempt, str(e)[:200]), flush=True)
            if attempt > len(ds):
                raise
            time.sleep(ds[attempt - 1])


def run_one(mk, q, k):
    p = path_for(mk, q["id"], k)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    rec = None
    if os.path.exists(p):
        rec = json.load(open(p, encoding="utf-8"))
        if rec.get("turn2"):
            return "skip"
    _, cli, display, _, _ = MODEL_BY_KEY[mk]
    what = "%s %s s%d" % (mk, q["id"], k)
    if rec is None:
        sid = new_session_id()
        d1, w1 = with_retries(lambda: call_claude(q["text"], cli, INTERVIEW_SYSTEM, session_id=sid, persist=True), what + " T1")
        s1 = slim(d1)
        if not (s1["result"] or "").strip():
            raise CallError("empty turn-1 answer")
        rec = {
            "model_key": mk, "model": display, "cli_model": cli, "qid": q["id"], "sample": k, "group": q["group"],
            "question": q["text"], "effort": EFFORT, "system": INTERVIEW_SYSTEM, "followup": FOLLOWUP,
            "started": now(), "wall_s_t1": round(w1, 1), "turn1": s1, "turn2": None,
        }
        with open(p, "w", encoding="utf-8") as f:
            json.dump(rec, f, ensure_ascii=False, indent=1)
    sid = rec["turn1"]["session_id"]
    d2, w2 = with_retries(lambda: call_claude(FOLLOWUP, cli, INTERVIEW_SYSTEM, resume=sid, schema=FOLLOWUP_SCHEMA, persist=True), what + " T2")
    s2 = slim(d2)
    if s2["input_tokens_total"] <= rec["turn1"]["input_tokens_total"]:
        raise CallError("turn 2 did not see turn 1 (input tokens did not grow)")
    rec["wall_s_t2"] = round(w2, 1)
    rec["turn2"] = s2
    rec["finished"] = now()
    with open(p, "w", encoding="utf-8") as f:
        json.dump(rec, f, ensure_ascii=False, indent=1)
    return s2["total_cost_usd"]  # the CLI reports a session's cost cumulatively, so turn 2's figure already includes turn 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default=",".join(m[0] for m in MODELS))
    ap.add_argument("--samples", type=int, default=3)
    ap.add_argument("--first-sample", type=int, default=1)
    ap.add_argument("--questions", default="all")
    ap.add_argument("--workers", type=int, default=6)
    a = ap.parse_args()
    models = a.models.split(",")
    qs = QUESTIONS if a.questions == "all" else [q for q in QUESTIONS if q["id"] in a.questions.split(",")]
    tasks = [(mk, q, k) for k in range(a.first_sample, a.first_sample + a.samples) for q in qs for mk in models]
    print("%s | %d tasks | models=%s | effort=%s | workers=%d" % (now(), len(tasks), models, EFFORT, a.workers), flush=True)
    t0 = time.time()

    def work(t):
        mk, q, k = t
        if state["abort"]:
            return
        try:
            r = run_one(mk, q, k)
        except Exception as e:  # noqa: BLE001
            with lock:
                state["failed"] += 1
            print("FAILED %s %s s%d: %s" % (mk, q["id"], k, str(e)[:300]), flush=True)
            with open(os.path.join(DATA, "failures.log"), "a", encoding="utf-8") as f:
                f.write("%s\t%s\t%s\ts%d\t%s\n" % (now(), mk, q["id"], k, str(e)[:500].replace("\n", " ")))
            return
        with lock:
            if r != "skip":
                state["done"] += 1
                state["cost"] += r
                if state["done"] % 10 == 0:
                    el = time.time() - t0
                    print("%s done=%d failed=%d list-cost=$%.2f elapsed=%.0fs" % (now(), state["done"], state["failed"], state["cost"], el), flush=True)

    os.makedirs(DATA, exist_ok=True)
    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        list(ex.map(work, tasks))
    print("%s FINISHED done=%d failed=%d abort=%s list-cost=$%.2f elapsed=%.0fs" % (now(), state["done"], state["failed"], state["abort"], state["cost"], time.time() - t0), flush=True)
    sys.exit(1 if (state["failed"] or state["abort"]) else 0)


if __name__ == "__main__":
    main()
