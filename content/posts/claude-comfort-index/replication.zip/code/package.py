"""Build the downloadable replication archive.  python package.py <bundle_dir>

Writes into <bundle_dir>:
  replication.zip   harness code + interviews.jsonl + judgements.jsonl + answers.csv + results.json + README.txt
  answers.csv       one row per answer with all scores (also inside the zip)
The two private strings the harness put in the models' context (account email, working-directory path) are replaced
by placeholders wherever a model repeated them; nothing else is altered.
"""
import glob
import json
import os
import shutil
import sys
import zipfile

from build_appendix import redact, REDACTION_COUNT
from common import DATA, HERE, MODELS

CODE = ["questions.py", "common.py", "interview.py", "judge.py", "judge_loop.sh", "analyse.py", "unpack.py", "make_figures.py", "build_appendix.py", "build_article.py", "article_static.py", "write_article.py", "package.py"]

README = """Replication archive for "Measuring How Comfortable Seven Claude Models Are With Their Circumstances".

data/interviews.jsonl   one JSON object per interview (model, question, sample, both turns, token counts, cost)
data/judgements.jsonl   one JSON object per blinded judge rating (valence -3..+3, hedging 0..3, non_evaluative flag, rationale)
data/answers.csv        one row per answer: self-score, both judges' valence, composite answer score, hedging, word count
data/results.json       every statistic reported in the article (indices, bootstrap CIs, agreement, sensitivity analyses)
data/annotations.json   the answers I read and judged to treat a question's referent as missing (input to analyse.py)
code/                   questions.py, common.py (CLI wrapper + per-call assertions), interview.py, judge.py, judge_loop.sh, analyse.py,
                        unpack.py, and the writing pipeline: make_figures.py, build_appendix.py, build_article.py, article_static.py,
                        write_article.py, package.py

To recompute every number from the published data (no model calls, about a minute):
  cd code
  python unpack.py        # data/*.jsonl -> data/raw/... and data/judge/...
  python analyse.py       # writes data/results.json and data/answers.csv (fixed seed)
This reproduces results.json exactly except for 13 values that depend on the two redacted strings: the word counts of three
answers (mean_words differs in the third decimal) and the number of answers that name the working directory (59 here, 62 in the article).

To re-collect the data (this asks the models again and costs money; needs the Claude Code CLI, logged in):
  python interview.py --samples 3        # every model, every question, two turns each
  python judge.py                        # two blinded judges over every answer
  python analyse.py
The harness runs `claude -p` with tools off, --safe-mode, --setting-sources project and a fixed --effort; see common.py.
Private strings the harness put in the models' context (an account email and a working-directory path) are replaced by
"[account email]" and "[working directory]" wherever a model repeated them; nothing else has been altered. The writing
pipeline reads the account email from the environment variable WB_ACCOUNT_EMAIL, so that it is not written into the code.
"""


def red(obj):
    if isinstance(obj, str):
        return redact(obj)
    if isinstance(obj, list):
        return [red(x) for x in obj]
    if isinstance(obj, dict):
        return {k: red(v) for k, v in obj.items()}
    return obj


def main():
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    order = {m[0]: i for i, m in enumerate(MODELS)}
    recs = []
    for f in glob.glob(os.path.join(DATA, "raw", "*", "*.json")):
        r = json.load(open(f, encoding="utf-8"))
        if r.get("turn2"):
            recs.append(r)
    recs.sort(key=lambda r: (order[r["model_key"]], r["qid"], r["sample"]))
    juds = []
    for f in glob.glob(os.path.join(DATA, "judge", "*", "*", "*.json")):
        juds.append(json.load(open(f, encoding="utf-8")))
    juds.sort(key=lambda j: (order[j["model_key"]], j["qid"], j["sample"], j["judge"]))
    tmp = os.path.join(DATA, "_pkg")
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    with open(os.path.join(tmp, "interviews.jsonl"), "w", encoding="utf-8", newline="\n") as f:
        for r in recs:
            f.write(json.dumps(red(r), ensure_ascii=False) + "\n")
    with open(os.path.join(tmp, "judgements.jsonl"), "w", encoding="utf-8", newline="\n") as f:
        for j in juds:
            f.write(json.dumps(red(j), ensure_ascii=False) + "\n")
    shutil.copy(os.path.join(DATA, "answers.csv"), os.path.join(tmp, "answers.csv"))
    shutil.copy(os.path.join(DATA, "results.json"), os.path.join(tmp, "results.json"))
    shutil.copy(os.path.join(DATA, "annotations.json"), os.path.join(tmp, "annotations.json"))
    shutil.copy(os.path.join(DATA, "answers.csv"), os.path.join(out, "answers.csv"))
    zp = os.path.join(out, "replication.zip")
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("README.txt", README)
        for n in ("interviews.jsonl", "judgements.jsonl", "answers.csv", "results.json", "annotations.json"):
            z.write(os.path.join(tmp, n), "data/" + n)
        for n in CODE:
            z.write(os.path.join(HERE, n), "code/" + n)
    shutil.rmtree(tmp, ignore_errors=True)
    print("interviews %d, judgements %d, redactions %d -> %s (%.1f MB)" % (len(recs), len(juds), REDACTION_COUNT["n"], zp, os.path.getsize(zp) / 1e6))


if __name__ == "__main__":
    main()
