"""Cover image for the post: a night-time school campus in the site's cover style (dark gradient, glowing marks,
no text). A columned private school with a clock tower in the centre, a gabled grammar school on the left and a
modern comprehensive block on the right, in the article's three colours, with lit windows and a starry sky.

Usage: .venv/Scripts/python -I code/figures/make_cover.py <out_dir>   (writes cover.svg; render with Chrome)
"""
import pathlib
import random
import sys

OUT = pathlib.Path(sys.argv[1])
W, H, GROUND = 2000, 1050, 850
BLUE, ORANGE, GREEN = "#7fb2ff", "#ff9f66", "#5fdcaa"
LIT, DIM = "#ffd27a", "#22314a"
rnd = random.Random(7)

p = [f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">
<defs>
  <linearGradient id="sky" x1="0" y1="0" x2="1" y2="0.6">
    <stop offset="0" stop-color="#3a1a26"/><stop offset="0.45" stop-color="#101a2b"/><stop offset="1" stop-color="#112a47"/>
  </linearGradient>
  <radialGradient id="horizon" cx="0.5" cy="0.86" r="0.55">
    <stop offset="0" stop-color="#ff9f66" stop-opacity="0.32"/><stop offset="0.5" stop-color="#ff9f66" stop-opacity="0.08"/>
    <stop offset="1" stop-color="#ff9f66" stop-opacity="0"/>
  </radialGradient>
  <linearGradient id="ground" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#0d1626"/><stop offset="1" stop-color="#070c16"/>
  </linearGradient>
  <filter id="glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="9"/></filter>
  <filter id="soft" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>
</defs>
<rect width="{W}" height="{H}" fill="url(#sky)"/>
<rect width="{W}" height="{H}" fill="url(#horizon)"/>''']

# stars
for _ in range(140):
    x, y, r = rnd.uniform(0, W), rnd.uniform(0, 520), rnd.choice((1, 1, 1.5, 2))
    p.append(f'<circle cx="{x:.0f}" cy="{y:.0f}" r="{r}" fill="#ffffff" opacity="{rnd.uniform(0.15, 0.6):.2f}"/>')
# moon
p.append('<circle cx="1640" cy="170" r="54" fill="#f4e7c8" opacity="0.9"/>'
         '<circle cx="1664" cy="152" r="50" fill="#13213a"/>'
         '<circle cx="1640" cy="170" r="90" fill="#f4e7c8" opacity="0.08" filter="url(#glow)"/>')


def window(x, y, w, h, lit, arch=False):
    col = LIT if lit else DIM
    shape = (f'<path d="M{x},{y + h} V{y + w / 2} A{w / 2},{w / 2} 0 0 1 {x + w},{y + w / 2} V{y + h} Z"'
             if arch else f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="2"')
    s = ""
    if lit:
        s += shape.replace("<path", '<path filter="url(#glow)" opacity="0.55"').replace(
            "<rect", '<rect filter="url(#glow)" opacity="0.55"') + f' fill="{LIT}"/>'
    return s + shape + f' fill="{col}"/>'


def body(x, y, w, h, stroke):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#142238" stroke="{stroke}" stroke-width="4"/>'


# ground and a faint perspective grid
p.append(f'<rect x="0" y="{GROUND}" width="{W}" height="{H - GROUND}" fill="url(#ground)"/>')
for i in range(-12, 13):
    x2 = W / 2 + i * 260
    p.append(f'<line x1="{W / 2 + i * 40}" y1="{GROUND}" x2="{x2}" y2="{H}" stroke="#ffffff" stroke-opacity="0.05" stroke-width="2"/>')
for k, y in enumerate((880, 920, 975, 1040)):
    p.append(f'<line x1="0" y1="{y}" x2="{W}" y2="{y}" stroke="#ffffff" stroke-opacity="{0.06 - k * 0.01:.2f}" stroke-width="2"/>')
p.append(f'<line x1="0" y1="{GROUND}" x2="{W}" y2="{GROUND}" stroke="#ffffff" stroke-opacity="0.18" stroke-width="3"/>')

# ---- grammar school (left): gabled hall with bell cupola
gx, gw, gh = 130, 400, 230
gy = GROUND - gh
p.append(body(gx, gy, gw, gh, ORANGE))
p.append(f'<path d="M{gx - 18},{gy} L{gx + gw / 2},{gy - 130} L{gx + gw + 18},{gy} Z" fill="#182a44" stroke="{ORANGE}" stroke-width="4" stroke-linejoin="round"/>')
cx = gx + gw / 2
p.append(f'<rect x="{cx - 22}" y="{gy - 200}" width="44" height="60" fill="#182a44" stroke="{ORANGE}" stroke-width="4"/>'
         f'<path d="M{cx - 32},{gy - 200} L{cx},{gy - 236} L{cx + 32},{gy - 200} Z" fill="#182a44" stroke="{ORANGE}" stroke-width="4"/>'
         f'<circle cx="{cx}" cy="{gy - 60}" r="26" fill="none" stroke="{ORANGE}" stroke-width="4"/>'
         f'<path d="M{cx},{gy - 60} V{gy - 78} M{cx},{gy - 60} H{cx + 14}" stroke="{ORANGE}" stroke-width="3"/>')
for row, y in enumerate((gy + 40, gy + 120)):
    for j in range(5):
        x = gx + 30 + j * 74
        if row == 1 and j == 2:
            continue
        p.append(window(x, y, 44, 58, rnd.random() < 0.55, arch=True))
p.append(f'<path d="M{cx - 30},{GROUND} V{GROUND - 80} A30,30 0 0 1 {cx + 30},{GROUND - 80} V{GROUND} Z" fill="{LIT}" opacity="0.85"/>')

# ---- comprehensive (right): modern flat-roofed block, long window bands
mx, mw, mh = 1430, 400, 250
my = GROUND - mh
p.append(body(mx, my, mw, mh, GREEN))
p.append(f'<rect x="{mx - 12}" y="{my - 16}" width="{mw + 24}" height="16" fill="#182a44" stroke="{GREEN}" stroke-width="4"/>')
for r_ in range(3):
    for j in range(8):
        x = mx + 22 + j * 47
        if r_ == 2 and mx + mw / 2 - 70 < x + 36 and x < mx + mw / 2 + 70:
            continue                      # keep the entrance canopy clear
        p.append(window(x, my + 28 + r_ * 66, 36, 40, rnd.random() < 0.5))
p.append(f'<rect x="{mx + mw / 2 - 40}" y="{GROUND - 70}" width="80" height="70" fill="{LIT}" opacity="0.8"/>'
         f'<rect x="{mx + mw / 2 - 60}" y="{GROUND - 84}" width="120" height="14" fill="#182a44" stroke="{GREEN}" stroke-width="3"/>')

# ---- private school (centre): wings, columned portico with pediment, clock tower with cupola and flag
px, pw, ph = 610, 780, 300
py = GROUND - ph
p.append(body(px, py, pw, ph, BLUE))
p.append(f'<rect x="{px - 14}" y="{py - 18}" width="{pw + 28}" height="18" fill="#182a44" stroke="{BLUE}" stroke-width="4"/>')
for side in (px + 26, px + pw - 26 - (3 * 52 + 34)):
    for r_ in range(2):
        for j in range(4):
            p.append(window(side + j * 52, py + 40 + r_ * 120, 34, 70, rnd.random() < 0.6, arch=True))
cx = px + pw / 2
tx, tw = cx - 55, 110
p.append(f'<rect x="{tx}" y="{py - 250}" width="{tw}" height="250" fill="#162640" stroke="{BLUE}" stroke-width="4"/>'
         f'<circle cx="{cx}" cy="{py - 180}" r="36" fill="#0f1a2c" stroke="{BLUE}" stroke-width="4"/>'
         f'<circle cx="{cx}" cy="{py - 180}" r="36" fill="{LIT}" opacity="0.18" filter="url(#glow)"/>'
         f'<path d="M{cx},{py - 180} V{py - 206} M{cx},{py - 180} L{cx + 19},{py - 170}" stroke="{LIT}" stroke-width="4" stroke-linecap="round"/>'
         f'<path d="M{tx - 10},{py - 250} H{tx + tw + 10} M{tx},{py - 250} Q{cx},{py - 330} {tx + tw},{py - 250}" fill="#162640" stroke="{BLUE}" stroke-width="4"/>'
         f'<path d="M{cx},{py - 312} V{py - 390}" stroke="{BLUE}" stroke-width="4"/>'
         f'<path d="M{cx},{py - 390} L{cx + 52},{py - 376} L{cx},{py - 362} Z" fill="{BLUE}" opacity="0.9"/>')
for j in range(2):
    p.append(window(tx + 20 + j * 46, py - 110, 24, 60, True, arch=True))
# portico
qx, qw = cx - 150, 300
p.append(f'<path d="M{qx - 16},{py + 40} L{cx},{py - 40} L{qx + qw + 16},{py + 40} Z" fill="#182a44" stroke="{BLUE}" stroke-width="4" stroke-linejoin="round"/>'
         f'<rect x="{qx - 10}" y="{py + 40}" width="{qw + 20}" height="14" fill="#182a44" stroke="{BLUE}" stroke-width="4"/>')
for j in range(6):
    x = qx + 10 + j * 54
    p.append(f'<rect x="{x}" y="{py + 54}" width="16" height="{ph - 74}" fill="#1b2d4a" stroke="{BLUE}" stroke-width="3"/>')
p.append(f'<rect x="{qx - 20}" y="{GROUND - 20}" width="{qw + 40}" height="20" fill="#182a44" stroke="{BLUE}" stroke-width="3"/>'
         f'<path d="M{cx - 34},{GROUND - 20} V{GROUND - 120} A34,34 0 0 1 {cx + 34},{GROUND - 120} V{GROUND - 20} Z" fill="{LIT}" opacity="0.9"/>'
         f'<path d="M{cx - 34},{GROUND - 20} V{GROUND - 120} A34,34 0 0 1 {cx + 34},{GROUND - 120} V{GROUND - 20} Z" fill="{LIT}" opacity="0.45" filter="url(#glow)"/>')

# trees between buildings
for tx_, s_ in ((572, 0.95), (1411, 0.85), (70, 0.8), (1890, 0.85)):
    p.append(f'<path d="M{tx_},{GROUND} V{GROUND - 60 * s_}" stroke="#2a3b55" stroke-width="6"/>'
             f'<ellipse cx="{tx_}" cy="{GROUND - 95 * s_}" rx="{38 * s_}" ry="{55 * s_}" fill="#17283f" stroke="#2f4566" stroke-width="3"/>')
# lit paths from the doors
for x0 in (130 + 200, 610 + 390, 1430 + 200):
    p.append(f'<path d="M{x0 - 30},{GROUND} L{x0 - 120},{H} L{x0 + 120},{H} L{x0 + 30},{GROUND} Z" fill="{LIT}" opacity="0.06"/>')
p.append("</svg>")
(OUT / "cover.svg").write_text("\n".join(p), encoding="utf-8")
print("wrote", OUT / "cover.svg")
