"""Cover image for the post, in the style of the site's other covers: abstract chart, dark gradient, glowing marks,
no text. Three school icons (private, grammar, comprehensive) each lead a track; a hollow ring marks the raw gap and
a glowing dot the gap after adjusting for intake, drawn back towards a dashed comprehensive reference line. The
positions are illustrative, scaled from the article's raw and adjusted figures (private 45% raw at the median vs
17% adjusted; grammar about zero adjusted).

Usage: .venv/Scripts/python -I code/figures/make_cover.py <out_dir>   (writes cover.svg, then render with Chrome)
"""
import pathlib
import sys

OUT = pathlib.Path(sys.argv[1])
W, H = 2000, 1050
REF_X = 840                      # comprehensive reference (dashed line)
PX = 1700 / 1.0                  # px per unit premium, illustrative

BLUE, ORANGE, GREEN = "#6aa8ff", "#ff9a5c", "#4fd6a0"
ICON_BLUE, ICON_ORANGE, ICON_GREEN = "#5b7fc4", "#c4794e", "#4f9c7e"


def school(x, y, color, kind):
    """Outline school building centred on (x, y)."""
    s = f'<g fill="none" stroke="{color}" stroke-width="5" stroke-linejoin="round" stroke-linecap="round">'
    if kind == "private":        # pediment and columns
        s += f'<path d="M{x-62},{y-18} L{x},{y-58} L{x+62},{y-18} Z"/>'
        s += f'<path d="M{x-58},{y-18} H{x+58} M{x-62},{y+52} H{x+62}"/>'
        for dx in (-40, -13, 13, 40):
            s += f'<path d="M{x+dx},{y-10} V{y+44}"/>'
    elif kind == "grammar":      # gable, clock, windows
        s += f'<path d="M{x-60},{y+52} V{y-14} L{x},{y-56} L{x+60},{y-14} V{y+52} Z"/>'
        s += f'<circle cx="{x}" cy="{y-20}" r="11"/>'
        for dx in (-34, 34):
            s += f'<rect x="{x+dx-10}" y="{y+2}" width="20" height="22" rx="3"/>'
        s += f'<path d="M{x-12},{y+52} V{y+22} H{x+12} V{y+52}"/>'
    else:                        # flat-roofed block with window grid
        s += f'<rect x="{x-66}" y="{y-40}" width="132" height="92" rx="6"/>'
        for row in (-22, 6):
            for dx in (-42, -14, 14, 42):
                s += f'<rect x="{x+dx-8}" y="{y+row}" width="16" height="14" rx="2"/>'
        s += f'<path d="M{x-12},{y+52} V{y+32} H{x+12} V{y+52}"/>'
    return s + "</g>"


def glow_dot(x, y, color):
    return (f'<circle cx="{x}" cy="{y}" r="34" fill="{color}" opacity="0.35" filter="url(#glow)"/>'
            f'<circle cx="{x}" cy="{y}" r="21" fill="{color}"/>'
            f'<circle cx="{x}" cy="{y}" r="8" fill="#eaf2ff"/>')


def ring(x, y, color):
    return f'<circle cx="{x}" cy="{y}" r="20" fill="#0d1a2c" stroke="{color}" stroke-width="5" opacity="0.85"/>'


parts = [f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">
<defs>
  <linearGradient id="bg" x1="0" y1="0" x2="1" y2="0.55">
    <stop offset="0" stop-color="#4a1f2a"/><stop offset="0.38" stop-color="#121c2d"/>
    <stop offset="1" stop-color="#13304f"/>
  </linearGradient>
  <radialGradient id="vig" cx="0.55" cy="0.45" r="0.8">
    <stop offset="0.6" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.35"/>
  </radialGradient>
  <filter id="glow" x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation="14"/></filter>
  <filter id="soft" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5"/></filter>
</defs>
<rect width="{W}" height="{H}" fill="url(#bg)"/>
<rect width="{W}" height="{H}" fill="url(#vig)"/>''']

for gx in (380, 610, 1070, 1300, 1530, 1760):
    parts.append(f'<line x1="{gx}" y1="90" x2="{gx}" y2="980" stroke="#ffffff" stroke-opacity="0.07" stroke-width="2"/>')
parts.append(f'<line x1="{REF_X}" y1="90" x2="{REF_X}" y2="980" stroke="#c8d0dc" stroke-opacity="0.55" '
             f'stroke-width="3" stroke-dasharray="12 12"/>')

rows = [  # (y, icon colour, mark colour, kind, raw premium, adjusted premium, band half-width)
    (270, ICON_BLUE, BLUE, "private", 0.45, 0.17, 0.08),
    (525, ICON_ORANGE, ORANGE, "grammar", 0.38, 0.02, 0.07),
    (780, ICON_GREEN, GREEN, "comprehensive", 0.0, 0.0, 0.0),
]
for y, icol, col, kind, raw, adj, hw in rows:
    parts.append(f'<line x1="300" y1="{y}" x2="1930" y2="{y}" stroke="#ffffff" stroke-opacity="0.09" stroke-width="3"/>')
    parts.append(school(190, y, icol, kind))
    xr, xa = REF_X + raw * PX, REF_X + adj * PX
    if hw:
        parts.append(f'<rect x="{xa - hw * PX}" y="{y - 11}" width="{2 * hw * PX}" height="22" rx="11" '
                     f'fill="{col}" opacity="0.22"/>')
    if raw > adj:
        parts.append(f'<line x1="{xa + 30}" y1="{y}" x2="{xr - 24}" y2="{y}" stroke="{col}" stroke-opacity="0.45" '
                     f'stroke-width="3" stroke-dasharray="2 12" stroke-linecap="round"/>')
        parts.append(ring(xr, y, col))
    parts.append(glow_dot(xa, y, col))
parts.append("</svg>")
(OUT / "cover.svg").write_text("\n".join(parts), encoding="utf-8")
print("wrote", OUT / "cover.svg")
