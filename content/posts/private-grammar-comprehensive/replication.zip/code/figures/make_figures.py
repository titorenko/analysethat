"""Figures for the write-up (P7): hand-built SVGs in the site's house style (system-ui, surface #fcfcfb, light and
dark via prefers-color-scheme). Every number is read from results/ or data/derived/.

Usage: .venv/Scripts/python -I code/figures/make_figures.py <out_dir>
Palette (validated with the dataviz validator, light and dark): independent #2a78d6 / #3987e5, grammar #eb6834 /
#d95926, comprehensive #1baf7a / #199e70 (contrast < 3:1 on light, so every series is direct-labelled).
"""
import math
import pathlib
import sys

import numpy as np
import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
RES, DER = ROOT / "results", ROOT / "data" / "derived"
OUT = pathlib.Path(sys.argv[1])
OUT.mkdir(parents=True, exist_ok=True)

CSS = """<style>
  .surface { fill: #fcfcfb; stroke: rgba(11,11,11,.10); }
  .t1 { fill: #0b0b0b; } .t2 { fill: #52514e; } .t3 { fill: #6b6a65; }
  .grid { stroke: #e1e0d9; stroke-width: 1; } .axis { stroke: #c3c2b7; stroke-width: 1; }
  .ind { fill: #2a78d6; stroke: #2a78d6; } .ind-l { stroke: #2a78d6; fill: none; } .ind-band { fill: #2a78d6; opacity: .18; }
  .gra { fill: #eb6834; stroke: #eb6834; } .gra-l { stroke: #eb6834; fill: none; }
  .com { fill: #1baf7a; stroke: #1baf7a; } .com-l { stroke: #1baf7a; fill: none; }
  .neu { fill: #898781; stroke: #898781; } .neu-l { stroke: #898781; fill: none; } .neu-band { fill: #898781; opacity: .14; }
  .hollow { fill: #fcfcfb; stroke-width: 2; }
  .ink { stroke: #0b0b0b; fill: none; }
  .dash { stroke-dasharray: 5 4; }
  .halo { paint-order: stroke; stroke: #fcfcfb; stroke-width: 4px; stroke-linejoin: round; }
  text { font-family: system-ui, -apple-system, 'Segoe UI', sans-serif; }
  @media (prefers-color-scheme: dark) {
    .surface { fill: #1a1a19; stroke: rgba(255,255,255,.10); }
    .t1 { fill: #ffffff; } .t2 { fill: #c3c2b7; } .t3 { fill: #a9a8a1; }
    .grid { stroke: #2c2c2a; } .axis { stroke: #383835; }
    .ind { fill: #3987e5; stroke: #3987e5; } .ind-l { stroke: #3987e5; } .ind-band { fill: #3987e5; }
    .gra { fill: #d95926; stroke: #d95926; } .gra-l { stroke: #d95926; }
    .com { fill: #199e70; stroke: #199e70; } .com-l { stroke: #199e70; }
    .hollow { fill: #1a1a19; }
    .ink { stroke: #ffffff; }
    .halo { stroke: #1a1a19; }
  }
</style>"""


class Svg:
    def __init__(self, w, h, title, desc):
        self.w, self.h, self.parts = w, h, []
        self.head = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" '
                     f'role="img" aria-labelledby="t d">\n<title id="t">{esc(title)}</title><desc id="d">{esc(desc)}'
                     f'</desc>\n{CSS}\n<rect class="surface" x="0.5" y="0.5" width="{w - 1}" height="{h - 1}" rx="8"/>')

    def add(self, s):
        self.parts.append(s)

    def text(self, x, y, s, cls="t2", size=12, anchor="start", weight=None, halo=False):
        w = f' font-weight="{weight}"' if weight else ""
        c = cls + (" halo" if halo else "")
        self.add(f'<text class="{c}" x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}"{w}>{esc(s)}</text>')

    def line(self, x1, y1, x2, y2, cls, width=1, extra=""):
        self.add(f'<line class="{cls}" x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke-width="{width}"{extra}/>')

    def path(self, pts, cls, width=2, close=False):
        d = "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in pts) + (" Z" if close else "")
        self.add(f'<path class="{cls}" d="{d}" stroke-width="{width}" stroke-linejoin="round" stroke-linecap="round"/>')

    def circle(self, x, y, r, cls, width=None):
        sw = f' stroke-width="{width}"' if width else ""
        self.add(f'<circle class="{cls}" cx="{x:.1f}" cy="{y:.1f}" r="{r}"{sw}/>')

    def rect(self, x, y, w, h, cls, rx=0):
        self.add(f'<rect class="{cls}" x="{x:.1f}" y="{y:.1f}" width="{max(w, 0):.1f}" height="{max(h, 0):.1f}" rx="{rx}"/>')

    def save(self, name):
        (OUT / name).write_text(self.head + "\n" + "\n".join(self.parts) + "\n</svg>\n", encoding="utf-8")
        print("wrote", OUT / name)


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def scale(d0, d1, r0, r1):
    return lambda v: r0 + (v - d0) / (d1 - d0) * (r1 - r0)


def yaxis(svg, ys, ticks, x0, x1, fmt):
    for t in ticks:
        svg.line(x0, ys(t), x1, ys(t), "grid")
        svg.text(x0 - 8, ys(t) + 4, fmt(t), "t3", 11, "end")


# ---------------------------------------------------------------- F1 Cambridge per 1,000 A-level students
def fig_cambridge():
    e = pd.read_csv(RES / "p2_cambridge_per_student_england.csv")
    p = e.pivot_table(index="cycle", columns="sector",
                      values=["per_1000_england", "per_1000_england_home_only"])
    cyc = list(p.index)
    W, H, L, R, T, B = 820, 458, 64, 210, 74, 48
    last = cyc[-1]
    assert p.loc[last, ("per_1000_england", "selective_state")] > p.loc[last, ("per_1000_england", "independent")]
    s = Svg(W, H, "For every A-level student, grammar sixth forms now send more to Cambridge than private ones",
            "Cambridge acceptances per 1,000 A-level students by sixth-form sector, 2013-2023 cycles, English schools "
            "only. Independent shown as a band from Home-fee-only to all fee statuses. Grammar overtakes independent "
            f"between 2020 and 2022; in 2023 grammar {p.loc[2023, ('per_1000_england', 'selective_state')]:.1f}, "
            f"independent {p.loc[2023, ('per_1000_england_home_only', 'independent')]:.1f}-"
            f"{p.loc[2023, ('per_1000_england', 'independent')]:.1f}, other state "
            f"{p.loc[2023, ('per_1000_england', 'other_state')]:.1f}.")
    xs = scale(cyc[0], cyc[-1], L, W - R)
    ys = scale(0, 40, H - B, T)
    s.text(24, 30, "For every A-level student, grammar sixth forms now send more to Cambridge than private ones", "t1",
           15, weight=600)
    s.text(24, 50, "Cambridge acceptances per 1,000 A-level students, English schools", "t3", 11)
    yaxis(s, ys, range(0, 41, 10), L, W - R, lambda t: f"{t}")
    for c in cyc[::2]:
        s.text(xs(c), H - B + 20, str(c), "t3", 11, "middle")
    s.line(L, H - B, W - R, H - B, "axis")
    lo = [(xs(c), ys(p.loc[c, ("per_1000_england_home_only", "independent")])) for c in cyc]
    hi = [(xs(c), ys(p.loc[c, ("per_1000_england", "independent")])) for c in cyc]
    s.path(hi + lo[::-1], "ind-band", 0, close=True)
    s.path(hi, "ind-l", 2)
    s.path(lo, "ind-l dash", 1.5)
    for key, cls in (("selective_state", "gra-l"), ("other_state", "com-l")):
        s.path([(xs(c), ys(p.loc[c, ("per_1000_england", key)])) for c in cyc], cls, 2.5)
    gy = ys(p.loc[last, ("per_1000_england", "selective_state")])
    iy = max(ys(p.loc[last, ("per_1000_england", "independent")]), gy + 34)
    s.text(W - R + 10, gy - 4, f"Grammar {p.loc[last, ('per_1000_england', 'selective_state')]:.1f}", "t1", 12,
           weight=600)
    s.text(W - R + 10, gy + 10, "(lower bound)", "t3", 11)
    s.text(W - R + 10, iy + 6, f"Independent {p.loc[last, ('per_1000_england_home_only', 'independent')]:.1f}-"
           f"{p.loc[last, ('per_1000_england', 'independent')]:.1f}", "t1", 12, weight=600)
    s.text(W - R + 10, iy + 20, "(Home fee only to all)", "t3", 11)
    s.text(W - R + 10, ys(p.loc[last, ("per_1000_england", "other_state")]) + 4,
           f"Other state {p.loc[last, ('per_1000_england', 'other_state')]:.1f}", "t1", 12, weight=600)
    s.save("fig-cambridge.svg")


# ---------------------------------------------------------------- F2 ONS earnings ratio by percentile
def fig_ons():
    o = pd.read_csv(RES / "p2_ons_percentiles.csv").set_index("percentile")
    kb = pd.read_csv(RES / "p4_ons_ks4_bands.csv").set_index("ks4_quintile")
    W, H, L, R, T, B = 820, 438, 64, 150, 74, 52
    q = [p for p in o.index if p >= 5]
    r = o.ratio_independent_to_nonfsm[q]
    assert (r > 1).all() and r.idxmax() == max(q)
    s = Svg(W, H, "At 30, private pupils out-earn state pupils at every level, and most at the top",
            "Ratio of independent-school pupils' PAYE earnings at age 30 to state non-FSM pupils', at each "
            f"percentile: {o.ratio_independent_to_nonfsm[10]:.2f} at P10, {o.ratio_independent_to_nonfsm[50]:.2f} at "
            f"P50, {o.ratio_independent_to_nonfsm[90]:.2f} at P90, {o.ratio_independent_to_nonfsm[99]:.2f} at P99 "
            "(raw). Within the same GCSE attainment quintile the mean ratio is "
            f"{kb.ratio_independent_to_non_fsm.min():.2f}-{kb.ratio_independent_to_non_fsm.max():.2f}.")
    xs = scale(5, 99, L, W - R)
    ys = scale(1.0, 2.2, H - B, T)
    s.text(24, 30, "At 30, private pupils out-earn state pupils at every level, and most at the top", "t1", 15,
           weight=600)
    s.text(24, 50, "Earnings of private pupils relative to state pupils not on free school meals, by percentile", "t3",
           11)
    yaxis(s, ys, [1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.2], L, W - R, lambda t: f"{t:.1f}×")
    for t in (10, 25, 50, 75, 90, 99):
        s.text(xs(t), H - B + 20, f"P{t}", "t3", 11, "middle")
    s.text((L + W - R) / 2, H - 10, "percentile of each group's earnings distribution (ONS, LEO PAYE, age 30)", "t3", 11,
           "middle")
    s.line(L, H - B, W - R, H - B, "axis")
    s.path([(xs(p), ys(o.ratio_independent_to_nonfsm[p])) for p in q], "ind-l", 2.5)
    for p in (10, 50, 90, 99):
        v = o.ratio_independent_to_nonfsm[p]
        s.circle(xs(p), ys(v), 4.5, "ind")
        s.text(xs(p), ys(v) - 10, f"{v:.2f}×", "t1", 12, "middle", 600, halo=True)
    # within-KS4-quintile means (ADJ-MED) as a grey band
    lo, hi = kb.ratio_independent_to_non_fsm.min(), kb.ratio_independent_to_non_fsm.max()
    s.rect(L, ys(hi), W - R - L, ys(lo) - ys(hi), "neu-band")
    s.text(W - R + 10, ys((lo + hi) / 2) - 4, "Same GCSE band,", "t2", 11)
    s.text(W - R + 10, ys((lo + hi) / 2) + 10, f"means: {lo:.2f}-{hi:.2f}×", "t2", 11)
    s.text(W - R + 10, ys(o.ratio_independent_to_nonfsm[95]), "Raw, by", "t1", 12, weight=600)
    s.text(W - R + 10, ys(o.ratio_independent_to_nonfsm[95]) + 14, "percentile", "t1", 12, weight=600)
    s.save("fig-ons-ratio.svg")


# ---------------------------------------------------------------- F3 VA distributions by sector
SECTORS = [("independent", "Independent", "ind"), ("selective", "Grammar", "gra"),
           ("partially_selective", "Partially selective", "neu"),
           ("non_selective_other", "Comprehensive", "com"),
           ("non_selective_highly_selective_area", "Non-selective, grammar areas", "neu")]


def fig_va():
    u = pd.read_csv(RES / "p3_universe.csv")
    W, H, L, R, T = 820, 360, 210, 40, 70
    rowh = 52
    med = {k: u[u.sector == k].value_added.median() for k, _, _ in SECTORS}
    assert max(med, key=med.get) == "independent"
    s = Svg(W, H, "Private sixth-formers beat their GCSE prediction by the most",
            "School-level A-level value added (grades per entry), 2024/25, by sector: line P10-P90, bar P25-P75, "
            "tick median. " + "; ".join(
                f"{lab} median {u[u.sector == k].value_added.median():+.2f}" for k, lab, _ in SECTORS) + ".")
    xs = scale(-0.8, 0.8, L, W - R)
    s.text(24, 30, "Private sixth-formers beat their GCSE prediction by the most", "t1", 15, weight=600)
    s.text(24, 50, "A-level value added by school, grades per entry, 2024/25 · line: P10-P90 of schools · bar: P25-P75 · "
                   "tick: median", "t3", 11)
    for t in np.arange(-0.8, 0.81, 0.2):
        s.line(xs(t), T - 6, xs(t), T + rowh * len(SECTORS), "grid")
        s.text(xs(t), T + rowh * len(SECTORS) + 18, f"{t:+.1f}" if abs(t) > 1e-9 else "0", "t3", 11, "middle")
    s.line(xs(0), T - 6, xs(0), T + rowh * len(SECTORS), "axis", 1.5)
    for i, (k, lab, cls) in enumerate(SECTORS):
        v = u[u.sector == k].value_added.dropna()
        y = T + rowh * i + rowh / 2
        p10, p25, p50, p75, p90 = (v.quantile(x) for x in (0.1, 0.25, 0.5, 0.75, 0.9))
        s.line(xs(p10), y, xs(p90), y, f"{cls}-l", 2)
        s.rect(xs(p25), y - 9, xs(p75) - xs(p25), 18, cls, 4)
        s.line(xs(p50), y - 13, xs(p50), y + 13, "ink", 3)
        s.text(L - 12, y - 2, lab, "t1", 12, "end", 600)
        s.text(L - 12, y + 13, f"{len(v)} schools, median {p50:+.2f}", "t3", 11, "end")
    s.save("fig-va-sectors.svg")


def top20_union():
    """Top 20 private schools open to boys plus top 20 open to girls, each school once."""
    return pd.concat([pd.read_csv(RES / "p3_top20_boys.csv"), pd.read_csv(RES / "p3_top20_girls.csv")]).drop_duplicates("urn")


# ---------------------------------------------------------------- F2b value added by tenth of results
def fig_alpha_deciles():
    t = pd.read_csv(RES / "p3_alpha_by_results_decile.csv")
    W, H, L, R, T, B = 820, 440, 70, 170, 64, 56
    series = [("independent", "Private", "ind"), ("selective", "Grammar", "gra"), ("non_selective_other", "Comprehensive", "com")]
    assert (t[(t.sector == "independent") & (t.decile <= 9)].va_mean > 0).all()
    s = Svg(W, H, "Private sixth-formers beat their GCSE prediction at almost every level of results",
            "Average A-level value added of each tenth of schools sorted by A-level points, best first: " + "; ".join(
                f"{lab} " + ", ".join(f"{v:+.2f}" for v in t[t.sector == k].sort_values("decile").va_mean)
                for k, lab, _ in series) + ".")
    xs = scale(1, 10, L, W - R)
    ys = scale(-0.4, 0.4, H - B, T)
    s.text(24, 30, "Private sixth-formers beat their GCSE prediction at almost every level of results", "t1", 15,
           weight=600)
    s.text(24, 48, "A-level value added (grades per A level above the GCSE prediction, 2024/25), average of each tenth of "
                   "schools sorted by A-level results", "t3", 11)
    yaxis(s, ys, [-0.4, -0.2, 0, 0.2, 0.4], L, W - R, lambda v: f"{v:+.1f}" if v else "0")
    s.line(L, ys(0), W - R, ys(0), "axis", 1.5)
    for d in range(1, 11):
        s.text(xs(d), H - B + 20, {1: "1 best", 10: "10 weakest"}.get(d, str(d)), "t3", 11, "middle")
    s.text((L + W - R) / 2, H - 12, "tenth of schools by A-level points per entry", "t3", 11, "middle")
    ends = []
    for k, lab, cls in series:
        x = t[t.sector == k].sort_values("decile")
        pts = [(xs(d), ys(v)) for d, v in zip(x.decile, x.va_mean)]
        s.path(pts, f"{cls}-l", 2.5)
        for px_, py_ in pts:
            s.circle(px_, py_, 4.5, cls)
        ends.append([pts[-1][1], lab])
    ends.sort()
    for i in range(1, len(ends)):
        ends[i][0] = max(ends[i][0], ends[i - 1][0] + 18)
    for y, lab in ends:
        s.text(W - R + 12, y + 4, lab, "t1", 12, weight=600)
    s.save("fig-alpha-deciles.svg")


# ---------------------------------------------------------------- F4 fee vs VA, top private schools
def fig_fee_va():
    p = top20_union().dropna(subset=["fee_senior_day_2627"])
    rho = p[["fee_senior_day_2627", "value_added"]].corr(method="spearman").iloc[0, 1]
    W, H, L, R, T, B = 820, 488, 70, 30, 78, 52
    assert abs(rho) < 0.3
    s = Svg(W, H, "No sign that higher fees go with more value added",
            f"Scatter of 2026/27 senior day fee (incl. VAT) against 2024/25 A-level value added with 95% CI, for "
            f"the {len(p)} top private schools for boys or girls with a day fee. Rank correlation {rho:.2f}.")
    xs = scale(18, 52, L, W - R)
    ys = scale(-0.4, 0.8, H - B, T)
    s.text(L - 46, 30, "No sign that higher fees go with more value added", "t1", 15, weight=600)
    s.text(L - 46, 48, f"Senior day fee and A-level value added, top private schools for boys and girls (rank "
                       f"correlation {rho:.2f})", "t3", 11)
    yaxis(s, ys, [-0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8], L, W - R, lambda t: f"{t:+.1f}" if t else "0")
    for t in range(20, 53, 5):
        s.text(xs(t), H - B + 20, f"£{t}k", "t3", 11, "middle")
    s.text((L + W - R) / 2, H - 10, "senior day fee 2026/27, incl. VAT", "t3", 11, "middle")
    s.text(L - 46, 66, "value added (grades per A-level entry), 95% CI", "t3", 11)
    s.line(L, ys(0), W - R, ys(0), "axis", 1.5)
    label = {"Westminster School", "St Paul's School", "Withington Girls' School", "Wycombe Abbey",
             "The Perse School", "Latymer Upper School and Latymer Prep", "Tonbridge School",
             "King Edward VI High School for Girls", "Brighton College"}
    for r in p.itertuples():
        x, y = xs(r.fee_senior_day_2627 / 1000), ys(r.value_added)
        s.line(x, ys(r.value_added_lower_ci), x, ys(r.value_added_upper_ci), "ind-l", 1, ' opacity="0.45"')
        s.circle(x, y, 5, "ind hollow" if r.va_low_coverage else "ind", 2 if r.va_low_coverage else None)
        if r.name in label:
            nm = (r.name.replace("King Edward VI High School for Girls", "KEHS Birmingham")
                  .replace(" and Latymer Prep", "").replace(" School", ""))
            right = x > W - R - 120
            s.text(x - 8 if right else x + 8, y - 6, nm, "t2", 11, "end" if right else "start", halo=True)
    s.text(W - R - 4, H - B - 8, "hollow: value-added coverage below 70%", "t3", 11, "end")
    s.save("fig-fee-va.svg")


# ---------------------------------------------------------------- F5 overlay: comprehensives vs top 30
def fig_overlay():
    u = pd.read_csv(RES / "p3_universe.csv")
    ti = top20_union()
    tg = pd.read_csv(RES / "p3_top30_grammar.csv")
    comp = u[u.sector == "non_selective_other"]
    W, H = 820, 498
    s = Svg(W, H, "Top schools beat nearly every comprehensive on results; on value added the lead shrinks",
            f"Histograms of {comp.aps_pooled.notna().sum()} comprehensive sixth forms on A-level points per entry and "
            "on value added, with the top private (boys' and girls' lists) and top-30 grammar schools as ticks. On points every top school "
            "is above the comprehensive maximum region; on value added the top private median is at the "
            f"comprehensive {ti.value_added_comp_pctile.median():.0f}th percentile and the grammar median at the "
            f"{tg.value_added_comp_pctile.median():.0f}th.")
    top = pd.concat([ti, tg])
    assert (top.aps_pooled > comp.aps_pooled.quantile(0.95)).mean() >= 0.9
    assert ti.value_added_comp_pctile.median() < 95 and tg.value_added_comp_pctile.median() < 95
    s.text(24, 30, "Top schools beat nearly every comprehensive on results; on value added the lead shrinks", "t1", 15,
           weight=600)
    s.text(24, 50, f"Grey bars: comprehensive sixth forms ({comp.aps_pooled.notna().sum():,} on A-level points, "
                   f"{comp.value_added.notna().sum():,} on value added)", "t3", 11)
    s.text(24, 66, "Ticks: top private schools, boys' and girls' lists (upper row); top-30 grammar schools (lower row)",
           "t3", 11)
    panels = [("aps_pooled", "A-level points per entry (pooled 2023/24-2024/25)", 20, 58, 2, lambda t: f"{t:.0f}",
               range(20, 58, 5)),
              ("value_added", "Value added 2024/25 (grades per entry)", -1.0, 1.0, 0.1,
               lambda t: f"{t:+.1f}" if abs(t) > 1e-9 else "0", np.arange(-1.0, 1.01, 0.5))]
    L, R = 40, 40
    for i, (col, lab, a, b, bw, fmt, ticks) in enumerate(panels):
        top = 92 + i * 200
        xs = scale(a, b, L, W - R)
        s.text(L, top, lab, "t2", 12, weight=600)
        v = comp[col].dropna()
        bins = np.arange(a, b + bw, bw)
        h, _ = np.histogram(v.clip(a, b - 1e-9), bins)
        hy = scale(0, h.max(), top + 110, top + 20)
        for k, n in enumerate(h):
            s.rect(xs(bins[k]) + 1, hy(n), xs(bins[k + 1]) - xs(bins[k]) - 2, top + 110 - hy(n), "neu", 2)
        s.line(L, top + 110, W - R, top + 110, "axis")
        for r in ti[col].dropna():
            s.line(xs(r), top + 116, xs(r), top + 132, "ind-l", 2)
        for r in tg[col].dropna():
            s.line(xs(r), top + 136, xs(r), top + 152, "gra-l", 2)
        for t in ticks:
            s.text(xs(t), top + 168, fmt(t), "t3", 11, "middle")
    s.save("fig-overlay.svg")


# ---------------------------------------------------------------- F6 evidence forest
def fig_evidence():
    ev = pd.read_csv(DER / "evidence_table.csv").set_index("row_id")
    rows = [("Private", "NCDS 1958, age 33, all", "GMMZ2012-01", "GMMZ2012-19"),
            ("Private", "BCS70, age 34, men", "GMMZ2012-08", "GMMZ2012-22"),
            ("Private", "BCS70, age 34, women", "GMMZ2012-14", "GMMZ2012-24"),
            ("Private", "BCS70, age 42, men", "GHV2017-02", "GHV2017-04"),
            ("Private", "BCS70, age 42, women", "GHV2017-11", "GHV2017-13"),
            ("Private", "Next Steps 1989-90, age 25 (background only)", "GAHH2020-01", "GAHH2020-02"),
            ("Private", "NCDS 1958, age 33, men, vs comprehensive", None, "DFM2002-08"),
            ("Private", "Graduates 2006/07, 3.5 yrs, men †", "CV2014-17", "CV2014-19"),
            ("Private", "Graduates 2006/07, 3.5 yrs, women †", "CV2014-21", "CV2014-23"),
            ("Grammar", "NCDS 1958, age 33, men", None, "DFM2002-04"),
            ("Grammar", "NCDS 1958, age 33, all (RD)", None, "PJ2023-03"),
            ("Grammar", "Aberdeen 1950s, late 40s, men (RD)", "CDB2016-09", "CDB2016-11"),
            ("Grammar", "Aberdeen 1950s, late 40s, women (RD)", "CDB2016-13", "CDB2016-15")]
    W, rowh, T, L, R = 820, 30, 92, 300, 40
    assert all(ev.loc[a].estimate < ev.loc[r].estimate for k, _, r, a in rows if k == "Private" and r)
    H = T + rowh * len(rows) + 70
    xs = scale(-0.3, 0.9, L, W - R)
    pct = lambda lp: math.exp(lp) - 1
    s = Svg(W, H, "Compare like with like and the private-school pay advantage shrinks",
            "Forest plot of log-point pay premiums converted to percent, raw (hollow) and adjusted for background and "
            "early ability (filled, with 95% CI where a standard error is published), by cohort and age. "
            + "; ".join(f"{lab}: adjusted {100 * pct(ev.loc[a].estimate):.1f}%" for _, lab, _, a in rows) + ".")
    s.text(24, 30, "Compare like with like and the private-school pay advantage shrinks", "t1", 15, weight=600)
    s.text(24, 50, "Pay advantage by study: raw (hollow) and allowing for background and early test scores (filled)",
           "t3", 11)
    s.text(24, 66, "hourly pay unless noted; Next Steps weekly pay, background only; † graduates only, also A levels, "
                   "degree, university", "t3", 11)
    for t in (-0.2, 0, 0.2, 0.4, 0.6, 0.8):
        s.line(xs(t), T - 8, xs(t), T + rowh * len(rows), "grid")
        s.text(xs(t), T + rowh * len(rows) + 18, f"{100 * t:+.0f}%" if t else "0", "t3", 11, "middle")
    s.line(xs(0), T - 8, xs(0), T + rowh * len(rows), "axis", 1.5)
    for i, (grp, lab, raw, adj) in enumerate(rows):
        y = T + rowh * i + rowh / 2
        cls = "ind" if grp == "Private" else "gra"
        r = ev.loc[adj]
        if not pd.isna(r.se):
            s.line(xs(pct(r.estimate - 1.96 * r.se)), y, xs(pct(r.estimate + 1.96 * r.se)), y, f"{cls}-l", 2)
        if raw:
            s.circle(xs(pct(ev.loc[raw].estimate)), y, 5, f"{cls} hollow", 2)
        s.circle(xs(pct(r.estimate)), y, 5.5, cls)
        s.text(L - 10, y + 4, lab, "t1", 12, "end")
        s.text(xs(pct(r.estimate)), y - 9, f"{100 * pct(r.estimate):.0f}%", "t2", 11, "middle", halo=True)
    s.text(18, T + rowh * 9 + 2, "Grammar", "t2", 11, weight=600)
    s.text(18, T - 2, "Private", "t2", 11, weight=600)
    s.save("fig-evidence.svg")


# ---------------------------------------------------------------- F7 break-even vs premium scenarios
def fig_breakeven():
    be = pd.read_csv(RES / "p5_breakeven.csv")
    be = be[(be.scenario == "B") & (be.route == "11-18") & (be.fee_type == "day_at_day_schools")]
    pr = pd.read_csv(RES / "p4_premiums.csv")
    pr = pr[(pr.school_type == "private") & (pr.route == "11-18")]
    npv = pd.read_csv(RES / "p6_npv.csv")
    typ = npv[(npv.percentile_label == "typical") & (npv.premium_scenario == "central") & (npv.route == "11-18")
              & (npv.school_type == "private")].groupby("sex").percentile.first()
    W, H, YMAX = 820, 500, 1.0
    cen = pr[(pr.scenario == "central") & (pr.sex == "men")].premium_pct.iloc[0]
    b35 = be[be.rate == "3.5% stepped"].set_index(["sex", "percentile"]).breakeven_premium
    assert all(b35[(sx, 50)] > cen > b35[(sx, 99)] for sx in ("men", "women"))
    s = Svg(W, H, "On the central estimate, only top earners would earn back the fees",
            "Break-even gross pay premium for 11-18 private day fees by the child's counterfactual earnings percentile "
            "(all employees, weighted by employment), at 3.5% (solid) and 2.1% (dashed) real discount rates, for men "
            "and women, with the low, central and high premium scenarios for today's pupils and the typical private "
            f"pupil's counterfactual rank (about P{typ.mean():.0f}). " + "; ".join(
                f"{sx} at 3.5%: P50 {100 * float(be[(be.sex == sx) & (be.rate == '3.5% stepped') & (be.percentile == 50)].breakeven_premium.iloc[0]):.0f}%, "
                f"P90 {100 * float(be[(be.sex == sx) & (be.rate == '3.5% stepped') & (be.percentile == 90)].breakeven_premium.iloc[0]):.0f}%"
                for sx in ("men", "women")) + ".")
    s.text(24, 30, "On the central estimate, only top earners would earn back the fees", "t1", 15, weight=600)
    s.text(24, 50, "Lifetime pay rise needed to repay 11-18 day fees (black: solid 3.5%, dashed 2.1% discount rate) "
                   "against the scenarios for today's pupils (blue)", "t3", 11)
    for j, sex in enumerate(("men", "women")):
        L, R, T, B = 70 + j * 380, 70 + j * 380 + 320, 84, H - 64
        xs = scale(10, 99, L, R)
        ys = scale(0, YMAX, B, T)
        s.text(L, T - 10, sex.capitalize(), "t1", 13, weight=600)
        for t in np.arange(0, YMAX + 1e-9, 0.2):
            s.line(L, ys(t), R, ys(t), "grid")
            s.text(L - 6, ys(t) + 4, f"{100 * t:.0f}%", "t3", 11, "end")
        for t in (10, 25, 50, 75, 90, 99):
            s.text(xs(t), B + 18, f"P{t}", "t3", 11, "middle")
        s.text((L + R) / 2, B + 38, "child's earnings rank had they gone to a state school", "t3", 10.5, "middle")
        sp = pr[pr.sex == sex]
        band = {k: (math.exp(g.premium_lp.min()) - 1, math.exp(g.premium_lp.max()) - 1) for k, g in sp.groupby("scenario")}
        s.rect(L, ys(band["high"][1]), R - L, ys(band["high"][0]) - ys(band["high"][1]), "ind-band")
        s.line(L, ys(band["central"][0]), R, ys(band["central"][0]), "ind-l", 2)
        s.line(L, ys(band["low"][0]), R, ys(band["low"][0]), "ind-l dash", 1.5)
        for rate, cls, wdt in (("3.5% stepped", "ink", 2.5), ("2.1% borrowing", "ink dash", 1.8)):
            x = be[(be.sex == sex) & (be.rate == rate)].sort_values("percentile")
            s.path([(xs(q), ys(min(v, YMAX))) for q, v in zip(x.percentile, x.breakeven_premium)], cls, wdt)
        xq = xs(typ[sex])
        s.line(xq, T, xq, B, "axis dash", 1.5)
        s.text(xq + 4, T + 12, f"typical private pupil ≈ P{typ[sex]:.0f}", "t3", 11, halo=True)
        lx = xs(52)
        s.text(lx, ys(band["high"][1]) - 5, f"high (1970 cohort) {100 * band['high'][0]:.0f}-{100 * band['high'][1]:.0f}%",
               "t2", 11, halo=True)
        s.text(lx, ys(band["central"][0]) + 15, f"central {100 * band['central'][0]:.0f}%", "t2", 11, halo=True)
        s.text(lx, ys(band["low"][0]) + 15, f"low {100 * band['low'][0]:.1f}%", "t2", 11, halo=True)
        s.line(L, B, R, B, "axis")
    s.save("fig-breakeven.svg")


LABEL = {"counterfactual rank": "earnings rank (state path)"}


def fig_tornado():
    t = pd.read_csv(RES / "p6_tornado.csv")
    t = t[t.input != "premium shape"]
    W = 820
    order = (t[t.sex == "men"].assign(span=lambda d: (d.npv_high - d.npv_low).abs())
             .sort_values("span", ascending=False).input.tolist())
    rowh, T = 40, 86
    H = T + rowh * len(order) + 64
    pos = t.assign(ok=t[["npv_low", "npv_high"]].max(axis=1) > 0).groupby("sex").ok.sum()
    assert pos["women"] == 0 and 0 < pos["men"] <= 3
    s = Svg(W, H, "Change one assumption at a time and the fees pay in only a few cases, all for boys",
            "Tornado chart of NPV at 3.5% for a typical private pupil (central premium, all-employee scenario): "
            + "; ".join(f"{r.sex} {r.input} {r.low_label} {r.npv_low / 1000:.0f}k, {r.high_label} {r.npv_high / 1000:.0f}k"
                        for r in t.itertuples()) + ".")
    s.text(24, 30, "Change one assumption at a time and the fees pay in only a few cases, all for boys", "t1", 15,
           weight=600)
    s.text(24, 50, "Net gain of 11-18 day fees for a typical private pupil, £k at 3.5%; each bar changes one assumption; "
                   "blue bars reach a positive net gain", "t3", 11)
    first = t[t.sex == "men"].set_index("input")
    for i, inp in enumerate(order):
        y = T + rowh * i
        s.text(250, y + 14, LABEL.get(inp, inp), "t1", 12, "end", 600)
        s.text(250, y + 29, f"{first.loc[inp, 'low_label']} ↔ {first.loc[inp, 'high_label']}", "t3", 10.5, "end")
    for j, sex in enumerate(("men", "women")):
        L0 = 270 + j * 280
        xs = scale(-140, 140, L0, L0 + 250)
        d = t[t.sex == sex].set_index("input")
        base = d.base_npv.iloc[0] / 1000
        s.text(L0 + 125, T - 14, f"{sex.capitalize()} (base {base:.0f}k)", "t1", 13, "middle", 600)
        for k in (-120, -60, 0, 60, 120):
            s.line(xs(k), T - 4, xs(k), T + rowh * len(order), "grid")
            s.text(xs(k), T + rowh * len(order) + 16, f"{k:+d}" if k else "0", "t3", 11, "middle")
        s.line(xs(0), T - 4, xs(0), T + rowh * len(order), "axis", 2)
        s.line(xs(base), T - 4, xs(base), T + rowh * len(order), "ink dash", 1)
        for i, inp in enumerate(order):
            r = d.loc[inp]
            y = T + rowh * i + 8
            lo, hi = sorted((r.npv_low / 1000, r.npv_high / 1000))
            s.rect(xs(lo), y, max(xs(hi) - xs(lo), 2), rowh - 16, "ind" if hi > 0 else "neu", 3)
            s.text(xs(hi) + 4, y + 16, f"{hi:+.0f}", "t3", 10)
            s.text(xs(lo) - 4, y + 16, f"{lo:+.0f}", "t3", 10, "end")
    s.save("fig-tornado.svg")


for f in (fig_alpha_deciles, fig_cambridge, fig_ons, fig_va, fig_fee_va, fig_overlay, fig_evidence, fig_breakeven, fig_tornado):
    f()
