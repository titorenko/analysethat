"""Render the write-up from writeup/article.md.tmpl: fills {placeholders} from article_values.values() and the
generated tables, then fails if any placeholder is left. Run make_figures.py into the same bundle first.

Usage: .venv/Scripts/python -I code/figures/build_article.py <bundle_dir>
"""
import pathlib
import re
import sys

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from article_values import ROOT, RES, k1, sgn, values  # noqa: E402

OUT = pathlib.Path(sys.argv[1])


SHORT = {"King Edward VI High School for Girls": "KEHS Birmingham", "Queen Elizabeth's School, Barnet": "QE Barnet",
         "King Edward VI Grammar School, Chelmsford": "KEGS Chelmsford",
         "King Edward VI Camp Hill School for Girls": "Camp Hill Girls",
         "King Edward VI Camp Hill School for Boys": "Camp Hill Boys",
         "St Olave's and St Saviour's Grammar School": "St Olave's", "King Edward VI School": "KES Stratford",
         "Chelmsford County High School for Girls": "Chelmsford County High",
         "Altrincham Grammar School for Girls": "Altrincham Girls", "Altrincham Grammar School for Boys": "Altrincham Boys",
         "St Michael's Catholic Grammar School": "St Michael's (Barnet)",
         "Stratford Girls' Grammar School": "Stratford Girls'", "Wallington County Grammar School": "Wallington County",
         "Wallington High School for Girls": "Wallington Girls", "Nonsuch High School for Girls": "Nonsuch",
         "Westcliff High School for Boys Academy": "Westcliff Boys", "Sir William Borlase's Grammar School": "Borlase's",
         "The Royal Grammar School, High Wycombe": "RGS High Wycombe", "Dr Challoner's Grammar School": "Dr Challoner's GS",
         "Dr Challoner's High School": "Dr Challoner's High", "The Henrietta Barnett School": "Henrietta Barnett",
         "Queen Elizabeth's Grammar Alford - A Selective Academy": "Queen Elizabeth's GS, Alford",
         "King Edward VI Grammar School": "KEGS Louth"}


SHORT_URN = {124883: "St Joseph's College, Ipswich", 136460: "St Joseph's College, Stoke-on-Trent"}


def short(name, urn=None):
    if urn in SHORT_URN:
        return SHORT_URN[urn]
    if name in SHORT:
        return SHORT[name]
    return (re.sub(r" School\b", "", name).replace(" GDST", "").replace(" and Latymer Prep", "")
            .replace("Royal Grammar", "RGS").replace(" Grammar", " GS").replace("The ", "").strip())


def pct_cell(x):
    return "n/a" if pd.isna(x) else f"{x:.0f}%"


def va_cell(r):
    if pd.isna(r.value_added):
        return "n/a"
    flag = " ‡" if r.va_low_coverage else ""
    return f"{sgn(r.value_added)} [{sgn(r.value_added_lower_ci)}, {sgn(r.value_added_upper_ci)}]{flag}"


# Column hints for the school tables ("Label ⟦hint⟧" headers, shown on hover by the site's table hook)
H = {"fee": "Fee ⟦Senior day fee for 2026/27 including VAT; boarding fee where there are no day pupils⟧",
     "aps": "APS ⟦A-level points per entry (50 = A, 40 = B)⟧",
     "aa": "A*/A ⟦Share of A-level grades at A* or A, 2024/25⟧",
     "va": "Value added [95% CI] ⟦Grades per A level above the GCSE prediction, 2024/25, with its range. ‡ fewer than 70% "
           "of A levels have a GCSE baseline⟧",
     "cam": "Cam/100 ⟦Cambridge places per 100 sixth-form leavers, 2022-2025⟧",
     "p8": "P8 ⟦Progress 8: GCSEs compared with tests at 11, 2023/24⟧",
     "ss": "Super-sel. ⟦Super-selective: admits by test rank from a wide area, with at least five applicants per place. "
           "– not assessed⟧"}


def table_independent(name="p3_top30_independent.csv", links=None):
    t = pd.read_csv(RES / name)
    out = [f"| # | School | {H['fee']} | {H['aps']} | {H['aa']} | {H['va']} | {H['cam']} |", "|---|---|---|---|---|---|---|"]
    for r in t.itertuples():
        fee = k1(r.fee_senior_day_2627) + ("" if r.fee_senior_day_2627_vat_stated is not False else " †") if not pd.isna(
            r.fee_senior_day_2627) else (
            f"{k1(r.fee_senior_boarding_2627)} (boarding)" if not pd.isna(r.fee_senior_boarding_2627) else "not found")
        school = f"[{short(r.name, r.urn)}](#{links[r.urn]})" if links and r.urn in links else short(r.name, r.urn)
        out.append(f"| {r.rank} | {school} | {fee} | {r.aps_pooled:.1f} | {pct_cell(r.pct_astar_a)} | {va_cell(r)} | "
                   f"{r.cam_acceptances_per100_est:.1f} |")
    return "\n".join(out)


# Table 7 schools whose name opens an admission note (shortcode school-note): the FOI results, urn -> anchor
NOTES = {136290: "school-qe", 138051: "school-hbs", 136412: "school-cchs", 136789: "school-wallington", 136795: "school-nonsuch"}


def note(anchor, lead, head, rows, foot):
    align = "|".join("---" for _ in head)
    table = "\n".join("| " + " | ".join(str(c) for c in r) + " |" for r in rows)
    return (f'{{{{< school-note id="{anchor}" >}}}}\n{lead}\n\n| {" | ".join(head)} |\n|{align}|\n{table}\n\n{foot}\n'
            "{{< /school-note >}}")


def school_notes():
    """Admission notes for NOTES. Every figure comes from grammar_intake.csv."""
    gi = pd.read_csv(ROOT / "data" / "derived" / "grammar_intake.csv", dtype=str, keep_default_na=False)

    def get(urn, measure, category="all", offer_round=None):
        s = gi[(gi.urn == str(urn)) & (gi.measure == measure) & (gi.category == category) & gi.value.ne("")]
        if offer_round is not None:
            s = s[s.offer_round == offer_round]
        return s.set_index("entry_year").value

    n = lambda x: f"{int(float(x)):,}"
    out = []

    # Queen Elizabeth's: FOI reply 2026-10-12 + admissions guide. 2026 entry withheld by the school.
    u = 136290
    took, per, offers = get(u, "testers_stage1"), get(u, "testers_per_place"), get(u, "offers")
    day = get(u, "lowest_score_offered", offer_round="national_offer_day")
    final = get(u, "lowest_score_offered", offer_round="final_excluding_appeals")
    y = took.index.max()
    out.append(note(NOTES[u],
        f"**QE Barnet: admission figures.** {n(took[y])} boys took the test for {y} entry, about {float(per[y]):.0f} for each "
        "offer on national offer day. There is no catchment area, so places go by score. The school's freedom of information "
        "reply adds two things its admissions guide doesn't give: the lowest score on offer day, and total offers once the "
        "waiting list has run.",
        ["Entry", "Took the test", "Offers, whole round", "Lowest score, offer day", "Lowest score, after waiting list"],
        [[e, n(took[e]), offers[e], day[e], final[e]] for e in sorted(took.index)],
        "The school withheld 2026 entry while that round was live and says it will publish in the spring term. From a freedom "
        "of information reply, October 2026, and the school's admissions guide."))

    # Henrietta Barnett: FOI reply 2026-10-19
    u = 138051
    r1, cut, low = get(u, "testers_stage1"), get(u, "qualifying_score", "round1_cutoff"), get(u, "lowest_score_offered")
    offers, per = get(u, "offers"), get(u, "testers_per_place")
    y, p = "2026", "2025"
    assert int(offers[y]) > int(offers[p]) and float(low[y]) < float(low[p]), "the note says offers rose and the score fell"
    out.append(note(NOTES[u],
        f"**Henrietta Barnett: admission figures.** {n(r1[y])} girls sat the first round for {y} entry, about "
        f"{float(per[y]):.0f} for each offer, and the top {n(get(u, 'testers_stage2')[y])} went through to the second. Offers "
        f"rose from {offers[p]} to {offers[y]} that year, and the lowest combined score fell from {low[p]} to {low[y]}.",
        ["Entry", "Sat round 1", "Round 1 cut-off", "Lowest combined score", "Offers"],
        [[e, n(r1[e]), cut[e], low[e], offers[e]] for e in sorted(r1.index)],
        "The reply doesn't explain its labels. The cut-off is read as the score of the last girl through to round 2; how the "
        "rounds are combined, and whether the lowest score is from national offer day, aren't stated. From a freedom of "
        "information reply, October 2026."))

    # Chelmsford County High: the school's own FOI page (ranges released, offer round varies by year)
    u = 136412
    ins, outs = get(u, "lowest_score_offered", "inside_priority_area"), get(u, "lowest_score_offered", "outside_priority_area")
    gaps = [int(outs[e].split("-")[0]) - int(ins[e].split("-")[0]) for e in ins.index]
    km = get(u, "catchment_km").iloc[-1]
    out.append(note(NOTES[u],
        f"**Chelmsford County High: admission figures.** Girls from outside the priority area, about {float(km):.0f} km around "
        f"the school, needed about {min(gaps)}-{max(gaps)} points more than girls inside it.",
        ["Entry", "Last offer, inside the area", "Last offer, outside the area"],
        [[e, ins[e], outs[e]] for e in sorted(ins.index)],
        "Scores are released as ranges, and the date of the figures varies a little by year. From answers to freedom of "
        "information requests on the school's website."))

    # Wallington Girls and Nonsuch: FOI reply 2026-11-05. The test is shared, so its counts are for the pair.
    pool = gi[(gi.urn == "") & (gi.name == "Sutton Selective Eligibility Test (SET)") & (gi.category == "girls")]
    pool = pool.pivot(index="entry_year", columns="measure", values="value")
    for u, name in ((136789, "Wallington Girls"), (136795, "Nonsuch")):
        pan = get(u, "pan").iloc[-1]
        policy = gi[(gi.urn == str(u)) & (gi.measure == "admissions_model")].note.iloc[0]
        open_n, pp_n, catch_n, km = re.search(
            r"(\d+) open by score; up to (\d+) FSM/PP; up to (\d+) by score inside a ([\d.]+) km", policy).groups()
        op, ca, pp = (get(u, "lowest_score_offered", c) for c in ("open_by_score", "catchment", "pupil_premium"))
        out.append(note(NOTES[u],
            f"**{name}: admission figures.** Nonsuch and Wallington Girls share an entrance test, which "
            f"{n(pool.testers_stage1['2026'])} girls sat for 2026 entry: about {float(pool.testers_per_place['2026']):.0f} for "
            f"each place across the two schools. That clears the five-per-place mark, but up to {catch_n} of the school's {pan} "
            f"places can go by score to girls living within {km} km, so it isn't marked super-selective.",
            ["Entry", "Girls sitting the test (both schools)", f"Open to all ({open_n} places)",
             f"Catchment (up to {catch_n})", f"Pupil premium (up to {pp_n})"],
            [[e, n(pool.testers_stage1[e]), op[e], ca[e], pp[e]] for e in sorted(op.index)],
            "Lowest score offered a place on national offer day, by route. Scores are the test total: second-stage marks plus "
            "half the first-stage marks. Pupil premium is extra school funding for poorer pupils. From a freedom of "
            "information reply, November 2026."))
    return "\n\n".join(out)


# Generated notes for the other top-30 grammars: one row per entry year, one column per figure the school (or its
# council or test consortium) publishes, plus the DfE offer-day counts. (measure, column label), in column order.
G_COLS = [("registrations", "Registered for the test"), ("applications", "Applied"),
          ("test_applicants", "Applied to sit the test"), ("testers_stage1", "Took the test"),
          ("candidates_qualified", "Qualified"), ("testers_stage2", "Second stage"),
          ("testers_per_place", "Took the test per place"), ("test_applicants_per_place", "Applicants per place"),
          ("qualifying_score", "Pass mark"), ("score_of_150th_rank", "Score of 150th place"),
          ("lowest_score_offered", "Lowest score offered"), ("last_rank_offered", "Last rank offered"),
          ("last_distance_offered", "Furthest distance offered"), ("places", "Places"), ("offers", "Offers"),
          ("offers_waiting_list", "Offers from waiting list"), ("waiting_list_position_reached", "Waiting list reached"),
          ("appeals_upheld", "Appeals upheld"), ("dfe_preferences_1st", "Put it first (DfE)"),
          ("dfe_offers_total", "Offers (DfE)")]
G_CAT = {"all": "", "rank": "", "inside_priority_area": "inside the area", "outside_priority_area": "outside the area",
         "catchment": "catchment", "outside_catchment": "outside catchment", "pupil_premium": "pupil premium",
         "aptitude_sport_music": "sport and music places", "stage1_pass": "first stage", "stage2_pass": "second stage",
         "set_pool": "all Sutton test schools, boys and girls", "all_others": "everyone else", "looked_after": "children in care",
         "priority_score_inside_catchment": "catchment", "pupil_premium_inside_catchment": "pupil premium, catchment",
         "pupil_premium_outside_catchment": "pupil premium, outside catchment", "bucks_residents": "Bucks residents",
         "distance": "by distance", "siblings": "siblings", "non-catchment siblings": "siblings outside catchment",
         "priority_area_1": "area 1", "priority_area_2": "area 2", "eligible_111_plus": "scoring 111 or more",
         "inner_area": "inner area", "pupil_premium_or_looked_after": "pupil premium or in care"}
G_ROUND = {"": "", "national_offer_day": "", "september": "September", "april_reallocation": "April",
           "final_excluding_appeals": "after waiting list", "end_of_year7": "end of Year 7"}
G_DIST = {"km": " km", "miles": " miles", "metres": " m"}
G_CODE = {"all_offered": "all offered", "no_offers": "none"}


def anchor(name):
    return "school-" + re.sub(r"[^a-z0-9]+", "-", name.lower().replace("'", "")).strip("-")


def sources(urls):
    """Markdown links grouped by site (an archived copy under the site it copies), in first-seen order; an emailed FOI
    reply is named, not linked; derived values (no URL) are skipped."""
    by = {}
    for u in dict.fromkeys(urls):
        if u.startswith("http"):
            orig = re.sub(r"^https?://web[.]archive[.]org/web/\w+/", "", u)
            by.setdefault(re.sub(r"^www[.]", "", orig.split("/")[2]), []).append(u)
    parts = [f"[{h}]({us[0]})" if len(us) == 1 else f"{h} (" + ", ".join(f"[{i}]({u})" for i, u in enumerate(us, 1)) + ")"
             for h, us in by.items()]
    return ", ".join(parts + (["a freedom of information reply"] if any(u.startswith("mailto:") for u in urls) else []))


def grammar_notes(skip):
    """Notes for top-30 grammars not in skip that publish anything beyond the DfE counts. Returns (urn -> anchor, text)."""
    gi = pd.read_csv(ROOT / "data" / "derived" / "grammar_intake.csv", dtype=str, keep_default_na=False)
    gi = gi[gi.value.ne("") & gi.status.eq("confirmed")]
    order = {m: i for i, (m, _) in enumerate(G_COLS)}
    links, out = {}, []
    for r in pd.read_csv(RES / "p3_top30_grammar.csv").itertuples():
        s = gi[(gi.urn == str(r.urn)) & gi.measure.isin(order)]
        if r.urn in skip or s.measure.str.startswith("dfe_").all():
            continue
        cols = sorted({(m, c, o) for m, c, o in zip(s.measure, s.category, s.offer_round)},
                      key=lambda k: (order[k[0]], k[1] != "all", k[1], k[2]))
        head = ["Entry"]
        for m, c, o in cols:
            extra = [x for x in (G_CAT.get(c, c.replace("_", " ")), G_ROUND[o]) if x]
            lab = "Qualifying rank" if (m, c) == ("qualifying_score", "rank") else dict(G_COLS)[m]
            head.append(lab + (f", {', '.join(extra)}" if extra else ""))
        cell = {}
        for x in s.itertuples():
            v = G_CODE.get(x.value, x.value)
            if re.fullmatch(r"\d{4,}", v):
                v = f"{int(v):,}"
            elif x.measure.endswith("per_place") and re.fullmatch(r"[\d.]+", v):
                v = f"{float(v):.1f}"
            cell[(x.entry_year, x.measure, x.category, x.offer_round)] = v + G_DIST.get(x.unit, "")
        rows = [[y] + [cell.get((y, *k), "–") for k in cols] for y in sorted(s.entry_year.unique())]
        name = short(r.name, r.urn)
        lead = f"**{name}: admission figures.**"
        took, per = (s[(s.measure == m) & (s.category == "all")].set_index("entry_year").value
                     for m in ("testers_stage1", "testers_per_place"))
        if len(took) and took.index.max() in per.index:
            y = took.index.max()
            lead += f" {int(took[y]):,} children took the test for {y} entry, about {float(per[y]):.0f} for each place."
        pan = gi[(gi.urn == str(r.urn)) & (gi.measure == "pan")].sort_values("entry_year").value
        if len(pan):
            lead += f" It admits {pan.iloc[-1]} a year."
        scores = s[s.measure.isin(["lowest_score_offered", "qualifying_score", "score_of_150th_rank"])
                   & ~s.unit.isin(["code", "score"]) & ~s.unit.str.contains("rank")].unit.unique()
        foot = ("Scores, ranks and distances are at national offer day unless marked."
                if s.measure.isin(["lowest_score_offered", "last_rank_offered", "last_distance_offered"]).any() else "")
        if len(scores):
            foot += f" Scores: {'; '.join(scores)}."
        if r.urn == 136621:     # Wilson's FOI reply 2026-11-19: pool-wide first stage, offers above the DfE count, banded score
            mine, dfe = (s[(s.measure == m) & (s.entry_year == "2025") & (s.category == "all")].value.iloc[0]
                         for m in ("offers", "dfe_offers_total"))
            assert int(mine) > int(dfe), "the footer says the school's offers are the higher count"
            foot += (f" \"Took the test\" is the whole Sutton test, taken for all its schools, so it is not Wilson's own count. "
                     f"\"Offers\" is the school's count with no round stated: it is above the DfE's offer-day count in 2023 to 2025 "
                     f"({mine} against {dfe} in 2025), so it probably includes waiting-list offers. The school gives the lowest "
                     "score only as a band of ten points, and cites the personal-information exemption for what it withheld "
                     "without saying which part.")
        foot += (" From " + sources(s[~s.measure.str.startswith("dfe_")].source_url)
                 + ", and the DfE's offer-day statistics (applications and offers by school).")
        links[r.urn] = anchor(name)
        out.append(note(links[r.urn], lead, head, rows, foot.strip()))
    return links, "\n\n".join(out)


# Generated notes for the private schools in Tables 5 and 6 (sections 3.2 and 3.3), from independent_admissions.csv: one row per entry point.
P_COLS = [("places_total", "Places"), ("places_external", "Places for pupils from outside"),
          ("from_own_junior", "From its own junior school"), ("applicants", "Applicants"),
          ("applicants_per_place", "Applicants per place"), ("entry_steps", "How it selects")]
P_ENTRY = {"10+": "10+", "11+": "11+", "13+": "13+", "16+": "16+ (sixth form)", "all": "Not stated"}


def private_notes():
    ia = pd.read_csv(ROOT / "data" / "derived" / "independent_admissions.csv", dtype=str, keep_default_na=False)
    ia = ia[(ia.entry_year.eq("") | ia.entry_year.ge("2020")) & (ia.unit.ne("text") | ia.measure.eq("entry_steps"))]
    links, out = {}, []
    for urn, s in ia.groupby("urn", sort=False):
        name = short(s.name.iloc[0], int(urn))
        cells = {}
        for x in s.itertuples():       # a dated figure beats an undated one; among undated, the last listed (latest policy)
            k = (x.category, x.measure)
            if k in cells and cells[k][0] and not x.entry_year:
                continue
            v = x.value + ("%" if x.unit == "percent" else "")
            cells[k] = (x.entry_year, v + (f" ({x.entry_year} entry)" if x.entry_year and x.measure != "entry_steps" else ""))
        cols = [(m, lab) for m, lab in P_COLS if any(k[1] == m for k in cells)]
        cats = [c for c in P_ENTRY if any(k[0] == c and k[1] in dict(cols) for k in cells)]
        lead = f"**{name}: admissions.**"
        ox = s[s.measure.isin(["oxbridge_places", "oxbridge_offers"])].sort_values("entry_year")
        if len(ox):
            o = ox.iloc[-1]
            lead += (f" The school reports {o.value} Oxford and Cambridge "
                     f"{'places' if o.measure == 'oxbridge_places' else 'offers'} in {o.entry_year}.")
        links[int(urn)] = anchor(name)
        if not cols:            # only an Oxbridge figure
            out.append(f'{{{{< school-note id="{links[int(urn)]}" >}}}}\n{lead}\n\nFrom '
                       f"{sources(s.source_url)}.\n{{{{< /school-note >}}}}")
            continue
        rows = [[P_ENTRY[c]] + [cells.get((c, m), ("", "–"))[1] for m, _ in cols] for c in cats]
        out.append(note(links[int(urn)], lead, ["Entry"] + [lab for _, lab in cols], rows,
                        "As the school's website or accounts give them, read November 2026; a year is shown where the "
                        f"school gives one. From {sources(s.source_url)}."))
    return links, "\n\n".join(out)


def table_grammar(name="p3_top30_grammar.csv", super_sel=True):
    t = pd.read_csv(RES / name)
    out = [f"| # | School | {H['aps']} | {H['aa']} | {H['va']} | {H['p8']} | {H['cam']} |" + (f" {H['ss']} |" if super_sel else ""),
           "|---|---|---|---|---|---|---|" + ("---|" if super_sel else "")]
    for r in t.itertuples():
        ss = {"yes": "yes", "probable": "probable", "no": "no", "unassessed": "–"}.get(
            r.super_selective if isinstance(r.super_selective, str) else "", "–")
        if r.urn == 138051:
            ss += " §"
        school = short(r.name, r.urn)
        if super_sel and r.urn in LINKS:
            school = f"[{school}](#{LINKS[r.urn]})"
        out.append(f"| {r.rank} | {school} | {r.aps_pooled:.1f} | {pct_cell(r.pct_astar_a)} | {va_cell(r)} | "
                   f"{sgn(r.progress8)} | {r.cam_acceptances_per100_est:.1f} |" + (f" {ss} |" if super_sel else ""))
    return "\n".join(out)


def table_alpha_quantiles():
    q = pd.read_csv(RES / "p3_alpha_quantiles.csv")
    order = ["independent", "selective", "partially_selective", "non_selective_other", "non_selective_highly_selective_area"]
    q = q.set_index("sector").loc[order]
    cols = [f"p{k}" for k in range(10, 100, 10)]
    out = ["| Kind of school | Schools ⟦Number with a value-added figure⟧ | " + " | ".join(
        f"{k}th ⟦Value added of the school that {k} in every 100 of that kind fall below⟧" for k in range(10, 100, 10)) + " |",
           "|---|---|" + "---|" * 9]
    for _, r in q.iterrows():
        out.append(f"| {r.label} | {r.schools:,} | " + " | ".join(sgn(r[c]) for c in cols) + " |")
    return "\n".join(out)


def table_alpha_deciles():
    t = pd.read_csv(RES / "p3_alpha_by_results_decile.csv").set_index(["sector", "decile"])
    pts = "⟦The group's average A-level points per entry, 2023/24 and 2024/25 (50 = A, 40 = B)⟧"
    va = "⟦Average value added across the group's schools, 2024/25⟧"
    out = ["| Tenth by results ⟦Sixth forms of each kind sorted into ten equal groups by A-level points per entry, best "
           f"first⟧ | Private: points {pts} | Private: value added {va} | Grammar: points {pts} | Grammar: value added {va} | "
           f"Comprehensive: points {pts} | Comprehensive: value added {va} |", "|---|---|---|---|---|---|---|"]
    for d in range(1, 11):
        lab = {1: "1 (best)", 10: "10 (weakest)"}.get(d, str(d))
        cells = []
        for sec in ("independent", "selective", "non_selective_other"):
            r = t.loc[(sec, d)]
            cells += [f"{r.aps_mean:.1f}", sgn(r.va_mean)]
        out.append(f"| {lab} | " + " | ".join(cells) + " |")
    return "\n".join(out)


G_LINKS, g_notes = grammar_notes(set(NOTES))
LINKS = {**NOTES, **G_LINKS}
P_LINKS, p_notes = private_notes()
assert len(set(LINKS.values()) | set(P_LINKS.values())) == len(LINKS) + len(P_LINKS), "note anchors must be unique"
v = values()
v["table_alpha_quantiles"] = table_alpha_quantiles()
v["table_bottom20_private"] = table_independent("p3_bottom20_private.csv")
v["table_bottom30_grammar"] = table_grammar("p3_bottom30_grammar.csv", super_sel=False)
v["table_alpha_deciles"] = table_alpha_deciles()
v["table_top30_independent"] = table_independent()
v["table_top20_boys"] = table_independent("p3_top20_boys.csv", P_LINKS)
v["table_top20_girls"] = table_independent("p3_top20_girls.csv", P_LINKS)
v["school_notes_private"] = p_notes
v["REVIEW-LINE-2"] = ""
v["table_top30_grammar"] = table_grammar()
v["school_notes"] = school_notes() + "\n\n" + g_notes
tmpl = (ROOT / "writeup" / "article.md.tmpl").read_text(encoding="utf-8")
text = tmpl.format_map(v)
left = re.findall(r"\{[a-z0-9_]+\}", text)
assert not left, left
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "index.md").write_text(text, encoding="utf-8")
print("wrote", OUT / "index.md", len(text.split()), "words")
