"""Render the write-up from writeup/article.md.tmpl: fills {placeholders} from article_values.values() and the
generated tables, then fails if any placeholder is left. Run make_figures.py into the same bundle first.

Usage: .venv/Scripts/python -I code/figures/build_article.py <bundle_dir>
"""
import pathlib
import re
import sys

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from article_values import ROOT, RES, k1, sgn, values  # noqa: E402

OUT = pathlib.Path(sys.argv[1])


SHORT = {"King Edward VI High School for Girls": "KEHS Birmingham", "Queen Elizabeth's School, Barnet": "QE Barnet",
         "King Edward VI Grammar School, Chelmsford": "KEGS Chelmsford",
         "King Edward VI Camp Hill School for Girls": "Camp Hill Girls",
         "King Edward VI Camp Hill School for Boys": "Camp Hill Boys",
         "St Olave's and St Saviour's Grammar School": "St Olave's", "King Edward VI School": "KES Stratford",
         "Chelmsford County High School for Girls": "Chelmsford County High",
         "Altrincham Grammar School for Girls": "Altrincham Girls", "Altrincham Grammar School for Boys": "Altrincham Boys",
         "St Michael's Catholic Grammar School": "St Michael's (Barnet)",
         "Stratford Girls' Grammar School": "Stratford Girls'", "Wallington County Grammar School": "Wallington County",
         "Wallington High School for Girls": "Wallington Girls", "Nonsuch High School for Girls": "Nonsuch",
         "Westcliff High School for Boys Academy": "Westcliff Boys", "Sir William Borlase's Grammar School": "Borlase's",
         "The Royal Grammar School, High Wycombe": "RGS High Wycombe", "Dr Challoner's Grammar School": "Dr Challoner's GS",
         "Dr Challoner's High School": "Dr Challoner's High", "The Henrietta Barnett School": "Henrietta Barnett",
         "Queen Elizabeth's Grammar Alford - A Selective Academy": "Queen Elizabeth's GS, Alford",
         "King Edward VI Grammar School": "KEGS Louth"}


SHORT_URN = {124883: "St Joseph's College, Ipswich", 136460: "St Joseph's College, Stoke-on-Trent"}


def short(name, urn=None):
    if urn in SHORT_URN:
        return SHORT_URN[urn]
    if name in SHORT:
        return SHORT[name]
    return (re.sub(r" School\b", "", name).replace(" GDST", "").replace(" and Latymer Prep", "")
            .replace("Royal Grammar", "RGS").replace(" Grammar", " GS").replace("The ", "").strip())


def pct_cell(x):
    return "n/a" if pd.isna(x) else f"{x:.0f}%"


def va_cell(r):
    if pd.isna(r.value_added):
        return "n/a"
    flag = " ‡" if r.va_low_coverage else ""
    return f"{sgn(r.value_added)} [{sgn(r.value_added_lower_ci)}, {sgn(r.value_added_upper_ci)}]{flag}"


def table_independent(name="p3_top30_independent.csv"):
    t = pd.read_csv(RES / name)
    out = ["| # | School | Fee | APS | A*/A | Value added [95% CI] | Cam/100 |", "|---|---|---|---|---|---|---|"]
    for r in t.itertuples():
        fee = k1(r.fee_senior_day_2627) + ("" if r.fee_senior_day_2627_vat_stated is not False else " †") if not pd.isna(
            r.fee_senior_day_2627) else (
            f"{k1(r.fee_senior_boarding_2627)} (boarding)" if not pd.isna(r.fee_senior_boarding_2627) else "not found")
        out.append(f"| {r.rank} | {short(r.name, r.urn)} | {fee} | {r.aps_pooled:.1f} | {pct_cell(r.pct_astar_a)} | {va_cell(r)} | "
                   f"{r.cam_acceptances_per100_est:.1f} |")
    return "\n".join(out)


# Table 5 schools whose name opens an admission note (shortcode school-note): the FOI results, urn -> anchor
NOTES = {136290: "school-qe", 138051: "school-hbs", 136412: "school-cchs", 136789: "school-wallington", 136795: "school-nonsuch"}


def note(anchor, lead, head, rows, foot):
    align = "|".join("---" for _ in head)
    table = "\n".join("| " + " | ".join(str(c) for c in r) + " |" for r in rows)
    return (f'{{{{< school-note id="{anchor}" >}}}}\n{lead}\n\n| {" | ".join(head)} |\n|{align}|\n{table}\n\n{foot}\n'
            "{{< /school-note >}}")


def school_notes():
    """Admission notes for NOTES. Every figure comes from grammar_intake.csv."""
    gi = pd.read_csv(ROOT / "data" / "derived" / "grammar_intake.csv", dtype=str, keep_default_na=False)

    def get(urn, measure, category="all", offer_round=None):
        s = gi[(gi.urn == str(urn)) & (gi.measure == measure) & (gi.category == category) & gi.value.ne("")]
        if offer_round is not None:
            s = s[s.offer_round == offer_round]
        return s.set_index("entry_year").value

    n = lambda x: f"{int(float(x)):,}"
    out = []

    # Queen Elizabeth's: FOI reply 2026-10-12 + admissions guide. 2026 entry withheld by the school.
    u = 136290
    took, per, offers = get(u, "testers_stage1"), get(u, "testers_per_place"), get(u, "offers")
    day = get(u, "lowest_score_offered", offer_round="national_offer_day")
    final = get(u, "lowest_score_offered", offer_round="final_excluding_appeals")
    y = took.index.max()
    out.append(note(NOTES[u],
        f"**QE Barnet: admission figures.** {n(took[y])} boys took the test for {y} entry, about {float(per[y]):.0f} for each "
        "offer on national offer day. There is no catchment area, so places go by score. The school's freedom of information "
        "reply adds two things its admissions guide doesn't give: the lowest score on offer day, and total offers once the "
        "waiting list has run.",
        ["Entry", "Took the test", "Offers, whole round", "Lowest score, offer day", "Lowest score, after waiting list"],
        [[e, n(took[e]), offers[e], day[e], final[e]] for e in sorted(took.index)],
        "The school withheld 2026 entry while that round was live and says it will publish in the spring term. From a freedom "
        "of information reply, October 2026, and the school's admissions guide."))

    # Henrietta Barnett: FOI reply 2026-10-19
    u = 138051
    r1, cut, low = get(u, "testers_stage1"), get(u, "qualifying_score", "round1_cutoff"), get(u, "lowest_score_offered")
    offers, per = get(u, "offers"), get(u, "testers_per_place")
    y, p = "2026", "2025"
    assert int(offers[y]) > int(offers[p]) and float(low[y]) < float(low[p]), "the note says offers rose and the score fell"
    out.append(note(NOTES[u],
        f"**Henrietta Barnett: admission figures.** {n(r1[y])} girls sat the first round for {y} entry, about "
        f"{float(per[y]):.0f} for each offer, and the top {n(get(u, 'testers_stage2')[y])} went through to the second. Offers "
        f"rose from {offers[p]} to {offers[y]} that year, and the lowest combined score fell from {low[p]} to {low[y]}.",
        ["Entry", "Sat round 1", "Round 1 cut-off", "Lowest combined score", "Offers"],
        [[e, n(r1[e]), cut[e], low[e], offers[e]] for e in sorted(r1.index)],
        "The reply doesn't explain its labels. The cut-off is read as the score of the last girl through to round 2; how the "
        "rounds are combined, and whether the lowest score is from national offer day, aren't stated. From a freedom of "
        "information reply, October 2026."))

    # Chelmsford County High: the school's own FOI page (ranges released, offer round varies by year)
    u = 136412
    ins, outs = get(u, "lowest_score_offered", "inside_priority_area"), get(u, "lowest_score_offered", "outside_priority_area")
    gaps = [int(outs[e].split("-")[0]) - int(ins[e].split("-")[0]) for e in ins.index]
    km = get(u, "catchment_km").iloc[-1]
    out.append(note(NOTES[u],
        f"**Chelmsford County High: admission figures.** Girls from outside the priority area, about {float(km):.0f} km around "
        f"the school, needed about {min(gaps)}-{max(gaps)} points more than girls inside it.",
        ["Entry", "Last offer, inside the area", "Last offer, outside the area"],
        [[e, ins[e], outs[e]] for e in sorted(ins.index)],
        "Scores are released as ranges, and the date of the figures varies a little by year. From answers to freedom of "
        "information requests on the school's website."))

    # Wallington Girls and Nonsuch: FOI reply 2026-11-05. The test is shared, so its counts are for the pair.
    pool = gi[(gi.urn == "") & (gi.name == "Sutton Selective Eligibility Test (SET)") & (gi.category == "girls")]
    pool = pool.pivot(index="entry_year", columns="measure", values="value")
    for u, name in ((136789, "Wallington Girls"), (136795, "Nonsuch")):
        pan = get(u, "pan").iloc[-1]
        policy = gi[(gi.urn == str(u)) & (gi.measure == "admissions_model")].note.iloc[0]
        open_n, pp_n, catch_n, km = re.search(
            r"(\d+) open by score; up to (\d+) FSM/PP; up to (\d+) by score inside a ([\d.]+) km", policy).groups()
        op, ca, pp = (get(u, "lowest_score_offered", c) for c in ("open_by_score", "catchment", "pupil_premium"))
        out.append(note(NOTES[u],
            f"**{name}: admission figures.** Nonsuch and Wallington Girls share an entrance test, which "
            f"{n(pool.testers_stage1['2026'])} girls sat for 2026 entry: about {float(pool.testers_per_place['2026']):.0f} for "
            f"each place across the two schools. That clears the five-per-place mark, but up to {catch_n} of the school's {pan} "
            f"places can go by score to girls living within {km} km, so it isn't marked super-selective.",
            ["Entry", "Girls sitting the test (both schools)", f"Open to all ({open_n} places)",
             f"Catchment (up to {catch_n})", f"Pupil premium (up to {pp_n})"],
            [[e, n(pool.testers_stage1[e]), op[e], ca[e], pp[e]] for e in sorted(op.index)],
            "Lowest score offered a place on national offer day, by route. Scores are the test total: second-stage marks plus "
            "half the first-stage marks. Pupil premium is extra school funding for poorer pupils. From a freedom of "
            "information reply, November 2026."))
    return "\n\n".join(out)


def table_grammar(name="p3_top30_grammar.csv", super_sel=True):
    t = pd.read_csv(RES / name)
    out = ["| # | School | APS | A*/A | Value added [95% CI] | P8 | Cam/100 |" + (" Super-sel. |" if super_sel else ""),
           "|---|---|---|---|---|---|---|" + ("---|" if super_sel else "")]
    for r in t.itertuples():
        ss = {"yes": "yes", "probable": "probable", "no": "no", "unassessed": "–"}.get(
            r.super_selective if isinstance(r.super_selective, str) else "", "–")
        if r.urn == 138051:
            ss += " §"
        school = short(r.name, r.urn)
        if super_sel and r.urn in NOTES:
            school = f"[{school}](#{NOTES[r.urn]})"
        out.append(f"| {r.rank} | {school} | {r.aps_pooled:.1f} | {pct_cell(r.pct_astar_a)} | {va_cell(r)} | "
                   f"{sgn(r.progress8)} | {r.cam_acceptances_per100_est:.1f} |" + (f" {ss} |" if super_sel else ""))
    return "\n".join(out)


def table_alpha_quantiles():
    q = pd.read_csv(RES / "p3_alpha_quantiles.csv")
    order = ["independent", "selective", "partially_selective", "non_selective_other", "non_selective_highly_selective_area"]
    q = q.set_index("sector").loc[order]
    cols = [f"p{k}" for k in range(10, 100, 10)]
    out = ["| Kind of school | Schools | " + " | ".join(f"{k}th" for k in range(10, 100, 10)) + " |",
           "|---|---|" + "---|" * 9]
    for _, r in q.iterrows():
        out.append(f"| {r.label} | {r.schools:,} | " + " | ".join(sgn(r[c]) for c in cols) + " |")
    return "\n".join(out)


def table_alpha_deciles():
    t = pd.read_csv(RES / "p3_alpha_by_results_decile.csv").set_index(["sector", "decile"])
    out = ["| Tenth by results | Private: points | Private: value added | Grammar: points | Grammar: value added | "
           "Comprehensive: points | Comprehensive: value added |", "|---|---|---|---|---|---|---|"]
    for d in range(1, 11):
        lab = {1: "1 (best)", 10: "10 (weakest)"}.get(d, str(d))
        cells = []
        for sec in ("independent", "selective", "non_selective_other"):
            r = t.loc[(sec, d)]
            cells += [f"{r.aps_mean:.1f}", sgn(r.va_mean)]
        out.append(f"| {lab} | " + " | ".join(cells) + " |")
    return "\n".join(out)


v = values()
v["table_alpha_quantiles"] = table_alpha_quantiles()
v["table_bottom20_private"] = table_independent("p3_bottom20_private.csv")
v["table_bottom30_grammar"] = table_grammar("p3_bottom30_grammar.csv", super_sel=False)
v["table_alpha_deciles"] = table_alpha_deciles()
v["table_top30_independent"] = table_independent()
v["table_top20_boys"] = table_independent("p3_top20_boys.csv")
v["table_top20_girls"] = table_independent("p3_top20_girls.csv")
v["REVIEW-LINE-2"] = ""
v["table_top30_grammar"] = table_grammar()
v["school_notes"] = school_notes()
tmpl = (ROOT / "writeup" / "article.md.tmpl").read_text(encoding="utf-8")
text = tmpl.format_map(v)
left = re.findall(r"\{[a-z0-9_]+\}", text)
assert not left, left
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "index.md").write_text(text, encoding="utf-8")
print("wrote", OUT / "index.md", len(text.split()), "words")
