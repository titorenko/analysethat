"""Render the write-up from writeup/article.md.tmpl: fills {placeholders} from article_values.values() and the
generated tables, then fails if any placeholder is left. Run make_figures.py into the same bundle first.

Usage: .venv/Scripts/python -I code/figures/build_article.py <bundle_dir>
"""
import pathlib
import re
import sys

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from article_values import ROOT, RES, k1, sgn, values  # noqa: E402

OUT = pathlib.Path(sys.argv[1])


SHORT = {"King Edward VI High School for Girls": "KEHS Birmingham", "Queen Elizabeth's School, Barnet": "QE Barnet",
         "King Edward VI Grammar School, Chelmsford": "KEGS Chelmsford",
         "King Edward VI Camp Hill School for Girls": "Camp Hill Girls",
         "King Edward VI Camp Hill School for Boys": "Camp Hill Boys",
         "St Olave's and St Saviour's Grammar School": "St Olave's", "King Edward VI School": "KES Stratford",
         "Chelmsford County High School for Girls": "Chelmsford County High",
         "Altrincham Grammar School for Girls": "Altrincham Girls", "Altrincham Grammar School for Boys": "Altrincham Boys",
         "St Michael's Catholic Grammar School": "St Michael's (Barnet)",
         "Stratford Girls' Grammar School": "Stratford Girls'", "Wallington County Grammar School": "Wallington County",
         "Wallington High School for Girls": "Wallington Girls", "Nonsuch High School for Girls": "Nonsuch",
         "Westcliff High School for Boys Academy": "Westcliff Boys", "Sir William Borlase's Grammar School": "Borlase's",
         "The Royal Grammar School, High Wycombe": "RGS High Wycombe", "Dr Challoner's Grammar School": "Dr Challoner's GS",
         "Dr Challoner's High School": "Dr Challoner's High", "The Henrietta Barnett School": "Henrietta Barnett",
         "Queen Elizabeth's Grammar Alford - A Selective Academy": "Queen Elizabeth's GS, Alford",
         "King Edward VI Grammar School": "KEGS Louth"}


SHORT_URN = {124883: "St Joseph's College, Ipswich", 136460: "St Joseph's College, Stoke-on-Trent"}


def short(name, urn=None):
    if urn in SHORT_URN:
        return SHORT_URN[urn]
    if name in SHORT:
        return SHORT[name]
    return (re.sub(r" School\b", "", name).replace(" GDST", "").replace(" and Latymer Prep", "")
            .replace("Royal Grammar", "RGS").replace(" Grammar", " GS").replace("The ", "").strip())


def pct_cell(x):
    return "n/a" if pd.isna(x) else f"{x:.0f}%"


def va_cell(r):
    if pd.isna(r.value_added):
        return "n/a"
    flag = " ‡" if r.va_low_coverage else ""
    return f"{sgn(r.value_added)} [{sgn(r.value_added_lower_ci)}, {sgn(r.value_added_upper_ci)}]{flag}"


def table_independent(name="p3_top30_independent.csv"):
    t = pd.read_csv(RES / name)
    out = ["| # | School | Fee | APS | A*/A | Value added [95% CI] | Cam/100 |", "|---|---|---|---|---|---|---|"]
    for r in t.itertuples():
        fee = k1(r.fee_senior_day_2627) + ("" if r.fee_senior_day_2627_vat_stated is not False else " †") if not pd.isna(
            r.fee_senior_day_2627) else (
            f"{k1(r.fee_senior_boarding_2627)} (boarding)" if not pd.isna(r.fee_senior_boarding_2627) else "not found")
        out.append(f"| {r.rank} | {short(r.name, r.urn)} | {fee} | {r.aps_pooled:.1f} | {pct_cell(r.pct_astar_a)} | {va_cell(r)} | "
                   f"{r.cam_acceptances_per100_est:.1f} |")
    return "\n".join(out)


def table_grammar(name="p3_top30_grammar.csv", super_sel=True):
    t = pd.read_csv(RES / name)
    out = ["| # | School | APS | A*/A | Value added [95% CI] | P8 | Cam/100 |" + (" Super-sel. |" if super_sel else ""),
           "|---|---|---|---|---|---|---|" + ("---|" if super_sel else "")]
    for r in t.itertuples():
        ss = {"yes": "yes", "probable": "probable", "no": "no", "unassessed": "–"}.get(
            r.super_selective if isinstance(r.super_selective, str) else "", "–")
        if r.urn == 136290:
            ss += " §"
        out.append(f"| {r.rank} | {short(r.name, r.urn)} | {r.aps_pooled:.1f} | {pct_cell(r.pct_astar_a)} | {va_cell(r)} | "
                   f"{sgn(r.progress8)} | {r.cam_acceptances_per100_est:.1f} |" + (f" {ss} |" if super_sel else ""))
    return "\n".join(out)


def table_alpha_quantiles():
    q = pd.read_csv(RES / "p3_alpha_quantiles.csv")
    order = ["independent", "selective", "partially_selective", "non_selective_other", "non_selective_highly_selective_area"]
    q = q.set_index("sector").loc[order]
    cols = [f"p{k}" for k in range(10, 100, 10)]
    out = ["| Kind of school | Schools | " + " | ".join(f"{k}th" for k in range(10, 100, 10)) + " |",
           "|---|---|" + "---|" * 9]
    for _, r in q.iterrows():
        out.append(f"| {r.label} | {r.schools:,} | " + " | ".join(sgn(r[c]) for c in cols) + " |")
    return "\n".join(out)


def table_alpha_deciles():
    t = pd.read_csv(RES / "p3_alpha_by_results_decile.csv").set_index(["sector", "decile"])
    out = ["| Tenth by results | Private: points | Private: value added | Grammar: points | Grammar: value added | "
           "Comprehensive: points | Comprehensive: value added |", "|---|---|---|---|---|---|---|"]
    for d in range(1, 11):
        lab = {1: "1 (best)", 10: "10 (weakest)"}.get(d, str(d))
        cells = []
        for sec in ("independent", "selective", "non_selective_other"):
            r = t.loc[(sec, d)]
            cells += [f"{r.aps_mean:.1f}", sgn(r.va_mean)]
        out.append(f"| {lab} | " + " | ".join(cells) + " |")
    return "\n".join(out)


v = values()
v["table_alpha_quantiles"] = table_alpha_quantiles()
v["table_bottom20_private"] = table_independent("p3_bottom20_private.csv")
v["table_bottom30_grammar"] = table_grammar("p3_bottom30_grammar.csv", super_sel=False)
v["table_alpha_deciles"] = table_alpha_deciles()
v["table_top30_independent"] = table_independent()
v["table_top20_boys"] = table_independent("p3_top20_boys.csv")
v["table_top20_girls"] = table_independent("p3_top20_girls.csv")
v["REVIEW-LINE-2"] = ""
v["table_top30_grammar"] = table_grammar()
tmpl = (ROOT / "writeup" / "article.md.tmpl").read_text(encoding="utf-8")
text = tmpl.format_map(v)
left = re.findall(r"\{[a-z0-9_]+\}", text)
assert not left, left
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "index.md").write_text(text, encoding="utf-8")
print("wrote", OUT / "index.md", len(text.split()), "words")
