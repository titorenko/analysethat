"""Every number quoted in the write-up, computed from results/ and data/derived/ (and the engine where a value is
not stored). build_article.py fills the template with these; nothing in the article's numbers is typed by hand.

Usage (inspection): .venv/Scripts/python -I code/figures/article_values.py
"""
import math
import pathlib
import sys

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
RES, DER = ROOT / "results", ROOT / "data" / "derived"
sys.path.insert(0, str(ROOT / "code" / "engine"))
import lifetime as L  # noqa: E402


def k(x):
    return f"£{x / 1000:,.0f}k" if x >= 0 else f"−£{-x / 1000:,.0f}k"


def knpv(x):
    return f"+£{x / 1000:,.0f}k" if x >= 0 else f"−£{-x / 1000:,.0f}k"


def k1(x):
    return f"£{x / 1000:,.1f}k"


def pct(x, d=0):
    return f"{100 * x:.{d}f}%".replace("-", "−")


def ordinal(n):
    n = int(round(n))
    return f"{n}{'th' if 10 <= n % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')}"


def sgn(x, d=2):
    s = f"{x:+.{d}f}"
    return "0.00" if s in ("+0.00", "-0.00") else s.replace("-", "−")


def values():
    v = {}
    # --- P2 national
    wp = pd.read_csv(RES / "p2_wp_series.csv")
    w = wp[(wp.by_age == 19)].sort_values("cohort_age15").iloc[-1]
    v["wp_cohort"] = w.cohort_age15
    for s, lab in (("independent", "ind"), ("selective_state", "gra"), ("other_state", "oth")):
        v[f"he_{lab}"] = f"{w[f'he_rate__{s}']:.1f}%"
        v[f"ht_{lab}"] = f"{w[f'high_tariff_rate__{s}']:.1f}%"
    cam = pd.read_csv(RES / "p2_cambridge_per_student_england.csv").set_index(["cycle", "sector"])
    v["cam23_gra"] = f"{cam.loc[(2023, 'selective_state'), 'per_1000_england']:.1f}"
    v["cam23_ind_lo"] = f"{cam.loc[(2023, 'independent'), 'per_1000_england_home_only']:.1f}"
    v["cam23_ind_hi"] = f"{cam.loc[(2023, 'independent'), 'per_1000_england']:.1f}"
    v["cam23_oth"] = f"{cam.loc[(2023, 'other_state'), 'per_1000_england']:.1f}"
    v["cam13_ind_hi"] = f"{cam.loc[(2013, 'independent'), 'per_1000_england']:.1f}"
    v["cam13_ind_lo"] = f"{cam.loc[(2013, 'independent'), 'per_1000_england_home_only']:.1f}"
    v["cam13_gra"] = f"{cam.loc[(2013, 'selective_state'), 'per_1000_england']:.1f}"
    g23 = cam.loc[(2023, "selective_state"), "per_1000_england"]
    v["cam23_lead_lo"] = pct(g23 / cam.loc[(2023, "independent"), "per_1000_england"] - 1)
    v["cam23_lead_hi"] = pct(g23 / cam.loc[(2023, "independent"), "per_1000_england_home_only"] - 1)
    ct = pd.read_csv(RES / "p2_cambridge_type.csv")
    c25 = ct[ct.cycle == 2025].set_index("type").offer_rate
    v["offer25_gra"], v["offer25_ind"], v["offer25_com"] = (f"{c25[t]:.1f}%" for t in ("grammar", "independent", "comprehensive"))
    ks5 = pd.read_csv(RES / "p2_ks5_by_sector.csv")
    ks5 = ks5[ks5.exam_cohort == "A level"].set_index("sector")
    for s, lab in (("independent", "ind"), ("selective", "gra"), ("non_selective_other", "com"),
                   ("non_selective_highly_selective_area", "sm"), ("partially_selective", "ps")):
        v[f"aps_{lab}"] = f"{ks5.loc[s, 'aps_per_entry']:.1f}"
        v[f"va_{lab}"] = sgn(ks5.loc[s, "value_added_entry_weighted"])
    p8 = pd.read_csv(RES / "p4_progress8_by_sector.csv").set_index("sector")
    for s, lab in (("selective", "gra"), ("non_selective_other", "com"), ("non_selective_highly_selective_area", "sm"),
                   ("partially_selective", "ps")):
        v[f"p8_{lab}"] = sgn(p8.loc[s, "p8_pupil_weighted"])
    ons = pd.read_csv(RES / "p2_ons_percentiles.csv").set_index("percentile")
    for q in (10, 25, 50, 75, 90, 95, 99):
        v[f"ons_r{q}"] = f"{ons.loc[q, 'ratio_independent_to_nonfsm']:.2f}"
    v["ons_p99_ind"] = k(ons.loc[99, "independent"])
    v["ons_p99_st"] = k(ons.loc[99, "state_non_fsm"])
    kb = pd.read_csv(RES / "p4_ons_ks4_bands.csv")
    v["ons_ks4_lo"], v["ons_ks4_hi"] = (f"{kb.ratio_independent_to_non_fsm.min():.2f}",
                                        f"{kb.ratio_independent_to_non_fsm.max():.2f}")
    # --- P3
    ti = pd.read_csv(RES / "p3_top30_independent.csv")
    tg = pd.read_csv(RES / "p3_top30_grammar.csv")
    v["t30i_fee_med"] = k1(ti.fee_senior_day_2627.median())
    v["t30i_fee_min"], v["t30i_fee_max"] = k1(ti.fee_senior_day_2627.min()), k1(ti.fee_senior_day_2627.max())
    v["t30i_rho"] = sgn(ti[["fee_senior_day_2627", "value_added"]].corr(method="spearman").iloc[0, 1])
    v["t30i_rho_n"] = int(ti[["fee_senior_day_2627", "value_added"]].dropna().shape[0])
    v["t30i_rem_med"] = pct(ti.remission_share.median(), 1)
    v["t30i_va_med"], v["t30g_va_med"] = sgn(ti.value_added.median()), sgn(tg.value_added.median())
    v["t30i_va_pct"] = ordinal(ti.value_added_comp_pctile.median())
    v["t30g_va_pct"] = ordinal(tg.value_added_comp_pctile.median())
    v["t30i_va_ci_pos"] = int((ti.value_added_lower_ci > 0).sum())
    v["t30g_va_ci_pos"] = int((tg.value_added_lower_ci > 0).sum())
    v["t30i_cam"], v["t30g_cam"] = (f"{x.cam_acceptances_per100_est.median():.1f}" for x in (ti, tg))
    v["t30i_aps"], v["t30g_aps"] = (f"{x.aps_pooled.median():.1f}" for x in (ti, tg))
    v["t30g_p8"] = sgn(tg.progress8.median())
    isc = L.annual_fees()
    v["isc_senior"] = k1(isc["senior"])
    u = pd.read_csv(RES / "p3_universe.csv")
    comp = u[u.sector == "non_selective_other"]
    v["comp_n"] = f"{comp.aps_pooled.notna().sum():,}"
    v["comp_n_va"] = f"{comp.value_added.notna().sum():,}"
    v["comp_va_beat"] = pct((comp.value_added > ti.value_added.median()).mean())
    v["t30i_rem_n"] = int(ti.remission_share.notna().sum())
    k5 = pd.read_csv(DER / "ks5_school.csv", dtype={"urn": str})
    k5 = k5[(k5.exam_cohort == "A level") & (k5.time_period == "2024/25")].merge(
        pd.read_csv(DER / "school_master.csv", dtype={"urn": str}, low_memory=False)[["urn", "sector"]], on="urn")
    v["ind_lowcov_n"] = int(((k5.sector == "independent") & (pd.to_numeric(k5.va_coverage) < 0.7)).sum())
    v["t30i_lowcov_n"] = int(ti.va_low_coverage.sum())
    ps = pd.read_csv(DER / "partially_selective.csv")
    v["ps_n"] = int((ps.classification == "partially_selective").sum())
    v["wp_cohorts_n"] = int(wp[wp.by_age == 19].cohort_age15.nunique())
    # --- P4 premiums
    pr = pd.read_csv(RES / "p4_premiums.csv")
    P = lambda sch, rt, sx, sc, age: math.exp(pr[(pr.school_type == sch) & (pr.route == rt) & (pr.sex == sx) & (pr.scenario == sc) & (pr.age == age)].premium_lp.iloc[0]) - 1
    v["prem_central"] = pct(P("private", "11-18", "men", "central", 40), 0)
    v["prem_high_m"] = pct(P("private", "11-18", "men", "high", 50))
    v["prem_high_w"] = pct(P("private", "11-18", "women", "high", 50))
    v["prem_low_m"] = pct(P("private", "11-18", "men", "low", 40), 1)
    v["prem_low_w"] = pct(P("private", "11-18", "women", "low", 40), 1)
    v["prem_g_high_m"] = pct(P("grammar", "11-18", "men", "high", 40), 1)
    v["prem_g_high_w"] = pct(P("grammar", "11-18", "women", "high", 40), 1)
    v["prem_sixth_c"] = pct(P("private", "16-18", "men", "central", 40), 1)
    v["prem_sixth_h"] = pct(P("private", "16-18", "men", "high", 40), 1)
    # --- P5 / P6
    be = pd.read_csv(RES / "p5_breakeven.csv")
    B = lambda sc, sx, q, rate="3.5% stepped", rt="11-18": be[(be.scenario == sc) & (be.sex == sx) & (be.percentile == q) & (be.rate == rate) & (be.route == rt) & (be.fee_type == "day_at_day_schools")].breakeven_premium.iloc[0]
    for sx in ("men", "women"):
        for q in (50, 90):
            v[f"be_B_{sx}_{q}"] = pct(B("B", sx, q))
            v[f"be_A_{sx}_{q}"] = pct(B("A", sx, q))
        v[f"be_B_{sx}_50_21"] = pct(B("B", sx, 50, "2.1% borrowing"))
    fees = pd.read_csv(RES / "p5_pv_fees.csv")
    v["pv_fees_35"] = k(fees[(fees.route == "11-18") & (fees.fee_type == "day_at_day_schools") & (fees.rate == "3.5% stepped")].pv_fees.iloc[0])
    npv = pd.read_csv(RES / "p6_npv.csv")
    N = npv[(npv.school_type == "private") & (npv.route == "11-18") & (npv.earnings_scenario == "B") & ~npv.ons_shaped]
    for sx in ("men", "women"):
        for sc in ("low", "central", "high"):
            r = N[(N.sex == sx) & (N.premium_scenario == sc) & (N.percentile_label == "typical")].iloc[0]
            v[f"npv_{sx}_{sc}"] = knpv(r["npv_3.5% stepped"])
            v[f"irr_{sx}_{sc}"] = pct(r.irr, 1)
            v[f"rank_{sx}_{sc}"] = ordinal(r.percentile)
            v[f"gross_{sx}_{sc}"] = k(r.gross_gain_undiscounted)
            v[f"net_{sx}_{sc}"] = k(r.net_gain_undiscounted)
            v[f"npv_{sx}_{sc}_21"] = knpv(r["npv_2.1% borrowing"])
            v[f"npv_{sx}_{sc}_top30"] = knpv(r["npv_3.5%_top30_fees"])
            v[f"be_typ_{sx}_{sc}"] = pct(L.breakeven(sx, r.percentile, "11-18", L.DISCOUNT["3.5% stepped"], None, "B"))
        c = N[(N.sex == sx) & (N.premium_scenario == "central") & (N.percentile_label == "typical")].iloc[0]
        v[f"top30_diff_{sx[0]}"] = k(c["npv_3.5% stepped"] - c["npv_3.5%_top30_fees"])
        r90 = N[(N.sex == sx) & (N.premium_scenario == "central") & (N.percentile_label == "P90")].iloc[0]
        v[f"npv_{sx}_central_p90"] = knpv(r90["npv_3.5% stepped"])
        v["fees_undisc"] = k(r.fees_undiscounted)
    for sx in ("men", "women"):
        for sc in ("central_lo95", "central_hi95"):
            r = N[(N.sex == sx) & (N.premium_scenario == sc) & (N.percentile_label == "typical")].iloc[0]
            v[f"npv_{sx}_{sc.split('_')[1]}"] = knpv(r["npv_3.5% stepped"])
    v["ci_lo"] = pct(P("private", "11-18", "men", "central_lo95", 40))
    v["ci_hi"] = pct(P("private", "11-18", "men", "central_hi95", 40))
    S6 = npv[(npv.school_type == "private") & (npv.route == "16-18") & (npv.earnings_scenario == "B") & ~npv.ons_shaped
             & (npv.percentile_label == "typical")]
    for sx in ("men", "women"):
        for sc in ("central", "high"):
            v[f"npv6_{sx}_{sc}"] = knpv(S6[(S6.sex == sx) & (S6.premium_scenario == sc)]["npv_3.5% stepped"].iloc[0])
        v[f"be6_{sx}_50"] = pct(B("B", sx, 50, rt="16-18"))
        v[f"rank6_{sx}"] = ordinal(S6[(S6.sex == sx) & (S6.premium_scenario == "central")].percentile.iloc[0])
    v["pv_fees6_35"] = k(fees[(fees.route == "16-18") & (fees.fee_type == "day_at_day_schools") & (fees.rate == "3.5% stepped")].pv_fees.iloc[0])
    reg = pd.read_csv(DER / "isc_fees_region_2026.csv")
    reg = reg[(reg.basis == "all_schools_2026") & (reg.fee_type == "day_at_day_schools") & (reg.statistic == "termly_fee_gbp_excl_vat")].drop_duplicates("region").set_index("region").value
    pv11 = fees[(fees.route == "11-18") & (fees.fee_type == "day_at_day_schools") & (fees.rate == "3.5% stepped")].pv_fees.iloc[0]
    v["pv_fees_london"] = k(pv11 * reg["London"] / reg["all"])
    v["pv_fees_nw"] = k(pv11 * reg["North West"] / reg["all"])
    G = npv[(npv.school_type == "grammar") & (npv.earnings_scenario == "B") & ~npv.ons_shaped]
    for sx in ("men", "women"):
        v[f"g_high_p50_{sx}"] = knpv(G[(G.sex == sx) & (G.premium_scenario == "high") & (G.percentile_label == "P50")]["npv_3.5% stepped"].iloc[0])
    v["g_central"] = knpv(G[(G.premium_scenario == "central")]["npv_3.5% stepped"].iloc[0])
    gt = pd.read_csv(RES / "p5_grammar_tutoring_breakeven.csv")
    T = lambda tut, p, sx: pct(gt[(gt.scenario == "B") & (gt.percentile == 50) & (gt.tutoring_gbp == tut) & (gt.p_admit == p) & (gt.sex == sx)].breakeven_grammar_premium.iloc[0], 1)
    v["gt_3k_25_m"], v["gt_3k_25_w"] = T(3000, 0.25, "men"), T(3000, 0.25, "women")
    v["gt_8k_10_m"], v["gt_8k_10_w"] = T(8000, 0.1, "men"), T(8000, 0.1, "women")
    alt = pd.read_csv(RES / "p5_alternatives.csv")
    A = lambda item, sh=None: alt[(alt.item == item) & (alt.rate == "3.5% stepped") & ((alt.premium_share_of_house == sh) if sh else True)].pv_gbp.iloc[0]
    v["house_any_10"], v["house_any_20"] = k(A("house_premium_user_cost_7y", 0.10)), k(A("house_premium_user_cost_7y", 0.20))
    v["house_caused_10"], v["house_caused_20"] = k(A("house_move_caused_by_school_7y", 0.10)), k(A("house_move_caused_by_school_7y", 0.20))
    v["state_spend"], v["social_net"] = k(A("state_spend_avoided_11_18")), k(A("social_net_cost_11_18_ex_vat"))
    v["pv_fees_35_exvat"] = k(A("fees_11_18_day") / 1.2)
    tor = pd.read_csv(RES / "p6_tornado.csv").set_index(["sex", "input"])
    v["tor_m_rate_hi"] = knpv(tor.loc[("men", "discount rate"), "npv_high"])
    v["tor_m_p90"] = knpv(tor.loc[("men", "counterfactual rank"), "npv_high"])
    v["tor_m_top30"] = knpv(tor.loc[("men", "fees"), "npv_low"])
    v["tor_m_disc"] = knpv(tor.loc[("men", "bursary or sibling discount"), "npv_high"])
    v["growth"] = pct(L.GROWTH, 1)
    v["emp_m"], v["emp_w"] = pct(L.EMPLOYMENT["men"], 1), pct(L.EMPLOYMENT["women"], 1)
    ev = pd.read_csv(DER / "evidence_table.csv")
    v["ev_rows"], v["ev_verified"] = len(ev), int((ev.status == "verified").sum())
    v["ev_studies"] = ev.study.nunique()
    e = ev.set_index("row_id")
    for rid in ("GMMZ2012-19", "GMMZ2012-21", "GMMZ2012-22", "GMMZ2012-24", "GHV2017-04", "GHV2017-13", "GAHH2020-02",
                "CV2014-19", "CV2014-23", "DFM2002-04", "PJ2023-03", "CDB2016-03", "CDB2016-07", "CDB2016-11",
                "CDB2016-15"):
        r = e.loc[rid]
        assert r.measure == "log_points" and r.status == "verified", rid
        v["ev_" + rid.replace("-", "_").lower()] = pct(math.exp(r.estimate) - 1).replace("−", "−")
    for rid in ("HAGH2020-03", "HAGH2020-07"):
        r = e.loc[rid]
        assert r.status == "verified", rid
        v["ev_" + rid.replace("-", "_").lower()] = f"{100 * r.estimate:.0f}"
    v["ev_aghh2024_02"] = sgn(e.loc["AGHH2024-02"].estimate)
    v["ev_aghh2024_04"] = sgn(e.loc["AGHH2024-04"].estimate)
    r = e.loc["DFM2002-08"]
    assert r.status == "verified" and r.comparison == "private_vs_comprehensive"
    v["ev_dfm2002_08"] = pct(math.exp(r.estimate) - 1)
    pairs = [("GMMZ2012-01", "GMMZ2012-19"), ("GMMZ2012-07", "GMMZ2012-21"), ("GMMZ2012-13", "GMMZ2012-23"),
             ("GMMZ2012-08", "GMMZ2012-22"), ("GMMZ2012-14", "GMMZ2012-24"),
             ("GHV2017-02", "GHV2017-04"), ("GHV2017-11", "GHV2017-13"), ("GAHH2020-01", "GAHH2020-02")]
    shares = [1 - e.loc[adj].estimate / e.loc[raw].estimate for raw, adj in pairs]
    v["adj_removed_min"], v["adj_removed_max"] = pct(min(shares)), pct(max(shares))
    v["ev_unverified"] = int((ev.status != "verified").sum())
    v["ev_sw2018_grammar"] = f"{e.loc['SW2018-03'].estimate:.2f}" if "SW2018-03" in e.index else "n/a"
    for key, sec in (("ind", "independent"), ("gra", "selective"), ("ps", "partially_selective"),
                     ("com", "non_selective_other"), ("sm", "non_selective_highly_selective_area")):
        v[f"va_med_{key}"] = sgn(u[u.sector == sec].value_added.median())
    # ---- top 20 private schools open to boys / to girls (§3, §6) and house costs by region (§7.1)
    tb, tgl = pd.read_csv(RES / "p3_top20_boys.csv"), pd.read_csv(RES / "p3_top20_girls.csv")
    tu = pd.concat([tb, tgl]).drop_duplicates("urn")
    for lab, t in (("t20b", tb), ("t20g", tgl)):
        day = t.fee_senior_day_2627.dropna()
        v[f"{lab}_fee_med"], v[f"{lab}_fee_min"], v[f"{lab}_fee_max"] = k1(day.median()), k1(day.min()), k1(day.max())
    v["t20_n"] = len(tu)
    v["t20_va_med"] = sgn(tu.value_added.median())
    v["t20_va_pct"] = ordinal(tu.value_added_comp_pctile.median())
    v["t20_va_ci_pos"] = int((tu.value_added_lower_ci > 0).sum())
    v["t20_rho"] = sgn(tu[["fee_senior_day_2627", "value_added"]].corr(method="spearman").iloc[0, 1])
    v["t20_rho_n"] = int(tu[["fee_senior_day_2627", "value_added"]].dropna().shape[0])
    v["t20_rem_med"] = pct(tu.remission_share.median(), 1)
    v["t20_rem_n"] = int(tu.remission_share.notna().sum())
    v["t20_lowcov_n"] = int(tu.va_low_coverage.sum())
    v["comp_va_beat"] = pct((comp.value_added > tu.value_added.median()).mean())
    info = pd.read_csv(sorted((ROOT / "data" / "raw" / "dfe_ks5").glob("*/ks5_institution_info_v*.csv"))[-1], dtype=str)
    uni = pd.read_csv(DER / "ks5_eligible_pooled.csv", dtype={"urn": str})
    pol = uni[uni.sector == "independent"].merge(info[["school_urn", "sex_policy"]].drop_duplicates("school_urn"),
                                                  left_on="urn", right_on="school_urn", how="left")
    v["boys_only_n"] = int((pol.sex_policy == "Boys").sum())
    co = pd.read_csv(DER / "coed_entry.csv", dtype={"urn": str}).set_index("urn")
    tb_s = tb.assign(urn=tb.urn.astype(str))
    no_girls = [u for u in tb_s.urn if u in co.index and co.at[u, "girls_at_11_or_13_for_2027_entry"] == "no"]
    v["boys_list_boysonly_n"] = int((tb_s.sex_policy == "Boys").sum() + len(no_girls))
    v["girls_excluded_names"] = ", ".join(tb_s.set_index("urn").loc[no_girls, "name"].str.replace("The ", "", regex=False))
    t6 = pd.read_csv(RES / "p6_top20.csv")
    for lab, lst in (("t20b", "boys"), ("t20g", "girls")):
        x = t6[t6.list == lst]
        f = x.iloc[0]
        v[f"{lab}_fee_senior"] = k1(f.fee_senior_2627_median / L.cpi_index(2026))
        v[f"{lab}_fee_sixth"] = k1(f.fee_sixth_2627_median / L.cpi_index(2026))
        v[f"{lab}_pv_fees"] = k(f.pv_fees_35)
        v[f"{lab}_n_day"] = int(f.schools_with_day_fee)
        for sc in ("low", "central", "high", "central_lo95", "central_hi95"):
            name = {"central_lo95": "lo95", "central_hi95": "hi95"}.get(sc, sc)
            for ql, suf in (("typical", ""), ("P75", "_p75"), ("P90", "_p90")):
                r = x[(x.premium_scenario == sc) & (x.percentile_label == ql)].iloc[0]
                v[f"{lab}_npv_{name}{suf}"] = knpv(r.npv_35)
                if ql == "typical":
                    v[f"{lab}_irr_{name}"] = pct(r.irr, 1) if pd.notna(r.irr) else "below −5%"
                    v[f"{lab}_be_{name}"] = pct(r.breakeven_35)
        v[f"{lab}_npv_central_abs"] = k(-x[(x.premium_scenario == "central") & (x.percentile_label == "typical")].npv_35.iloc[0])
    nb = len(tb) - v["t20b_n_day"]
    ng = len(tgl) - v["t20g_n_day"]
    names = [r.name for r in tb.itertuples() if pd.isna(r.fee_senior_day_2627)]
    v["t20b_boarding_note"] = (f"Boarding-only schools ({', '.join(names)}) are left out of the boys' median."
                               if nb else "") + ("" if not ng else " Some girls' schools without a day fee are left out of the median.")
    for sx in ("men", "women"):
        r = N[(N.sex == sx) & (N.premium_scenario == "central") & (N.percentile_label == "typical")].iloc[0]
        v[f"npv_{sx}_central_abs"] = k(-r["npv_3.5% stepped"])
    hr = pd.read_csv(RES / "p5_house_regions.csv")
    hr = hr[hr.rate == "3.5% stepped"]
    for key, region_name in (("eng", "England"), ("se", "South East"), ("lon", "London")):
        x = hr[hr.region == region_name].set_index("premium_share")
        v[f"house_{key}_price"] = f"£{x.house_price.iloc[0]:,.0f}"
        v[f"house_{key}_prem_15"] = k(x.loc[0.15, "premium_gbp"])
        v[f"house_{key}_sdlt_15"] = k1(x.loc[0.15, "sdlt_whole_new_home"])
        v[f"house_{key}_sdlt_prem_15"] = k1(x.loc[0.15, "sdlt_on_premium"])
        v[f"house_{key}_caused_15"] = k(x.loc[0.15, "pv_move_caused_by_school"])
        for sh, suf in ((0.10, "10"), (0.20, "20")):
            v[f"house_{key}_any_{suf}"] = k(x.loc[sh, "pv_moving_anyway"])
            v[f"house_{key}_caused_{suf}"] = k(x.loc[sh, "pv_move_caused_by_school"])
    v["house_growth"] = pct(L.REAL["house_growth"][0], 2)
    v["selling_cost"], v["moving_cost"] = pct(L.SELLING_COST, 1), f"£{L.MOVING_COST:,}"
    lon = hr[hr.region == "London"].set_index("premium_share").pv_move_caused_by_school
    v["house_lon_share_lo"], v["house_lon_share_hi"] = pct(lon[0.10] / (pv11 * reg["London"] / reg["all"])), pct(lon[0.20] / (pv11 * reg["London"] / reg["all"]))
    # ---- A-level value added ("alpha") by tenths (§2.4)
    td = pd.read_csv(RES / "p3_alpha_by_results_decile.csv").set_index(["sector", "decile"]).va_mean
    v["va_d1_com"], v["va_d10_com"] = sgn(td[("non_selective_other", 1)]), sgn(td[("non_selective_other", 10)])
    v["va_d10_com_abs"] = f"{abs(td[('non_selective_other', 10)]):.2f}"
    v["va_d10_gra"] = sgn(td[("selective", 10)])
    pr = td.loc["independent"]
    v["va_priv_min_1_9"], v["va_priv_max_1_9"] = sgn(pr.loc[1:9].min()), sgn(pr.loc[1:9].max())
    v["va_d1_priv"], v["va_d5_priv"], v["va_d10_priv"] = sgn(pr[1]), sgn(pr[5]), sgn(pr[10])
    # ---- bottom lists (§3.5, §3.6)
    b20 = pd.read_csv(RES / "p3_bottom20_private.csv")
    b30 = pd.read_csv(RES / "p3_bottom30_grammar.csv")
    v["b20p_aps_lo"], v["b20p_aps_hi"] = f"{b20.aps_pooled.min():.1f}", f"{b20.aps_pooled.max():.1f}"
    vb = b20.value_added.dropna()
    v["b20p_va_med"], v["b20p_va_n"], v["b20p_va_neg_n"] = sgn(vb.median()), len(vb), int((vb < 0).sum())
    bl = pd.read_csv(DER / "bottom20_private.csv")
    from13 = bl[bl.age_range.str.split(" to ").str[0].astype(int) >= 13]
    v["b20p_from13_n"] = {1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five"}.get(len(from13), str(len(from13)))
    v["b20p_from13_names"] = "; ".join(f"{r.name}, ages {r.age_range}" for r in from13.itertuples())
    fees_b = b20.fee_senior_day_2627.dropna()
    for lst in ("p3_top20_boys.csv", "p3_top20_girls.csv"):  # their captions carry no † note
        assert pd.read_csv(RES / lst).fee_senior_day_2627_vat_stated.ne(False).all(), lst
    novat = b20[b20.fee_senior_day_2627_vat_stated.eq(False)]
    v["b20p_fee_note"] = (f"Median day fee {k1(fees_b.median())} ({k1(fees_b.min())}-{k1(fees_b.max())}), "
                          f"for the {len(fees_b)} schools whose 2026/27 fee was found." if len(fees_b) else "") + (
        " † The fee sheet does not say whether VAT is included." if len(novat) else "")
    cl = pd.read_csv(DER / "bottom_closed_excluded.csv")
    cl = cl[cl.sector == "independent"].assign(d=lambda d: pd.to_datetime(d.close_date, dayfirst=True))
    v["b20p_closed_note"] = " ".join(f"{r.name}, which closed on {r.d.day} {r.d:%B %Y}, would otherwise be on the list "
                                     "and is left out (it still counts in the national figures, which describe "
                                     "2023/24 and 2024/25)." for r in cl.itertuples())
    # schools whose DfE A-level cohort is larger than their whole roll on the schools register
    odd = bl.merge(b20[["urn", "pupils"]], on="urn")
    odd = odd[odd[["n_2023", "n_2024"]].min(axis=1) > odd.pupils]
    v["b20p_register_note"] = " ".join(
        f"{r.name} has {r.pupils:.0f} pupils on the schools register but {r.n_2023:.0f} and {r.n_2024:.0f} A-level "
        "students in DfE's results for the two years, so its figures may not describe an ordinary sixth form."
        for r in odd.itertuples())
    v["b30g_aps_lo"], v["b30g_aps_hi"] = f"{b30.aps_pooled.min():.1f}", f"{b30.aps_pooled.max():.1f}"
    v["b30g_va_med"], v["b30g_p8_med"] = sgn(b30.value_added.median()), sgn(b30.progress8.median())
    v["b30g_pa_med"] = pct(b30.pa_high_pct_of_known.median() / 100)
    v["t30g_pa_med"] = pct(tg.pa_high_pct_of_known.median() / 100)
    return v


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for key, val in values().items():
        print(f"{key:24s} {val}")
