"""Separate cost-benefit for the top 20 private schools open to boys (boys, men's earnings) and open to girls
(girls, women's earnings), using those schools' own fees rather than the national average (user request).

Fees: median 2026/27 senior and sixth-form day fees of each list (incl. VAT), deflated by one year of CPI to
2025/26 prices; schools without a day fee (boarding only) are left out of the median and counted. Premiums: the P4
scenarios for private 11-18 (no school-specific earnings evidence exists). Earnings scenario B. Ranks: each
scenario's implied typical rank, and P75 and P90, since pupils at the most selective schools may sit higher.

Usage: .venv/Scripts/python -I code/engine/run_p6_top20.py data/derived results
Writes results/p6_top20.csv.
"""
import math
import pathlib
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import lifetime as L  # noqa: E402

D, R = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
prem = pd.read_csv(R / "p4_premiums.csv")
prem = prem[(prem.school_type == "private") & (prem.route == "11-18")]
SCHED = {k: dict(zip(g.age, g.premium_lp)) for k, g in prem.groupby(["sex", "scenario"])}
cfr = pd.read_csv(R / "p5_counterfactual_rank.csv")
cfr = cfr[cfr.private_percentile == 50].sort_values("assumed_causal_premium")
d35, d21 = L.DISCOUNT["3.5% stepped"], L.DISCOUNT["2.1% borrowing"]


def premium(sex, scen):
    s = SCHED[(sex, scen)]
    return lambda age: math.exp(s[age]) - 1


def typical_rank(sex, scen):
    p30 = math.exp(SCHED[(sex, scen)][30]) - 1
    return float(np.interp(p30, cfr.assumed_causal_premium, cfr.counterfactual_rank_state_non_fsm))


def npv(sex, q, scen, disc, fees):
    f = premium(sex, scen)
    gain = L.pv_net(sex, q, f, disc, 11, scenario="B") - L.pv_net(sex, q, 0.0, disc, 11, scenario="B")
    return gain - L.pv_fees("11-18", disc, fees=fees)


def irr(sex, q, scen, fees):
    lo, hi = -0.05, 0.30
    d = lambda r: (lambda t: (1 + r) ** -t)
    if npv(sex, q, scen, d(lo), fees) < 0:
        return None
    for _ in range(50):
        m = (lo + hi) / 2
        lo, hi = (m, hi) if npv(sex, q, scen, d(m), fees) > 0 else (lo, m)
    return lo


rows = []
for label, sex in (("boys", "men"), ("girls", "women")):
    t = pd.read_csv(R / f"p3_top20_{label}.csv")
    day = t.dropna(subset=["fee_senior_day_2627"])
    fees = {"senior": day.fee_senior_day_2627.median() / L.cpi_index(2026),
            "sixth_form": day.fee_sixth_day_2627.median() / L.cpi_index(2026)}
    for scen in ("low", "central_lo95", "central", "central_hi95", "high"):
        for qlab, q in (("typical", typical_rank(sex, scen)), ("P75", 75), ("P90", 90)):
            rows.append({"list": label, "sex": sex, "schools": len(t), "schools_with_day_fee": len(day),
                         "fee_senior_2627_median": day.fee_senior_day_2627.median(),
                         "fee_sixth_2627_median": day.fee_sixth_day_2627.median(),
                         "pv_fees_35": L.pv_fees("11-18", d35, fees=fees), "premium_scenario": scen,
                         "percentile_label": qlab, "percentile": q, "npv_35": npv(sex, q, scen, d35, fees),
                         "npv_21": npv(sex, q, scen, d21, fees), "irr": irr(sex, q, scen, fees),
                         "breakeven_35": L.breakeven(sex, q, "11-18", d35, L.pv_fees("11-18", d35, fees=fees), "B")})
res = pd.DataFrame(rows)
res.to_csv(R / "p6_top20.csv", index=False)
pd.set_option("display.width", 220)
print(res.assign(npv_35=(res.npv_35 / 1000).round(0), npv_21=(res.npv_21 / 1000).round(0),
                 irr=(100 * res.irr).round(1), be=(100 * res.breakeven_35).round(0), q=res.percentile.round(0))
      [["list", "premium_scenario", "percentile_label", "q", "npv_35", "npv_21", "irr", "be"]].to_string(index=False))
print(res.groupby("list")[["schools_with_day_fee", "fee_senior_2627_median", "fee_sixth_2627_median", "pv_fees_35"]]
      .first().round(0))
