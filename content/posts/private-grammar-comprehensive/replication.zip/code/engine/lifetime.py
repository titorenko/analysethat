"""Lifetime earnings and cost-benefit engine (PLAN v2 §4.5-4.6, phase P5).

The engine holds no estimate of the private- or grammar-school effect. Premiums are inputs (P4 supplies them); the
break-even premium needs none.

Conventions (every one is an assumption, stated in the write-up)
- Money: 2025/26 prices, deflated by CPI (the IFS 2026 convention). Every rate and growth figure is CPI-real;
  `REAL` records each one's basis and source, and gate G-real asserts them.
- Calendar: the decision is made in 2026/27 at the route's decision age (11 for 11-18), so age a falls in the
  fiscal year starting 2026 + a - decision age.
- Earnings: ASHE 2025 (provisional) Table 6.7a, full-time annual gross, by sex x age band, P10-P90; P95 and P99 =
  each band's P90 x the all-age P95/P90 and P99/P90 ratios (ASHE ad hoc 3105, full-time, UK, 2025). Profiles are
  linear between band mid-ages, extrapolated at 22 and 67. Reading a cross-section as a lifetime path at a fixed
  percentile assumes people keep their rank as they age (pseudo-cohort).
- Growth: real earnings grow GROWTH a year by calendar year from 2025, the ASHE base year.
- Premium: gross earnings x (1 + premium). A group gap applied at the child's counterfactual percentile assumes the
  child keeps the same rank whichever school they attend (rank preservation). Public data cannot test it.
- Tax: 2026/27 income tax (rUK) and employee NI, with the personal-allowance taper. Thresholds are cash-frozen to
  2030/31 and CPI-uprated after, so they are constant in real terms from 2030/31 at the cash value / CPI index.
- Plan 5: 9% above a threshold of £25,168 in 2025/26 prices from 2030/31 (IFS 2026 Table B.2), constant real after
  (RPI is aligned to CPIH from 2030); zero real interest; balance LOAN0 at graduation (age 21); repayments at ages
  22-61 (written off 40 years after graduation). Both the private and state paths graduate.
- Employment: scenario A (full-time pay, employed at every age 22-67) and scenario B (all-employee pay weighted by
  the graduate employment rate by sex); see SCENARIOS.
"""
import pathlib

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
DER = ROOT / "data" / "derived"
AGES = range(22, 68)
GRID = (10, 20, 25, 30, 40, 50, 60, 70, 75, 80, 90, 95, 99)
BANDS = {"22-29": 25.5, "30-39": 34.5, "40-49": 44.5, "50-59": 54.5, "60+": 63.5}

# ---- real quantities: (value, price basis, source). Gate G-real asserts every basis is CPI-real.
REAL = {
    "growth": (0.017, "CPI-real", "OBR FRS July 2026 Table 2.1: average earnings 3.7% nominal less CPI 2.0% "
                                  "(BoE target, OBR long-run assumption)"),
    "fee_growth": (0.0, "CPI-real", "assumption; tornado 0-3%"),
    "plan5_interest": (0.0, "CPI-real", "Plan 5 interest is RPI; RPI aligned to CPIH from 2030; CPIH-CPI wedge "
                                        "(0.14pp in OBR 2030-31) ignored"),
    "rate_borrowing": (0.021, "CPI-real", "BoE effective rate on new mortgages Aug 2026, 4.60% nominal, less 2.5% "
                                          "inflation (between OBR CPI 2.0% and BoE 10y implied RPI 3.42% less the "
                                          "RPI-CPI wedge, about 3.0%)"),
    "rate_3_0": (0.030, "CPI-real", "Green Book discount-rate review recommendation, 0-30 years"),
    "rate_3_5_stepped": (0.035, "CPI-real", "Green Book STPR 3.5% years 0-30, 3.0% after (IFS 2026 convention)"),
    "rate_equity_5": (0.050, "CPI-real", "flagged sensitivity: equity return, NOT risk-adjusted; UK figure unverified"),
}
GROWTH = REAL["growth"][0]
LOAN0 = 56_700      # IFS 2026 footnote 22: mean initial loan outlay £56,700 undiscounted (£53,500 GB-discounted)
PLAN5_THRESHOLD = 25_168
DISCOUNT = {
    "2.1% borrowing": lambda t: (1 + REAL["rate_borrowing"][0]) ** -t,
    "3.0%": lambda t: (1 + REAL["rate_3_0"][0]) ** -t,
    "3.5% stepped": lambda t: 1.035 ** -min(t, 30) * 1.030 ** -max(0, t - 30),
    "5% equity (flagged)": lambda t: (1 + REAL["rate_equity_5"][0]) ** -t,
}


def load_tax():
    t = pd.read_csv(DER / "tax_2026_27.csv").set_index("parameter").value
    return {k: float(t[k]) for k in ("personal_allowance", "basic_rate_band_width", "additional_rate_threshold_gross",
                                     "pa_taper_start", "ni_primary_threshold", "ni_upper_earnings_limit")}


def cpi_index(fy_start):
    """CPI price level of fiscal year fy_start relative to 2025/26 (OBR March 2026 forecast to 2030/31)."""
    c = pd.read_csv(DER / "obr_inflation_2026_03.csv").set_index("fiscal_year").cpi_pct
    idx = 1.0
    for y in range(2026, min(fy_start, 2030) + 1):
        idx *= 1 + c[f"{y}-{str(y + 1)[2:]}"] / 100
    return idx


TAX_CASH = load_tax()
REAL_THRESHOLD_INDEX = cpi_index(2030)          # thresholds frozen in cash to 2030/31, then CPI-uprated


def tax_ni(g, idx=REAL_THRESHOLD_INDEX):
    """Income tax + employee NI on gross g, thresholds = 2026/27 cash values / idx (idx=1: 2026/27 cash terms)."""
    t = {k: v / idx for k, v in TAX_CASH.items()}
    pa = max(0.0, t["personal_allowance"] - max(0.0, g - t["pa_taper_start"]) / 2)
    taxable = max(0.0, g - pa)
    band = t["basic_rate_band_width"]
    tax = (0.2 * min(taxable, band) + 0.4 * max(0.0, min(taxable, t["additional_rate_threshold_gross"]) - band)
           + 0.45 * max(0.0, g - t["additional_rate_threshold_gross"]))
    ni = (0.08 * max(0.0, min(g, t["ni_upper_earnings_limit"]) - t["ni_primary_threshold"])
          + 0.02 * max(0.0, g - t["ni_upper_earnings_limit"]))
    return tax + ni


def load_profiles(work_pattern):
    """{sex: {q: [earnings at ages 22..67 in 2025]}} in 2025/26 prices, before growth."""
    a = pd.read_csv(DER / "ashe2025_age_percentiles.csv")
    a = a[(a.measure == "annual_gross_pay_gbp") & (a.work_pattern == work_pattern) & a.age_band.isin(BANDS)]
    top = pd.read_csv(DER / "ashe_top_percentiles.csv")
    top = top[(top.year == 2025) & (top.measure == "annual_gross_pay_gbp") & (top.work_pattern == work_pattern)
              & (top.geography == "United Kingdom") & (top.sector == "all")].set_index(["sex", "statistic"]).value
    out = {}
    for sex, label in (("men", "male"), ("women", "female")):
        s = a[a.sex == label].set_index(["age_band", "statistic"]).value
        out[sex] = {}
        for q in GRID:
            if q in (95, 99):
                pts = [s[(b, "p90")] * top[(label, f"p{q}")] / top[(label, "p90")] for b in BANDS]
            else:
                pts = [s[(b, "median" if q == 50 else f"p{q}")] for b in BANDS]
            mids = list(BANDS.values())
            path = []
            for age in AGES:
                i = 0 if age < mids[1] else len(mids) - 2 if age >= mids[-2] else next(
                    j for j in range(len(mids) - 1) if mids[j] <= age < mids[j + 1])
                w = (age - mids[i]) / (mids[i + 1] - mids[i])
                path.append(pts[i] + w * (pts[i + 1] - pts[i]))
            out[sex][q] = path
    return out


PROFILES = {wp: load_profiles(wp) for wp in ("full_time", "all")}


def graduate_employment():
    """DfE Graduate labour market statistics 2024, England: graduate employment rate by sex (ages 16-64)."""
    g = pd.read_csv(DER / "glms_2024_employment.csv")
    g = g[(g.measure == "employment_rate") & (g.graduate_type == "Graduate") & (g.breakdown_topic == "sex")]
    v = g.set_index("breakdown").value_pct / 100
    return {"men": float(v["Male"]), "women": float(v["Female"])}


# Earnings scenarios (PLAN §4.5). A: full-time pay, employed every year 22-67 (an upper bound on any gain).
# B: pay of all employees (full- and part-time, ASHE 'all'), weighted each year by the graduate employment rate
# for the sex; no employment data exist by sex x age or beyond 64, so the rate is flat. A percentage premium is
# applied to annual pay in both: hourly premiums carry over only if school type does not change hours or
# employment (assumed, no estimate).
EMPLOYMENT = graduate_employment()
SCENARIOS = {"A": "full_time", "B": "all"}


def earnings(sex, q, age, decision_age=11, scenario="A"):
    """Counterfactual gross earnings at age, in 2025/26 prices, with calendar growth from 2025."""
    prof = PROFILES[SCENARIOS[scenario]][sex]
    i = age - AGES.start
    lo = max(p for p in GRID if p <= q)
    hi = min(p for p in GRID if p >= q)
    e = prof[lo][i] if lo == hi else prof[lo][i] + (q - lo) / (hi - lo) * (prof[hi][i] - prof[lo][i])
    return e * (1 + GROWTH) ** (2026 + age - decision_age - 2025)


def pv_net(sex, q, premium, disc, decision_age, loan0=LOAN0, scenario="A"):
    """PV at decision_age of net earnings (after tax, NI, Plan 5) for ages 22-67. premium: float or f(age).
    Scenario B weights each year by the employment rate; the loan runs along the employed path."""
    prem = premium if callable(premium) else (lambda age: premium)
    w = 1.0 if scenario == "A" else EMPLOYMENT[sex]
    bal, total = loan0, 0.0
    for age in AGES:
        g = earnings(sex, q, age, decision_age, scenario) * (1 + prem(age))
        repay = min(bal, 0.09 * max(0.0, g - PLAN5_THRESHOLD)) if age <= 61 else 0.0
        bal = (bal - repay) * (1 + REAL["plan5_interest"][0])
        total += w * (g - tax_ni(g) - repay) * disc(age - decision_age)
    return total


# ---- costs
ROUTES = {  # route -> (decision age, [(ISC phase, ages)])
    "11-18": (11, [("senior", range(11, 16)), ("sixth_form", range(16, 18))]),
    "7-18": (7, [("junior", range(7, 11)), ("senior", range(11, 16)), ("sixth_form", range(16, 18))]),
    "16-18": (16, [("sixth_form", range(16, 18))]),
    "13-18": (13, [("senior", range(13, 16)), ("sixth_form", range(16, 18))]),
}


def annual_fees(fee_type="day_at_day_schools"):
    """ISC Census 2026 (2025/26 fees) termly fee x 3 terms x 1.2 VAT, by phase."""
    f = pd.read_csv(DER / "isc_fees_2026.csv")
    f = f[(f.table == "5.1") & (f.statistic == "termly_fee_gbp_excl_vat") & (f.fee_type == fee_type)]
    return {r.phase: r.value * 3 * 1.2 for r in f.itertuples()}


def pv_fees(route, disc, fee_type="day_at_day_schools", fee_growth=REAL["fee_growth"][0], fees=None):
    """PV at the decision age; fees: optional {phase: annual fee} replacing the ISC averages."""
    dec, phases = ROUTES[route]
    fee = annual_fees(fee_type) if fees is None else fees
    return sum(fee[ph] * (1 + fee_growth) ** (age - dec + 1) * disc(age - dec) for ph, ages in phases for age in ages)


def breakeven(sex, q, route, disc, cost=None, scenario="A"):
    """Flat gross premium at which PV of the net earnings gain equals PV of fees (bisection, 0-500%)."""
    dec = ROUTES[route][0]
    cost = pv_fees(route, disc) if cost is None else cost
    ref = pv_net(sex, q, 0.0, disc, dec, scenario=scenario)
    lo, hi = 0.0, 5.0
    for _ in range(60):
        m = (lo + hi) / 2
        lo, hi = (m, hi) if pv_net(sex, q, m, disc, dec, scenario=scenario) - ref < cost else (lo, m)
    return lo


def irr(sex, q, route, premium, fee_type="day_at_day_schools", scenario="A"):
    """Real internal rate of return of fees vs the net earnings gain (bisection on a flat rate, -5% to 30%)."""
    dec = ROUTES[route][0]

    def npv(r):
        d = lambda t: (1 + r) ** -t
        return (pv_net(sex, q, premium, d, dec, scenario=scenario) - pv_net(sex, q, 0.0, d, dec, scenario=scenario)
                - pv_fees(route, d, fee_type))
    lo, hi = -0.05, 0.30
    if npv(lo) < 0:
        return None
    for _ in range(60):
        m = (lo + hi) / 2
        lo, hi = (m, hi) if npv(m) > 0 else (lo, m)
    return lo


# ---- alternatives to fees and the social view (PLAN §4.6)
def house_real_growth():
    """Mean real house-price growth, OBR EFO March 2026 forecast years 2026-27 to 2030-31 (house prices less CPI)."""
    o = pd.read_csv(DER / "obr_inflation_2026_03.csv")
    o = o[o.status == "forecast"]
    return float(((1 + o.house_price_pct / 100) / (1 + o.cpi_pct / 100)).prod() ** (1 / len(o)) - 1)


REAL["house_growth"] = (house_real_growth(), "CPI-real", "OBR EFO March 2026 Tables 1.16 and 1.7: house prices less "
                                                          "CPI, geometric mean 2026-27 to 2030-31")
HOUSE_PRICE = 293_000   # UK HPI England, July 2026 (data/raw/ons_hpi/2026-10-10/ukhpi_england_july_2026.html)
# Average price paid by existing owners who move ("former owner occupier"), UK HPI July 2026, same saved page:
# the relevant price for a family moving into a catchment.
HOUSE_PRICES = {"England": 357_496, "South East": 476_549, "London": 693_923}
SDLT_MARGINAL = 0.05    # 5% on £250,001-£925,000 (data/raw/hmt/2026-10-10/sdlt_residential_rates.html)
SELLING_COST = 0.018    # estate agent about 1.5% + VAT: assumption, no source fetched; tornado 1-2.5%
MOVING_COST = 2_500     # removals and conveyancing for one move: assumption, no source fetched
SDLT_BANDS = ((125_000, 0.0), (250_000, 0.02), (925_000, 0.05), (1_500_000, 0.10), (float("inf"), 0.12))
STATE_SPEND = 7_800     # IFS secondary spending per pupil 2025-26 (state_funding_per_pupil.csv, recommended row)


def sdlt(price):
    """Residential SDLT, standard rates (gov.uk, 2026/27; no surcharge or first-time-buyer relief)."""
    tax, lo = 0.0, 0.0
    for hi, rate in SDLT_BANDS:
        tax += rate * max(0.0, min(price, hi) - lo)
        lo = hi
    return tax


def house_user_cost(share, disc, years=7, g=None, selling=SELLING_COST, caused=False, price=HOUSE_PRICE):
    """PV at purchase of a catchment premium P = share x price (default: the average England house), held for `years`.
    caused=False (the family would move anyway): pay P plus SDLT at the marginal rate now, sell P grown at real
    house-price growth less selling costs; the financing cost is the discount rate.
    caused=True (the school causes the move): additionally the SDLT on the rest of the new home, selling costs on the
    old home (taken as the average house) and one move's costs. Price risk is not modelled."""
    g = REAL["house_growth"][0] if g is None else g
    p = share * price
    marginal_sdlt = sdlt(price + p) - sdlt(price)
    cost = p + marginal_sdlt - p * (1 + g) ** years * (1 - selling) * disc(years)
    if caused:
        cost += sdlt(price) + selling * price + MOVING_COST
    return cost


def pv_state_spend(route, disc):
    """PV of state secondary spending avoided over the route's ages 11+ (social view; no primary figure is used)."""
    dec, phases = ROUTES[route]
    return sum(STATE_SPEND * disc(age - dec) for _, ages in phases for age in ages if age >= 11)
