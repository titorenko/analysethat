"""P5 outputs that need no premium estimate: PV of fees and the break-even gross premium by earnings scenario x
sex x counterfactual percentile x route x discount rate (PLAN v2 §4.6). Day fees at day schools; boarding as a
comparison row.

Usage: .venv/Scripts/python -I code/engine/run_p5.py results
Writes results/p5_pv_fees.csv and results/p5_breakeven.csv.
"""
import pathlib
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import lifetime as L  # noqa: E402

R = pathlib.Path(sys.argv[1])
R.mkdir(parents=True, exist_ok=True)
QS = (10, 25, 50, 75, 90, 95, 99)

fees = []
for route in L.ROUTES:
    for ft in ("day_at_day_schools", "boarding"):
        for rate, d in L.DISCOUNT.items():
            fees.append({"route": route, "fee_type": ft, "rate": rate, "pv_fees": L.pv_fees(route, d, ft)})
fees = pd.DataFrame(fees)
fees.to_csv(R / "p5_pv_fees.csv", index=False)

rows = []
for scen in L.SCENARIOS:
    for route in L.ROUTES:
        for ft in ("day_at_day_schools", "boarding") if route == "11-18" else ("day_at_day_schools",):
            for rate, d in L.DISCOUNT.items():
                cost = L.pv_fees(route, d, ft)
                for sex in ("men", "women"):
                    for q in QS:
                        rows.append({"scenario": scen, "route": route, "fee_type": ft, "rate": rate, "sex": sex,
                                     "percentile": q, "pv_fees": cost,
                                     "breakeven_premium": L.breakeven(sex, q, route, d, cost, scen)})
be = pd.DataFrame(rows)
be.to_csv(R / "p5_breakeven.csv", index=False)

pd.set_option("display.width", 200)
print(fees[fees.fee_type == "day_at_day_schools"].pivot_table(index="route", columns="rate", values="pv_fees").round(0))
for scen in L.SCENARIOS:
    h = be[(be.scenario == scen) & (be.route == "11-18") & (be.fee_type == "day_at_day_schools")]
    print(f"\nScenario {scen}: break-even gross premium, 11-18 day, %:")
    print(h.assign(v=100 * h.breakeven_premium).pivot_table(index="percentile", columns=["rate", "sex"],
                                                           values="v").round(1))
    for route in ("7-18", "13-18", "16-18"):
        x = be[(be.scenario == scen) & (be.route == route) & (be.rate == "3.5% stepped")]
        print(f"{route}, 3.5% stepped:", {(r.sex, r.percentile): round(100 * r.breakeven_premium, 1)
                                          for r in x.itertuples() if r.percentile in (25, 50, 75, 90)})

alt = []
for rate, d in L.DISCOUNT.items():
    for share in (0.05, 0.10, 0.15, 0.20):
        alt.append({"item": "house_premium_user_cost_7y", "rate": rate, "premium_share_of_house": share,
                    "premium_gbp": share * L.HOUSE_PRICE, "pv_gbp": L.house_user_cost(share, d)})
        alt.append({"item": "house_move_caused_by_school_7y", "rate": rate, "premium_share_of_house": share,
                    "premium_gbp": share * L.HOUSE_PRICE, "pv_gbp": L.house_user_cost(share, d, caused=True)})
    fees11 = L.pv_fees("11-18", d)
    alt.append({"item": "fees_11_18_day", "rate": rate, "pv_gbp": fees11})
    alt.append({"item": "state_spend_avoided_11_18", "rate": rate, "pv_gbp": L.pv_state_spend("11-18", d)})
    alt.append({"item": "social_net_cost_11_18", "rate": rate, "pv_gbp": fees11 - L.pv_state_spend("11-18", d)})
    # VAT is a transfer to the Treasury, not a resource cost: the social view uses fees excluding VAT
    alt.append({"item": "social_net_cost_11_18_ex_vat", "rate": rate,
                "pv_gbp": fees11 / 1.2 - L.pv_state_spend("11-18", d)})
alt = pd.DataFrame(alt)
alt.to_csv(R / "p5_alternatives.csv", index=False)
print("\nHouse-premium user cost (7 years), fees and social net cost, PV £:")
print(alt.assign(k=alt.item + alt.premium_share_of_house.map(lambda s: "" if pd.isna(s) else f" {s:.0%}"))
      .pivot_table(index="k", columns="rate", values="pv_gbp").round(0))

# House-move cost at movers' prices (UK HPI former-owner-occupier averages), with stamp duty shown separately
house = []
for region, price in L.HOUSE_PRICES.items():
    for share in (0.10, 0.15, 0.20):
        p_ = share * price
        for rate in ("3.5% stepped", "2.1% borrowing"):
            d = L.DISCOUNT[rate]
            house.append({"region": region, "house_price": price, "premium_share": share, "premium_gbp": p_,
                          "rate": rate, "sdlt_whole_new_home": L.sdlt(price + p_),
                          "sdlt_on_premium": L.sdlt(price + p_) - L.sdlt(price),
                          "selling_cost_old_home": L.SELLING_COST * price,
                          "pv_moving_anyway": L.house_user_cost(share, d, price=price),
                          "pv_move_caused_by_school": L.house_user_cost(share, d, caused=True, price=price)})
house = pd.DataFrame(house)
house.to_csv(R / "p5_house_regions.csv", index=False)
print("\nHouse-move cost at movers' prices, 3.5% (£k):")
h = house[house.rate == "3.5% stepped"]
print(h.assign(**{c: (h[c] / 1000).round(1) for c in ("premium_gbp", "sdlt_whole_new_home", "sdlt_on_premium",
                                                         "pv_moving_anyway", "pv_move_caused_by_school")})
      [["region", "premium_share", "premium_gbp", "sdlt_whole_new_home", "sdlt_on_premium", "pv_moving_anyway",
        "pv_move_caused_by_school"]].to_string(index=False))

# Grammar route, cost side (PLAN §4.6): tutoring is paid for certain (at age 10, so valued x disc(-1) at 11), admission
# comes with probability p. Break-even grammar premium: p x PV gain = tutoring. p is a parameter: testers per place
# (grammar_super_selective.csv) gives the unconditional rate for a tester, not for a tutored, able child.
gram = []
d = L.DISCOUNT["3.5% stepped"]
for scen in L.SCENARIOS:
    for tutoring in (3000, 8000):
        for p in (0.1, 0.25, 0.5):
            for sex in ("men", "women"):
                for q in (50, 75, 90):
                    cost = tutoring * d(-1) / p
                    gram.append({"scenario": scen, "rate": "3.5% stepped", "tutoring_gbp": tutoring, "p_admit": p,
                                 "sex": sex, "percentile": q,
                                 "breakeven_grammar_premium": L.breakeven(sex, q, "11-18", d, cost, scen)})
gram = pd.DataFrame(gram)
gram.to_csv(R / "p5_grammar_tutoring_breakeven.csv", index=False)
g = gram[(gram.scenario == "B") & (gram.percentile == 50)]
print("\nGrammar: break-even premium that justifies tutoring, scenario B, P50, 3.5%, %:")
print(g.assign(v=100 * g.breakeven_grammar_premium).pivot_table(index=["tutoring_gbp", "p_admit"], columns="sex",
                                                                 values="v").round(2))

# Typical private pupil's counterfactual rank (PLAN §4.5): private percentile p's PAYE earnings at 30 deflated by an
# assumed causal premium, placed in the state non-FSM distribution at 30 (ONS 2022). Rank preservation assumed.
o = pd.read_csv(L.DER / "ons_fsm_percentiles.csv").pivot_table(index="percentile", columns="group",
                                                                 values="earnings_gbp")
cf = []
for prem in (0.0, 0.1, 0.2, 0.3, 0.45):
    for p in (25, 50, 75, 90):
        x = o.independent[p] / (1 + prem)
        cf.append({"assumed_causal_premium": prem, "private_percentile": p,
                   "counterfactual_rank_state_non_fsm": float(np.interp(x, o.state_non_fsm, o.index))})
cf = pd.DataFrame(cf)
cf.to_csv(R / "p5_counterfactual_rank.csv", index=False)
print("\nCounterfactual rank (state non-FSM, PAYE at 30) of private percentiles:")
print(cf.pivot_table(index="assumed_causal_premium", columns="private_percentile",
                     values="counterfactual_rank_state_non_fsm").round(1))
