"""P6: NPV and IRR of private and grammar routes under the P4 premium scenarios, by sex x counterfactual percentile,
with the ONS-shaped variant and a one-at-a-time tornado (PLAN v2 §4.3, §4.6). No Monte Carlo.

Usage: .venv/Scripts/python -I code/engine/run_p6.py data/derived results
Inputs: results/p4_premiums.csv, results/p5_counterfactual_rank.csv, results/p3_top30_independent.csv.
Writes results/p6_npv.csv, results/p6_tornado.csv.

- Typical private pupil: each premium scenario is evaluated at its own implied counterfactual rank (the private
  median's rank in the state non-FSM distribution at 30, given that scenario's premium at age 30).
- ONS shape: premium(q) = premium x log(ONS ratio at q) / log(ONS ratio at P50), i.e. the adjusted/raw scaling in
  log points, applied under rank preservation.
- Grammar: benefit = p_admit x PV gain; cost = tutoring paid at 10 (valued at 11). Central p 0.25, tutoring £3,000.
"""
import math
import pathlib
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import lifetime as L  # noqa: E402

D, R = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
prem = pd.read_csv(R / "p4_premiums.csv")
SCHED = {k: dict(zip(g.age, g.premium_lp)) for k, g in prem.groupby(["school_type", "route", "sex", "scenario"])}
ons = pd.read_csv(D / "ons_fsm_percentiles.csv").pivot_table(index="percentile", columns="group",
                                                             values="earnings_gbp")
LOG_RATIO = np.log(ons.independent / ons.state_non_fsm)
cfr = pd.read_csv(R / "p5_counterfactual_rank.csv")
cfr = cfr[cfr.private_percentile == 50].sort_values("assumed_causal_premium")
top = pd.read_csv(R / "p3_top30_independent.csv")
# top-30 fees are 2026/27 cash; deflate one year by OBR CPI to the engine's 2025/26 prices
TOP30_FEES = {"senior": top.fee_senior_day_2627.median() / L.cpi_index(2026),
              "sixth_form": top.fee_sixth_day_2627.median() / L.cpi_index(2026)}
TUTORING, P_ADMIT = 3000, 0.25


def premium_fn(key, q, shaped):
    s = SCHED[key]
    k = float(LOG_RATIO[round(q)] / LOG_RATIO[50]) if shaped else 1.0
    return lambda age: math.exp(s[age] * k) - 1


def typical_rank(key):
    p30 = math.exp(SCHED[key][30]) - 1
    return float(np.interp(p30, cfr.assumed_causal_premium, cfr.counterfactual_rank_state_non_fsm))


def npv(key, q, scen, disc, shaped=False, fees=None, fee_growth=0.0):
    school, route, sex, _ = key
    dec = L.ROUTES[route][0]
    f = premium_fn(key, q, shaped)
    gain = L.pv_net(sex, q, f, disc, dec, scenario=scen) - L.pv_net(sex, q, 0.0, disc, dec, scenario=scen)
    if school == "grammar":
        return P_ADMIT * gain - TUTORING * disc(-1)
    return gain - L.pv_fees(route, disc, fees=fees, fee_growth=fee_growth)


def lifetime_gain_undiscounted(key, q, scen, shaped=False):
    """Undiscounted real (2025/26 £) lifetime gain, ages 22-67: gross pay and net (after tax, NI, Plan 5)."""
    school, route, sex, _ = key
    dec = L.ROUTES[route][0]
    f = premium_fn(key, q, shaped)
    w = 1.0 if scen == "A" else L.EMPLOYMENT[sex]
    gross = sum(w * L.earnings(sex, q, age, dec, scen) * f(age) for age in L.AGES)
    one = lambda t: 1.0
    net = L.pv_net(sex, q, f, one, dec, scenario=scen) - L.pv_net(sex, q, 0.0, one, dec, scenario=scen)
    return gross, net


def irr(key, q, scen, shaped=False):
    lo, hi = -0.05, 0.30
    d = lambda r: (lambda t: (1 + r) ** -t)
    if npv(key, q, scen, d(lo), shaped) < 0:
        return None
    for _ in range(50):
        m = (lo + hi) / 2
        lo, hi = (m, hi) if npv(key, q, scen, d(m), shaped) > 0 else (lo, m)
    return lo


rows = []
for key in SCHED:
    school, route, sex, scenario = key
    if route == "7-18":
        continue
    qs = [("P25", 25), ("P50", 50), ("P75", 75), ("P90", 90)]
    if school == "private":
        qs.append(("typical", typical_rank(key)))
    for label, q in qs:
        for scen in L.SCENARIOS:
            for shaped in (False, True):
                r = {"school_type": school, "route": route, "sex": sex, "premium_scenario": scenario,
                     "earnings_scenario": scen, "percentile_label": label, "percentile": q, "ons_shaped": shaped}
                for rate, d in L.DISCOUNT.items():
                    r[f"npv_{rate}"] = npv(key, q, scen, d, shaped)
                if school == "private" and route == "11-18":
                    r["npv_3.5%_top30_fees"] = npv(key, q, scen, L.DISCOUNT["3.5% stepped"], shaped, fees=TOP30_FEES)
                r["irr"] = irr(key, q, scen, shaped) if school == "private" and not shaped else None
                r["gross_gain_undiscounted"], r["net_gain_undiscounted"] = lifetime_gain_undiscounted(key, q, scen, shaped)
                r["fees_undiscounted"] = L.pv_fees(route, lambda t: 1.0) if school == "private" else None
                rows.append(r)
res = pd.DataFrame(rows)
res.to_csv(R / "p6_npv.csv", index=False)

# Tornado: private 11-18, typical pupil, central premium, scenario B, 3.5% stepped, flat premium; one input at a time.
tor = []
for sex in ("men", "women"):
    key = ("private", "11-18", sex, "central")
    q = typical_rank(key)
    d35 = L.DISCOUNT["3.5% stepped"]
    base = npv(key, q, "B", d35)

    def bar(name, lo_val, hi_val, lo_lab, hi_lab):
        tor.append({"sex": sex, "input": name, "low_label": lo_lab, "high_label": hi_lab, "base_npv": base,
                    "npv_low": lo_val, "npv_high": hi_val})

    bar("premium scenario", npv(("private", "11-18", sex, "low"), typical_rank(("private", "11-18", sex, "low")),
                                "B", d35),
        npv(("private", "11-18", sex, "high"), typical_rank(("private", "11-18", sex, "high")), "B", d35),
        "low (residual only)", "high (1970 cohort)")
    bar("discount rate", npv(key, q, "B", L.DISCOUNT["5% equity (flagged)"]), npv(key, q, "B", L.DISCOUNT["2.1% borrowing"]),
        "5% equity", "2.1% borrowing")
    bar("earnings scenario", npv(key, q, "B", d35), npv(key, q, "A", d35), "B all employees", "A full-time")
    bar("premium shape", npv(key, q, "B", d35), npv(key, q, "B", d35, shaped=True), "flat", "ONS-shaped")
    bar("fees", npv(key, q, "B", d35, fees=TOP30_FEES), base, "top-30 median", "ISC average")
    bar("real fee growth", npv(key, q, "B", d35, fee_growth=0.03), base, "3% a year", "0%")
    bar("extras on fees", base - 0.15 * L.pv_fees("11-18", d35), base - 0.05 * L.pv_fees("11-18", d35),
        "+15%", "+5%")
    bar("bursary or sibling discount", base, base + 0.10 * L.pv_fees("11-18", d35), "none", "10% off fees")
    g0 = L.GROWTH
    L.GROWTH = 0.012
    lo_g = npv(key, q, "B", d35)
    L.GROWTH = 0.0183
    hi_g = npv(key, q, "B", d35)
    L.GROWTH = g0
    bar("real earnings growth", lo_g, hi_g, "1.2%", "1.83%")
    bar("counterfactual rank", npv(key, 50, "B", d35), npv(key, 90, "B", d35), "P50", "P90")
tor = pd.DataFrame(tor)
tor.to_csv(R / "p6_tornado.csv", index=False)

pd.set_option("display.width", 220)
k = res[(res.school_type == "private") & (res.route == "11-18") & (res.earnings_scenario == "B") & ~res.ons_shaped]
print("Private 11-18, scenario B, flat premium: NPV at 3.5% (£k) and IRR")
print(k.assign(npv=(k["npv_3.5% stepped"] / 1000).round(0), irr=(100 * k.irr).round(1))
      .pivot_table(index=["sex", "premium_scenario"], columns="percentile_label", values=["npv", "irr"]).to_string())
print("\nUndiscounted real lifetime gain, typical pupil, flat premium (£k): gross / net; fees undiscounted")
u = k[k.percentile_label == "typical"]
print(u.assign(gross=(u.gross_gain_undiscounted / 1000).round(0), net=(u.net_gain_undiscounted / 1000).round(0),
               fees=(u.fees_undiscounted / 1000).round(0))[["sex", "premium_scenario", "gross", "net", "fees"]]
      .to_string(index=False))
k2 = res[(res.school_type == "private") & (res.route == "11-18") & (res.earnings_scenario == "B") & res.ons_shaped]
print("\nSame, ONS-shaped premium: NPV at 3.5% (£k)")
print(k2.assign(npv=(k2["npv_3.5% stepped"] / 1000).round(0))
      .pivot_table(index=["sex", "premium_scenario"], columns="percentile_label", values="npv").to_string())
gm = res[(res.school_type == "grammar") & (res.earnings_scenario == "B") & ~res.ons_shaped]
print("\nGrammar 11-18 (p=0.25, £3k tutoring), scenario B: NPV at 3.5% (£k)")
print(gm.assign(npv=(gm["npv_3.5% stepped"] / 1000).round(1))
      .pivot_table(index=["sex", "premium_scenario"], columns="percentile_label", values="npv").to_string())
print("\nTornado (£k):")
print(tor.assign(lo=(tor.npv_low / 1000).round(0), hi=(tor.npv_high / 1000).round(0), base=(tor.base_npv / 1000).round(0))
      [["sex", "input", "low_label", "lo", "high_label", "hi", "base"]].to_string(index=False))
