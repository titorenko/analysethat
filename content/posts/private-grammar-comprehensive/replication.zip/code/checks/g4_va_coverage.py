"""G4: independent schools' A level VA entries, school level vs national (2024/25), and per-school coverage.

National: 'All independent schools' A level VA entries = 97,826 (Value added - institution type and sex).
School level: 'Schools and colleges - qualification and subject value added', exam cohort 'A level',
All subjects, entries_count, size-weighted as DfE counts them: GCE A level + 0.5 x 'GCE AS level (Not continued
to A2)'. (The all-institution control shows this basis reproduces the national total; A level only falls ~1.3%
short.) The gate check is on U2; U1 and the unweighted sums are reported. Two universes:
  U1 = the 572 'Independent School' rows of the 16-18 institution information (performance-table list);
  U2 = every URN in the school-level VA file whose GIAS type is an independent school (incl. special and
       closed schools not in U1).
Coverage = VA entries / GCE A level exam entries (subject entries and grades file, 'Total exam entries').
The EES files carry no LOWCOV marker (performance-table symbol: < 50% of pupils covered); coverage < 50% is
listed as the entries-based equivalent.
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
from common import Gate, latest_raw, read_ees, num, DERIVED  # noqa: E402

NATIONAL = 97826
TOL = 0.01


def main():
    va_p = latest_raw("dfe_ks5", "ks5_subject_va_v*.csv")
    nat_p = latest_raw("dfe_ks5", "ks5_nat_va_inst_sex_v*.csv")
    info_p = latest_raw("dfe_ks5", "ks5_institution_info_v*.csv")
    ks5_p, sm_p = DERIVED / "ks5_school.csv", DERIVED / "school_master.csv"
    g = Gate("G4 (independent A level VA entries: national reconciliation and coverage, 2024/25)",
             [va_p, nat_p, info_p, ks5_p, sm_p])

    nat = read_ees(nat_p)
    nat = nat[(nat.time_period == "202425") & (nat.sex == "All") & (nat.exam_cohort == "A level")].set_index("establishment_type")
    n_all = int(nat.loc["All independent schools", "entries_count"])
    n_ind, n_spec = int(nat.loc["Independent schools", "entries_count"]), int(nat.loc["Independent special schools", "entries_count"])
    g.check("national file 'All independent schools' A level VA entries", n_all == NATIONAL,
            f"published {NATIONAL:,d}, file {n_all:,d} (= Independent schools {n_ind:,d} + independent special {n_spec:,d})")

    va = read_ees(va_p)
    va = va[(va.exam_cohort == "A level") & (va.subject == "All subjects")]
    va = va.assign(n=num(va.entries_count))
    w = va.pivot_table(index="school_urn", columns="qualification_detailed", values="n", aggfunc="sum")
    a_only = w["GCE A level"].fillna(0)
    weighted = a_only + 0.5 * w["GCE AS level (Not continued to A2)"].fillna(0)
    nsupp = va[va.qualification_detailed == "GCE A level"].set_index("school_urn").n.isna()
    info = read_ees(info_p)
    u1 = set(info[info.establishment_type == "Independent School"].school_urn)
    sm = read_ees(sm_p).set_index("urn")
    gias_ind = set(sm.index[sm.establishment_type.isin(["Other independent school", "Other independent special school"])])
    u2 = set(w.index) & (gias_ind | u1)
    all_nat = int(nat.loc["All schools and FE sector colleges", "entries_count"])

    def share(x, nat_n):
        return f"{x:,.0f} = {100 * x / nat_n:.2f}% of {nat_n:,d} (short {nat_n - x:,.0f})"

    g.note("- control, all institutions vs national 'All schools and FE sector colleges': "
           f"A level only {share(a_only.sum(), all_nat)}; A level + 0.5 x AS not continued {share(weighted.sum(), all_nat)}; "
           f"A level + 1.0 x AS not continued {share(a_only.sum() + 2 * (weighted.sum() - a_only.sum()), all_nat)}. "
           "The size-weighted basis (AS = 0.5 A level) is the one that reproduces the national count, so it is the gate basis.")
    for label, u, gate in [("U2 (all independents in the school-level VA file)", u2, True),
                           ("U1 (572 performance-table independents)", u1, False)]:
        idx = [i for i in w.index if i in u]
        tot, tot_a = weighted[idx].sum(), a_only[idx].sum()
        detail = (f"weighted {share(tot, n_all)}; A level only {share(tot_a, n_all)}; {len(idx)} schools, "
                  f"{int(nsupp.reindex(idx, fill_value=False).sum())} with A level VA entries suppressed ('c')")
        if gate:
            g.check(f"sum of school-level VA entries, {label}", abs(1 - tot / n_all) <= TOL, detail)
        else:
            g.note(f"- info {label}: {detail}. The difference from U2 = {len(u2 - u1)} independents (mostly closed, "
                   "some special) that are in the VA file but not in the performance-table list.")

    # Coverage list (U1; exam entries exist only for performance-table schools)
    k = read_ees(ks5_p)
    k = k[(k.time_period == "2024/25") & (k.exam_cohort == "A level") & k.urn.isin(u1)].copy()
    k["ve"], k["ae"] = num(k.va_entries), num(k.alevel_exam_entries)
    k["cov"] = k.ve / k.ae
    k.loc[(k.va_entries_flag == "absent") & (k.ae > 0), "cov"] = 0.0
    low = k[(k["cov"] < 0.7) | ((k.va_entries_flag == "c") & (k.ae > 0))].sort_values("cov")
    g.note(f"\nIndependents (U1) with A level VA entries < 70% of GCE A level exam entries: {(k['cov'] < 0.7).sum()} "
           f"(of which < 50%, LOWCOV-equivalent: {(k['cov'] < 0.5).sum()}); VA entries suppressed: "
           f"{((k.va_entries_flag == 'c') & (k.ae > 0)).sum()}; no A level exam entries: {int((k.ae.fillna(0) == 0).sum())}.\n")
    g.note("| urn | school | A level exam entries | VA entries | coverage | VA [95% CI] |\n|---|---|---|---|---|---|")
    for _, r in low.iterrows():
        ve = r.va_entries if r.va_entries else r.va_entries_flag
        cov = "" if pd.isna(r["cov"]) else f"{r['cov']:.2f}"
        va_s = f"{r.value_added} [{r.value_added_lower_ci}, {r.value_added_upper_ci}]" if r.value_added else r.value_added_flag
        g.note(f"| {r.urn} | {r.school_name} | {int(r.ae)} | {ve} | {cov} | {va_s} |")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
