"""G-beyond-pay: data/derived/beyond_pay.csv is read correctly from its five PDFs.

Re-checks the table independently of code/derive/build_beyond_pay.py:
1. every row's quote is in the pdfplumber text of its page (whitespace-insensitive; whole page or either half,
   for two-column pages);
2. every row's value is one of the numbers printed in its quote (rows with measure "claim" hold a sentence only);
3. coverage: 46 Elitist Britain professions x 3 school types; 4 IFS groups; 4 school types in the 2009 fellows table.
Notes (not failures) the 2009 report's own inconsistency: its independent count (557) is not RS + BA.

Usage: .venv/Scripts/python -I code/checks/g_beyond_pay.py
"""
import re
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
import pdfplumber  # noqa: E402
from common import DERIVED, ROOT, Gate  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def squash(s):
    return "".join((s or "").replace("−", "-").split())


def main():
    d = pd.read_csv(DERIVED / "beyond_pay.csv")
    files = sorted(d.source_file.unique())
    g = Gate("G-beyond-pay (PhDs, elites, fellows, top jobs, wellbeing read from their PDFs)",
             [DERIVED / "beyond_pay.csv"] + [ROOT / f for f in files])
    for f in files:
        rows = d[d.source_file == f]
        bad_q, bad_v = [], []
        with pdfplumber.open(ROOT / f) as pdf:
            for page, grp in rows.groupby("page"):
                pg = pdf.pages[int(page) - 1]
                w, h = pg.width, pg.height
                texts = [squash(t.extract_text()) for t in (pg, pg.crop((0, 0, w / 2, h)), pg.crop((w / 2, 0, w, h)))]
                for r in grp.itertuples():
                    if not any(squash(r.quote) in t for t in texts):
                        bad_q.append(r.row_id)
                    q = re.sub(r"(?<=\d),(?=\d{3}\b)", "", r.quote)      # thousands separators, not "[1.32,2.24]"
                    printed = {float(x) for x in re.findall(r"\d+(?:\.\d+)?", q)}
                    if r.measure != "claim" and abs(r.value) not in printed:
                        bad_v.append(r.row_id)
        g.check(f"{pathlib.Path(f).name}: quotes on their pages", not bad_q, f"{len(rows)} rows, missing: {bad_q}")
        g.check(f"{pathlib.Path(f).name}: values printed in quotes", not bad_v, f"not printed: {bad_v}")

    eb = d[(d.source == "eb2025") & (d.measure == "share_of_group")]
    g.check("Elitist Britain: 46 professions x 3 school types", eb.groupby("group").size().eq(3).all()
            and eb.group.nunique() == 46 and eb.page.nunique() == 46, f"{eb.group.nunique()} professions")
    ifs = d[(d.source == "ifs_pg") & (d.measure == "started_phd_by_30")]
    g.check("IFS: four groups with a PhD rate", set(ifs.group) == {"private", "state_richest_fifth",
            "state_poorest_fifth", "everyone"}, ", ".join(f"{r.group} {r.value}%" for r in ifs.itertuples()))
    st = d[(d.source == "st2009") & (d.group == "both") & (d.measure == "share_of_fellows")]
    g.check("2009 fellows: four school types", len(st) == 4, f"printed shares sum to {st.value.sum():.0f}%")
    n = d[(d.source == "st2009") & (d.measure == "fellows") & (d.school_type == "private")].set_index("group").value
    g.note(f"  note: the 2009 report prints {n['both']:.0f} independent fellows in all, but Royal Society "
           f"{n['royal_society']:.0f} + British Academy {n['british_academy']:.0f} = "
           f"{n['royal_society'] + n['british_academy']:.0f}; the article computes shares from the counts")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
