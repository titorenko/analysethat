"""G1-KS5-national: 2024/25 national 16-18 A level figures by institution type (EES API data sets).

Published (EES release, scouting A §1.3): all independent schools APS per entry 43.07, A level VA +0.190 on
97,826 entries; all state-funded schools APS 35.49, VA -0.005. The files carry more decimals than the
release, so values are compared after rounding to the published precision; raw values are logged.
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import Gate, latest_raw, read_ees  # noqa: E402


def one(df, inst, col):
    r = df[(df.time_period == "202425") & (df.establishment_type == inst) & (df.sex == "All")
           & (df.exam_cohort == "A level")]
    assert len(r) == 1, (inst, col, len(r))
    return r[col].iloc[0]


def main():
    att_p = latest_raw("dfe_ks5", "ks5_nat_attainment_inst_sex_v*.csv")
    va_p = latest_raw("dfe_ks5", "ks5_nat_va_inst_sex_v*.csv")
    att, va = read_ees(att_p), read_ees(va_p)
    g = Gate("G1-KS5-national (16-18 A level, 2024/25)", [att_p, va_p])
    for inst, aps_w, va_w, n_w in [("All independent schools", "43.07", "0.190", "97826"),
                                   ("All state-funded schools", "35.49", "-0.005", None)]:
        aps = one(att, inst, "aps_per_entry")
        g.check(f"{inst} APS per A level entry", f"{float(aps):.2f}" == aps_w, f"published {aps_w}, file {aps}")
        v = one(va, inst, "value_added")
        g.check(f"{inst} A level VA", f"{float(v):.3f}" == va_w, f"published {va_w}, file {v}")
        n = one(va, inst, "entries_count")
        if n_w:
            g.check(f"{inst} A level VA entries", n == n_w, f"published {n_w}, file {n}")
        else:
            g.note(f"- info: {inst} A level VA entries = {n}")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
