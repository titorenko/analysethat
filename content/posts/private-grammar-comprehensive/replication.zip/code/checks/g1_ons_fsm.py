"""G1-ONS: ONS 2022 FSM-earnings Fig 1 (PAYE earnings at age 30) reproduces the published percentiles.

The xlsx stores some percentiles with decimals (e.g. 71304.8); the published figures are whole pounds, so the
check is round-half-up(file value) == published value, and the raw file value is printed.
"""
import decimal
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
from common import DERIVED, Gate, latest_raw  # noqa: E402

EXPECTED = [("independent", 50, 33042), ("state_non_fsm", 50, 22717), ("state_fsm", 50, 17036),
            ("independent", 10, 8424), ("independent", 90, 71305), ("independent", 99, 180629)]


def gbp(x):
    return int(decimal.Decimal(str(x)).quantize(decimal.Decimal("1"), rounding=decimal.ROUND_HALF_UP))


def main():
    path = DERIVED / "ons_fsm_percentiles.csv"
    d = pd.read_csv(path).set_index(["group", "percentile"]).earnings_gbp
    g = Gate("G1-ONS (ONS 2022 FSM earnings, Fig 1 percentiles at age 30)",
             [path, latest_raw("ons_fsm", "Fig_1_Earnings_percentiles.xlsx")])
    for group, pct, want in EXPECTED:
        got = d.loc[(group, pct)]
        g.check(f"{group} P{pct}", gbp(got) == want, f"published {want:,}, file {got} (rounded {gbp(got):,})")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
