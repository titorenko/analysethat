"""G3: %A*/A per school from the DfE 'subject entries and grades' file reproduces the three verified schools.

Basis checked: 2024/25, exam cohort 'A level', qualification 'GCE A level', the 'All subjects' row, and the
derived table data/derived/ks5_astar_a_school.csv. The sum of per-subject rows is reported for information
only: it undercounts A*/A because grade counts of subjects with fewer than ~5 entries are suppressed ('c').
(GCE A level appears only under exam cohort 'A level' in this file, so no other cohort basis exists.)
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import Gate, latest_raw, read_ees, num, DERIVED  # noqa: E402

EXPECTED = {  # urn: (name, A*, A, entries, % A*/A)
    "102942": ("St Paul's School", 354, 228, 650, "89.5"),
    "101162": ("Westminster School", 326, 190, 591, "87.3"),
    "136290": ("Queen Elizabeth's School, Barnet", 296, 189, 560, "86.6"),
}


def main():
    gr_p = latest_raw("dfe_ks5", "ks5_subject_grades_v*.csv")
    der_p = DERIVED / "ks5_astar_a_school.csv"
    gr = read_ees(gr_p)
    gr = gr[(gr.exam_cohort == "A level") & (gr.qualification_detailed == "GCE A level") & gr.school_urn.isin(EXPECTED)]
    gr = gr.assign(n=num(gr.entries_count))
    der = read_ees(der_p)
    der = der[(der.qualification == "GCE A level") & (der.time_period == "2024/25")].set_index("urn")
    g = Gate("G3 (%A*/A, DfE subject entries and grades, 2024/25)", [gr_p, der_p])
    for urn, (name, a_star, a, tot, pct) in EXPECTED.items():
        s = gr[gr.school_urn == urn]
        for label, by in [("All subjects row", s[s.subject == "All subjects"].groupby("grade").n.sum()),
                          ("sum of subject rows", s[s.subject != "All subjects"].groupby("grade").n.sum())]:
            got = (int(by.get("A*", -1)), int(by.get("A", -1)), int(by.get("Total exam entries", -1)))
            got_pct = f"{100 * (got[0] + got[1]) / got[2]:.1f}"
            detail = f"published {a_star}+{a} of {tot} ({pct}%), file {got[0]}+{got[1]} of {got[2]} ({got_pct}%)"
            if label == "All subjects row":
                g.check(f"{name} ({urn}) [{label}]", got == (a_star, a, tot) and got_pct == pct, detail)
            else:  # alternative basis, reported only: grade counts of subjects with < ~5 entries are 'c'
                g.note(f"- info {name} ({urn}) [{label}, small-subject grades suppressed]: {detail}")
        r = der.loc[urn]
        got = (int(r.astar_count), int(r.a_count), int(r.total_entries))
        got_pct = f"{float(r.pct_astar_a):.1f}"
        g.check(f"{name} ({urn}) [derived ks5_astar_a_school]", got == (a_star, a, tot) and got_pct == pct,
                f"derived {got[0]}+{got[1]} of {got[2]} ({got_pct}%)")
    g.note("Basis that reproduces all three: 2024/25 'A level' exam cohort (students at the end of 16-18 study), "
           "GCE A level, all subjects, all grades counted as entries (Total exam entries incl. U/Fail).")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
