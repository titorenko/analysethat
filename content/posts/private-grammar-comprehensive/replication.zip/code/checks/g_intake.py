"""G-intake: grammar admission figures confirmed by the scouts are reproduced exactly, both in the downloaded
source file (extracted text) and in data/derived/grammar_intake.csv.

Checks (scouting C 4b):
- Tiffin School 2026: 1,866 tested at stage 1, 665 at stage 2, 186 places, lowest score offered 100
  (2025: 100; 2024: 104) - Patterns of Admissions 2026 PDF.
- CSSE Sept 2025 entry (sheet 'for 2026 entry'): KEGS 355 inside / 372 outside the priority area; CRGS 343.
- KEF 2026 entry, 'all other applicants', national offer day: Camp Hill Boys 254, Camp Hill Girls 255.
- Kent Test threshold (test sat Sept 2025, Sept 2026 entry): total >= 332, no single score below 108.
- Queen Elizabeth's Barnet 2025 entry: 3,433 took the test (admissions guide p.14, Issuu text layer); lowest score
  offered on national offer day 237 (FOI reply 2026-10-12), above the guide's 235 after waiting-list offers.
- The Henrietta Barnett School 2025 entry: 2,686 Round 1 attendees and lowest combined score 578.25 (FOI reply
  2026-10-19, transcribed from the attached sheet).
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import Gate, DERIVED, latest_raw  # noqa: E402
from extract_text import text_of, norm  # noqa: E402

import pandas as pd  # noqa: E402

TIFFIN, KEGS, CRGS, CHB, CHG, QE, HBS = "136910", "136642", "149899", "137045", "137044", "136290", "138051"
KENT = "Kent Test (Kent County Council)"
# (label, raw file pattern, snippet in raw text, derived-row filter, expected value)
CHECKS = [
    ("Tiffin 2026 tested at stage 1", "tiffin_patterns_of_admissions_2026.pdf",
     "Applicants tested at Stage One 1866 1675 1654", dict(urn=TIFFIN, entry_year="2026", measure="testers_stage1"), "1866"),
    ("Tiffin 2026 tested at stage 2", "tiffin_patterns_of_admissions_2026.pdf",
     "Applicants tested at Stage Two 665 653 666", dict(urn=TIFFIN, entry_year="2026", measure="testers_stage2"), "665"),
    ("Tiffin 2026 places", "tiffin_patterns_of_admissions_2026.pdf",
     "Places offered initially 186 186 186", dict(urn=TIFFIN, entry_year="2026", measure="places"), "186"),
    ("Tiffin 2026 lowest score offered (1 March)", "tiffin_patterns_of_admissions_2026.pdf",
     "(the lowest score achieved by a student 100 100 104 offered a place on 1st March)",
     dict(urn=TIFFIN, entry_year="2026", measure="lowest_score_offered", offer_round="national_offer_day"), "100"),
    ("Tiffin 2025 lowest score offered (1 March)", "tiffin_patterns_of_admissions_2026.pdf",
     "(the lowest score achieved by a student 100 100 104 offered a place on 1st March)",
     dict(urn=TIFFIN, entry_year="2025", measure="lowest_score_offered", offer_round="national_offer_day"), "100"),
    ("Tiffin 2024 lowest score offered (1 March)", "tiffin_patterns_of_admissions_2026.pdf",
     "(the lowest score achieved by a student 100 100 104 offered a place on 1st March)",
     dict(urn=TIFFIN, entry_year="2024", measure="lowest_score_offered", offer_round="national_offer_day"), "104"),
    ("CSSE Sept 2025 KEGS lowest, inside priority area", "csse_historical_guidance_sheet_for_2026_entry.pdf",
     "King Edward VI Grammar School (Boys) 355 372",
     dict(urn=KEGS, entry_year="2025", measure="lowest_score_offered", category="inside_priority_area"), "355"),
    ("CSSE Sept 2025 KEGS lowest, outside priority area", "csse_historical_guidance_sheet_for_2026_entry.pdf",
     "King Edward VI Grammar School (Boys) 355 372",
     dict(urn=KEGS, entry_year="2025", measure="lowest_score_offered", category="outside_priority_area"), "372"),
    ("CSSE Sept 2025 Colchester RGS lowest", "csse_historical_guidance_sheet_for_2026_entry.pdf",
     "Colchester Royal 343 Grammar School (Boys)*",
     dict(urn=CRGS, entry_year="2025", measure="lowest_score_offered", category="all"), "343"),
    ("KEF 2026 Camp Hill Boys 'all others' (March)", "kef_results_and_offers.html", "254 (242)",
     dict(urn=CHB, entry_year="2026", measure="lowest_score_offered", category="all_others",
          offer_round="national_offer_day"), "254"),
    ("KEF 2026 Camp Hill Girls 'all others' (March)", "kef_results_and_offers.html", "255 (242)",
     dict(urn=CHG, entry_year="2026", measure="lowest_score_offered", category="all_others",
          offer_round="national_offer_day"), "255"),
    ("Kent Test threshold 2026 entry: total", "judd_historical_11plus_information_2026.pdf",
     "Kent Test 320 320 320 320 323 330 332 332 332 332 332 332 Pass Mark",
     dict(urn="", name=KENT, entry_year="2026", measure="qualifying_score", category="total"), "332"),
    ("Kent Test threshold 2026 entry: minimum per test", "judd_historical_11plus_information_2026.pdf",
     "Minimum 106 106 106 106 107 110 108 109 109 107 108 108",
     dict(urn="", name=KENT, entry_year="2026", measure="qualifying_score", category="minimum_each_test"), "108"),
    ("QE Barnet 2025 took the test (guide p.14)", "issuu_qe_admissions_guide_2027_entry_page16.bin",
     "235 2025 3433 809 764", dict(urn=QE, entry_year="2025", measure="testers_stage1"), "3433"),
    ("QE Barnet 2025 lowest score, after waiting list (guide p.14)", "issuu_qe_admissions_guide_2027_entry_page16.bin",
     "235 2025 3433 809 764",
     dict(urn=QE, entry_year="2025", measure="lowest_score_offered", offer_round="final_excluding_appeals"), "235"),
    ("QE Barnet 2025 lowest score, national offer day (FOI)", "qe_foi_reply_2026-10-12.txt", "2025 entry 237",
     dict(urn=QE, entry_year="2025", measure="lowest_score_offered", offer_round="national_offer_day"), "237"),
    ("Henrietta Barnett 2025 Round 1 attendees (FOI)", "hbs_foi_reply_2026-10-19.txt",
     "Attendees R1 2637 2686 2649 2545", dict(urn=HBS, entry_year="2025", measure="testers_stage1"), "2686"),
    ("Henrietta Barnett 2025 lowest combined score (FOI)", "hbs_foi_reply_2026-10-19.txt",
     "Lowest combined score 1/3 563.73 578.25 569.14 574.98",
     dict(urn=HBS, entry_year="2025", measure="lowest_score_offered"), "578.25"),
]


def main():
    derived = DERIVED / "grammar_intake.csv"
    d = pd.read_csv(derived, dtype=str, keep_default_na=False)
    files = {f: latest_raw("grammar_intake", f) for f in dict.fromkeys(c[1] for c in CHECKS)}
    texts = {f: norm(text_of(p)) for f, p in files.items()}
    g = Gate("G-intake (grammar admission figures, scouting C 4b)", [derived] + list(files.values()))
    for label, f, snippet, filt, want in CHECKS:
        in_raw = norm(snippet) in texts[f]
        sel = d.copy()
        for k, v in filt.items():
            sel = sel[sel[k] == v]
        sel = sel[sel.status == "confirmed"]
        got = sel.value.tolist()
        ok = in_raw and got == [want]
        g.check(label, ok, f"published {want}; raw '{snippet}' {'found' if in_raw else 'NOT FOUND'} in {f}; "
                           f"derived {got} ({', '.join(sel.row_id)})")
    g.note("Kent threshold source: The Judd School's historical table (kent.gov.uk returns 403 to scripts). "
           "For the test sat Sept 2024 (2025 entry) the Wayback copy of the KCC page says 'no single score lower "
           "than 106' while Judd's table says 108 for 2025: both rows are kept in grammar_intake.csv.")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
