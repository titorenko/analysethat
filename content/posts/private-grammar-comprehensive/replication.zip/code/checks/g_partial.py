"""G-partial: every row of data/derived/partially_selective.csv rests on a quote that is verbatim in its local source.

Per row (one PASS/FAIL line each):
- the URN is unique in the table and Open in data/derived/school_master.csv;
- rows with a source_file: the file exists, its text is re-extracted (code/derive/extract_text.py: pdfplumber for
  PDFs, html.parser for HTML) and every " ... "-separated segment of source_quote occurs in it after normalising
  whitespace (plus case, curly quotes and dashes); the same for each " || "-separated second_source_file /
  second_quote pair when present;
- partially_selective rows have ability_places_pct or ability_places_n;
- blocked / unverified rows carry a source_url and a reason in note.
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import Gate, DERIVED, ROOT, read_ees  # noqa: E402
from extract_text import text_of, norm  # noqa: E402


def quote_found(path, quote, cache):
    p = ROOT / path
    if not p.exists():
        return False, f"missing file {path}"
    if path not in cache:
        cache[path] = norm(text_of(p))
    missing = [s for s in quote.split(" ... ") if norm(s) not in cache[path]]
    return not missing, (f"segment not found: '{missing[0][:60]}'" if missing else f"quote found in {p.name}")


def main():
    t_p, sm_p = DERIVED / "partially_selective.csv", DERIVED / "school_master.csv"
    t = read_ees(t_p)
    open_urns = set(read_ees(sm_p, usecols=["urn", "status"]).query("status == 'Open'").urn)
    g = Gate("G-partial", [t_p, sm_p])
    dup = set(t.urn[t.urn.duplicated()])
    cache = {}
    for r in t.itertuples():
        problems, details = [], []
        if r.urn in dup:
            problems.append("duplicate URN")
        if r.urn not in open_urns:
            problems.append("URN not Open in school_master")
        if r.source_file:
            ok, d = quote_found(r.source_file, r.source_quote, cache)
            (details if ok else problems).append(d)
        elif r.classification not in ("blocked", "unverified"):
            problems.append("no source_file")
        if r.second_source_file:
            for f, q in zip(r.second_source_file.split(" || "), r.second_quote.split(" || ")):
                ok, d = quote_found(f, q, cache)
                (details if ok else problems).append("second " + d)
        if r.classification == "partially_selective":
            if r.ability_places_pct or r.ability_places_n:
                details.append(f"{r.ability_places_pct}% / n={r.ability_places_n or '-'}")
            else:
                problems.append("partially_selective without pct or n")
        if r.classification in ("blocked", "unverified") and not (r.source_url and r.note):
            problems.append(f"{r.classification} without URL and reason")
        g.check(f"{r.urn} {r.name} [{r.classification}]", not problems, "; ".join(problems or details))
    g.note("- counts: " + "; ".join(f"{k} {v}" for k, v in t.classification.value_counts().items()))
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
