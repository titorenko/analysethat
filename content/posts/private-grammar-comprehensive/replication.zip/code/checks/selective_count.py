"""Resolve: how many selective (grammar) schools have 16-18 data in 2024/25 -- 162 or 163?

Counts the selective set in every file that labels it and names the URNs in any difference.
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import Gate, latest_raw, read_ees, num, DERIVED  # noqa: E402


def main():
    info_p = latest_raw("dfe_ks5", "ks5_institution_info_v*.csv")
    perf_p = latest_raw("dfe_ks5", "ks5_performance_v*.csv")
    k4i_p = latest_raw("dfe_ks4", "ks4_school_info.csv")
    k4p_p = latest_raw("dfe_ks4", "ks4_performance_v*.csv")
    nat_p = latest_raw("dfe_ks4", "ks4_nat_by_school_type_v*.csv")
    sm_p = DERIVED / "school_master.csv"
    g = Gate("Resolve: selective schools with 16-18 data, 2024/25 (162 vs 163)",
             [info_p, perf_p, k4i_p, k4p_p, nat_p, sm_p])
    info = read_ees(info_p)
    sel = set(info[info.admissions_policy == "Selective"].school_urn)
    names = info.set_index("school_urn").school_name
    sets = {"16-18 institution info 2024/25, admissions_policy = Selective": sel}
    perf = read_ees(perf_p)
    p = perf[(perf.time_period == "202425") & (perf.disadvantage_status == "Total") & perf.school_urn.isin(sel)]
    for coh in ["A level", "Academic"]:
        for col in ["aps_per_entry", "value_added"]:
            q = p[(p.exam_cohort == coh)]
            sets[f"... with numeric {coh} {col} 2024/25"] = set(q[num(q[col]).notna()].school_urn)
    k4i = read_ees(k4i_p)
    sets["KS4 school information 2024/25, admpol_pt = selective schools"] = set(k4i[k4i.admpol_pt == "selective schools"].school_urn)
    k4 = read_ees(k4p_p, usecols=["time_period", "school_urn", "breakdown_topic", "progress8_average"])
    t = k4[(k4.time_period == "202324") & (k4.breakdown_topic == "Total") & k4.school_urn.isin(sel)]
    sets["... with numeric Progress 8 in KS4 2023/24"] = set(t[num(t.progress8_average).notna()].school_urn)
    sm = read_ees(sm_p)
    sets["GIAS AdmissionsPolicy = Selective, state-funded mainstream, open"] = set(sm[
        (sm.gias_admissions_policy == "Selective") & (sm.establishment_type_group.isin(
            ["Local authority maintained schools", "Academies", "Free Schools"])) & (sm.status != "Closed")].urn)
    for label, s in sets.items():
        diff = sorted(sel ^ s)
        g.note(f"- {label}: {len(s)}" + (f"; differs from 16-18 info by {', '.join(f'{u} {names.get(u, u)}' for u in diff)}" if diff else ""))
    nat = read_ees(nat_p)
    f = nat[nat.school_admission_type == "Selective schools"]
    for c in ["disadvantage_status", "ethnicity_major", "first_language", "fsm_status", "prior_attainment", "sex",
              "sen_provision", "sen_status"]:
        f = f[f[c] == "Total"]
    f = f[f.establishment_type_group == "State-funded mainstream"].sort_values("time_period")
    g.note("- KS4 national school_count, selective, state-funded mainstream: " +
           ", ".join(f"{r.time_period[:4]}/{r.time_period[4:]} {r.school_count}" for r in f.itertuples()))
    g.check("selective schools with 16-18 data 2024/25 (institution info)", len(sel) == 163, f"{len(sel)}")
    g.check("every selective school has Academic-cohort APS and VA 2024/25",
            len(sets["... with numeric Academic aps_per_entry 2024/25"]) == len(sets["... with numeric Academic value_added 2024/25"]) == 163,
            "Academic APS {} / VA {}".format(len(sets["... with numeric Academic aps_per_entry 2024/25"]),
                                            len(sets["... with numeric Academic value_added 2024/25"])))
    g.check("KS4 2024/25 selective set equals 16-18 selective set",
            sets["KS4 school information 2024/25, admpol_pt = selective schools"] == sel, "identical URNs")
    g.check("all selective schools have Progress 8 2023/24", len(sets["... with numeric Progress 8 in KS4 2023/24"]) == 163,
            f"{len(sets['... with numeric Progress 8 in KS4 2023/24'])}")
    g.note("Verdict: 163. No DfE or GIAS count for 2023/24 or 2024/25 gives 162 (national KS4 counts: 163 in 2022/23-2024/25, "
           "164 in 2020/21-2021/22). The scouting '162' (C §0.4/§5, 'P8 pulled for all 162 selective schools') is not "
           "reproducible from the files and was most likely an artefact of the ad-hoc API pull. Separately, ranking on "
           "the A level cohort drops 5 IB-heavy grammars (158 with A level APS); the Academic cohort keeps all 163.")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
