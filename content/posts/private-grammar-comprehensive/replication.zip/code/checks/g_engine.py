"""Gates G-tax and G-real for the P5 engine (code/engine/lifetime.py), plus the tax-threshold path and the IFS
discount-schedule component of G5.

G-tax  : 2026/27 take-home pay (income tax + employee NI, rUK, no pension or loan) at £30k, £60k, £110k, £130k,
         £200k matches listentotaxman.com (saved pages) within £10; salarytax.uk shown where it has a page.
G-real : every REAL entry is CPI-real with a source; each DISCOUNT schedule uses its REAL value; the stepped
         schedule is 3.5% to year 30 and 3.0% after.
Path   : the engine's real thresholds from 2030/31 equal the 2026/27 cash values deflated by CPI 2026-27..2030-31,
         re-read here straight from the OBR xlsx; the Plan 5 anchor £25,168 is printed in IFS Table B.2.
G5 (components): 1.035^30 x 1.03^19 = 4.92, the IFS 2026 report's own figure; and the tax + NI share of a 20%
         gross gain (decile mean of full-time paths, discounted to 18) within 10% of the IFS decomposition (men 48%,
         women 41%). The IFS net return itself (£99k) averages individual LEO paths and is not reproducible here.

Usage: .venv/Scripts/python -I code/checks/g_engine.py
"""
import re
import sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "code" / "derive"))
sys.path.insert(0, str(ROOT / "code" / "engine"))
import openpyxl  # noqa: E402
import pdfplumber  # noqa: E402
from common import Gate, latest_raw  # noqa: E402
import lifetime as L  # noqa: E402


def page_value(path, label):
    t = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", re.sub(r"<script.*?</script>", " ", path.read_text(
        encoding="utf-8", errors="replace"), flags=re.S)))
    m = re.search(label, t)
    return float(m.group(1).replace(",", "")) if m else None


def main():
    obr = latest_raw("obr", "efo_march_2026_economy_tables.xlsx")
    ifs = latest_raw("ifs", "ifs_2026_degrees_lifetime_earnings.pdf")
    pages = {s: latest_raw("tax_calc", f"listentotaxman_{s}.html") for s in (30000, 60000, 110000, 130000, 200000)}
    g = Gate("G-tax / G-real / threshold path (P5 engine)", [obr, ifs] + list(pages.values()))

    for s, p in pages.items():
        ext = page_value(p, r"Net Wage [\d.]+% &pound;([\d,]+(?:\.\d+)?)")
        own = s - L.tax_ni(s, idx=1.0)
        alt = latest_raw("tax_calc", f"salarytax_uk_{s}.html") if s in (30000, 60000, 110000) else None
        alt_v = page_value(alt, r"Take-home pay: £([\d,]+) a year") if alt else None
        g.check(f"G-tax £{s:,}", ext is not None and abs(own - ext) <= 10,
                f"engine £{own:,.2f}, listentotaxman £{ext:,.2f}" + (f", salarytax.uk £{alt_v:,.0f}" if alt_v else ""))

    for k, (v, basis, src) in L.REAL.items():
        g.check(f"G-real {k}", basis == "CPI-real" and len(src) > 20, f"{v} {basis}; {src[:70]}")
    for label, key in (("2.1% borrowing", "rate_borrowing"), ("3.0%", "rate_3_0"), ("5% equity (flagged)", "rate_equity_5")):
        d = L.DISCOUNT[label]
        g.check(f"G-real schedule '{label}'", abs(d(10) - (1 + L.REAL[key][0]) ** -10) < 1e-12, f"d(10) = {d(10):.6f}")
    d = L.DISCOUNT["3.5% stepped"]
    g.check("G-real schedule '3.5% stepped'", abs(d(30) - 1.035 ** -30) < 1e-12 and abs(d(31) / d(30) - 1 / 1.03) < 1e-12,
            f"d(30) = {d(30):.6f}, d(31)/d(30) = {d(31) / d(30):.6f}")

    rows = list(openpyxl.load_workbook(obr, read_only=True, data_only=True)["1.7"].iter_rows(values_only=True))
    cpi = {r[1]: r[4] for r in rows if isinstance(r[1], str) and re.fullmatch(r"\d{4}-\d{2}", r[1])}
    idx = 1.0
    for fy in ("2026-27", "2027-28", "2028-29", "2029-30", "2030-31"):
        idx *= 1 + cpi[fy] / 100
    g.check("threshold path: CPI index 2025/26 -> 2030/31", abs(idx - L.REAL_THRESHOLD_INDEX) < 1e-9,
            f"OBR xlsx {idx:.5f}, engine {L.REAL_THRESHOLD_INDEX:.5f}")
    for k in ("personal_allowance", "basic_rate_band_width", "additional_rate_threshold_gross", "pa_taper_start",
              "ni_primary_threshold", "ni_upper_earnings_limit"):
        g.note(f"  real {k} from 2030/31: £{L.TAX_CASH[k] / idx:,.0f} (cash £{L.TAX_CASH[k]:,.0f})")
    pa_real = L.TAX_CASH["personal_allowance"] / idx
    g.check("threshold path: tax at the real PA is zero, £1 above is 28p", L.tax_ni(pa_real) < 1e-6 and
            abs(L.tax_ni(pa_real + 1) - 0.28) < 1e-6, f"real PA £{pa_real:,.2f}")
    with pdfplumber.open(ifs) as pdf:
        t96 = re.sub(r"\s+", " ", pdf.pages[95].extract_text())
    g.check("Plan 5 anchor in IFS Table B.2", "25,168" in t96 and "Table B.2" in t96,
            f"PLAN5_THRESHOLD = {L.PLAN5_THRESHOLD}")
    sdlt = latest_raw("hmt", "sdlt_residential_rates.html")
    hpi = latest_raw("ons_hpi", "ukhpi_england_july_2026.html")
    t = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", sdlt.read_text(encoding="utf-8")))
    g.check("house: SDLT 5% band on the saved gov.uk page", "(the portion from £250,001 to £925,000) 5%" in t,
            f"SDLT_MARGINAL = {L.SDLT_MARGINAL}")
    t = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", hpi.read_text(encoding="utf-8")))
    g.check("house: England average price on the saved UK HPI page",
            f"The average price of a property in England was £{L.HOUSE_PRICE:,}" in t, f"HOUSE_PRICE = {L.HOUSE_PRICE}")
    for region, price in L.HOUSE_PRICES.items():
        g.check(f"house: {region} movers' price on the saved UK HPI page", f"£{price:,}" in t,
                f"{region} = £{price:,} (former owner occupier, July 2026)")
    f = 1.035 ** 30 * 1.03 ** 19
    g.check("G5 component: IFS discount factor age 18 vs 67", round(f, 2) == 4.92, f"{f:.4f}")
    # IFS Table 5.1 / Figure 5.2 text: gross earnings return £215k men (income tax £99k + NI £4k), £148k women
    # (net £90k = 148 - tax/NI + maintenance 24 - repayments 22, so tax/NI £60k). The full net return averages
    # individual LEO paths with zeros and cannot be rebuilt from public data; the tax wedge on a 20% gain can.
    with pdfplumber.open(ifs) as pdf:
        t38, t39 = (re.sub(r"\s+", " ", pdf.pages[i].extract_text()) for i in (37, 38))
    assert "£148k 20% £215k 20%" in t38 and "reduces the net return by £99,000 for men" in t39
    d = L.DISCOUNT["3.5% stepped"]
    for sex, ifs_share in (("men", (99 + 4) / 215), ("women", (148 + 24 - 22 - 90) / 148)):
        gain = tax = 0.0
        for q in range(10, 100, 10):
            for age in L.AGES:
                e = L.earnings(sex, q, age, decision_age=18)
                gain += 0.2 * e * d(age - 18)
                tax += (L.tax_ni(1.2 * e) - L.tax_ni(e)) * d(age - 18)
        g.check(f"G5 component: tax+NI share of a 20% gross gain, {sex}", abs(tax / gain / ifs_share - 1) <= 0.10,
                f"engine {tax / gain:.3f} (decile mean, full-time paths) vs IFS {ifs_share:.3f}")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
