"""G-fees: school fees and charity remissions (independent_fees.csv, independent_bursaries.csv).

1. Westminster, exact: 2025/26 fees from the Wayback capture of 17 Oct 2025 (13+ day £15,451/term, 16+ day £16,650,
   boarding £21,992, incl. VAT), 2026/27 from the live page (£16,456 / £17,482 / £23,094), and the accounts for the
   year to 30 Jun 2025 (gross fees £39,106k; bursaries, scholarships and other concessions £2,988k). Each value is
   checked twice: parsed from the saved raw file by pattern (independently of the transcription), and read from the
   derived CSVs.
2. Hand-check of 10 schools drawn at random (fixed seed, Westminster excluded): for every confirmed fee row the
   saved page is re-read, the printed figure(s) behind the CSV amount are re-found next to the row's stage label,
   the CSV amount is re-derived from them, and ~170 characters of page text around the figure are written to
   logs/gates.md so the stage and year assignment can be read by eye. For the school's charity, the printed gross
   and remission lines are re-found in the accounts text (PDF text layer, or OCR text for scanned filings) and the
   CSV figures re-derived; filings read only from the rendered page are reported as such. The pool is the schools in
   top30_independent.csv, so adding other schools to the CSV does not change this draw.
3. The same fee hand-check for every bottom-20 private school with confirmed 2026/27 rows (bottom20_private.csv,
   including Sidcot, which replaced the closed St Lawrence). They have no charity-accounts rows, so no accounts check.
"""
import csv
import random
import re
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
from common import DERIVED, ROOT, Gate  # noqa: E402
from fees_text import near, norm, page_text, pdf_pages  # noqa: E402
import build_fees as BF  # noqa: E402  (transcription tables: printed figures behind each row)
import build_bursaries as BB  # noqa: E402

SEED, N_SAMPLE, WM = 20261010, 10, "101162"
RAWF = "data/raw/fees/2026-10-10/"


def westminster(g, fees, burs, man):
    wm25, wm26 = RAWF + "101162_2025.html", RAWF + "101162_2026.html"
    g.check("Westminster 2025/26 source is the Wayback capture of 17 Oct 2025", "/web/20251017" in man[wm25]["url"],
            man[wm25]["url"])
    for path, year, exp in ((wm25, "2025-2026", {"13+ day pupils": "15,451", "16+ day pupils": "16,650",
                                                 "13+ and 16+ boarding pupils": "21,992"}),
                            (wm26, "2026-2027", {"13+ day pupils": "16,456", "16+ day pupils": "17,482",
                                                 "13+ and 16+ boarding pupils": "23,094"})):
        t = page_text(ROOT / path)
        heading = ("Fees for 2025-2026" if year == "2025-2026" else "Westminster School Fees 2026-2027")
        g.check(f"Westminster raw {year}: year heading and VAT statement on page",
                heading in t and "All fees displayed are inclusive of VAT." in t, f"'{heading}' + 'inclusive of VAT'")
        for label, want in exp.items():
            m = re.search(re.escape(label) + r" \| £([\d,]+) \| £([\d,]+)", t)
            g.check(f"Westminster raw {year} {label} per term", bool(m) and m.group(1) == want,
                    f"published {want}, parsed {m.group(1) if m else None} (per year {m.group(2) if m else None})")
    acc = ROOT / "data/raw/charity_accounts/2026-10-10/312728_2025-06-30_accounts.pdf"
    note = next(norm(p) for p in pdf_pages(acc) if "fee income comprised" in p)
    gross = re.search(r"Gross fees ([\d,]+) [\d,]+", note)
    conc = re.search(r"Total bursaries, scholarships and other concessions \(([\d,]+)\)", note)
    g.check("Westminster accounts y/e 30 Jun 2025: gross fees £k", gross and gross.group(1) == "39,106",
            f"published 39,106, parsed {gross and gross.group(1)}")
    g.check("Westminster accounts: total bursaries, scholarships and other concessions £k",
            conc and conc.group(1) == "2,988", f"published 2,988, parsed {conc and conc.group(1)}")

    w = fees[(fees.urn == WM) & (fees.status == "confirmed")]
    for fy, stage, mode, want in (("2025/26", "senior", "day", 15451), ("2025/26", "sixth_form_new_entrant", "day", 16650),
                                  ("2025/26", "senior", "boarding", 21992), ("2026/27", "senior", "day", 16456),
                                  ("2026/27", "sixth_form_new_entrant", "day", 17482),
                                  ("2026/27", "senior", "boarding", 23094)):
        r = w[(w.fee_year == fy) & (w.stage == stage) & (w.day_or_boarding == mode)]
        ok = len(r) == 1 and r.amount.iloc[0] == want and bool(r.incl_vat.iloc[0]) and r.period.iloc[0] == "term"
        g.check(f"Westminster CSV {fy} {stage} {mode}", ok,
                f"expected £{want:,}/term incl. VAT; CSV {r[['amount', 'period', 'incl_vat', 'snapshot_date']].to_dict('records')}")
    b = burs[burs.urn == WM].iloc[0]
    g.check("Westminster CSV accounts", b.fy_end == "2025-06-30" and b.gross_fees == 39_106_000
            and b.total_remissions == 2_988_000,
            f"fy_end {b.fy_end}, gross £{b.gross_fees:,.0f}, remissions £{b.total_remissions:,.0f} "
            f"(share {b.remission_share:.2%})")


def fee_rows_check(g, fees, urn, texts):
    rows = fees[(fees.urn == urn) & (fees.status == "confirmed")]
    bad, shown = [], set()
    for _, r in rows.iterrows():
        tr = [x for x in BF.ROWS if (x[0], x[1], x[3], x[4], x[5]) == (urn, r.fee_year, r.stage, r.years, r.day_or_boarding)]
        if len(tr) != 1:
            bad.append(f"{r.fee_year} {r.stage} {r.day_or_boarding}: no single transcription row")
            continue
        _, fy, fname, stage, years, mode, label, amount, period, incl, excl, lunch, note = tr[0]
        t = texts.setdefault(fname, page_text(ROOT / RAWF / fname))
        image = (urn, fy) in BF.IMAGE_AMOUNT
        derived = BF.money(excl) * 1.2 if image else BF.money(amount)
        printed = excl.split("+") if image else amount.split("+")
        found = [near(t, label, p) for p in printed]
        what = f"{fy} {stage} {years} {mode} £{r.amount:,.2f}/{period}"
        if abs(derived - r.amount) > 0.005 or not all(ok for ok, _ in found):
            bad.append(what)
        key = (fy, fname, amount)
        if key not in shown:
            shown.add(key)
            g.note(f"  - {urn} {what} [{'+'.join(printed)} next to '{label}']: …{found[0][1][:170]}…")
    g.check(f"hand-check {urn} {rows.name.iloc[0]}: {len(rows)} confirmed fee rows re-found and re-derived",
            not bad, "; ".join(bad) or "all rows match the page")


def accounts_check(g, burs, urn):
    r = burs[burs.urn == urn].iloc[0]
    if r.status == "not_charity":
        g.note(f"  - {urn}: not a charity ({r.note[:120]})")
        return
    c = next(x for x in BB.C if x["n"] == r.charity_number)
    pdf = ROOT / r.local_path
    if c["verify"] == "visual":
        g.note(f"  - {urn} accounts {c['n']}: figures read from the rendered scan ({c['loc']}); "
               f"identity gross - remissions + adj = net holds (checked in build_bursaries.py); no text layer to re-read")
        return
    hay = " ".join(norm(p) for p in pdf_pages(pdf)) if c["verify"] == "pdf_text" else \
        norm(pdf.with_suffix(".md").read_text(encoding="utf-8", errors="replace"))
    printed = (c["gross"].split("+") if c["gross"] else []) + c["rem"]
    # figures the text layer garbles are found by their recorded OCR spelling (e.g. '4,229' printed as '(4,22e)')
    ocr = c.get("ocr", {})
    missing = [p for p in printed if p not in hay and (p not in ocr or ocr[p] not in hay)]
    via_ocr = [f"{p} as '{ocr[p]}'" for p in printed if p not in hay and p in ocr]
    gross_ok = (BB.money(c["gross"]) * c["unit"] == r.gross_fees) if c["gross"] else pd.isna(r.gross_fees)
    rem_ok = (sum(BB.money(x) for x in c["rem"]) * c["unit"] == r.total_remissions) if c["rem"] else pd.isna(r.total_remissions)
    g.check(f"hand-check {urn} accounts {c['n']} ({c['verify']}): printed gross/remission lines re-found, CSV re-derived",
            not missing and gross_ok and rem_ok,
            f"gross {c['gross'] or '-'} x{c['unit']} = £{r.gross_fees:,.0f}; remissions {'+'.join(c['rem']) or '-'}"
            + (f" = £{r.total_remissions:,.0f}" if c["rem"] else "") + (f"; OCR spelling: {via_ocr}" if via_ocr else "")
            + (f"; not found: {missing}" if missing else ""))


def main():
    fees = pd.read_csv(DERIVED / "independent_fees.csv", dtype={"urn": str})
    burs = pd.read_csv(DERIVED / "independent_bursaries.csv", dtype={"urn": str, "charity_number": str})
    man = {r["local_path"]: r for r in csv.DictReader((ROOT / "data/manifest/fees.csv").open(encoding="utf-8"))}
    g = Gate("G-fees (school fees and charity remissions)",
             [ROOT / RAWF / "101162_2025.html", ROOT / RAWF / "101162_2026.html",
              ROOT / "data/raw/charity_accounts/2026-10-10/312728_2025-06-30_accounts.pdf",
              DERIVED / "independent_fees.csv", DERIVED / "independent_bursaries.csv"])
    westminster(g, fees, burs, man)
    confirmed = fees[(fees.status == "confirmed") & (fees.urn != WM)]
    top = set(pd.read_csv(DERIVED / "top30_independent.csv", dtype={"urn": str}).urn)
    pool = sorted(set(confirmed.urn) & top)
    sample = sorted(random.Random(SEED).sample(pool, N_SAMPLE))
    g.note(f"- info: hand-check sample (random.Random({SEED}).sample of {len(pool)} schools): {', '.join(sample)}")
    texts = {}
    for urn in sample:
        fee_rows_check(g, fees, urn, texts)
        accounts_check(g, burs, urn)
    bottom = set(pd.read_csv(DERIVED / "bottom20_private.csv", dtype={"urn": str}).urn)
    all_b20 = sorted(set(confirmed.urn) & bottom)
    g.note(f"- info: bottom-20 hand-check, all {len(all_b20)} schools with confirmed rows: {', '.join(all_b20)}")
    for urn in all_b20:
        fee_rows_check(g, fees, urn, texts)
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
