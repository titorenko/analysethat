"""G1-ISC: ISC Census 2026 transcription (pdfplumber) reproduces Table 5.1 day fees and Table 6.1 bursaries."""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
from common import DERIVED, Gate, latest_raw  # noqa: E402


def main():
    pf, pb = DERIVED / "isc_fees_2026.csv", DERIVED / "isc_bursaries_2026.csv"
    f = pd.read_csv(pf, dtype={"year": str})
    f = f[(f.table == "5.1") & (f.statistic == "termly_fee_gbp_excl_vat")].set_index(["phase", "fee_type"]).value
    b = pd.read_csv(pb, dtype={"table": str})            # '6.1' must stay a string
    b = b[b.table == "6.1"].set_index(["category", "statistic"]).value
    g = Gate("G1-ISC (ISC Census 2026, Tables 5.1 and 6.1)", [pf, pb, latest_raw("isc", "isc_census_2026.pdf")])
    for label, got, want in (
            ("5.1 senior day fee at day schools (per term, excl. VAT)", f.get(("senior", "day_at_day_schools")), 6492),
            ("5.1 sixth form day fee at day schools (per term, excl. VAT)", f.get(("sixth_form", "day_at_day_schools")), 6754),
            ("6.1 means-tested bursaries: pupils", b.get(("Means-tested: bursaries", "pupils")), 36676),
            ("6.1 means-tested bursaries: average support per pupil", b.get(("Means-tested: bursaries",
                                                                             "average_support_per_pupil_gbp")), 14077)):
        g.check(label, got == want, f"published {want:,}, parsed {got}")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
