"""G1-ASHE: ASHE Table 6.7a (annual gross pay, UK, 2025 provisional) age-band values parsed exactly, plus a
cross-file consistency check: ad hoc 3105 (J76.7a, 2025) UK male full-time median and P90 equal Table 6.7a
'All employees' for male full-time (both come from the same 2025 provisional ASHE).
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
from common import DERIVED, Gate, latest_raw  # noqa: E402

EXPECTED = [("male", "30-39", "median", 42899), ("male", "30-39", "p90", 80241), ("female", "40-49", "median", 39737)]


def main():
    p6, pt = DERIVED / "ashe2025_age_percentiles.csv", DERIVED / "ashe_top_percentiles.csv"
    d = pd.read_csv(p6)
    d = d[(d.edition == "2025 provisional") & (d.measure == "annual_gross_pay_gbp") & (d.work_pattern == "full_time")]
    v = d.set_index(["sex", "age_band", "statistic"]).value
    g = Gate("G1-ASHE (ASHE 2025 provisional Table 6.7a, annual gross, full-time)",
             [p6, pt, latest_raw("ashe", "ashetable62025provisional.zip"),
              latest_raw("ons_adhoc3105", "asheadhocj762025.zip")])
    for sex, age, stat, want in EXPECTED:
        got = v.get((sex, age, stat))
        g.check(f"{sex} full-time {age} {stat}", got == want, f"published {want:,}, parsed {got}")
    t = pd.read_csv(pt)
    t = t[(t.year == 2025) & (t.sex == "male") & (t.work_pattern == "full_time") & (t.geography == "United Kingdom")
          & (t.sector == "all")].set_index("statistic").value
    for stat in ("median", "p90"):
        g.check(f"consistency: ad hoc 3105 UK male FT {stat} == Table 6.7a male FT all ages",
                t[stat] == v[("male", "all", stat)], f"3105 {t[stat]:,}, 6.7a {v[('male', 'all', stat)]:,}")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
