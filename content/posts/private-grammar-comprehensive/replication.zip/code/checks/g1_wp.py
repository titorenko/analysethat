"""G1-WP: Widening Participation 'School Type' file reproduces the published three-way HE figures exactly.

time_period = year the cohort was aged 15; A-level students (a_level_status = ALevel).
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import Gate, latest_raw, read_ees  # noqa: E402

TYPES = ["Independent", "Selective State", "Other State"]
EXPECTED = {  # (time_period, entry_age, indicator): values for TYPES
    ("202021", "By Age 19", "participation_rate"): ["86.9", "88.8", "77.2"],
    ("202021", "By Age 19", "high_tariff_participation_rate"): ["58.6", "50.2", "24.2"],
    ("200910", "By Age 30", "participation_rate"): ["87.3", "93.1", "83.6"],
    ("200910", "By Age 30", "high_tariff_participation_rate"): ["60.3", "55.3", "24.1"],
}


def main():
    path = latest_raw("dfe_wp", "wp_school_type.csv")
    df = read_ees(path)
    g = Gate("G1-WP (Widening Participation, School Type)", [path])
    for (tp, age, ind), want in EXPECTED.items():
        for typ, w in zip(TYPES, want):
            rows = df[(df.time_period == tp) & (df.entry_age == age) & (df.a_level_status == "ALevel")
                      & (df.establishment_type == typ)]
            got = rows[ind].tolist()
            g.check(f"{tp} {age} A level {typ} {ind}", got == [w], f"published {w}, file {got}")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
