"""G-class: sector labels agree across DfE, GIAS and Cambridge, and the partially-selective hand list is applied.

Part 1, DfE vs GIAS admissions policy for state-funded schools:
DfE three-way label (16-18 institution info, else KS4 school information, 2024/25) is collapsed to
selective / non-selective and compared with GIAS AdmissionsPolicy (Selective / Non-selective / Not applicable /
blank). A hard disagreement = one says selective, the other non-selective. A soft disagreement = GIAS has no
policy ('Not applicable' or blank) for a school DfE labels. The full list is written to
logs/g_class_disagreements.csv; hard ones are listed in logs/gates.md.
The check FAILS on any hard disagreement (those need resolving by hand); soft ones are reported.
Part 2, partially selective schools (partially_selective.csv, gate G-partial): every listed URN is in school_master,
none is labelled selective by DfE or GIAS, none is in the grammar list, and the P3 universe carries them as their own
sector ('partially_selective').
Part 3, Cambridge sector vs GIAS sector for linked apply centres: every disagreement has a hand resolution in
class_resolutions.csv.
"""
import pandas as pd
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import Gate, read_ees, DERIVED, ROOT  # noqa: E402


def main():
    sm_p = DERIVED / "school_master.csv"
    sm = read_ees(sm_p)
    ps_p, link_p, res_p = DERIVED / "partially_selective.csv", DERIVED / "cambridge_centre_urn.csv", DERIVED / "class_resolutions.csv"
    uni_p = ROOT / "results" / "p3_universe.csv"
    g = Gate("G-class (DfE vs GIAS; partially selective list; Cambridge sector)", [sm_p, ps_p, link_p, res_p, uni_p])
    labelled = sm[sm.dfe_admissions_policy != ""]
    dis = labelled[labelled.selectivity_disagreement != ""].copy()
    dis["kind"] = dis.gias_admissions_policy.map(lambda v: "hard" if v in ("Selective", "Non-selective") else "soft")
    out = ROOT / "logs" / "g_class_disagreements.csv"
    dis[["urn", "name", "la_name", "establishment_type", "status", "dfe_admissions_policy", "gias_admissions_policy",
         "kind"]].to_csv(out, index=False)
    hard = dis[dis.kind == "hard"]
    g.note(f"- state schools with a DfE label: {len(labelled)}; agree with GIAS: {len(labelled) - len(dis)}")
    g.note(f"- soft (GIAS 'Not applicable' or blank): {(dis.kind == 'soft').sum()} -> "
           + "; ".join(f"{k}: {v}" for k, v in dis[dis.kind == 'soft'].selectivity_disagreement.value_counts().items()))
    g.note(f"- full list: {out.relative_to(ROOT).as_posix()}")
    by_type = dis[dis.kind == "soft"].establishment_type.value_counts()
    g.note("- soft by GIAS type: " + "; ".join(f"{k}: {v}" for k, v in by_type.items()))
    g.check("hard disagreements (selective vs non-selective)", len(hard) == 0, f"{len(hard)}")
    for r in hard.itertuples():
        g.note(f"  - {r.urn} {r.name} ({r.la_name}): {r.selectivity_disagreement}")

    ps = pd.read_csv(ps_p, dtype={"urn": str})
    ps = ps[ps.classification == "partially_selective"]
    smi = sm.set_index("urn")
    missing = sorted(set(ps.urn) - set(smi.index))
    g.check("partially selective: URNs in school_master", not missing, f"{len(ps)} listed; missing {missing}")
    sel = [u for u in ps.urn if u in smi.index and "Selective" in (smi.at[u, "dfe_admissions_policy"],
                                                                     smi.at[u, "gias_admissions_policy"])]
    g.check("partially selective: none labelled selective by DfE or GIAS", not sel, f"{sel}")
    gram = pd.read_csv(DERIVED / "top30_grammar.csv", dtype={"urn": str})
    clash = sorted(set(ps.urn) & set(gram.urn))
    g.check("partially selective: none in the grammar top-45 list", not clash, f"{clash}")
    uni = pd.read_csv(uni_p, dtype={"urn": str})
    inu = uni[uni.urn.isin(ps.urn)]
    g.check("partially selective: own sector in the P3 universe", (inu.sector == "partially_selective").all(),
            f"{len(inu)} of {len(ps)} are in the 16-18 universe; sectors {inu.sector.value_counts().to_dict()}")

    link = pd.read_csv(link_p, dtype=str)
    dis_c = link[link.urn.notna() & ((link.cam_sector == "Independent") != (link.gias_sector == "independent"))]
    res = pd.read_csv(res_p, dtype=str)
    unresolved = sorted(set(dis_c.urn) - set(res.urn))
    g.check("Cambridge vs GIAS sector: every disagreement resolved by hand", not unresolved,
            f"{len(dis_c)} disagreements, {len(dis_c) - len(unresolved)} resolved in class_resolutions.csv")
    for r in dis_c.itertuples():
        g.note(f"  - {r.urn} {r.centre_name}: Cambridge {r.cam_sector}, GIAS {r.gias_sector}")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
