"""G6: reproduce two published cost-benefit benchmarks from their own inputs (PLAN v2 §5).

GMMZ (Green, Machin, Murphy & Zhu; IZA DP 5018, 2010): boarding fees £75,000 at 2000 prices, £5,000 a year extra
  pay, "a return on capital of approximately 7%". Their figure is annual benefit / capital (a perpetuity yield),
  so the reproduction is 5,000 / 75,000; pass within 2pp. Shown for information: the day-school figure of the
  published version (£43,000, 13%, scouting B, not in this working paper) and the IRR of the same inputs once the
  10-15 year wait between fees and earnings is timed (fees at ages 8-17, premium at ages 23-60).
GMS (Gibbons, Machin & Silva; CEE DP 132, 2012): 12% of £10,700 at ages 16-65, 3.5%, discounted to age 5, NPV "about
  £20,600"; pass within 15%.

Usage: .venv/Scripts/python -I code/checks/g6_literature.py
"""
import re
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pdfplumber  # noqa: E402
from common import Gate, latest_raw  # noqa: E402


def text(path):
    with pdfplumber.open(path) as pdf:
        return re.sub(r"\s+", " ", " ".join(p.extract_text() or "" for p in pdf.pages))


def irr(flows):
    lo, hi = -0.05, 0.5
    for _ in range(80):
        m = (lo + hi) / 2
        lo, hi = (m, hi) if sum(c / (1 + m) ** t for t, c in flows) > 0 else (lo, m)
    return lo


def main():
    gmmz, gms = latest_raw("literature", "gmmz_iza_dp5018.pdf"), latest_raw("literature", "gms_ceedp132.pdf")
    g = Gate("G6 (GMMZ return on capital; GMS house premium vs NPV)", [gmmz, gms])

    t = text(gmmz)
    quotes = ("equates roughly to £75,000 at 2000 prices", "implies an additional £5,000 extra pay received in 2000",
              "gives a return on capital of approximately 7%")
    g.check("GMMZ quotes present", all(q in t for q in quotes), "; ".join(quotes))
    r = 5000 / 75000
    g.check("GMMZ boarding return on capital", abs(100 * r - 7) <= 2, f"5,000 / 75,000 = {r:.1%} vs 7%")
    g.note(f"  info: day, published version: 5,000 / 43,000 = {5000 / 43000:.1%} vs 13% (scouting B; not in DP 5018)")
    for label, cost in (("day", 4300), ("boarding", 7500)):
        flows = [(a - 8, -cost) for a in range(8, 18)] + [(a - 8, 5000) for a in range(23, 61)]
        g.note(f"  info: timed IRR, {label} (fees £{cost:,}/yr at ages 8-17, £5,000/yr at 23-60): {irr(flows):.1%}")

    t = text(gms)
    quotes = ("benefit of approximately £20,600", "to be at around £10,700", "discount rate of 3.5%")
    g.check("GMS quotes present", all(q in t for q in quotes), "; ".join(quotes))
    npv = sum(0.12 * 10700 / 1.035 ** (a - 5) for a in range(16, 66))
    g.check("GMS NPV of a 12% gain", abs(npv / 20600 - 1) <= 0.15, f"£{npv:,.0f} vs £20,600 ({npv / 20600 - 1:+.1%})")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
