"""G-article: no result number is typed by hand into the write-up.

Every number in writeup/article.md.tmpl that states a result must be a {placeholder} filled by article_values.py
from results/ or data/derived/ (evidence rows by row_id). This gate deletes the placeholders and fails if any %, £,
× or decimal number is left, other than section numbers, model versions and the inputs and definitions listed in
ALLOWED (each with its reason). An earlier version matched literals against all stored values; that test matched
a random number 97-100% of the time and was dropped.

Usage: .venv/Scripts/python -I code/checks/g_article.py writeup/article.md.tmpl
"""
import pathlib
import re
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import Gate  # noqa: E402

ALLOWED = {  # token -> reason
    "£3,000": "tutoring input (assumption stated in text)", "£8,000": "tutoring input (assumption stated in text)",
    "3.5%": "Green Book discount rate (input)", "3.0%": "Green Book discount rate after year 30 (input)",
    "2.1%": "borrowing discount rate (input)", "10-20%": "house-premium input range",
    "70%": "value-added coverage threshold (definition)", "95%": "confidence-interval level (definition)",
    "1.00×": "reference group (definition)", "-10%": "'top-10%' (a definition of P90+)",
    "3.5": "'3.5 years after graduation': Crawford and Vignoles survey timing (design, not a result)",
    "£4": "G-tax: largest gap to listentotaxman at five salaries (logs/gates.md, g_engine.py)",
    "10%": "G5 tolerance (definition of the check)",
}
MODELS = re.compile(r"(Opus|Fable|Sonnet|Haiku) \d\.\d")


def tokens(text):
    pat = r"[−-]?£?\d[\d,]*(?:\.\d+)?(?:k|%|×)?(?:-\d[\d,]*(?:\.\d+)?(?:k|%|×)?)?"
    for m in re.finditer(pat, text):
        t = m.group(0)
        if re.search(r"[%×k£.]", t):
            yield t, text[max(0, m.start() - 60):m.end() + 40].replace("\n", " ")


def main():
    art = pathlib.Path(sys.argv[1]).resolve()
    raw = art.read_text(encoding="utf-8")
    body = raw.split("\n---\n", 1)[1] if raw.startswith("---") else raw
    body = "\n".join(ln for ln in body.splitlines() if not ln.startswith("#"))      # section numbers
    body = MODELS.sub(" ", re.sub(r"\{[a-z0-9_]+\}", " ", body))
    body = re.sub(r"§\d+(?:\.\d+)*", " ", body)                                       # section references
    body = re.sub(r"\(fig-[^)]*\)|\[replication\.zip\]\(replication\.zip\)", "", body)
    g = Gate("G-article (no hand-typed result numbers in the write-up template)", [art])
    bad, n = [], 0
    for tok, ctx in tokens(body):
        n += 1
        if tok not in ALLOWED:
            bad.append((tok, ctx))
    g.check("no hand-typed result numbers", not bad, f"{n} literal numbers, {len(bad)} not in ALLOWED")
    for tok, ctx in bad:
        g.note(f"  - {tok}: …{ctx}…")
    g.check("placeholders present", len(re.findall(r"\{[a-z0-9_]+\}", raw)) > 100,
            f"{len(re.findall(r'[{][a-z0-9_]+[}]', raw))} placeholders")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
