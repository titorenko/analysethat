"""G1-RR1125: DfE RR1125 Table 6 school-type rows (2001/02 KS4 cohort, tax year 2017-18) parsed exactly."""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
from common import DERIVED, Gate, latest_raw  # noqa: E402

EXPECTED = {"non_selective": (60, 8, 23000), "independent": (60, 2, 35000), "selective": (67, 2, 33000)}
MEASURES = ["employment_rate", "out_of_work_benefits_rate", "average_earnings"]


def main():
    path = DERIVED / "rr1125_school_type.csv"
    d = pd.read_csv(path)
    t6 = d[d.table == 6].set_index(["school_type", "measure"]).value
    g = Gate("G1-RR1125 (DfE RR1125 Table 6, outcomes 15 years after GCSEs)",
             [path, latest_raw("rr1125", "RR1125_post16_pathways_LEO.pdf")])
    for st, want in EXPECTED.items():
        for m, w in zip(MEASURES, want):
            got = t6.get((st, m))
            g.check(f"{st} {m}", got == w, f"published {w:,}, parsed {got}")
    g.note(f"- info: table 5 (para 85) values = share of individuals on one of the 50 most common pathways: "
           f"{d[d.table == 5].set_index('school_type').value.to_dict()}")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
