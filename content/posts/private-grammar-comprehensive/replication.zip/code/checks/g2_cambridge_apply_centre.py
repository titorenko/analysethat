"""G2: Cambridge apply-centre parser.

(a) Hand check: the rows below were transcribed by eye from page images rendered by g2_render_pages.py
    (logs/g2_pages/*.png), not from parser output. Every field must match the parsed row exactly
    (name compared with typographic apostrophes unified). 46 rows, 5 cycles, both page geometries, '<3' cells,
    overseas rows without postcode, a UK row printed without postcode, and a postcode printed flush against
    the sector column (2013, 45985).
(b) Totals plausibility: per cycle, the apply-centre sums by sector must bracket the Cambridge school-type
    table (Home + Other blocks) for Maintained and Independent: lower bound counts each suppressed cell at its
    minimum ('<3' -> 0, or 1 for applications since a listed centre has >= 1 application; floor-5 '5' -> 1), upper
    bound at its maximum ('<3' -> 2, '5' -> 5). The residual reported is table minus the exact (unsuppressed)
    sum, i.e. what the suppressed cells must hold, and its mean per suppressed cell.

    .venv/Scripts/python -I code/checks/g2_cambridge_apply_centre.py
"""
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import DERIVED, Gate  # noqa: E402

import pandas as pd  # noqa: E402

M = ["applications", "offers", "acceptances"]
# cycle, centre, name, postcode ('' = blank), sector, applications, offers, acceptances -- as printed
HAND = """
2024|10011|Bedford Modern School|MK41 7NT|Independent|9|5|5
2024|10070|Kendrick School|RG1 5BN|Maintained|22|9|7
2024|10080|Reading School|RG1 5LW|Maintained|29|10|10
2024|10092|Eton College|SL4 6DW|Independent|50|16|13
2024|10107|Dr Challoner's Grammar School|HP6 5HA|Maintained|54|22|17
2024|10134|Wycombe Abbey School, High Wycombe|HP11 1PE|Independent|43|11|11
2024|10029|Abingdon School|OX14 1DE|Independent|30|6|5
2024|10033|St Helen & St Katharine|OX14 1BE|Independent|13|5|0
2024|10045|Wellington College, Crowthorne|RG45 7PU|Independent|24|9|9
2024|10132|Royal Grammar School, Buckinghamshire|HP13 6QT|Maintained|32|12|9
2024|10137|Sir William Borlase's Grammar School|SL7 2BR|Maintained|25|10|9
2024|10123|Stowe School|MK18 5EH|Independent|9|0|0
2024|89974|Trinity College Dublin||Other and Overseas|6|5|5
2024|89488|Christian Brothers Secondary School, Kilkenny||Other and Overseas|5|5|0
2025|10011|Bedford Modern School|MK41 7NT|Independent|14|5|5
2025|10070|Kendrick School|RG1 5BN|Maintained|20|9|7
2025|10080|Reading School|RG1 5LW|Maintained|34|12|11
2025|10092|Eton College|SL4 6DW|Independent|52|20|16
2025|10107|Dr Challoner's Grammar School|HP6 5HA|Maintained|52|16|13
2025|10134|Wycombe Abbey|HP11 1PE|Independent|31|7|6
2025|10132|The Royal Grammar School, High Wycombe|HP13 6QT|Maintained|50|7|7
2025|10125|Westhill Academy|AB32 6XZ|Maintained|5|5|5
2013|10011|Bedford Modern School|MK41 7NT|Independent|15|6|4
2013|10012|Bedford School|MK40 2TU|Independent|18|3|<3
2013|10070|Kendrick School|RG1 5BN|Maintained|16|6|<3
2013|10080|Reading School|RG1 5LW|Maintained|21|9|8
2013|10092|Eton College|SL4 6DW|Independent|62|31|24
2013|10107|Dr Challoners Grammar School|HP6 5HA|Maintained|27|11|10
2013|10134|Wycombe Abbey School, High Wycombe|HP11 1PE|Independent|33|17|16
2013|10172|Hills Road Sixth Form College|CB2 8PE|Maintained|55|23|21
2013|10002|Ysgol David Hughes|LL59 5SS|Maintained|<3|<3|<3
2013|45985|American Creativity Academy|32018|Other and Overseas|<3|<3|<3
2013|45769|NUS (National University of Singapore) High School of Math and Science||Other and Overseas|15|4|3
2013|46049|The High School Affiliated to Renmin University||Other and Overseas|11|3|3
2017|11057|Winchester College|SO23 9NA|Independent|28|13|13
2017|11078|Queen Elizabeth's School, Barnet|EN5 4DQ|Maintained|45|19|18
2017|11111|Haberdashers' Aske's Boys' School|WD6 3AF|Independent|47|19|19
2017|11139|Fearnhill School||Maintained|<3|<3|<3
2017|11162|St Albans High School for Girls|AL1 3SJ|Independent|12|4|<3
2017|11055|Peter Symonds College|SO22 6RX|Maintained|61|14|12
2020|10092|Eton College|SL4 6DW|Independent|64|25|20
2020|10107|Dr Challoner's Grammar School|HP6 5HA|Maintained|27|9|8
2020|10134|Wycombe Abbey School, High Wycombe|HP11 1PE|Independent|26|8|8
2020|10172|Hills Road Sixth Form College|CB2 8PE|Maintained|129|38|31
2020|10110|Aylesbury High School|HP21 7SX|Maintained|11|<3|<3
2020|10080|Reading School|RG1 5LW|Maintained|28|9|7
"""


def printed(row, m):
    """Reconstruct the printed token from the parsed row."""
    return "<3" if row[f"{m}_lt3"] else str(int(row[m]))


def main():
    ac = pd.read_csv(DERIVED / "cambridge_apply_centre.csv", dtype={"centre_number": str, "postcode": str},
                     keep_default_na=False, na_values={m: [""] for m in M})
    st = pd.read_csv(DERIVED / "cambridge_school_type.csv")
    g = Gate("G2-Cambridge apply-centre parser", [DERIVED / "cambridge_apply_centre.csv",
                                                  DERIVED / "cambridge_school_type.csv"])
    idx = ac.set_index(["cycle", "centre_number"])

    # (a) hand check
    rows = [r.split("|") for r in HAND.strip().split("\n")]
    ok_n = 0
    for cy, cn, name, pc, sector, *vals in rows:
        key = (int(cy), cn)
        if key not in idx.index:
            g.check(f"{cy} {cn} {name}", False, "row missing from parsed table")
            continue
        r = idx.loc[key]
        got = [r.centre_name.replace("’", "'"), r.postcode, r.sector] + [printed(r, m) for m in M]
        exp = [name, pc, sector] + vals
        floor_ok = all(r[f"{m}_floor5"] == (int(cy) >= 2024 and v == "5") for m, v in zip(M, vals))
        ok = got == exp and floor_ok
        ok_n += ok
        g.check(f"{cy} {cn} {name}", ok, " / ".join(vals) + f", {sector}, '{pc}'"
                + ("" if ok else f" -- parsed {got}, floor5 flags ok={floor_ok}"))
    cycles = sorted({int(r[0]) for r in rows})
    g.check("hand-check coverage", len(rows) >= 20 and len(cycles) >= 3 and ok_n == len(rows),
            f"{ok_n}/{len(rows)} rows match exactly, cycles {cycles}")

    # (b) totals plausibility vs the school-type table (Home + Other blocks)
    tab = st[st.level.eq("sector")].groupby(["cycle", "school_type"])[M].sum(min_count=1)
    g.note("\nTotals residual (Table 1.1/2.1 Home+Other vs apply-centre sums; residual = table - exact sum "
           "= what the suppressed cells hold):\n")
    g.note("| cycle | sector | measure | table | exact sum | suppressed cells | residual | mean per suppressed cell | allowed [lo, hi] |")
    g.note("|---|---|---|---|---|---|---|---|---|")
    for cy in sorted(ac.cycle.unique()):
        for sec in ["Maintained", "Independent", "Other and Overseas"]:
            sub = ac[(ac.cycle == cy) & (ac.sector == sec)]
            for m in M:
                t = tab.loc[(cy, sec), m]
                if pd.isna(t):      # 2013 has no offers column
                    continue
                lt3, f5 = sub[f"{m}_lt3"], sub[f"{m}_floor5"]
                exact = sub[m][~(lt3 | f5)].sum()
                n_sup = int(lt3.sum() + f5.sum())
                lo = exact + lt3.sum() * (1 if m == "applications" else 0) + f5.sum()
                hi = exact + 2 * lt3.sum() + 5 * f5.sum()
                resid = int(t - exact)
                g.note(f"| {cy} | {sec} | {m} | {int(t):,} | {int(exact):,} | {n_sup:,} | {resid:,} | "
                       f"{resid / n_sup:.2f} | [{int(lo):,}, {int(hi):,}] |")
                if sec != "Other and Overseas":
                    g.check(f"{cy} {sec} {m} bracketed", lo <= t <= hi,
                            f"table {int(t):,} in [{int(lo):,}, {int(hi):,}]")
    sys.exit(g.finish())


if __name__ == "__main__":
    main()
