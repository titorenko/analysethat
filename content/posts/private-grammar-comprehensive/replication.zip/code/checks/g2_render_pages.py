"""G2 helper: render the apply-centre PDF pages used for the hand check to PNG (pypdfium2, ships with
pdfplumber) under logs/g2_pages/, split into top/bottom halves so the rows are legible. The expected values
in g2_cambridge_apply_centre.py were transcribed by eye from these images, not from parser output.

    .venv/Scripts/python -I code/checks/g2_render_pages.py
"""
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import ROOT, latest_raw  # noqa: E402

import pypdfium2 as pdfium  # noqa: E402

PAGES = [(2013, 1), (2013, 28), (2017, 5), (2020, 1), (2024, 1), (2024, 56), (2025, 1)]
OUT = ROOT / "logs" / "g2_pages"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for cycle, pno in PAGES:
        path = latest_raw("cambridge_apply_centre", f"undergraduate_admissions_by_apply_centre_{cycle}_cycle.pdf")
        page = pdfium.PdfDocument(path)[pno - 1]
        scale = 2.5 if page.get_width() < 700 else 1.6
        img = page.render(scale=scale).to_pil()
        w, h = img.size
        for half, box in (("top", (0, 0, w, h // 2 + 20)), ("bottom", (0, h // 2 - 20, w, h))):
            f = OUT / f"apply_centre_{cycle}_p{pno:02d}_{half}.png"
            img.crop(box).save(f)
            print(f.relative_to(ROOT), img.crop(box).size)


if __name__ == "__main__":
    main()
