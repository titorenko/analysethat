"""G2: Imperial apply-centre table (data/derived/imperial_apply_centre.csv) against the workbook's own summary.

(a) For 2022-2024, the per-centre rows summed by centre type equal the 'Application Centre figures' sheet
    (its UK, EU and overseas centre blocks added together), for applications, offers, rejections, acceptances.
(b) Every row: offers + rejections <= applications (withdrawals are the rest). Acceptances can exceed offers (23
    rows, a few with no application that cycle): the excess must stay below 0.5% of acceptances.
(c) One row per cycle and centre; centre numbers shared with Oxford and Cambridge mean the same school: names agree
    with Cambridge's for most centres (a printed share, not a pass/fail; names change between cycles).

    .venv/Scripts/python -I code/checks/g2_imperial_apply_centre.py
"""
import difflib
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import DERIVED, Gate, latest_raw  # noqa: E402

import pandas as pd  # noqa: E402

M = ["applications", "offers", "rejections", "acceptances"]
HEAD = {"Applications": "applications", "Offers": "offers", "Rejections": "rejections", "Acceptance": "acceptances"}


def summary(path):
    raw = pd.read_excel(path, sheet_name="Application Centre figures", header=None)
    rows = []
    for i in raw.index[raw.iloc[:, 1].astype(str).str.strip() == "Applications"]:
        measure, cols = None, {}
        for j in range(1, raw.shape[1]):
            if pd.notna(raw.iat[i, j]):
                measure = HEAD.get(str(raw.iat[i, j]).strip())
            if measure:
                cols[j] = (measure, int(str(raw.iat[i + 1, j])[:4]))
        k = i + 2
        while k < len(raw) and pd.notna(raw.iat[k, 0]) and str(raw.iat[k, 0]).strip() != "Grand Total":
            for j, (m, cyc) in cols.items():
                v = raw.iat[k, j]
                rows.append({"centre_type": str(raw.iat[k, 0]).strip(), "measure": m, "cycle": cyc,
                             "value": 0 if pd.isna(v) else int(v)})
            k += 1
    return pd.DataFrame(rows).groupby(["cycle", "centre_type", "measure"]).value.sum()


def main():
    df = pd.read_csv(DERIVED / "imperial_apply_centre.csv")
    g = Gate("G2 Imperial apply centre", [DERIVED / "imperial_apply_centre.csv"])
    want = summary(latest_raw("imperial_apply_centre", "Application-figures-by-School-2020-2024.xlsx"))
    got = df[df.cycle >= 2022].melt(id_vars=["cycle", "centre_type"], value_vars=M, var_name="measure") \
        .groupby(["cycle", "centre_type", "measure"]).value.sum()
    both = pd.concat({"want": want, "got": got}, axis=1).fillna(0)
    bad = both[both.want != both.got]
    g.check("2022-2024 sums by centre type = summary sheet", bad.empty,
            f"{len(both)} type x measure x cycle cells equal" if bad.empty else bad.head(8).to_string())

    errs = int(((df.offers > df.applications) | (df.offers + df.rejections > df.applications)).sum())
    g.check("row validity", errs == 0, f"{len(df):,} rows, {errs} with offers + rejections > applications")
    over = df[df.acceptances > df.offers]
    excess = (over.acceptances - over.offers).sum() / df.acceptances.sum()
    g.check("acceptances above offers are rare", excess < 0.005,
            f"{len(over)} rows have more acceptances than offers (some with no application that cycle: places "
            f"counted outside the cycle's offers, e.g. deferred entry); the excess is {excess:.2%} of acceptances")
    g.check("one row per cycle x centre", not df.duplicated(["cycle", "centre_number"]).any(),
            f"{df.groupby('cycle').size().to_dict()} centres per cycle")

    cam = pd.read_csv(DERIVED / "cambridge_apply_centre.csv", dtype=str).sort_values("cycle") \
        .drop_duplicates("centre_number", keep="last").set_index("centre_number").centre_name
    imp = df.sort_values("cycle").drop_duplicates("centre_number", keep="last")
    imp = imp[imp.centre_number.astype(str).isin(cam.index) & (imp.centre_number >= 10000)]
    r = [difflib.SequenceMatcher(None, a.lower(), cam[str(c)].lower()).ratio()
         for a, c in zip(imp.centre_name, imp.centre_number)]
    share = sum(x >= 0.6 for x in r) / len(r)
    g.check("centre numbers name the same schools as Cambridge's", share >= 0.9,
            f"{share:.1%} of {len(r):,} shared centres have similar names (ratio >= 0.6)")
    sys.exit(g.finish())


if __name__ == "__main__":
    main()
