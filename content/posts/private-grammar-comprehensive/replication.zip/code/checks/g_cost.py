"""G-cost (ISC part): 11-18 day route at day schools, incl. 20% VAT, flat nominal fees, from the derived ISC table:
5 senior years + 2 sixth-form years, 3 terms a year. Must reproduce scouting file E's £165,500 within 1%.
(The Rathbones £461k comparison in PLAN.md G-cost needs the P5 engine and is not checked here.)
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
from common import DERIVED, Gate  # noqa: E402

TARGET, TOL, VAT, TERMS = 165_500, 0.01, 1.2, 3


def main():
    path = DERIVED / "isc_fees_2026.csv"
    f = pd.read_csv(path, dtype={"year": str})
    f = f[(f.table == "5.1") & (f.statistic == "termly_fee_gbp_excl_vat") & (f.fee_type == "day_at_day_schools")]
    fee = f.set_index("phase").value
    total = 5 * fee["senior"] * TERMS * VAT + 2 * fee["sixth_form"] * TERMS * VAT
    g = Gate("G-cost (ISC 2026 11-18 day route incl. VAT)", [path])
    g.check("5 x senior + 2 x sixth form, x3 terms x1.2 VAT", abs(total / TARGET - 1) <= TOL,
            f"£{total:,.1f} vs £{TARGET:,} (diff {100 * (total / TARGET - 1):+.2f}%, tolerance ±1%); "
            f"senior £{fee['senior']:,.0f}/term, sixth form £{fee['sixth_form']:,.0f}/term")
    g.note(f"- info: same route excl. VAT = £{total / VAT:,.1f}")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
