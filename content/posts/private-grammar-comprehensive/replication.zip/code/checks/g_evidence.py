"""G-evidence: data/derived/evidence_table.csv is quote-verified and fully labelled.

Re-checks the table independently of code/derive/build_evidence_table.py:
1. every row has an estimand (RAW / ADJ-PRE / ADJ-MED), a sex (all / men / women) and a documented measure;
2. every row with a source_file has its quote in the pdfplumber text of the page named in table_or_page
   ("PDF p.N"). Matching deletes all whitespace and NULs, maps U+2212 and the per-file (cid:N) minus glyphs to "-",
   and tries the whole page, left/right column crops (as g_quotes.py) and the character-reversed page (rotated
   tables);
3. rows not flagged [derived] / [worded] in `note` show their estimate inside the quote in some printed form
   (the unsigned value for rows flagged [signed], whose sign comes from the wording, e.g. "... lower");
4. estimate_pct = exp(estimate) - 1 on log-point rows and is empty elsewhere; row_id is unique.
Prints counts by study x status.

Usage: .venv/Scripts/python -I code/checks/g_evidence.py
"""
import math
import re
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
import pdfplumber  # noqa: E402
from common import DERIVED, ROOT, Gate  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ESTIMANDS = {"RAW", "ADJ-PRE", "ADJ-MED"}
SEXES = {"all", "men", "women"}
MEASURES = {"log_points", "pp", "pct", "frac", "sd", "grade", "points", "gbp", "ratio", "elasticity"}
CID = {"ghv2017_berj.pdf": {"(cid:3)": "-"}, "dfm2002_restat.pdf": {"(cid:11)": "-"},
       "bdm2020_oep.pdf": {"(cid:4)": "-"}}


def squash(s, fname):
    for k, v in CID.get(fname, {}).items():
        s = s.replace(k, v)
    return "".join(s.replace("\x00", "").replace("−", "-").split())


def variants(pg, fname):
    text = pg.extract_text() or ""
    out = [text]
    words = pg.extract_words()
    gaps = [x for x in range(150, 346, 2) if not any(w["x0"] < x < w["x1"] for w in words)]
    if gaps:
        x = gaps[len(gaps) // 2]
        out += [pg.crop((0, 0, x, pg.height)).extract_text() or "",
                pg.crop((x, 0, pg.width, pg.height)).extract_text() or ""]
    for k, v in CID.get(fname, {}).items():
        text = text.replace(k, v)
    out.append(text[::-1])
    return [squash(t, fname) for t in out]


def printed_forms(x):
    forms = {f"{x:g}", f"{x:.1f}", f"{x:.2f}", f"{x:.3f}"}
    forms |= {f.replace("0.", ".", 1) for f in list(forms) if f.startswith(("0.", "-0."))}
    if x == int(x) and abs(x) >= 1000:
        forms |= {f"{x:,.0f}", f"{x / 1000:g}k", f"{x / 1000:g}"}
    return forms


def main():
    path = DERIVED / "evidence_table.csv"
    df = pd.read_csv(path, dtype={"source_file": str, "quote": str, "note": str}, keep_default_na=False)
    files = sorted({f for f in df["source_file"] if f})
    g = Gate("G-evidence", [path] + [ROOT / f for f in files])

    g.check("row_id unique", df["row_id"].is_unique, f"{len(df)} rows")
    bad = df[~df["estimand"].isin(ESTIMANDS) | ~df["sex"].isin(SEXES) | ~df["measure"].isin(MEASURES)]
    g.check("estimand, sex and measure set on every row", bad.empty,
            "all rows labelled" if bad.empty else f"bad: {', '.join(bad['row_id'])}")

    est = pd.to_numeric(df["estimate"], errors="coerce")
    pct = pd.to_numeric(df["estimate_pct"], errors="coerce")
    logp = df["measure"] == "log_points"
    want = est.where(logp).map(lambda b: math.exp(b) - 1 if pd.notna(b) else float("nan"))
    ok_pct = ((pct - want).abs() < 1e-4) | (pct.isna() & want.isna())
    g.check("estimate_pct = exp(estimate) - 1 on log-point rows only", ok_pct.all(),
            f"{int(logp.sum())} log-point rows" if ok_pct.all() else f"bad: {', '.join(df.loc[~ok_pct, 'row_id'])}")

    cache = {}
    misses, nomatch = {}, {}
    for _, r in df.iterrows():
        if not r["source_file"]:
            continue
        fname = pathlib.Path(r["source_file"]).name
        m = re.search(r"PDF p\.(\d+)", r["table_or_page"])
        page = int(m.group(1))
        key = (r["source_file"], page)
        if key not in cache:
            with pdfplumber.open(ROOT / r["source_file"]) as pdf:
                cache[key] = variants(pdf.pages[page - 1], fname)
        q = squash(r["quote"], fname)
        if not any(q in t for t in cache[key]):
            misses.setdefault(r["study"], []).append(r["row_id"])
        flagged = "[derived]" in r["note"] or "[worded]" in r["note"]
        x = float(r["estimate"]) if r["estimate"] != "" else None
        if x is not None and "[signed]" in r["note"]:
            x = abs(x)
        if x is not None and not flagged and not any(f in q for f in printed_forms(x)):
            nomatch.setdefault(r["study"], []).append(r["row_id"])
    for study, sub in df[df["source_file"] != ""].groupby("study"):
        miss = misses.get(study, [])
        g.check(f"quotes in source PDF: {study}", not miss,
                f"{len(sub) - len(miss)}/{len(sub)}" + (f"; missing {', '.join(miss)}" if miss else ""))
        nm = nomatch.get(study, [])
        g.check(f"estimate printed in quote: {study}", not nm,
                "all unflagged rows" if not nm else f"not found: {', '.join(nm)}")

    counts = df.groupby(["study", "status"]).size().unstack(fill_value=0)
    g.note("\nRows by study x status:\n```\n" + counts.to_string() + "\n```")
    g.note(f"Totals: {df['status'].value_counts().to_dict()}")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
