"""G-quotes: every quoted line in the hand-written source notes is verbatim in its PDF (pdfplumber text).

Quote lines have the form   > "text" — PDF p. N
Matching is whitespace-normalised and is tried against the whole page and against left/right column crops
(split at a vertical gap that no word crosses), because several pages are multi-column.
"""
import re
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pdfplumber  # noqa: E402
from common import DERIVED, Gate, latest_raw  # noqa: E402

DOCS = {"isc_2025_vat.md": ("isc", "isc_census_2025.pdf"),
        "ifs2026_assumptions.md": ("ifs", "ifs_2026_degrees_lifetime_earnings.pdf")}
QUOTE = re.compile(r'^> "(.+)" — PDF p\. (\d+)\s*$')


def norm(s):
    return re.sub(r"\s+", " ", s or "").strip()


def page_texts(pg):
    texts = [pg.extract_text()]
    words = pg.extract_words()
    gaps = [x for x in range(150, 346, 2) if not any(w["x0"] < x < w["x1"] for w in words)]
    if gaps:
        x = gaps[len(gaps) // 2]
        texts += [pg.crop((0, 0, x, pg.height)).extract_text(), pg.crop((x, 0, pg.width, pg.height)).extract_text()]
    return [norm(t) for t in texts]


def main():
    sources = [DERIVED / d for d in DOCS] + [latest_raw(*v) for v in DOCS.values()]
    g = Gate("G-quotes (source notes quoted verbatim from PDFs)", sources)
    for doc, (src, pattern) in DOCS.items():
        quotes = [m.groups() for ln in (DERIVED / doc).read_text(encoding="utf-8").splitlines()
                  for m in [QUOTE.match(ln.strip())] if m]
        g.check(f"{doc}: quotes found", len(quotes) > 0, f"{len(quotes)} quote lines")
        with pdfplumber.open(latest_raw(src, pattern)) as pdf:
            cache = {}
            for text, page in quotes:
                p = int(page)
                if p not in cache:
                    cache[p] = page_texts(pdf.pages[p - 1])
                ok = any(norm(text) in t for t in cache[p])
                g.check(f"{doc} p.{p}", ok, f'"{text[:70]}{"..." if len(text) > 70 else ""}"')
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
