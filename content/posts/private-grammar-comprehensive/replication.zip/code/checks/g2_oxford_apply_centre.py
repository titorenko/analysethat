"""G2: Oxford apply-centre dashboard OCR (data/derived/oxford_apply_centre*.csv).

(a) Hand check: rows read by eye from the tile images and dashboard screenshots on 2026-11-07, not from
    OCR output. Five cycles plus the 2023-25 total, suppressed cells, a NULL postcode, the overseas row.
(b) Completeness: rows per table == the table's pixel height / 20 (one row = 20 CSS px; heights from the
    dashboard's own layout response, recorded when the tiles were captured).
(c) Row validity: IDs strictly increasing and unique (the table is sorted by UCAS School ID), postcode
    UK-format / 'Non-UK' / 'NULL', school type in {State, Independent, Other}, every shown count >= 3,
    acceptances <= offers <= applications, each rate shown iff both its counts are, and equal to the
    counts to the nearest whole percent.
(d) Three-year sum: for every centre and count, the 2023-25 total equals 2023 + 2024 + 2025 when all
    three are shown, and lies within the suppression bounds otherwise (a blank year adds 1-2
    applications or 0-2 offers/acceptances; a missing row adds 0; a blank total means 0-2).
Note only: UK-postcode sums by school type next to Table 4.1 of the annual report. They are not a check:
the report counts UK-domiciled applicants, the dashboard counts by apply centre (overseas pupils at UK
schools included), and suppressed cells are missing.

    .venv/Scripts/python -I code/checks/g2_oxford_apply_centre.py
"""
import re
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import DERIVED, Gate  # noqa: E402

import pandas as pd  # noqa: E402

M = ["applications", "offers", "acceptances"]
HEIGHT = {"2021": 70040, "2022": 71740, "2023": 71860, "2024": 71160, "2025": 72320, "2023-2025": 98540}
PC = re.compile(r"^[A-Z]{1,2}[0-9][0-9A-Z]? [0-9][A-Z]{2}$")
# cycle | centre | name | postcode | type | applications | offers | offer % | acceptances | acceptance %  ('' = grey)
HAND = """
2025|100|Apply Online Overseas|Non-UK|Other|3566|276|8|193|5
2025|10108|Dr Challoner's High School for Girls|HP7 9QB|State|23|6|26|5|22
2025|10134|Wycombe Abbey School, High Wycombe|HP11 1PE|Independent|34|14|41|11|32
2025|10172|Hills Road Sixth Form College|CB2 8PE|State|177|49|28|44|25
2025|10268|Sir John Deanes College|CW9 8AF|State|44|11|25|11|25
2025|10274|Sale Grammar School|M33 3NH|State|15|5|33|5|33
2025|14090|Down High School|BT30 6EU|State|7||||
2025|21365|Harris Rainham Sixth Form|NULL|State|||||
2024|10139|Langley Grammar School|SL3 7QS|State|22|7|32|7|32
2024|10380|Maelor School, Wrexham|LL13 0LU|State|3||||
2023|10371|Ysgol Dyffryn Conwy|LL26 0SD|State|||||
2022|12527|Headington Rye|OX3 7TB|Independent|7|3|43||
2021|12981|Brighton College|BN2 0AL|Independent|57|11|19|11|19
2021|45288|The British School Al Khubairat, UAE|Non-UK|Other|7||||
2023-2025|100|Apply Online Overseas|Non-UK|Other|9945|768|8|547|6
2023-2025|10029|Abingdon School|OX14 1DE|Independent|85|30|35|30|35
2023-2025|10032|Radley College|OX14 2HR|Independent|143|33|23|30|21
2023-2025|10045|Wellington College, Crowthorne|RG45 7PU|Independent|116|33|28|31|27
"""


def v(x):
    return "" if pd.isna(x) else str(int(x)) if not isinstance(x, str) else x


def main():
    kw = dict(dtype={"cycle": str}, keep_default_na=False, na_values=[""])   # keep the printed 'NULL' postcodes
    single = pd.read_csv(DERIVED / "oxford_apply_centre.csv", **kw)
    total = pd.read_csv(DERIVED / "oxford_apply_centre_2023_2025.csv", **kw)
    allr = pd.concat([single, total], ignore_index=True)
    g = Gate("G2 Oxford apply centre (OCR)", [DERIVED / "oxford_apply_centre.csv",
                                             DERIVED / "oxford_apply_centre_2023_2025.csv"])

    # (a) hand rows
    idx = allr.set_index(["cycle", "centre_number"])
    for line in HAND.strip().splitlines():
        cy, cn, name, pc, typ, a, o, orr, c, cr = line.split("|")
        r = idx.loc[(cy, int(cn))]
        got = [r.centre_name, r.postcode, r.school_type, v(r.applications), v(r.offers), v(r.offer_rate_pct),
               v(r.acceptances), v(r.acceptance_rate_pct)]
        want = [name, pc, typ, a, o, orr, c, cr]
        g.check(f"hand {cy} {cn}", got == want, f"{got}" if got != want else name)

    # (b) completeness
    for cy, h in HEIGHT.items():
        n = (allr.cycle == cy).sum()
        g.check(f"{cy} row count", n == h // 20, f"{n} rows, table height {h} px / 20 = {h // 20}")

    # (c) row validity
    for cy, d in allr.groupby("cycle"):
        ids = d.sort_values("table_row").centre_number
        bad = []
        bad += ["ids not strictly increasing"] if not ids.is_monotonic_increasing or ids.duplicated().any() else []
        pcs = d.postcode.fillna("")
        bad += [f"postcode {p!r}" for p in pcs if not (p in ("Non-UK", "NULL") or PC.match(p))]
        bad += [f"type {t!r}" for t in d.school_type if t not in ("State", "Independent", "Other")]
        for m in M:
            bad += [f"{m} {x} < 3" for x in d[m].dropna() if x < 3]
        a, o, c = d.applications, d.offers, d.acceptances
        bad += ["offers > applications"] * int((o > a).sum()) + ["acceptances > offers"] * int((c > o).sum())
        for rate, num in (("offer_rate_pct", o), ("acceptance_rate_pct", c)):
            shown = num.notna() & a.notna()
            bad += [f"{rate} presence"] * int((d[rate].notna() != shown).sum())
            dev = (d[rate] - 100 * num / a).abs()
            bad += [f"{rate} off by {x:.2f}" for x in dev[shown] if x > 0.5001]
        g.check(f"{cy} row validity", not bad, f"{len(d)} rows clean" if not bad else "; ".join(bad[:5]))

    # (d) three-year sum
    yrs = {cy: single[single.cycle == cy].set_index("centre_number") for cy in ("2023", "2024", "2025")}
    exact = bounded = 0; fails = []
    for _, t in total.iterrows():
        for m in M:
            lo = hi = 0; all_shown = True
            for d in yrs.values():
                if t.centre_number not in d.index:
                    all_shown = False; continue
                x = d.at[t.centre_number, m]
                if pd.notna(x):
                    lo += x; hi += x
                else:
                    all_shown = False; lo += 1 if m == "applications" else 0; hi += 2
            tv = t[m]
            ok = (tv == lo if all_shown else lo <= tv <= hi) if pd.notna(tv) else lo <= 2
            if not ok:
                fails.append(f"{t.centre_number} {m} total {v(tv)} vs [{lo}, {hi}]")
            elif all_shown:
                exact += 1
            else:
                bounded += 1
    only_single = set().union(*[set(d.index) for d in yrs.values()]) - set(total.centre_number)
    g.check("2023-25 total = sum of years", not fails and not only_single,
            f"{exact:,} exact sums equal, {bounded:,} within suppression bounds, {len(fails)} failures, "
            f"{len(only_single)} single-year centres missing from the total" + (f": {fails[:5]}" if fails else ""))

    # note: UK sums by school type vs annual report Table 4.1
    rep = pd.read_csv(DERIVED / "oxford_school_type.csv", dtype={"cycle": str})
    rep = rep[rep.latest_vintage].set_index(["cycle", "school_type"])
    g.note("\n| cycle | type | dashboard UK apps (shown) | report apps | offers shown | report offers | centres with apps < 3 |")
    g.note("|---|---|---|---|---|---|---|")
    for cy in ("2021", "2022", "2023", "2024", "2025"):
        d = single[(single.cycle == cy) & (single.postcode != "Non-UK")]
        for typ, lab in (("State", "state"), ("Independent", "independent")):
            x = d[d.school_type == typ]; R = rep.loc[(cy, lab)]
            g.note(f"| {cy} | {lab} | {int(x.applications.sum()):,} | {int(R.applications):,} | "
                   f"{int(x.offers.sum()):,} | {int(R.offers):,} | {int(x.applications_lt3.sum()):,} |")
    sys.exit(g.finish())


if __name__ == "__main__":
    main()
