"""G1-Cambridge and G1-Oxford: published school-type numbers reproduced exactly from the derived tables.

G1-Cambridge: 2025 Home rows of Table 2.1 and 2024 Home acceptances (values from the scouting report), plus
for every cycle 2013-2025 the headline 'proportions of acceptances' printed under the table (Maintained x%,
Independent y%), recomputed from the derived Home acceptances and compared at 1 dp.
G1-Oxford: Table 4.1 2025 row of the 2026 report, the state share of UK admitted, and a complete 2013-2025
latest-vintage series.

    .venv/Scripts/python -I code/checks/g1_cambridge_oxford.py
"""
import re
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import DERIVED, ROOT, Gate  # noqa: E402

import pandas as pd  # noqa: E402
import pdfplumber  # noqa: E402

CAM_2025 = {"Comprehensive School": (4955, 1125, 770), "Grammar School": (2799, 886, 721),
            "Sixth Form College": (1993, 534, 392), "FE and Tertiary Colleges": (415, 91, 54),
            "Maintained": (10162, 2636, 1937), "Independent": (3441, 890, 734)}
CAM_2024_ACC = {"Comprehensive School": 830, "Grammar School": 657, "Sixth Form College": 366,
                "FE and Tertiary Colleges": 44, "Independent": 776}
HEADLINE = re.compile(r"Maintained (\d+\.\d)% ?\((\d+\.\d)% in the previous cycle\)\s*Independent (\d+\.\d)%")


def cambridge():
    path = DERIVED / "cambridge_school_type.csv"
    st = pd.read_csv(path)
    g = Gate("G1-Cambridge (Undergraduate Admissions Statistics, school-type table)", [path])
    home = st[st.block.eq("home")].set_index(["cycle", "school_type"])
    for t, exp in CAM_2025.items():
        got = tuple(int(home.loc[(2025, t), m]) for m in ["applications", "offers", "acceptances"])
        g.check(f"2025 Home {t}", got == exp, f"{got} vs published {exp}")
    for t, exp in CAM_2024_ACC.items():
        got = int(home.loc[(2024, t), "acceptances"])
        g.check(f"2024 Home {t} acceptances", got == exp, f"{got} vs published {exp}")
    for cy in sorted(st.cycle.unique()):
        src = st[st.cycle.eq(cy)].iloc[0]
        with pdfplumber.open(ROOT / src.source_file) as pdf:
            text = pdf.pages[int(src.source_page) - 1].extract_text()
        m = HEADLINE.search(text)
        mt, it = home.loc[(cy, "Maintained"), "acceptances"], home.loc[(cy, "Independent"), "acceptances"]
        share = round(100 * mt / (mt + it), 1)
        ok = m is not None and float(m.group(1)) == share and float(m.group(3)) == round(100 - share, 1)
        g.check(f"{cy} headline maintained share of Home UK-school acceptances ({src.source_table})", ok,
                f"computed {share}% vs printed {m.group(1) if m else 'NOT FOUND'}%")
    return g.finish()


def oxford():
    path = DERIVED / "oxford_school_type.csv"
    ox = pd.read_csv(path)
    g = Gate("G1-Oxford (Annual Admissions Statistical Report 2026, Table 4.1)", [path])
    r = ox[ox.report_year.eq(2026) & ox.cycle.eq(2025)].set_index("school_type")
    for t, exp in {"state": (9959, 1971, 1671), "independent": (3706, 932, 842)}.items():
        got = tuple(int(r.loc[t, m]) for m in ["applications", "offers", "admitted"])
        g.check(f"2025 {t}", got == exp, f"{got} vs published {exp}")
    share = round(100 * r.loc["state", "admitted"] / (r.loc["state", "admitted"] + r.loc["independent", "admitted"]), 1)
    g.check("2025 state share of UK admitted", share == 66.5 == r.loc["state", "state_share_uk_admitted_pct_printed"],
            f"computed {share}%, printed {r.loc['state', 'state_share_uk_admitted_pct_printed']}%, published 66.5%")
    latest = ox[ox.latest_vintage]
    yrs = sorted(latest.cycle.unique())
    g.check("latest-vintage series complete", yrs == list(range(2013, 2026)) and len(latest) == 2 * len(yrs),
            f"cycles {yrs[0]}-{yrs[-1]}, {len(latest)} rows")
    return g.finish()


if __name__ == "__main__":
    sys.exit(cambridge() | oxford())
