"""Build data/derived/boe_curves_<YYYY-MM>.csv: Bank of England UK government spot curves for the latest date in
the 'latest yield curve data' zip: nominal spot, implied real spot (RPI-linked gilts) and implied RPI inflation spot,
by maturity in years (sheet '4. spot curve' of each GLC daily file). Values are % per year as published.

Usage: .venv/Scripts/python -I code/derive/build_boe.py
"""
import datetime as dt
import io
import zipfile
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import openpyxl  # noqa: E402
import pandas as pd  # noqa: E402
from common import latest_raw, write_derived  # noqa: E402

FILES = {"nominal_spot_pct": "GLC Nominal daily data current month.xlsx",
         "real_spot_pct": "GLC Real daily data current month.xlsx",
         "implied_inflation_spot_pct": "GLC Inflation daily data current month.xlsx"}


def spot(zf, name):
    rows = list(openpyxl.load_workbook(io.BytesIO(zf.read(name)), read_only=True, data_only=True)
                ["4. spot curve"].iter_rows(values_only=True))
    mat = next(r for r in rows if r[0] == "years:")
    dated = {r[0]: r for r in rows if isinstance(r[0], dt.datetime)}
    return mat, dated


def main():
    zp = latest_raw("boe", "latest-yield-curve-data.zip")
    zf = zipfile.ZipFile(zp)
    curves = {col: spot(zf, name) for col, name in FILES.items()}
    common = set.intersection(*(set(d) for _, d in curves.values()))
    date = max(common)
    cols = []
    for col, (mat, dated) in curves.items():
        row = dated[date]
        s = pd.Series({m: v for m, v in zip(mat[1:], row[1:]) if m is not None and isinstance(v, (int, float))},
                      name=col)
        cols.append(s)
    d = pd.concat(cols, axis=1).sort_index().rename_axis("maturity_years").reset_index()
    d.insert(0, "date", date.date().isoformat())
    gap = (d.nominal_spot_pct - d.real_spot_pct - d.implied_inflation_spot_pct).abs().max()
    print(f"curve date {date.date()}; max |nominal - real - inflation| = {gap:.2e} pct points")
    write_derived(d, f"boe_curves_{date:%Y-%m}")


if __name__ == "__main__":
    main()
