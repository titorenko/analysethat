"""Build data/derived/partially_selective.csv: hand-verified classification of state secondary schools whose
determined admission arrangements reserve places for applicants ranked or admitted on a test of ability
(grandfathered partial selection, SSFA 1998 s.100), and of the look-alikes that are not.

Usage: .venv/Scripts/python -I code/derive/build_partially_selective.py

Evidence: files fetched through code/harvest/fetch.py (source "partial_selection") into
data/raw/partial_selection/<day>/; the URL of each file is taken from data/manifest/partial_selection.csv.
Each EVIDENCE row is one school, read by hand. The build FAILS unless
- the URN is unique and an Open establishment in data/derived/school_master.csv;
- every segment of `quote` (segments are separated by " ... ") occurs in the file's extracted text
  (code/derive/extract_text.py; whitespace, case, curly quotes and dashes normalised);
- ability_places_n, pan and a stated ability_places_pct each occur inside the quote;
- a partially_selective row has n or pct; a blocked / unverified row has a URL and a reason in `note`.
ability_places_pct left blank but n and PAN known is computed as 100 * n / PAN and the note says so.
Classes and precedence: see data/derived/partially_selective.md.
"""
import csv
import re
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from common import DERIVED, RAW, ROOT, rel, read_ees, write_derived  # noqa: E402
from extract_text import text_of, norm  # noqa: E402

import pandas as pd  # noqa: E402

SOURCE = "partial_selection"
CLASSES = {"partially_selective", "aptitude_only", "banding", "sixth_form_entry_only", "none", "unverified",
           "blocked"}
COLS = ["urn", "name", "la_name", "classification", "ability_places_pct", "ability_places_n", "pan", "test_name",
        "entry_year_policy", "source_url", "source_file", "source_quote", "source_location", "note",
        "second_source_url", "second_source_file", "second_quote"]

SWHC = "SW Herts Consortium academic test (verbal reasoning and mathematics)"

# (urn, classification, pct, n, pan, test_name, entry_year_policy, file, quote, location, note[, pfile, pquote])
# file = a file name in data/raw/partial_selection/<day>/ ; for blocked / unverified rows it may be a URL instead.
# pfile / pquote: optional further document(s) (a string, or a list for several), used (a) for the place numbers
# when the determined arrangements classify the school but do not state n or PAN (n / PAN may then be inside a
# second quote), (b) for the Year 12 arrangements of a screened school, or (c) for a statement that ties the school
# to an LA document. Each is checked exactly like the first; in the CSV several are joined by " || ".
EVIDENCE = [
    # ------------------------------------------------------------------ Hertfordshire
    ("136554", "partially_selective", "", "65", "200",
     "Governors' Entrance Examination (verbal reasoning, then English and mathematics)", "2026/27",
     "owens_admission_arrangements_2026_27.pdf",
     "The Published Admission Number is 200 children. ... Up to 65 children selected by academic ability, having "
     "taken the two parts of the Governors' Entrance Examination.",
     "p1 (PAN); p3 oversubscription criterion 5",
     "also up to 10 places for musical aptitude (criterion 4); test open only to the local priority areas and "
     "Islington"),
    ("136276", "partially_selective", "25", "56", "224", SWHC, "2026/27",
     "wgsb_determined_admission_arrangements_2026_27.pdf",
     "Year 7 224 boys: 146 community places ... a further 56 places (25% of total admissions) for boys selected by "
     "academic ability",
     "s.1 Admission Numbers; s.2.1 Specialist places",
     "also 22 places (10%) for music aptitude"),
    ("136289", "partially_selective", "25", "52", "210", SWHC, "2026/27",
     "hcc_2627_watford-grammar-school-for-girls-determined-policy-26.27-5403.pdf",
     "Year 7 210 girls: 137 community places ... a further 52 places (25% of total admissions) for girls selected "
     "by academic ability",
     "s.1 Admission Numbers; s.2.1 Specialist places",
     "Hertfordshire CC copy (the school now links only its 2027 policy); also 21 places (10%) for music aptitude"),
    ("136899", "partially_selective", "25", "", "216", SWHC, "2026/27",
     "hcc_2627_parmiters-determined-policy-26.27-5404.pdf",
     "The School's Published Admissions Number for September 2026 is 216. ... Up to 25% of places shall be "
     "available in merit order by reference to academic ability.",
     "p1 (PAN); criterion 6",
     "Hertfordshire CC copy (school link 404s); also up to 10% for music aptitude (criterion 7)"),
    ("136606", "partially_selective", "25", "60", "240", SWHC, "2026/27",
     "ricky_admission_arrangements_2026_27.pdf",
     "The number of intended admissions in September 2026 is 240 pupils. ... 6. Not more than (25%) 60 places "
     "will be available by reference to academic ability in descending order of merit",
     "p4 Published Admission Number; p5 oversubscription criterion 6",
     "also not more than 24 (10%) for music aptitude (criterion 5)"),
    ("136901", "partially_selective", "10", "24", "240", SWHC, "2026/27",
     "hcc_2627_st-clements-danes-determined-policy-26.27-5421.pdf",
     "At Secondary Transfer, 10% of the intake is admitted on the basis of aptitude in music and a further 10% on "
     "their proven academic ability. ... 4.6 Testing for academic ability: Academic ability is determined through "
     "tests in verbal reasoning and mathematics.",
     "general information; s.4.6",
     "Hertfordshire CC copy; also 10% music aptitude (criterion 4); second source (school FAQ) gives PAN and the "
     "24 places allocated under criterion 5 on 2 March 2026",
     "scd_secondary_transfer_faqs.html",
     "The School's Published Admission Number (PAN) is 240. ... 662 applicants applied under the Academic Ability "
     "test. Scores ranged from 271 (highest) down to 138 (lowest). 24 places were awarded under this criterion."),
    ("136877", "partially_selective", "35", "94", "270", SWHC, "2026/27",
     "queens_admissions_policy_2026.pdf",
     "The published admission number (PAN) for Year 7 will be 270. ... (c) Up to 35% of places (94) will be "
     "available by ability, in strict order of merit, based on the results of the assessment test",
     "p1 (PAN); Rule 5 Assessment test",
     "rule 5 applies only to applicants in the school's listed postcodes; also up to 5% (13) sport and 5% (13) "
     "music aptitude"),
    ("144402", "aptitude_only", "", "", "180", "", "2026/27",
     "croxley_determined_admissions_arrangements_2026.pdf",
     "The school is a co-educational, all-ability academy. ... The PAN for Year 7 is 180 students. ... 4. Up to 10% "
     "of places will be for students demonstrating musical aptitude as determined by test",
     "p2 s.1 and s.2; oversubscription criterion 4",
     "SW Herts Consortium member for the music test only; no academic-ability criterion"),
    ("117577", "aptitude_only", "", "", "180", "", "2026/27",
     "hcc_2627_bishops-stortford-high-determined-policy-2627-5405.pdf",
     "TBSHS is an all-ability single sex boys* 11-16 school ... The Published Admission Number for the year "
     "commencing September 2026 is 180. ... 90% of places will be allocated using the following four criteria in "
     "the order set out below with 10% reserved for aptitude tests.",
     "p1 introduction; oversubscription preamble",
     "up to 9 sport and up to 9 music aptitude places; boys 11-16, co-educational sixth form"),
    ("136482", "aptitude_only", "", "", "120", "", "2026/27",
     "hockerill_determined_admission_arrangements_2026.pdf",
     "Year of Entry Day Boarding Total 7 68 52 120 ... Children who are successful in gaining one of the places "
     "available to those who demonstrate the greatest aptitude for modern foreign languages and/or music. 10% of "
     "places",
     "p2 Admission Numbers; p3 day oversubscription criterion 3",
     "aptitude = languages and/or music; boarding places need an interview for suitability for boarding, not "
     "an ability test"),
    ("140786", "aptitude_only", "", "", "186", "", "2026/27",
     "hertsessex_secondary_transfer_admissions_arrangements_2026.pdf",
     "The Hertfordshire & Essex High School is an all ability single sex school for girls aged 11-16 ... The number "
     "to be admitted to Year 7 in September 2026 is 186. ... 10% of allocations will be reserved for applicants "
     "taking the aptitude tests under criterion 7.",
     "p1 introduction and oversubscription preamble",
     "aptitude = music and/or sport tests"),
    ("137922", "none", "", "", "180", "", "2026/27",
     "stmichaels_watford_admissions_policy_2026_27.pdf",
     "Students will be admitted at age 11 without reference to ability or aptitude. ... The published admission "
     "number for admission to Year 7 each year will be 180.",
     "p1 introduction",
     "Catholic school: baptised Catholic, siblings, feeder schools, then distance; Year 12 not assessed"),
    ("136973", "none", "", "", "189", "", "2026/27",
     "roundwood_determined_admission_arrangements_2026_27.pdf",
     "Roundwood Park School is a co-educational, all-ability school for children aged 11-18. The published "
     "admission number for Year 7 is 189.",
     "p1",
     "Hertfordshire rules (looked after, medical/social, siblings, nearest school, priority-area distance); "
     "second source = Year 12 arrangements: external PAN 40, entry requirements left to the prospectus, "
     "oversubscription by non-academic rules",
     "roundwood_sixth_form_admission_arrangements_2026_27.pdf",
     "Minimum entry requirements are as set out in our Sixth Form prospectus. In the event of oversubscription to "
     "the Sixth Form places will be offered by applying the following criteria"),
    ("138356", "none", "", "", "170", "", "2026/27",
     "stgeorges_harpenden_admission_criteria_2026.pdf",
     "The Governors have agreed to admit 170 day pupils into Year 7 for September 2026. ... 5. Children living with "
     "a parent or parents with a Christian commitment shown by membership of a Christian Church",
     "p1 preamble and criterion 5",
     "day criteria: looked after, staff, siblings, Christian commitment, then others; no test; boarding places are "
     "separate (suitability for boarding); second source = Year 12 arrangements: minimum five GCSEs at 9-5, below "
     "the grade-6 bar for sixth_form_entry_only",
     "stgeorges_harpenden_sixth_form_criteria_2026.pdf",
     "a) All entrants must have a minimum of 5 full GCSEs or equivalent (see Note 1) at grades 9-5"),
    ("136396", "aptitude_only", "", "", "240", "", "2026/27",
     "hcc_2627_broxbourne-school-determined-policy-2627-4101.pdf",
     "The Published Admission Number for the school year commencing 1st September 2026 is 240 pupils. In line with "
     "the school's specialist status as a Language College 10% of pupils will be admitted on the basis of their "
     "aptitude for languages.",
     "Policy, first paragraph",
     "on the Hertfordshire CC list of schools that test; languages aptitude test, criterion 6"),
    ("147246", "aptitude_only", "", "", "210", "", "2026/27",
     "hcc_2627_chancellors-determined-policy-2627-5419.pdf",
     "The School Board offers places each September to 210 pupils. ... Ten percent of the PAN (21 places) will be "
     "allocated on the basis of both a written musical aptitude test and a performance musical aptitude test.",
     "s.2.1 General principles; note d",
     "on the Hertfordshire CC list of schools that test; music only"),
    ("137532", "aptitude_only", "", "", "240", "", "2026/27",
     "hcc_2627_goffs-academy-determined-policy-2627-5415.pdf",
     "Goffs' published admission number is 240. ... 5. Children with an aptitude in foreign languages up to a "
     "maximum of 10% for the year, as measured by the school's testing procedures",
     "Admissions criteria for 2026-27, criterion 5",
     "on the Hertfordshire CC list of schools that test; languages only"),
    ("150656", "partially_selective", "", "15", "120",
     "school test labelled technology aptitude: non-verbal reasoning paper + spatial awareness test", "2026/27",
     "hcc_2627_john-warner-determined-policy-2627-4039.pdf",
     "The published admission number (PAN) for September 2026 will be 120. ... This will amount to 15 places. ... "
     "two papers: a non-verbal reasoning paper (40 minutes) and a spatial awareness test (45 minutes)",
     "p1 PAN; Appendix F Rule 6 Technology Aptitude Test",
     "REASONING-TEST RULE: the arrangements call these s.102 technology-aptitude places, but they are ranked on a "
     "non-verbal reasoning paper and a spatial test, i.e. a general-ability test; on the Hertfordshire CC list of "
     "schools that test"),
    ("138632", "aptitude_only", "", "", "236", "", "2026/27",
     "hcc_2627_monks-walk-determined-policy-2627-4118.pdf",
     "Monk's Walk is an all ability 11 - 18 comprehensive school. The Published Admission Number for Year 7 in "
     "2026/27 is 236 ... Up to ten percent of the PAN (23 places) will be allocated on the basis of both a written "
     "musical aptitude test and a performance musical aptitude test.",
     "p2 introduction; Rule 5",
     "on the Hertfordshire CC list of schools that test; music only, priority-area residents"),
    ("152099", "aptitude_only", "", "", "120", "", "2026/27",
     "hcc_2627_mount-grace-determined-policy-26.27-4040.pdf",
     "The published admission number (PAN) for the school year commencing 1st September 2026 is 120 pupils. ... "
     "The remaining 10% of places (12) will be allocated for children who show an aptitude in Music",
     "p1; Rule 6",
     "policy issued as Mount Grace School (closed URN 137224); the open establishment is Gracewood Academy "
     "(opened 1 Dec 2025, same site); music only"),
    ("140294", "aptitude_only", "", "", "180", "", "2026/27",
     "hcc_2627_simon-balle-determined-policy-2627-4067.pdf",
     "the number of students admitted at 11 years of age to Year 7 is 180. ... Up to ten percent of the PAN (12 "
     "places) will be allocated on the basis of both a written / aural and a performance musical aptitude test.",
     "p1; Rule 6",
     "all-through school: 120 of the 180 Year 7 places are for external applicants; music only"),
    ("137847", "aptitude_only", "", "", "240", "", "2026/27",
     "hcc_2627_stanborough-determined-policy-2627-4014.pdf",
     "The school will have a published admission number of 240 ... Up to ten percent of the PAN (24 places) will be "
     "allocated on the basis of both a written musical aptitude test and a performance musical aptitude test.",
     "p1; Rule 5",
     "on the Hertfordshire CC list of schools that test; music only"),
    ("136608", "none", "", "", "210", "", "2026/27",
     "hcc_2627_knights-templar-determined-policy-2627-4016.pdf",
     "Knights Templar School is a co-educational, all-ability school for children aged 11-18. The Published "
     "Admission Number (PAN) for Year 7 is 210. ... Applicants for Knights Templar School do not need to complete a "
     "Supplementary Information Form (SIF).",
     "p1",
     "on the Hertfordshire CC list of schools that test (a list for a later admissions round), but the 2026/27 "
     "arrangements have no test; Year 12 not assessed"),
    ("147535", "none", "", "", "150", "", "2026/27",
     "hcc_2627_onslow-st-audreys-determined-policy-2627-4035.pdf",
     "Onslow St Audrey's School is a mixed ability, 11-18, comprehensive school. The Published Admission Number for "
     "Year 7 in 2026-2027 is 150.",
     "p1",
     "on the Hertfordshire CC list of schools that test, but the 2026/27 arrangements contain no test (Herts rules "
     "1-6 only); Year 12 not assessed"),
    ("137872", "none", "", "", "200", "", "2026/27",
     "hcc_2627_bushey-meads-determined-policy-26.27-5408.pdf",
     "Admission Criteria for the Academic Year 2026/27 The Governors offer places each September to 200 students. "
     "... 7. Any remaining places will be allocated by proximity to the School",
     "p1; criterion 7",
     "no test, aptitude or banding criterion in the 2026/27 arrangements; Year 12 not assessed"),
    ("137637", "none", "", "", "240", "", "2026/27",
     "hcc_2627_birchwood-high-determined-policy-2627-4200.pdf",
     "Birchwood admits 240 boys and girls per year into Year 7 ... We do not apply aptitude tests and are proud of "
     "our all-ability intake.",
     "p1",
     "Bishop's Stortford; Year 12 not assessed"),
    ("148499", "none", "", "", "186", "", "2026/27",
     "hcc_2627_st-marys-bs-determined-policy-2627-5422.pdf",
     "It is an all ability school and children will be admitted without reference to their aptitude or ability. ... "
     "Published Admissions Number (PAN) at 186 to year 7 in the school year which begins in September 2026.",
     "p1",
     "Bishop's Stortford, Catholic; Year 12 not assessed"),
    ("149078", "none", "", "", "180", "", "2026/27",
     "hcc_2627_avanti-grange-determined-policy-2627-4037.pdf",
     "The PAN for entry to year 7 in 2026 is 180. ... 2. Children with a sibling attending the School at the time of "
     "application. ... 3. Children whose home address is in the Bishop's Stortford North development",
     "Published Admission Number; oversubscription criteria 2-3",
     "Bishop's Stortford free school: looked after, siblings, development area, feeder primaries, staff, then "
     "distance; no test; Year 12 not assessed"),
    # ------------------------------------------------------------------ Wandsworth
    ("137005", "partially_selective", "", "70", "280", "Wandsworth Year 6 Test (non-verbal and verbal reasoning)",
     "2026/27", "graveney_admissions_criteria_2026_27.pdf",
     "70 places will be allocated by reference to general ability. The 70 applicants with the highest scores in the "
     "Wandsworth Year 6 Test will be offered places.",
     "p1 Category 1",
     "the remaining 210 places (Category 2) by looked-after, sibling, medical/social, staff, distance; PAN from "
     "the school's admissions-criteria page",
     "graveney_admissions_criteria.html",
     "We will admit 280 pupils into Year 7 in September 2026."),
    ("139842", "partially_selective", "", "60", "240", "Wandsworth Year 6 Test (non-verbal and verbal reasoning)",
     "2026/27", "wandsworth_burntwood_admissions_policy_2026_27.pdf",
     "The school will admit 240 pupils to Year 7 in September 2026. ... Up to 60 places will be allocated by "
     "reference to general ability to those applicants with the highest scores in the Wandsworth Year 6 Test.",
     "p1 introduction; Category 1 places",
     "girls; Wandsworth Council copy; 2026 offers: all 60 selective places filled (cut-off 209/210)"),
    ("149543", "none", "", "", "120", "", "2026/27",
     "wandsworth_ernest_bevin_admissions_policy_2026_27.pdf",
     "admits boys at 11 without reference to ability or aptitude ... The planned admission number for Year 7 is 120.",
     "p1-2",
     "NFER 2017 listed it at 33% academic ability; no test in 2026/27; Wandsworth Council copy; Year 12 not "
     "assessed"),
    ("135316", "banding", "", "", "240", "Wandsworth Year 6 Test (banding)", "2027/28",
     "wandsworth_choose_a_secondary_school.pdf",
     "Ashcroft Technology Academy boys & girls 240 Specialist (Design 24 page 22 ... Non-selective (banding) ... ALL "
     "applicants for a Wandsworth partially-selective school or banding school (they are: Ashcroft Technology "
     "Academy, Burntwood School, Chestnut Grove Academy and Graveney School) must register",
     "booklet p5 table 'The variety of school places'; section 4 'The Wandsworth Year 6 Test'",
     "Wandsworth Council booklet for Sept 2027 entry (2026/27 policy not fetched: school page 404); up to 24 "
     "design-technology/IT aptitude places, test content not described in the booklet (not checked); second "
     "source = how places were offered in March 2026",
     "wandsworth_how_places_were_offered_secondary_2026.pdf",
     "ASHCROFT TECHNOLOGY ACADEMY (DFE no 212 6905) Children with an Education Health Care Plan: 10 Specialist "
     "Aptitude Places: 24 Remaining places allocated within bands as follows:"),
    ("136883", "banding", "", "", "210", "Wandsworth Year 6 Test (banding)", "2027/28",
     "wandsworth_choose_a_secondary_school.pdf",
     "Chestnut Grove Academy boys & girls 210 Specialist (art & design) 30 page 31 Academy Specialist (languages) 30 "
     "Non-selective (banding) 150",
     "booklet p5 table 'The variety of school places'",
     "Wandsworth Council booklet for Sept 2027 entry; up to 30 art & design and 30 languages aptitude places "
     "(60 of 210 = 29%, an aptitude share above the usual 10% cap); second source = March 2026 offers",
     "wandsworth_how_places_were_offered_secondary_2026.pdf",
     "Specialist Aptitude Places in Art & Design: 30 Specialist Aptitude Places in Modern Foreign Languages: 30 "
     "Remaining places allocated within bands as follows:"),
    ("141808", "aptitude_only", "", "", "180", "", "2027/28",
     "wandsworth_choose_a_secondary_school.pdf",
     "Saint Cecilia's Academy boys & girls 180 Specialist (music) 18 page 43",
     "booklet p5 table 'The variety of school places'",
     "Church of England; Wandsworth Council booklet for Sept 2027 entry; 18 music aptitude places split across "
     "foundation and open places; second source = March 2026 offers",
     "wandsworth_how_places_were_offered_secondary_2026.pdf",
     "Foundation Places: Specialist Music Places: 7 ... Open places: Specialist Music Places: 11"),
    # ------------------------------------------------------------------ Sutton
    ("136800", "partially_selective", "", "60", "314", "Sutton Selective Eligibility Test (SET)", "2026/27",
     "greenshaw_admission_arrangements_2026_27.pdf",
     "Greenshaw High School has a Published Admission Number of 314 for entry into Year 7 in September 2026. ... "
     "Priority 4: Academic Ability Test Up to 60 students will be admitted based on the outcome of the Selective "
     "Eligibility Test (SET).",
     "s.1; Priority 4",
     "same test as the Sutton grammar schools; places in rank order of performance among those reaching the pass "
     "mark; Greenshaw Learning Trust copy"),
    # ------------------------------------------------------------------ Southend-on-Sea (CSSE test)
    ("137312", "partially_selective", "", "30", "175", "CSSE 11+ selection test", "2026/27",
     "southend_secondary_admissions_booklet_2026_27.pdf",
     "Admission Arrangements - STB Admissions Policy 2026 Published Admission Number (PAN): 175 ... 1. Up to 30 "
     "places will be offered to girls who have passed the 11+ Exam Selective Test as administered by the "
     "Consortium of Selective Schools in Essex",
     "Southend booklet 2026-27, St Bernard's page, criterion 1",
     "Catholic girls; selective places limited to SS0-SS9 residents; NFER 2017 listed 43%; Southend City Council "
     "booklet"),
    ("137310", "partially_selective", "", "30", "180", "CSSE 11+ selection test", "2026/27",
     "stm_southend_admissions_arrangements_2026.pdf",
     "St Thomas More Catholic High School is a six form, 11-18 bi-lateral school for boys ... Admission limit for "
     "year 7 - 11: 180 ... 1) Up to 30 places will be offered to boys who have passed the 11+ Exam Selective Test "
     "as administered by the Consortium of Selective Schools in Essex",
     "p1; oversubscription criterion 1",
     "Catholic boys; selective places limited to SS0-SS9 residents; describes itself as bilateral"),
    ("137733", "partially_selective", "", "28", "310", "CSSE 11+ selection test (score 303+)", "2026/27",
     "southend_secondary_admissions_booklet_2026_27.pdf",
     "Admission Arrangements - SHS Admissions Policy 2026 Published Admission Number (PAN): 310 ... 2. Up to 28 "
     "pupils granted preferential admission on the basis of their performance in the selection test procedure "
     "organised by the Consortium of Selective Schools in Essex",
     "Southend booklet 2026-27, Shoeburyness page, criterion 2",
     "priority-area residents; unfilled places may go to borderline scores 295-303; Southend City Council booklet"),
    ("147185", "none", "", "", "220", "", "2026/27",
     "southend_secondary_admissions_booklet_2026_27.pdf",
     "Admission Arrangements - CJA Admissions Policy 2026 Published Admission Number (PAN): 220 ... 3. Pupils who "
     "live in the catchment area served by the academy.",
     "Southend booklet 2026-27, Cecil Jones page, criterion 3",
     "a search lead (third-party 11+ site, not fetched) claimed 10% general-ability places; the 2026/27 criteria "
     "have no test; Year 12 not assessed"),
    # ------------------------------------------------------------------ other areas (NFER 2017 list, subagent leads)
    ("136577", "partially_selective", "15", "", "350", "school test of general ability (SS postcodes only)",
     "2026/27", "kjs_admissions_policy_2026_27_determined.pdf",
     "Up to 15 per cent may be selected by general ability, measured by tests to be determined by the Local "
     "Governing Body. ... The published admission number for the year commencing 1st September 2026 is to be 350.",
     "introduction; criterion (5)",
     "Essex (Thundersley); test open only to SS-postcode residents"),
    ("144610", "partially_selective", "", "42", "180", "school selection tests (selective stream)", "2026/27",
     "reading_girls_admissions_policy_2026_27.pdf",
     "The school has a published admission number of 180 pupils for entry in year 7. ... 2. Up to 42 places may be "
     "selected by ability assessed by means of selection tests and ranked according to the results of the tests.",
     "s.6.1; oversubscription criterion 2",
     "the policy calls the school 'partially selective'"),
    ("137484", "partially_selective", "", "60", "300", "school assessment (content not stated)", "2026/27",
     "kcc_homewood_admissions_criteria_2026_27_wayback.pdf",
     "The Planned Admission Number for Year 7 entry in August 2026 is set at 300. ... b) 20% of intake will be "
     "admitted with reference to ability or aptitude ... being used to select 60 students according to the scores "
     "achieved.",
     "Numbers; criterion b; section 'Ability or Aptitude'",
     "Kent (Tenterden); Wayback copy of the KCC-hosted policy (kent.gov.uk 403s); the policy says 'ability or "
     "aptitude' and does not name the assessment; NFER 2017 lists it as academic ability"),
    ("136286", "partially_selective", "", "29", "285", "school test of aptitude in mathematics", "2026/27",
     "kcc_westlands_admissions_criteria_2026_27_wayback.pdf",
     "The Planned Admissions Number for the school is 285. ... c) Places will then be offered to children who score "
     "highest on the school's test of aptitude in mathematics. Places offered under this criterion will not exceed "
     "10% of the school's planned admission number, i.e a maximum of 29 places",
     "s.1; criterion c",
     "REASONING-TEST RULE: labelled aptitude, but mathematics is an academic subject, not a s.102 aptitude subject; "
     "Kent (Sittingbourne); Wayback copy of the KCC-hosted policy"),
    ("150883", "partially_selective", "10", "", "325", "school tests for the 'Expressly Academic Class'", "2026/27",
     "poole_high_admissions_policy_2026_27.pdf",
     "Parents also have the opportunity to apply for a place within the \"Expressly Academic Class\" (10% of "
     "intake). These children are selected on the basis of ability and are required to take a series of tests. "
     "... The Published Admission Number for year 7 is 325.",
     "Admission arrangements; criterion 3",
     "BCP; ranked in order of test scores"),
    ("147443", "partially_selective", "", "30", "260", "school abilities test", "2026/27",
     "budmouth_admissions_policy_2026_27.pdf",
     "Published Admission Number (PAN) to Year 7 to Year 11 as 260 places. ... 2. The 30 students that demonstrate "
     "the highest ability within the abilities test are automatically provided with an offer.",
     "introduction; criterion 2",
     "Dorset (Weymouth)"),
    ("125314", "partially_selective", "", "26", "300",
     "school computer-based tests of English and mathematics (verbal, non-verbal, mathematical skills)", "2026/27",
     "winston_churchill_determined_admissions_criteria_2026_27.pdf",
     "Should the number of applicants exceed the 300 places available for admissions into Year 7 ... 4. Up to 41 "
     "specialist places will be available to children who live outside of the admission area ... Up to 26 places "
     "based on the marks achieved in tests of English and Mathematics.",
     "criteria for admission 2026-27; priority 4",
     "Surrey (Woking); specialist places are for applicants living outside the admission area; also up to 15 "
     "music aptitude places"),
    ("136398", "partially_selective", "", "12", "150", "school assessment of overall academic ability", "2026/27",
     "kings_peterborough_year7_admissions_criteria_2026.pdf",
     "The Published Admission Number (PAN) for the 2026 Year 7 group is 150 ... Group B: Pupils allocated by ability "
     "as measured by the School's assessment procedures in merit order for a maximum of 15 places. 1. 12 of these "
     "places will be allocated on overall academic ability.",
     "PAN; Group B",
     "Peterborough; also 3 places on musical ability; 15 Year 7 places go to the school's own Year 6"),
    ("136587", "partially_selective", "", "31", "256", "Warwickshire 11+ (automatic qualifying score)", "2026/27",
     "ashlawn_admissions_policy_2026_27.pdf",
     "The academy has a published admission number (PAN) of 256 students ... Thirty-one of these places are for "
     "applicants who meet the \"automatic qualifying scores\" in the 11+ selective test ... 2. Up to 31 selective "
     "places will then be allocated to students who have reached the Automatic Qualifying Score in the 11+ "
     "Selective Test.",
     "s.7.1; oversubscription criterion 2",
     "Rugby; calls itself bilateral; also 25 modern-languages aptitude places; the 2026-2027 document's PAN "
     "sentence still says 'entry in Year 7 in 2025-26'"),
    ("113526", "unverified", "", "", "210", "selection test (not named in this source)", "2026/27",
     "torbay_spires_allocations.html",
     "Children starting in year 7 at secondary school in September 2026 (on time applications) ... Admission number "
     "210 ... NON-SELECTIVE PLACES: 134 ... SELECTIVE PLACES 60",
     "Torbay Council allocation summary, criteria table for 2026",
     "LIKELY PARTIALLY SELECTIVE, determined arrangements not found: the school's admissions-policy page has no "
     "document (also in a 2025 Wayback copy). Torbay's 2026 allocation summary lists 60 selective places of 210 "
     "(28.6%) among the criteria; the last policy found (second source) is for 2022 entry, older than the "
     "2025/26 fallback",
     "torbay_spires_college_admissions_policy_media15971.pdf",
     "Admissions Policy For entry from 1 September 2022 ... There are up to 60 selective places available in each "
     "year group."),
    ("136302", "banding", "", "", "210", "school banding assessment (9 bands)", "2026/27",
     "kcc_canterbury_academy_admissions_criteria_2026_27_wayback.pdf",
     "The number of intended admissions for the year commencing 2026 will be 210 ... 31 places will be initially "
     "reserved for selective music students. ... The banding assessment is not an entry test",
     "p1",
     "Kent; Kent-Test passers get priority for an internal 'Simon Langton Grammar stream' after admission, not for "
     "places; 31 music places; Wayback copy of the KCC-hosted policy"),
    ("137458", "none", "", "", "235", "", "2026/27",
     "kcc_2627_brockhill-park-performing-arts-college-admissions-criteria-2026-2027.pdf",
     "provides courses for all students deemed selective or non-selective and is an appropriate placement for "
     "students who have passed the Kent tests. ... has an agreed Pupil Admissions Number (PAN) of 235 ... 4. "
     "Nearness of children's homes to school",
     "s.1 Overview; oversubscription criterion 4",
     "Kent (Hythe); a 'bilateral' school in name only: the Kent Test plays no part in its criteria (looked after, "
     "siblings, medical, distance); Wayback copy of the KCC-hosted policy; Year 12 not assessed"),
    ("136324", "aptitude_only", "", "", "210", "", "2026/27",
     "kcc_2627_fulston-manor-school-admissions-criteria-2026-2027.pdf",
     "PUBLISHED ADMISSION: 210 ... b. Particular aptitude in either sport or performing arts The Admissions "
     "Authority award a maximum of 10% of the PAN",
     "p1 header; criterion b",
     "Kent (Sittingbourne), historically described as bilateral; no Kent Test or ability criterion in 2026/27; "
     "Wayback copy of the KCC-hosted policy"),
    ("138783", "none", "", "", "90", "", "2026/27",
     "kevi_spilsby_admissions_policy_2026_27.pdf",
     "The Published Admission Number is 90. ... 4. The distance from the child's home address to the academy.",
     "PAN; criterion 4",
     "Lincolnshire (Spilsby); NFER 2017 listed 32% academic ability; no test in 2026/27; Year 12 not assessed"),
    ("118898", "none", "", "", "140", "", "2026/27",
     "archbishops_admissions_policy_2026.pdf",
     "The Published Admission Number (PAN) for each Year Group is 140.",
     "s.4.1",
     "Kent (Canterbury), Church of England: looked after, siblings, church, health, staff, distance (categories "
     "A-F); NFER 2017 listed 15% academic ability; Year 12 not assessed",
     "archbishops_admissions_policy_2026.pdf",
     "Category F: Nearness of children's homes to school"),
    ("141466", "none", "", "", "250", "", "undated (current page)",
     "howard_school_medway_admissions.html",
     "The Planned Admission Number (PAN) is 250. ... Where the child resides within the access area. Priority given "
     "to those nearest the school.",
     "school admissions page, over-subscription criteria",
     "Medway (Rainham); NFER 2017 listed 25% academic ability; current criteria have no test; the dated 2026 and "
     "2027 versions are .docx files, not readable under the project's tools"),
    ("104721", "none", "", "", "170", "", "2026/27",
     "st_hildas_admissions_policy_2026.pdf",
     "The admission number of pupils to be admitted into Year 7 to the school in September 2026 is 170. ... a points "
     "system will decide which pupils will be offered a place and will take into account variability of church "
     "attendance year on year.",
     "introduction; oversubscription",
     "Liverpool, Church of England; NFER 2017 listed 15% academic ability; Year 12 not assessed"),
    ("138850", "none", "", "", "190", "", "2027/28",
     "st_margarets_liverpool_admissions_policy_2027.pdf",
     "In September 2027, 190 boys will be admitted into Year 7 of the Academy.",
     "introduction",
     "Liverpool, Church of England boys; church-attendance points then distance; NFER 2017 listed 15% academic "
     "ability; only the 2027 policy is online; Year 12 not assessed"),
    ("138178", "none", "", "", "328", "", "2026/27",
     "riddlesdown_admissions_criteria_2026.pdf",
     "The Planned Admission Number (PAN) for Riddlesdown Collegiate is 328. ... All remaining places will then be "
     "allocated to children on the basis of distance from Riddlesdown Collegiate.",
     "Entry to Year 7; criterion 5",
     "Croydon; NFER 2017 listed 15% academic ability; Year 12 not assessed"),
    ("100849", "none", "", "", "125", "", "2026/27",
     "southwark_starting_secondary_brochure_2026_27.pdf",
     "Published admissions number: 125 ... 55 places will be offered to girls who are not ... (iii) Nearness from home "
     "to the school, measured",
     "Southwark brochure 2026-27, St Saviour's and St Olave's page",
     "Southwark, Church of England girls: 70 foundation and 55 open places by sisters, feeder schools, distance; "
     "NFER 2017 listed 15% academic ability; the school's own 2027-28 policy is a .docx; Year 12 not assessed"),
    ("137772", "unverified", "", "", "", "", "",
     "shirley_high_admission_arrangements_2025_file2701.pdf",
     "SHIRLEY HIGH SCHOOL PERFORMING ARTS COLLEGE ADMISSION ARRANGEMENTS FOR THE SEPTEMBER 2026 INTAKE",
     "p1",
     "Croydon; NFER 2017 listed 15% academic ability; the only document online is a one-page procedural note "
     "(performing-arts scholarship form, dates) without oversubscription criteria; school site checked, no "
     "determined arrangements found"),
    # ------------------------------------------------------------------ high-prior-attainment screen: London
    ("136309", "banding", "", "", "420", "school banding assessment (3 bands)", "2026/27",
     "kingsdale_admission_policy_2026_27.pdf",
     "Kingsdale Foundation School will admit no less than 420 pupils in Year 7 ... A maximum of the equivalent of "
     "15% of our Admission Number per year group will be designated for music or sports scholarships ... the "
     "School will use Banding as part of its admission arrangements.",
     "s.1.2-1.3",
     "also up to 15% music/sport aptitude scholarships; second quote = Year 12 A level pathway (six GCSEs at 9-7)",
     "kingsdale_admission_policy_2026_27.pdf",
     "A Level Pathway: Students study 3-4 courses and will need to have gained a minimum of six 9-7 grades at GCSE "
     "including English Language and Mathematics."),
    ("138607", "banding", "", "", "120", "school banding test (3 bands, 25/50/25)", "2026/27",
     "lady_margaret_y7_admissions_policy_2026.pdf",
     "There are 120 places in Year 7 for the school year starting in September 2026. ... A quarter of the girls we "
     "admit are of above average ability (Band 1), half are average (Band 2), and a quarter are below average "
     "(Band 3).",
     "paras 2-3",
     "Church of England girls' school: 67 foundation and 53 open places, each banded"),
    ("100054", "banding", "", "", "120", "banding assessment (4 bands of 30)", "2026/27",
     "camden_girls_determined_admissions_2026.pdf",
     "The school admits 120 girls into Year 7 each year representing the full range of ability, as determined by "
     "our banding assessments. ... Three places are offered on the basis of musical aptitude. Five places are "
     "offered on the basis of musical aptitude and ability.",
     "p1; criterion 4",
     "also 8 music places (musical aptitude/ability, not academic)"),
    ("149632", "banding", "", "", "240", "Year 6 banding test (4 bands of 54)", "2026/27",
     "holland_park_admission_policy_2026_27.pdf",
     "The Published Admission Number (PAN) is 240. Holland Park School admits students in four bands of ability ... "
     "A maximum of 24 places will be offered to applicants who can demonstrate an aptitude and capacity to succeed "
     "in the visual arts",
     "s.1.2; criterion 2.3",
     "also up to 24 art aptitude places; second quote = Year 12 entry (average grade 6)",
     "holland_park_admission_policy_2026_27.pdf",
     "that students achieve an average of a grade 6 across their top eight GCSE subjects"),
    ("141931", "banding", "", "", "128", "school banding test (3 bands, 25/50/25)", "2026/27",
     "cvms_determined_admission_policy_2026_27.pdf",
     "There are 128 places for boys in Year 7. To ensure the intake to the school is comprehensive and represents "
     "the ability range of the cohort applying, we admit boys in three bands of ability ... Up to 12 boys eligible "
     "for a music aptitude place",
     "s.4.1; criterion B.1",
     "Catholic boys' school; also up to 12 music aptitude places"),
    ("138313", "banding", "", "", "175", "non-verbal reasoning banding test (3 bands, 25/50/25)", "2026/27",
     "gch_admissions_policy_yr7_sept_2026.pdf",
     "the Published Admission Number (PAN) for entry into Year 7 will be 175 ... Up to 15 (fifteen) places of the "
     "PAN (Published Admissions Number) will be offered to applicants solely on the strength of their aptitude for "
     "languages ... To fill the remaining 160 places (excluding Language places and those with an EHC plan) and to "
     "ensure a balanced intake from all ability ranges, all girls must sit a non- verbal reasoning test",
     "s.1.2; section two Language places; section three Banding",
     "Church of England girls' school; also up to 15 languages aptitude places"),
    ("136750", "aptitude_only", "", "", "130", "", "2026/27",
     "wlfs_admission_policy_2026_27.pdf",
     "The School will admit 130 pupils to Year 7 in 2026-2027. ... 3. Up to 12 children who have applied to be "
     "considered under the musical aptitude scheme.",
     "para 4; oversubscription criterion 3",
     "music only; up to 45 pupil-premium places and random allocation; no ability test"),
    ("136298", "none", "", "", "192", "", "2026/27",
     "charter_north_dulwich_admissions_policy_2026_27.pdf",
     "The Charter School North Dulwich has a Year 7 admission number of 192 pupils. ... vi) Other children living "
     "closest to the school by the shortest straight-line measurement",
     "para 6; criterion vi",
     "no test; Year 12 entry requirements are left to the prospectus"),
    ("141716", "none", "", "", "124", "", "2026/27",
     "stm_greenwich_admissions_policy_sept_2026.pdf",
     "the governors intend to admit into Year 7, in September 2026, a planned admission number (PAN) of 124, "
     "without reference to ability or aptitude.",
     "p1",
     "Catholic; Year 12 not in this document, not assessed"),
    ("137157", "none", "", "", "160", "", "2026/27",
     "london_oratory_admission_arrangements_first_form_2026.pdf",
     "The School will admit 160 boys from across London to the first form (year 7) without reference to ability.",
     "First form admission arrangements",
     "Catholic; second quote = Year 12: places conditional on course requirements published separately, "
     "oversubscription by faith",
     "london_oratory_admission_arrangements_sixth_form_2026.pdf",
     "All places will be offered conditional on candidates meeting the Requirements for Advanced Courses"),
    ("138227", "sixth_form_entry_only", "", "", "180", "", "2026/27",
     "avanti_house_admission_policy_2026_27.pdf",
     "The PAN for entry to Year 7 is 180. ... 3. Children who attend Avanti House Primary School or Krishna Avanti "
     "Primary School (Harrow) at the time of application (Year 7 applications only).",
     "PAN; oversubscription criterion 3",
     "Year 7: looked after, siblings, feeder primaries, staff, Hindu faith places, distance (no test); second "
     "quote = Year 12 minimum of six GCSEs at grade 6",
     "avanti_house_admission_policy_2026_27.pdf",
     "The minimum academic entry criteria are: ... Six GCSEs at Grade 6."),
    ("136669", "sixth_form_entry_only", "", "", "420", "", "2026/27",
     "newham_school_admission_arrangements_sept_2026.pdf",
     "Brampton Manor Academy 420 ... Priority 6: All other children, whether or not they live in Newham",
     "Appendix 1 Determined Admission Numbers; oversubscription priority 6",
     "Year 7 uses LB Newham's arrangements (no test; second source 1 = school statement adopting them); second "
     "source 2 = sixth form: minimum GPA 6.5 across all GCSEs",
     ["brampton_manor_admissions_page.html", "brampton_manor_sixth_form_admissions_policy_2026.pdf"],
     ["The Directors of Brampton Manor Trust have formally agreed to adopt the London Borough of Newham's Admission "
      "Arrangements for entry in September 2026.",
      "They must also have achieved a minimum Grade Point Average (GPA) of 6.5 across all GCSE qualifications taken"]),
    ("137386", "partially_selective", "", "24", "243",
     "GL Assessment verbal + non-verbal reasoning test (labelled technological aptitude)", "2026/27",
     "mhchs_determined_admissions_policy_2026_27.pdf",
     "The Published Admission Number for September 2026 is 243 (two hundred and forty-three). ... Up to 24 "
     "technological aptitude, 24 musical aptitude and 12 dance aptitude places",
     "s.1; oversubscription criteria list",
     "REASONING-TEST RULE: the arrangements call the 24 places technological aptitude (s.102), but the second "
     "source shows they are ranked on a GL Assessment verbal and non-verbal reasoning test; also 24 music and 12 "
     "dance aptitude places",
     "mhchs_procedures_criterion5_2026_27.pdf",
     "sit a GL Assessment Verbal Reasoning and Non- Verbal Reasoning Test ... No minimum score will be required, "
     "places being offered strictly in descending order of each applicant's combined score."),
    # ------------------------------------------------------------------ high-prior-attainment screen: elsewhere
    ("138855", "none", "", "", "232", "", "2027/28",
     "bristol_redland_green_admissions.pdf",
     "Published Admission Number: 232 Redland Green School is a mixed comprehensive School ... 3. All other "
     "children living within the Area of First Priority.",
     "p3; oversubscription criterion 3",
     "Bristol City Council copy, which now carries the 2027/28 policy (determined 6 Feb 2026); second quote = "
     "Year 12 (North Bristol Post 16 consortium): five GCSEs at grade 4",
     "excalibur_sixth_form_admissions_arrangements_2027_28.pdf",
     "To study Level 3 courses at Redland Green School or Cotham School: 5 x GCSE at grade 4"),
    ("135174", "banding", "", "", "180", "non-verbal reasoning banding assessment", "2027/28",
     "belvedere_admissions_y7_sept_2027.pdf",
     "Admission Number: 180 ... will select 10% of the agreed admission number (18 places) on aptitude for learning "
     "Music ... 6. All remaining places will be allocated on the basis of fair banding",
     "p1; criteria 2 and 6",
     "girls; also 18 music aptitude places and 25 distance places; 2026/27 policy not found on the school site"),
    ("136531", "none", "", "", "330", "", "2027/28",
     "weydon_admissions_policy_2027_28.pdf",
     "There is no requirement for aptitude from prospective students. ... The Published Admission Number (PAN) for "
     "Year 7 starting September 2027 is 330.",
     "introduction",
     "11-16 school; the school site links only the 2027/28 policy"),
    ("136833", "none", "", "", "240", "", "2026/27",
     "howard_effingham_admission_arrangements_2026.pdf",
     "The school admits children without reference to aptitude or ability ... The Published Admission Number (PAN) "
     "for entry to Year 7 in September 2026 is 240.",
     "p1",
     "Year 12 entry requirements are left to the prospectus"),
    ("136880", "none", "", "", "240", "", "2027/28",
     "holt_admission_arrangements_2027_28.pdf",
     "The admissions number for entry in September 2027 is 240. ... E Children whose permanent home address is in "
     "the designated area of the school.",
     "p1; criterion E",
     "girls; only the 2027/28 policy is online (the site's '2024-25' download now serves it); second quote = "
     "Year 12: five GCSEs at grade 4",
     "holt_admission_arrangements_2027_28.pdf",
     "For admission to the Sixth Form, students will be required to achieve at least 5 GCSEs grade 4 to 9 including "
     "English and mathematics."),
]


def manifest_urls():
    out = {}
    with (ROOT / "data" / "manifest" / f"{SOURCE}.csv").open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            out[r["local_path"]] = r["url"]
    return out


def raw_file(name):
    hits = sorted((RAW / SOURCE).glob(f"*/{name}"))
    if not hits:
        raise FileNotFoundError(f"{SOURCE}/{name}")
    return hits[-1]


def check_quote(file, quote, tag, urls, texts, bad):
    """Every ' ... '-separated segment of quote must be in the file's normalised text; returns (url, rel path)."""
    p = raw_file(file)
    src = rel(p)
    if src not in texts:
        texts[src] = norm(text_of(p))
    for seg in quote.split(" ... "):
        if norm(seg) not in texts[src]:
            bad.append(f"{tag}: quote segment not in {file}: '{seg}'")
    if src not in urls:
        bad.append(f"{tag}: no manifest row for {src}")
    return urls.get(src, ""), src


def has_number(value, quote):
    return re.search(rf"(?<![\d.]){re.escape(value)}(?![\d])", quote.replace(",", "")) is not None


def main():
    sm = read_ees(DERIVED / "school_master.csv")
    sm = sm.set_index("urn")
    urls = manifest_urls()
    texts, rows, bad = {}, [], []
    seen = set()
    for ev in EVIDENCE:
        urn, cls, pct, n, pan, test, year, file, quote, loc, note = ev[:11]
        pfile, pquote = ev[11:] if len(ev) == 13 else ([], [])
        pfiles, pquotes = ([pfile], [pquote]) if isinstance(pfile, str) else (pfile, pquote)
        tag = f"{urn} ({file})"
        if urn in seen:
            bad.append(f"{tag}: duplicate URN")
        seen.add(urn)
        if cls not in CLASSES:
            bad.append(f"{tag}: unknown class {cls}")
        if urn not in sm.index or sm.at[urn, "status"] != "Open":
            bad.append(f"{tag}: URN not Open in school_master")
            continue
        url, src, purl, psrc = "", "", "", ""
        if file.startswith("http"):
            url = file
        elif file:
            url, src = check_quote(file, quote, tag, urls, texts, bad)
        if pfiles:
            checked = [check_quote(f, q, tag, urls, texts, bad) for f, q in zip(pfiles, pquotes)]
            purl, psrc = (" || ".join(c[i] for c in checked) for i in (0, 1))
        pquote = " || ".join(pquotes)
        if cls in ("blocked", "unverified"):
            if not url or not note:
                bad.append(f"{tag}: {cls} row needs a URL and a reason")
        elif not (src and quote):
            bad.append(f"{tag}: {cls} row needs a local file and a quote")
        for label, v in (("n", n), ("pan", pan), ("pct", pct)):
            if v and not (has_number(v, quote) or has_number(v, pquote)):
                bad.append(f"{tag}: {label}={v} not inside the quote")
        if cls == "partially_selective" and not (n or pct):
            bad.append(f"{tag}: partially_selective without n or pct")
        if cls != "partially_selective" and (n or pct):
            bad.append(f"{tag}: ability places given for a {cls} row")
        if not pct and n and pan:
            pct = f"{100 * int(n) / int(pan):.1f}"
            note = (note + "; " if note else "") + f"pct computed as {n}/{pan}"
        rows.append(dict(urn=urn, name=sm.at[urn, "name"], la_name=sm.at[urn, "la_name"], classification=cls,
                         ability_places_pct=pct, ability_places_n=n, pan=pan, test_name=test,
                         entry_year_policy=year, source_url=url, source_file=src, source_location=loc,
                         source_quote=quote, note=note, second_source_url=purl, second_source_file=psrc,
                         second_quote=pquote))
    if bad:
        raise SystemExit("evidence check failed:\n" + "\n".join(bad))
    df = pd.DataFrame(rows, columns=COLS).sort_values(["classification", "la_name", "name"])
    write_derived(df, "partially_selective")
    print(df.classification.value_counts().to_string())


if __name__ == "__main__":
    main()
