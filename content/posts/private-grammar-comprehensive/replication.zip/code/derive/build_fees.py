"""Build data/derived/independent_fees.csv: termly/annual fees for the 45 independents in top30_independent.csv,
2026/27 (live pages, retrieved 2026-10-10) and 2025/26 (Wayback captures Sept 2025 - July 2026), and for the 20 in
bottom20_private.csv, 2026/27 only (BOTTOM20_ROWS).

Every value below was transcribed by hand from the saved page (data/raw/fees/<day>/) and is re-checked here:
the amount must appear in the page text within a few hundred characters of the quoted label, or the build
fails. Run after code/harvest/fees.py:  .venv/Scripts/python -I code/derive/build_fees.py
"""
import csv
import datetime as dt
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
from common import DERIVED, RAW, ROOT, assert_unique, write_derived  # noqa: E402
from fees_text import near, page_text  # noqa: E402

DAY = "2026-10-10"
FEES_DIR = RAW / "fees" / DAY
T, F, U = True, False, None          # incl_vat / lunch_included: stated yes, stated no, not stated
Y26, Y25 = "2026/27", "2025/26"

# (urn, fee_year, file, stage, years, mode, label on page, amount as printed ('a+b' = sum of printed parts),
#  period, incl_vat, amount_excl_vat as printed, lunch_included, note)
# stage: senior_lower = Years 7-8 where priced separately (incl. 11+ entry into a linked prep school);
#        senior = Years 7/9-11; sixth_form = Years 12-13 (continuing pupils, or all if one price);
#        sixth_form_new_entrant = Years 12-13 for pupils joining at 16+, where priced separately.
ROWS = [
    # --- St Paul's Girls' School
    ("100366", Y26, "100366_2026.html", "senior", "Y7-11", "day", "academic year 2026-2027 is", "12,854", "term", T, "", T, "one fee for Y7-13 continuing pupils"),
    ("100366", Y26, "100366_2026.html", "sixth_form", "Y12-13", "day", "academic year 2026-2027 is", "12,854", "term", T, "", T, "one fee for Y7-13 continuing pupils"),
    ("100366", Y26, "100366_2026.html", "sixth_form_new_entrant", "Y12-13", "day", "new entrants to the Senior School (Year 12)", "13,880", "term", T, "", T, ""),
    ("100366", Y25, "100366_2025.html", "senior", "Y7-11", "day", "academic year 2025-2026 is", "12,414", "term", T, "", T, "one fee for Y7-13 continuing pupils"),
    ("100366", Y25, "100366_2025.html", "sixth_form", "Y12-13", "day", "academic year 2025-2026 is", "12,414", "term", T, "", T, "one fee for Y7-13 continuing pupils"),
    ("100366", Y25, "100366_2025.html", "sixth_form_new_entrant", "Y12-13", "day", "new entrants to the Senior School (Year 12)", "13,409", "term", T, "", T, ""),
    # --- St Paul's School (senior school from 13+; Years 7-8 at St Paul's Prep/Juniors)
    ("102942", Y26, "102942_2026.html", "senior_lower", "Y7-8", "day", "St Paul’s Prep School – Lower First to Upper Third Years (Years 3-8)", "10,221", "term", T, "", T, "Years 7-8 are at St Paul's Prep School (11+ entry)"),
    ("102942", Y26, "102942_2026.html", "senior", "Y9-11", "day", "Fourth to Upper Eighth Form (Years 9-13)", "12,666", "term", T, "", T, "one fee for Y9-13 continuing pupils"),
    ("102942", Y26, "102942_2026.html", "sixth_form", "Y12-13", "day", "Fourth to Upper Eighth Form (Years 9-13)", "12,666", "term", T, "", T, "one fee for Y9-13 continuing pupils"),
    ("102942", Y26, "102942_2026.html", "sixth_form_new_entrant", "Y12-13", "day", "New joiners into the Eighth Form (Year 12)", "12,905", "term", T, "", T, ""),
    ("102942", Y26, "102942_2026.html", "senior", "Y9-11", "boarding", "Boarding Fee (including tuition fees)", "19,181", "term", T, "", T, "one boarding fee for Y9-13 continuing pupils"),
    ("102942", Y26, "102942_2026.html", "sixth_form", "Y12-13", "boarding", "Boarding Fee (including tuition fees)", "19,181", "term", T, "", T, "one boarding fee for Y9-13 continuing pupils"),
    ("102942", Y26, "102942_2026.html", "sixth_form_new_entrant", "Y12-13", "boarding", "Boarding Fee for new joiners in Eighth Form", "19,420", "term", T, "", T, ""),
    ("102942", Y25, "102942_2025.html", "senior_lower", "Y7-8", "day", "St Paul’s Juniors – Lower First to Upper Third Years (Years 3-8)", "9,551", "term", U, "", T, "Autumn Term 2025 fee; Years 7-8 are at St Paul's Juniors (11+ entry)"),
    ("102942", Y25, "102942_2025.html", "senior", "Y9-11", "day", "Fourth to Upper Eighth Form per term (Years 9-13)", "11,949", "term", U, "", T, "Autumn Term 2025 fee; one fee for Y9-13"),
    ("102942", Y25, "102942_2025.html", "sixth_form", "Y12-13", "day", "Fourth to Upper Eighth Form per term (Years 9-13)", "11,949", "term", U, "", T, "Autumn Term 2025 fee; one fee for Y9-13"),
    ("102942", Y25, "102942_2025.html", "senior", "Y9-11", "boarding", "Boarding Fee (including tuition fees)", "17,981", "term", U, "", T, "Autumn Term 2025 fee"),
    ("102942", Y25, "102942_2025.html", "sixth_form", "Y12-13", "boarding", "Boarding Fee (including tuition fees)", "17,981", "term", U, "", T, "Autumn Term 2025 fee"),
    # --- Westminster School (13+ and 16+; 11+ entry is to Westminster Under School, Years 7-8)
    ("101162", Y26, "101162_2026.html", "senior_lower", "Y7-8", "day", "Years 2 – 8", "11,671", "term", T, "", T, "Westminster Under School (Years 2-8); 11+ entry"),
    ("101162", Y26, "101162_2026.html", "senior", "Y9-11", "day", "13+ day pupils", "16,456", "term", T, "", T, "fee labelled for 13+ entrants; the page prices by entry point and does not state the sixth-form fee for 13+ entrants"),
    ("101162", Y26, "101162_2026.html", "sixth_form_new_entrant", "Y12-13", "day", "16+ day pupils", "17,482", "term", T, "", T, ""),
    ("101162", Y26, "101162_2026.html", "senior", "Y9-11", "boarding", "13+ and 16+ boarding pupils", "23,094", "term", T, "", T, "one boarding fee for 13+ and 16+ pupils"),
    ("101162", Y26, "101162_2026.html", "sixth_form", "Y12-13", "boarding", "13+ and 16+ boarding pupils", "23,094", "term", T, "", T, "one boarding fee for 13+ and 16+ pupils"),
    ("101162", Y25, "101162_2025.html", "senior", "Y9-11", "day", "13+ day pupils", "15,451", "term", T, "", U, "fee labelled for 13+ entrants; the page prices by entry point and does not state the sixth-form fee for 13+ entrants; Under School fees on a separate page, not captured"),
    ("101162", Y25, "101162_2025.html", "sixth_form_new_entrant", "Y12-13", "day", "16+ day pupils", "16,650", "term", T, "", U, ""),
    ("101162", Y25, "101162_2025.html", "senior", "Y9-11", "boarding", "13+ and 16+ boarding pupils", "21,992", "term", T, "", U, "one boarding fee for 13+ and 16+ pupils"),
    ("101162", Y25, "101162_2025.html", "sixth_form", "Y12-13", "boarding", "13+ and 16+ boarding pupils", "21,992", "term", T, "", U, "one boarding fee for 13+ and 16+ pupils"),
    # --- North London Collegiate School
    ("102257", Y26, "102257_2026.html", "senior", "Y7-11", "day", "Senior School –", "10,365", "term", T, "", F, "Senior School fee covers Y7-13; lunches £1,275/yr billed separately"),
    ("102257", Y26, "102257_2026.html", "sixth_form", "Y12-13", "day", "Senior School –", "10,365", "term", T, "", F, "Senior School fee covers Y7-13"),
    ("102257", Y25, "102257_2025.html", "senior", "Y7-11", "day", "Senior School –", "9,917", "term", T, "", F, "Senior School fee covers Y7-13; lunches £1,215/yr billed separately"),
    ("102257", Y25, "102257_2025.html", "sixth_form", "Y12-13", "day", "Senior School –", "9,917", "term", T, "", F, "Senior School fee covers Y7-13"),
    # --- King's College School (JSON content endpoint of the site; 2025/26 not captured)
    ("102684", Y26, "102684_2026_json.html", "senior_lower", "Y7-8", "day", "Senior (lower school, years 7 and 8)", "11,004", "term", T, "", F, "lunch charged per term"),
    ("102684", Y26, "102684_2026_json.html", "senior", "Y9-11", "day", "Senior (year 9 and above)", "11,940", "term", T, "", F, "one fee for Y9-13"),
    ("102684", Y26, "102684_2026_json.html", "sixth_form", "Y12-13", "day", "Senior (year 9 and above)", "11,940", "term", T, "", F, "one fee for Y9-13"),
    # --- Guildford High School (United Learning; 2025/26 not captured)
    ("125342", Y26, "125342_2026.html", "senior", "Y7-11", "day", "Year 7 – Sixth Form", "8,923", "term", T, "", F, "lunch compulsory to Y8 at £376.50/term, charged separately"),
    ("125342", Y26, "125342_2026.html", "sixth_form", "Y12-13", "day", "Year 7 – Sixth Form", "8,923", "term", T, "", F, ""),
    # --- Godolphin and Latymer (fees change each January: annual = sum of the three termly fees)
    ("100369", Y26, "100369_2026.html", "senior", "Y7-11", "day", "Autumn Term 2026:", "11,698+12,341+12,341", "year", T, "", F, "Autumn 2026 + Spring 2027 + Summer 2027; one fee Y7-13"),
    ("100369", Y26, "100369_2026.html", "sixth_form", "Y12-13", "day", "Autumn Term 2026:", "11,698+12,341+12,341", "year", T, "", F, "Autumn 2026 + Spring 2027 + Summer 2027; one fee Y7-13"),
    ("100369", Y25, "100369_2025.html", "senior", "Y7-11", "day", "Autumn Term 2025:", "11,226+11,698+11,698", "year", T, "", F, "Autumn 2025 + Spring 2026 + Summer 2026; one fee Y7-13"),
    ("100369", Y25, "100369_2025.html", "sixth_form", "Y12-13", "day", "Autumn Term 2025:", "11,226+11,698+11,698", "year", T, "", F, "Autumn 2025 + Spring 2026 + Summer 2026; one fee Y7-13"),
    # --- City of London School for Girls (2025/26 not captured)
    ("100001", Y26, "100001_2026.html", "senior", "Y7-11", "day", "For the 2026/27 academic year, our fees are as follows:", "10,611.00", "term", T, "", F, "single fee; lunch £6.50/day extra"),
    ("100001", Y26, "100001_2026.html", "sixth_form", "Y12-13", "day", "For the 2026/27 academic year, our fees are as follows:", "10,611.00", "term", T, "", F, "single fee"),
    # --- Wimbledon High School GDST (page states the Autumn Term fee)
    ("102692", Y26, "102692_2026.html", "senior", "Y7-11", "day", "Senior Autumn Term 2026:", "10,152", "term", T, "", U, "Autumn Term 2026 fee; annual assumes 3 equal terms"),
    ("102692", Y26, "102692_2026.html", "sixth_form", "Y12-13", "day", "Sixth Autumn Term 2026:", "10,152", "term", T, "", U, "Autumn Term 2026 fee; annual assumes 3 equal terms"),
    ("102692", Y25, "102692_2025.html", "senior", "Y7-11", "day", "Senior Autumn Term 2025:", "9,619", "term", T, "", U, "Autumn Term 2025 fee; annual assumes 3 equal terms"),
    ("102692", Y25, "102692_2025.html", "sixth_form", "Y12-13", "day", "Sixth Autumn Term 2025:", "9,619", "term", T, "", U, "Autumn Term 2025 fee; annual assumes 3 equal terms"),
    # --- Concord College (one published boarding fee and one day fee; 'currently' = year of the page)
    ("123623", Y26, "123623_2026.html", "senior", "Form 3-5", "boarding", "Boarding fees are currently", "22,000", "term", T, "", T, "single boarding fee (UK and overseas students alike); year = date of page"),
    ("123623", Y26, "123623_2026.html", "sixth_form", "Y12-13", "boarding", "Boarding fees are currently", "22,000", "term", T, "", T, "single boarding fee; year = date of page"),
    ("123623", Y26, "123623_2026_day.html", "senior", "Form 3-5", "day", "Day fees are currently", "8,100", "term", T, "", T, "includes daily lunch; year = date of page"),
    ("123623", Y26, "123623_2026_day.html", "sixth_form", "Y12-13", "day", "Day fees are currently", "8,100", "term", T, "", T, "includes daily lunch; year = date of page"),
    ("123623", Y25, "123623_2025.html", "senior", "Form 3-5", "boarding", "Boarding fees are currently", "21,000", "term", T, "", T, "capture 2025-10-06"),
    ("123623", Y25, "123623_2025.html", "sixth_form", "Y12-13", "boarding", "Boarding fees are currently", "21,000", "term", T, "", T, "capture 2025-10-06"),
    ("123623", Y25, "123623_2025_day.html", "senior", "Form 3-5", "day", "Day fees are currently", "7,500", "term", T, "", T, "capture 2025-10-06"),
    ("123623", Y25, "123623_2025_day.html", "sixth_form", "Y12-13", "day", "Day fees are currently", "7,500", "term", T, "", T, "capture 2025-10-06"),
    # --- Magdalen College School (sixth-form levy added for Y12-13)
    ("123311", Y26, "123311_2026.html", "senior", "Y7-11", "day", "Termly Fees 2026-7", "10,036.00", "term", T, "8,363.33", F, "lunch £6.36 per meal"),
    ("123311", Y26, "123311_2026.html", "sixth_form", "Y12-13", "day", "Sixth Form Levy", "10,036.00+165.00", "term", T, "8,363.33+137.50", F, "Senior School fee + Sixth Form Levy"),
    ("123311", Y25, "123311_2025.html", "senior", "Y7-11", "day", "Termly Fees 2025-6", "9,604.00", "term", T, "8,003.00", F, "capture 2026-04-15"),
    ("123311", Y25, "123311_2025.html", "sixth_form", "Y12-13", "day", "Sixth Form Levy", "9,604.00+156.00", "term", T, "8,003.00+130.00", F, "Senior School fee + Sixth Form Levy; capture 2026-04-15"),
    # --- The Perse School
    ("110923", Y26, "110923_2026.html", "senior", "Y7-11", "day", "School fees per term", "9,482", "term", T, "", F, "'All fees include VAT where applicable'; lunch £368/term optional"),
    ("110923", Y26, "110923_2026.html", "sixth_form", "Y12-13", "day", "School fees per term", "9,482", "term", T, "", F, "one Upper School fee"),
    ("110923", Y25, "110923_2025.html", "senior", "Y7-11", "day", "School fees per term", "9,074", "term", T, "", F, "lunch £352/term optional; capture 2026-02-14"),
    ("110923", Y25, "110923_2025.html", "sixth_form", "Y12-13", "day", "School fees per term", "9,074", "term", T, "", F, "one Upper School fee"),
    # --- Latymer Upper (2025/26 not captured)
    ("100370", Y26, "100370_2026.html", "senior", "Y7-11", "day", "Tuition fees (from September 2026)", "10,675", "term", T, "8,895.83", F, "Upper School fee; lunch optional extra"),
    ("100370", Y26, "100370_2026.html", "sixth_form", "Y12-13", "day", "Tuition fees (from September 2026)", "10,675", "term", T, "8,895.83", F, "Upper School fee"),
    # --- King Edward VI High School for Girls
    ("103585", Y26, "103585_2026.html", "senior", "Y7-11", "day", "The fees for 2026/27 are", "7,512", "term", T, "6,260", F, "Year 7 lunch compulsory (£4.75/day)"),
    ("103585", Y26, "103585_2026.html", "sixth_form", "Y12-13", "day", "The fees for 2026/27 are", "7,512", "term", T, "6,260", F, ""),
    ("103585", Y25, "103585_2025.html", "senior", "Y7-11", "day", "The fees for 2025/2026 are", "7,145", "term", T, "5,954", F, ""),
    ("103585", Y25, "103585_2025.html", "sixth_form", "Y12-13", "day", "The fees for 2025/2026 are", "7,145", "term", T, "5,954", F, ""),
    # --- Highgate School
    ("102163", Y26, "102163_2026.html", "senior", "Y7-11", "day", "Senior School | Years 7-13:", "10,929", "term", T, "", F, "obligatory lunch charge £369/term stated separately"),
    ("102163", Y26, "102163_2026.html", "sixth_form", "Y12-13", "day", "Senior School | Years 7-13:", "10,929", "term", T, "", F, "obligatory lunch charge £369/term stated separately"),
    ("102163", Y25, "102163_2025.html", "senior", "Y7-11", "day", "Senior School | Years 7-13:", "10,525", "term", T, "", T, "figure includes the obligatory lunch charge of £355"),
    ("102163", Y25, "102163_2025.html", "sixth_form", "Y12-13", "day", "Senior School | Years 7-13:", "10,525", "term", T, "", T, "figure includes the obligatory lunch charge of £355"),
    # --- Wycombe Abbey (fees on the admissions page)
    ("110547", Y26, "110547_2026.html", "senior", "Y7-11", "boarding", "From September 2026, fees are:", "21,500", "term", T, "", T, "boarding fee covers board incl. meals"),
    ("110547", Y26, "110547_2026.html", "sixth_form", "Y12-13", "boarding", "From September 2026, fees are:", "21,500", "term", T, "", T, ""),
    ("110547", Y26, "110547_2026.html", "senior", "Y7-11", "day", "From September 2026, fees are:", "16,400", "term", T, "", U, ""),
    ("110547", Y26, "110547_2026.html", "sixth_form", "Y12-13", "day", "From September 2026, fees are:", "16,400", "term", T, "", U, ""),
    ("110547", Y25, "110547_2025.html", "senior", "Y7-11", "boarding", "From September 2025, fees are:", "20,500", "term", T, "", T, "capture 2025-11-18"),
    ("110547", Y25, "110547_2025.html", "sixth_form", "Y12-13", "boarding", "From September 2025, fees are:", "20,500", "term", T, "", T, ""),
    ("110547", Y25, "110547_2025.html", "senior", "Y7-11", "day", "From September 2025, fees are:", "15,600", "term", T, "", U, ""),
    ("110547", Y25, "110547_2025.html", "sixth_form", "Y12-13", "day", "From September 2025, fees are:", "15,600", "term", T, "", U, ""),
    # --- Alleyn's School (termly fee stated excl. VAT only; yearly both ways)
    ("100864", Y26, "100864_2026.html", "senior", "Y7-11", "day", "Yearly Fee - including VAT", "32,490", "year", T, "27,075", F, "termly £9,025 excl. VAT; lunch not included"),
    ("100864", Y26, "100864_2026.html", "sixth_form", "Y12-13", "day", "Yearly Fee - including VAT", "32,490", "year", T, "27,075", F, "one Senior School fee"),
    ("100864", Y25, "100864_2025.html", "senior", "Y7-11", "day", "Termly Fee - including VAT", "10,338", "term", T, "8,615", F, "lunch not included"),
    ("100864", Y25, "100864_2025.html", "sixth_form", "Y12-13", "day", "Termly Fee - including VAT", "10,338", "term", T, "8,615", F, "one Senior School fee"),
    # --- South Hampstead High School GDST (one Senior School fee)
    ("100076", Y26, "100076_2026.html", "senior", "Y7-11", "day", "Senior School -", "10,020", "term", T, "", F, "lunch £367/term extra"),
    ("100076", Y26, "100076_2026.html", "sixth_form", "Y12-13", "day", "Senior School -", "10,020", "term", T, "", F, "Senior School fee; sixth form not priced separately"),
    ("100076", Y25, "100076_2025.html", "senior", "Y7-11", "day", "Senior School -", "9,457", "term", T, "", F, ""),
    ("100076", Y25, "100076_2025.html", "sixth_form", "Y12-13", "day", "Senior School -", "9,457", "term", T, "", F, "Senior School fee; sixth form not priced separately"),
    # --- Lady Eleanor Holles
    ("102932", Y26, "102932_2026.html", "senior", "Y7-11", "day", "Senior School:", "10,651", "term", T, "", F, "lunch £325/term compulsory, extra"),
    ("102932", Y26, "102932_2026.html", "sixth_form", "Y12-13", "day", "Senior School:", "10,651", "term", T, "", F, ""),
    ("102932", Y25, "102932_2025.html", "senior", "Y7-11", "day", "Senior School:", "10,252", "term", T, "", F, "lunch £304/term compulsory, extra"),
    ("102932", Y25, "102932_2025.html", "sixth_form", "Y12-13", "day", "Senior School:", "10,252", "term", T, "", F, ""),
    # --- City of London School (2025/26 not captured)
    ("100003", Y26, "100003_2026.html", "senior", "Y7-11", "day", "Tuition fees are", "9,848.40", "term", T, "", U, "single fee"),
    ("100003", Y26, "100003_2026.html", "sixth_form", "Y12-13", "day", "Tuition fees are", "9,848.40", "term", T, "", U, "single fee"),
    # --- Haberdashers' Boys' School
    ("117648", Y26, "117648_2026.html", "senior", "Y7-11", "day", "Senior School (Years 7, 8, 9, 10 and 11)", "10,829.00", "term", T, "9,025.00", F, "lunch £5.50/day extra"),
    ("117648", Y26, "117648_2026.html", "sixth_form", "Y12-13", "day", "Sixth Form (Years 12 and 13)", "10,829.00", "term", T, "9,025.00", F, ""),
    ("117648", Y25, "117648_2025.html", "senior", "Y7-11", "day", "Senior School (Years 7, 8, 9, 10 and 11)", "10,423.00", "term", T, "8,686.00", F, "capture 2026-01-14"),
    ("117648", Y25, "117648_2025.html", "sixth_form", "Y12-13", "day", "Sixth Form (Years 12 and 13)", "10,423.00", "term", T, "8,686.00", F, ""),
    # --- Putney High School GDST
    ("101072", Y26, "101072_2026.html", "senior", "Y7-11", "day", "Senior Academic Year 2026/2027:", "10,152", "term", T, "", F, "lunch £382/term compulsory to Y11, extra"),
    ("101072", Y26, "101072_2026.html", "sixth_form", "Y12-13", "day", "Sixth Form Academic Year 2026/2027:", "10,152", "term", T, "", F, ""),
    ("101072", Y25, "101072_2025.html", "senior", "Y7-11", "day", "Senior Academic Year 2025/2026:", "9,669", "term", T, "", F, "lunch £364/term compulsory to Y11, extra"),
    ("101072", Y25, "101072_2025.html", "sixth_form", "Y12-13", "day", "Sixth Form Academic Year 2025/2026:", "9,659", "term", T, "", F, ""),
    # --- Withington Girls' School
    ("105595", Y26, "105595_2026.html", "senior", "Y7-11", "day", "Fees (including VAT)", "6,580", "term", T, "", F, "plus insurance £6 and lunches £343 per term"),
    ("105595", Y26, "105595_2026.html", "sixth_form", "Y12-13", "day", "Sixth Form | Per Term | Per Year | Fees (including VAT)", "6,580", "term", T, "", F, "plus insurance £6 per term"),
    ("105595", Y25, "105595_2025.html", "senior", "Y7-11", "day", "Fees for 2025-2026 Senior School", "5,275+1,055", "term", T, "5,275", F, "fee + VAT on fees; plus insurance £6 and lunches £330 per term"),
    ("105595", Y25, "105595_2025.html", "sixth_form", "Y12-13", "day", "Sixth Form | Per Term | Per Year | Fees", "5,275+1,055", "term", T, "5,275", F, "fee + VAT on fees"),
    # --- Haberdashers' Girls' School
    ("117649", Y26, "117649_2026.html", "senior", "Y7-11", "day", "Year 7, 8, 9, 10 and 11", "10,431.00", "term", T, "8,692.00", F, "lunch £5.50/day extra"),
    ("117649", Y26, "117649_2026.html", "sixth_form", "Y12-13", "day", "Sixth Form (Years 12 and 13)", "10,588.00", "term", T, "8,823.00", F, ""),
    ("117649", Y25, "117649_2025.html", "senior", "Y7-11", "day", "Year 7, 8, 9, 10 and 11", "10,039.00", "term", T, "8,366.00", F, ""),
    ("117649", Y25, "117649_2025.html", "sixth_form", "Y12-13", "day", "Sixth Form (Years 12 and 13)", "10,166.00", "term", T, "8,472.00", F, ""),
    # --- Eton College (all boarders; three 'Halves' a year)
    ("110158", Y26, "110158_2026.html", "senior", "Y9-11", "boarding", "2026/27 School Fee", "21,891", "term", T, "", U, "per Half; three Halves a year"),
    ("110158", Y26, "110158_2026.html", "sixth_form", "Y12-13", "boarding", "2026/27 School Fee", "21,891", "term", T, "", U, "per Half"),
    ("110158", Y25, "110158_2025.html", "senior", "Y9-11", "boarding", "2025/26 School Fee", "21,099.60", "term", T, "17,583", U, "per Half"),
    ("110158", Y25, "110158_2025.html", "sixth_form", "Y12-13", "boarding", "2025/26 School Fee", "21,099.60", "term", T, "17,583", U, "per Half"),
    # --- James Allen's Girls' School
    ("100863", Y26, "100863_2026.html", "senior", "Y7-11", "day", "Senior School Termly Tuition Fees", "10,146", "term", T, "", F, "lunch £462/£363/£371 by term, extra"),
    ("100863", Y26, "100863_2026.html", "sixth_form", "Y12-13", "day", "Senior School Termly Tuition Fees", "10,146", "term", T, "", F, ""),
    ("100863", Y25, "100863_2025.html", "senior", "Y7-11", "day", "Senior School Termly Tuition Fees", "9,784", "term", T, "", F, "capture 2026-01-18"),
    ("100863", Y25, "100863_2025.html", "sixth_form", "Y12-13", "day", "Senior School Termly Tuition Fees", "9,784", "term", T, "", F, ""),
    # --- Royal Grammar School Guildford
    ("125424", Y26, "125424_2026.html", "senior_lower", "Y7-8", "day", "Senior – First and Second Forms", "9,252", "term", T, "", F, "lunch compulsory Y7-8 at £370/term, extra"),
    ("125424", Y26, "125424_2026.html", "senior", "Y9-11", "day", "Senior – Third to Upper Sixth Forms", "9,360", "term", T, "", F, ""),
    ("125424", Y26, "125424_2026.html", "sixth_form", "Y12-13", "day", "Senior – Third to Upper Sixth Forms", "9,360", "term", T, "", F, ""),
    ("125424", Y25, "125424_2025.html", "senior", "Y7-11", "day", "Senior – First to Sixth Forms", "8,790", "term", T, "", F, "one fee Y7-13"),
    ("125424", Y25, "125424_2025.html", "sixth_form", "Y12-13", "day", "Senior – First to Sixth Forms", "8,790", "term", T, "", F, "one fee Y7-13"),
    # --- Kingston Grammar School (live page shows both years; 2025/26 taken from the Wayback capture)
    ("102619", Y26, "102619_2026.html", "senior", "Y7-11", "day", "Academic fees 2026-2027", "9,750", "term", T, "8,125", F, "lunch optional extra"),
    ("102619", Y26, "102619_2026.html", "sixth_form", "Y12-13", "day", "Academic fees 2026-2027", "9,750", "term", T, "8,125", F, ""),
    ("102619", Y25, "102619_2025.html", "senior", "Y7-11", "day", "Academic fees 2025-2026", "9,150", "term", T, "7,625", F, "capture 2026-05-07"),
    ("102619", Y25, "102619_2025.html", "sixth_form", "Y12-13", "day", "Academic fees 2025-2026", "9,150", "term", T, "7,625", F, ""),
    # --- Bancroft's School
    ("102875", Y26, "102875_2026.html", "senior", "Y7-11", "day", "Senior School", "10,400.00", "term", T, "8,666.67", T, "fees include school lunches"),
    ("102875", Y26, "102875_2026.html", "sixth_form", "Y12-13", "day", "Senior School", "10,400.00", "term", T, "8,666.67", T, ""),
    ("102875", Y25, "102875_2025.html", "senior", "Y7-11", "day", "Senior School", "10,048.00", "term", T, "8,373.33", T, ""),
    ("102875", Y25, "102875_2025.html", "sixth_form", "Y12-13", "day", "Senior School", "10,048.00", "term", T, "8,373.33", T, ""),
    # --- Tonbridge School (13+)
    ("118959", Y26, "118959_2026.html", "senior", "Y9-11", "boarding", "Boarding Fees", "21,417", "term", T, "", T, "fees cover tuition, meals"),
    ("118959", Y26, "118959_2026.html", "sixth_form", "Y12-13", "boarding", "Boarding Fees", "21,417", "term", T, "", T, ""),
    ("118959", Y26, "118959_2026.html", "senior", "Y9-11", "day", "Day Boy Fees", "16,069", "term", T, "", T, ""),
    ("118959", Y26, "118959_2026.html", "sixth_form", "Y12-13", "day", "Day Boy Fees", "16,069", "term", T, "", T, ""),
    ("118959", Y25, "118959_2025.html", "senior", "Y9-11", "boarding", "Boarding Fees", "20,693", "term", T, "", U, ""),
    ("118959", Y25, "118959_2025.html", "sixth_form", "Y12-13", "boarding", "Boarding Fees", "20,693", "term", T, "", U, ""),
    ("118959", Y25, "118959_2025.html", "senior", "Y9-11", "day", "Day Boy Fees", "15,526", "term", T, "", U, ""),
    ("118959", Y25, "118959_2025.html", "sixth_form", "Y12-13", "day", "Day Boy Fees", "15,526", "term", T, "", U, ""),
    # --- Hampton School
    ("102946", Y26, "102946_2026.html", "senior", "Y7-11", "day", "Tuition Fees", "10,416.00", "term", T, "", U, ""),
    ("102946", Y26, "102946_2026.html", "sixth_form", "Y12-13", "day", "Tuition Fees", "10,416.00", "term", T, "", U, ""),
    ("102946", Y25, "102946_2025.html", "senior", "Y7-11", "day", "Tuition Fees", "9,972.00", "term", T, "", U, "capture 2026-03-16, heading 'Fees 2025-26'"),
    ("102946", Y25, "102946_2025.html", "sixth_form", "Y12-13", "day", "Tuition Fees", "9,972.00", "term", T, "", U, ""),
    # --- Trinity School, Croydon (annual fee)
    ("101842", Y26, "101842_2026.html", "senior", "Y7-11", "day", "The School fee will be", "30,468", "year", T, "", F, "lunches not covered"),
    ("101842", Y26, "101842_2026.html", "sixth_form", "Y12-13", "day", "The School fee will be", "30,468", "year", T, "", F, ""),
    ("101842", Y25, "101842_2025.html", "senior", "Y7-11", "day", "The School fee is", "29,240", "year", T, "", U, ""),
    ("101842", Y25, "101842_2025.html", "sixth_form", "Y12-13", "day", "The School fee is", "29,240", "year", T, "", U, ""),
    # --- Winchester College (13+)
    ("116532", Y26, "116532_2026.html", "senior", "Y9-11", "boarding", "Boarding fees per term:", "20,700", "term", T, "", U, ""),
    ("116532", Y26, "116532_2026.html", "sixth_form", "Y12-13", "boarding", "Boarding fees per term:", "20,700", "term", T, "", U, ""),
    ("116532", Y26, "116532_2026.html", "senior", "Y9-11", "day", "Day fees per term:", "15,318", "term", T, "", U, ""),
    ("116532", Y26, "116532_2026.html", "sixth_form", "Y12-13", "day", "Day fees per term:", "15,318", "term", T, "", U, ""),
    ("116532", Y25, "116532_2025.html", "senior", "Y9-11", "boarding", "Boarding Fees per term:", "20,000", "term", U, "", U, ""),
    ("116532", Y25, "116532_2025.html", "sixth_form", "Y12-13", "boarding", "Boarding Fees per term:", "20,000", "term", U, "", U, ""),
    ("116532", Y25, "116532_2025.html", "senior", "Y9-11", "day", "Day Fees per term:", "14,800", "term", U, "", U, ""),
    ("116532", Y25, "116532_2025.html", "sixth_form", "Y12-13", "day", "Day Fees per term:", "14,800", "term", U, "", U, ""),
    # --- Reigate Grammar School
    ("125422", Y26, "125422_2026.html", "senior_lower", "Y7-8", "day", "Years 7-8", "9,635", "term", T, "", F, "lunch bought via cashless system"),
    ("125422", Y26, "125422_2026.html", "senior", "Y9-11", "day", "Years 9-13", "9,900", "term", T, "", F, ""),
    ("125422", Y26, "125422_2026.html", "sixth_form", "Y12-13", "day", "Years 9-13", "9,900", "term", T, "", F, ""),
    ("125422", Y25, "125422_2025.html", "senior_lower", "Y7-8", "day", "Years 7-8", "9,265", "term", T, "", F, ""),
    ("125422", Y25, "125422_2025.html", "senior", "Y9-11", "day", "Years 9-13", "9,515", "term", T, "", F, ""),
    ("125422", Y25, "125422_2025.html", "sixth_form", "Y12-13", "day", "Years 9-13", "9,515", "term", T, "", F, ""),
    # --- Sevenoaks School (separate fees for pupils entering at sixth form)
    ("118952", Y26, "118952_2026.html", "senior", "Y7-11", "day", "Day student: Lower and Middle School", "12,514", "term", T, "", T, "fees include lunch"),
    ("118952", Y26, "118952_2026.html", "sixth_form", "Y12-13", "day", "Day student: Sixth Form", "12,734", "term", T, "", T, ""),
    ("118952", Y26, "118952_2026.html", "sixth_form_new_entrant", "Y12-13", "day", "Day student entering at Sixth Form", "14,461", "term", T, "", T, ""),
    ("118952", Y26, "118952_2026.html", "senior", "Y9-11", "boarding", "Boarding student: Middle School", "20,472", "term", T, "", T, ""),
    ("118952", Y26, "118952_2026.html", "sixth_form", "Y12-13", "boarding", "Boarding student: Sixth Form", "20,639", "term", T, "", T, ""),
    ("118952", Y26, "118952_2026.html", "sixth_form_new_entrant", "Y12-13", "boarding", "Boarding student entering at Sixth Form", "22,383", "term", T, "", T, ""),
    ("118952", Y25, "118952_2025.html", "senior", "Y7-11", "day", "Day student: Lower and Middle School", "11,975", "term", T, "9,979", T, ""),
    ("118952", Y25, "118952_2025.html", "sixth_form", "Y12-13", "day", "Day student: Sixth Form", "12,186", "term", T, "10,155", T, ""),
    ("118952", Y25, "118952_2025.html", "sixth_form_new_entrant", "Y12-13", "day", "Day student entering at Sixth Form", "13,838", "term", T, "11,532", T, ""),
    ("118952", Y25, "118952_2025.html", "senior", "Y9-11", "boarding", "Boarding student: Middle School", "19,590", "term", T, "16,325", T, ""),
    ("118952", Y25, "118952_2025.html", "sixth_form", "Y12-13", "boarding", "Boarding student: Sixth Form", "19,750", "term", T, "16,458", T, ""),
    ("118952", Y25, "118952_2025.html", "sixth_form_new_entrant", "Y12-13", "boarding", "Boarding student entering at Sixth Form", "21,419", "term", T, "17,849", T, ""),
    # --- St Mary's School Ascot (fees on the admissions page)
    ("110120", Y26, "110120_2026.html", "senior", "Y7-11", "boarding", "Boarding Fee:", "23,016", "term", T, "", U, ""),
    ("110120", Y26, "110120_2026.html", "sixth_form", "Y12-13", "boarding", "Boarding Fee:", "23,016", "term", T, "", U, ""),
    ("110120", Y26, "110120_2026.html", "senior", "Y7-11", "day", "Day Boarding Fee:", "16,380", "term", T, "", U, "school's term for day pupils is 'day boarding'"),
    ("110120", Y26, "110120_2026.html", "sixth_form", "Y12-13", "day", "Day Boarding Fee:", "16,380", "term", T, "", U, ""),
    ("110120", Y25, "110120_2025.html", "senior", "Y7-11", "boarding", "Boarding Fee:", "21,912", "term", T, "", U, ""),
    ("110120", Y25, "110120_2025.html", "sixth_form", "Y12-13", "boarding", "Boarding Fee:", "21,912", "term", T, "", U, ""),
    ("110120", Y25, "110120_2025.html", "senior", "Y7-11", "day", "Day Boarding Fee:", "15,600", "term", T, "", U, ""),
    ("110120", Y25, "110120_2025.html", "sixth_form", "Y12-13", "day", "Day Boarding Fee:", "15,600", "term", T, "", U, ""),
    # --- The Manchester Grammar School
    ("105591", Y26, "105591_2026.html", "senior", "Y7-11", "day", "Fees for the year 2026/27 are", "6,603", "term", T, "", F, "£19,809 per year; meals optional"),
    ("105591", Y26, "105591_2026.html", "sixth_form", "Y12-13", "day", "Fees for the year 2026/27 are", "6,603", "term", T, "", F, ""),
    ("105591", Y25, "105591_2025.html", "senior", "Y7-11", "day", "Fees for the year 2025/26 are", "6,222", "term", T, "", F, "£18,666 per year"),
    ("105591", Y25, "105591_2025.html", "sixth_form", "Y12-13", "day", "Fees for the year 2025/26 are", "6,222", "term", T, "", F, ""),
    # --- St Albans High School for Girls (schedule PDF; 2025/26 PDF not archived)
    ("117617", Y26, "117617_2026_pdf.pdf", "senior", "Y7-11", "day", "Years 7 -13", "9,776", "term", T, "8,147", F, "senior lunch £330/term optional"),
    ("117617", Y26, "117617_2026_pdf.pdf", "sixth_form", "Y12-13", "day", "Years 7 -13", "9,776", "term", T, "8,147", F, ""),
    # --- Merchant Taylors' School (tuition + VAT; compulsory lunch billed on top)
    ("117616", Y26, "117616_2026.html", "senior", "Y7-11", "day", "School Fees 2026-2027", "8,939+1,788", "term", T, "8,939", F, "tuition + VAT; compulsory lunch £348/term on top (page total £11,075)"),
    ("117616", Y26, "117616_2026.html", "sixth_form", "Y12-13", "day", "School Fees 2026-2027", "8,939+1,788", "term", T, "8,939", F, ""),
    ("117616", Y25, "117616_2025.html", "senior", "Y7-11", "day", "School Fees 2025-2026", "8,595+1,719", "term", T, "8,595", F, "tuition + VAT; compulsory lunch £335/term on top (page total £10,649)"),
    ("117616", Y25, "117616_2025.html", "sixth_form", "Y12-13", "day", "School Fees 2025-2026", "8,595+1,719", "term", T, "8,595", F, ""),
    # --- University College School
    ("100065", Y26, "100065_2026.html", "senior", "Y7-11", "day", "Senior School |", "11,437", "term", T, "", T, "Senior School fees include lunch"),
    ("100065", Y26, "100065_2026.html", "sixth_form", "Y12-13", "day", "Senior School |", "11,437", "term", T, "", T, ""),
    ("100065", Y25, "100065_2025.html", "senior", "Y7-11", "day", "Senior School |", "10,971", "term", T, "", T, "capture 2026-03-15"),
    ("100065", Y25, "100065_2025.html", "sixth_form", "Y12-13", "day", "Senior School |", "10,971", "term", T, "", T, ""),
    # --- Abingdon School
    ("123312", Y26, "123312_2026.html", "senior", "Y7-11", "day", "Day fee (includes lunches)", "9,500", "term", T, "", T, ""),
    ("123312", Y26, "123312_2026.html", "sixth_form", "Y12-13", "day", "Day fee (includes lunches)", "9,500", "term", T, "", T, ""),
    ("123312", Y26, "123312_2026.html", "senior", "Y9-11", "weekly_boarding", "Weekly Boarding fee", "15,810", "term", T, "", U, ""),
    ("123312", Y26, "123312_2026.html", "sixth_form", "Y12-13", "weekly_boarding", "Weekly Boarding fee", "15,810", "term", T, "", U, ""),
    ("123312", Y26, "123312_2026.html", "senior", "Y9-11", "boarding", "Full Boarding fee", "19,375", "term", T, "", U, ""),
    ("123312", Y26, "123312_2026.html", "sixth_form", "Y12-13", "boarding", "Full Boarding fee", "19,375", "term", T, "", U, ""),
    ("123312", Y25, "123312_2025.html", "senior", "Y7-11", "day", "Day fee (includes lunches)", "9,225", "term", T, "", T, ""),
    ("123312", Y25, "123312_2025.html", "sixth_form", "Y12-13", "day", "Day fee (includes lunches)", "9,225", "term", T, "", T, ""),
    ("123312", Y25, "123312_2025.html", "senior", "Y9-11", "weekly_boarding", "Weekly Boarding fee", "15,350", "term", T, "", U, ""),
    ("123312", Y25, "123312_2025.html", "sixth_form", "Y12-13", "weekly_boarding", "Weekly Boarding fee", "15,350", "term", T, "", U, ""),
    ("123312", Y25, "123312_2025.html", "senior", "Y9-11", "boarding", "Full Boarding fee", "18,810", "term", T, "", U, ""),
    ("123312", Y25, "123312_2025.html", "sixth_form", "Y12-13", "boarding", "Full Boarding fee", "18,810", "term", T, "", U, ""),
    # --- Nottingham High School
    ("122915", Y26, "122915_2026.html", "senior", "Y7-11", "day", "Senior School", "7,718", "term", T, "", U, ""),
    ("122915", Y26, "122915_2026.html", "sixth_form", "Y12-13", "day", "Sixth Form", "7,718", "term", T, "", U, ""),
    ("122915", Y25, "122915_2025.html", "senior", "Y7-11", "day", "Senior School", "7,461", "term", T, "", U, ""),
    ("122915", Y25, "122915_2025.html", "sixth_form", "Y12-13", "day", "Sixth Form", "7,461", "term", T, "", U, ""),
    # --- Francis Holland School, Sloane Square (2025/26 table loaded by AJAX, not archived)
    ("101161", Y26, "101161_2026.html", "senior", "Y7-11", "day", "Year 7 to Year 13 –", "11,058", "term", T, "", T, "fees include lunch"),
    ("101161", Y26, "101161_2026.html", "sixth_form", "Y12-13", "day", "Year 7 to Year 13 –", "11,058", "term", T, "", T, ""),
    # --- Emanuel School (page text gives the fee excl. VAT; the incl.-VAT figure is in the page's table image)
    ("101071", Y26, "101071_2026.html", "senior", "Y7-11", "day", "For the academic year beginning in September 2026", "10,460.40", "term", T, "8,717", T, "incl.-VAT termly fee from the fee-table image 101071_2026_table.png (= 8,717 x 1.2); lunches included"),
    ("101071", Y26, "101071_2026.html", "sixth_form", "Y12-13", "day", "For the academic year beginning in September 2026", "10,460.40", "term", T, "8,717", T, "one fee; see above"),
    # --- St Swithun's School
    ("116534", Y26, "116534_2026_senior.html", "senior", "Y7-11", "boarding", "The 2026-27 fees are:", "19,272.08", "term", U, "", U, ""),
    ("116534", Y26, "116534_2026_senior.html", "sixth_form", "Y12-13", "boarding", "The 2026-27 fees are:", "19,272.08", "term", U, "", U, ""),
    ("116534", Y26, "116534_2026_senior.html", "senior", "Y7-11", "day", "The 2026-27 fees are:", "11,403.37", "term", U, "", U, ""),
    ("116534", Y26, "116534_2026_senior.html", "sixth_form", "Y12-13", "day", "The 2026-27 fees are:", "11,403.37", "term", U, "", U, ""),
    ("116534", Y25, "116534_2025_senior.html", "senior", "Y7-11", "boarding", "The 2025-26 fees will be:", "18,332.40", "term", T, "", U, ""),
    ("116534", Y25, "116534_2025_senior.html", "sixth_form", "Y12-13", "boarding", "The 2025-26 fees will be:", "18,332.40", "term", T, "", U, ""),
    ("116534", Y25, "116534_2025_senior.html", "senior", "Y7-11", "day", "The 2025-26 fees will be:", "10,846.80", "term", T, "", U, ""),
    ("116534", Y25, "116534_2025_senior.html", "sixth_form", "Y12-13", "day", "The 2025-26 fees will be:", "10,846.80", "term", T, "", U, ""),
]

# Brighton College: year-by-year fees from the UK fees-structure PDFs, excl. VAT and incl. VAT + price support
BRIGHTON = {  # year label -> {fee_year: (day, weekly, full) each as (excl, incl) or None}
    "Yr 7 – Lower 3rd": {Y26: (("8,280", "9,612"), None, None), Y25: (("8,000", "9,212"), None, None)},
    "Yr 8 – Upper 3rd": {Y26: (("9,010", "10,466"), None, None), Y25: (("8,700", "10,024"), None, None)},
    "Yr 9 – 4th Form": {Y26: (("10,840", "12,648"), ("15,830", "18,511"), ("18,770", "21,965")),
                        Y25: (("10,470", "12,067"), ("15,290", "17,659"), ("18,130", "20,953"))},
    "Yr 10 – Lower 5th": {Y26: (("10,990", "12,824"), ("15,910", "18,605"), ("19,040", "22,283")),
                          Y25: (("10,610", "12,230"), ("15,370", "17,751"), ("18,390", "21,255"))},
    "Yr 11 – Upper 5th": {Y26: (("11,060", "12,906"), ("15,980", "18,687"), ("19,160", "22,424")),
                          Y25: (("10,680", "12,311"), ("15,430", "17,821"), ("18,510", "21,394"))},
    "Yr 12 – Lower 6th": {Y26: (("11,060", "12,906"), ("16,210", "18,957"), ("19,690", "23,046")),
                          Y25: (("10,680", "12,311"), ("15,660", "18,088"), ("19,020", "21,985"))},
    "Yr 13 – Upper 6th": {Y26: (("11,360", "13,259"), ("16,320", "19,087"), ("19,810", "23,187")),
                          Y25: (("10,970", "12,647"), ("15,760", "18,204"), ("19,140", "22,125"))},
}
for label, by_year in BRIGHTON.items():
    yr = int(label.split()[1])
    stage = "senior_lower" if yr <= 8 else "senior" if yr <= 11 else "sixth_form"
    for fy, modes in by_year.items():
        f = "114614_2026_pdf.pdf" if fy == Y26 else "114614_2025_pdf.pdf"
        for mode, pair in zip(("day", "weekly_boarding", "boarding"), modes):
            if pair:
                ROWS.append(("114614", fy, f, stage, f"Y{yr}", mode, label, pair[1], "term", T, pair[0], T,
                             "incl. VAT and the school's transitional price support; lunch element included"))

# Bottom 20 private schools (data/derived/bottom20_private.csv): 2026/27 only, live pages retrieved 2026-10-10.
# Same tuple layout and the same text check as ROWS. Years 7-8 boarding fees are not transcribed.
BOTTOM20_ROWS = [
    # --- Ealing Independent College (GCSE and A level college; priced by number of subjects)
    ("133444", Y26, "133444_2026.html", "senior", "Y9-11", "day", "Up to 8 subjects", "7,875", "term", T, "", U, "GCSE course, Years 9-11, up to 8 subjects (£1,969/month over 12 months); plus books and resources £450/yr and £300 enrolment fee; exam fees extra"),
    ("133444", Y26, "133444_2026.html", "sixth_form", "Y12-13", "day", "2-3 subjects", "7,875", "term", T, "", U, "A level, 2-3 subjects (a 4th is free); Year 13 one-year intensive: £8,517/term up to 3 subjects, £6,212 two, £3,186 one; books £450/yr extra"),
    # --- David Game College (priced per subject, per year; boarding is accommodation only, on top of tuition)
    ("100544", Y26, "100544_2026_pdf.pdf", "senior", "1-yr GCSE", "day", "One year GCSE & IGCSE courses", "29,760", "year", T, "", U, "one-year GCSE course, five subjects (the minimum for EEA students): Sept 2026 £17,660 + Jan 2027 £12,100; £5,952 for one subject, further subjects £5,950 each; the UK/EEA sheet has no two-year GCSE fee; practical, textbook and exam fees extra"),
    ("100544", Y26, "100544_2026_pdf.pdf", "sixth_form", "Y12-13", "day", "Two year A level courses", "29,760", "year", T, "", U, "two-year A level course, three subjects, per year (Sept £18,300 + Jan £11,460); one subject £9,920, two £19,840, four £37,500; practical fees (£750/subject for sciences, art etc.) extra. Boarding (14+) is accommodation and meals only, charged on top of tuition: £28,200/yr standard single room (100544_2026_boarding_pdf.pdf), so no boarding row"),
    # --- Kirkham Grammar School (boarding = term fee + boarding supplement)
    ("119835", Y26, "119835_2026.html", "senior", "Y7-11", "day", "Fees per Term from September 2026 (includes VAT)", "6,617", "term", T, "", U, "one Senior School fee"),
    ("119835", Y26, "119835_2026.html", "sixth_form", "Y12-13", "day", "Fees per Term from September 2026 (includes VAT)", "6,617", "term", T, "", U, "one Senior School fee"),
    ("119835", Y26, "119835_2026.html", "senior", "Y7-11", "boarding", "Fees per Term from September 2026 (includes VAT)", "6,617+6,430", "term", T, "", U, "Senior term fee + boarding fee 'in addition to the term fee'"),
    ("119835", Y26, "119835_2026.html", "sixth_form", "Y12-13", "boarding", "Fees per Term from September 2026 (includes VAT)", "6,617+6,430", "term", T, "", U, "Senior term fee + boarding fee 'in addition to the term fee'"),
    # --- Bosworth Independent School (domestic fee sheet; annual tuition + supervised boarding)
    ("122149", Y26, "122149_2026_pdf.pdf", "senior", "Y7-11", "day", "Domestic Fees 2026-2027", "15,495", "year", U, "", U, "'Study Programmes Tuition', one figure for Years 7, 8, 9 and GCSE; tuition only (boarding is a separate column); the sheet does not state VAT treatment"),
    ("122149", Y26, "122149_2026_pdf.pdf", "sixth_form", "Y12-13", "day", "A level – 2 year", "15,495", "year", U, "", U, "tuition only; the sheet does not state VAT treatment"),
    ("122149", Y26, "122149_2026_pdf.pdf", "senior", "Y7-11", "boarding", "Domestic Fees 2026-2027", "29,985", "year", U, "", T, "'Total Annual Fee' = tuition £15,495 + supervised boarding £14,490 (twin room; single £15,990); boarding includes all meals"),
    ("122149", Y26, "122149_2026_pdf.pdf", "sixth_form", "Y12-13", "boarding", "A level – 2 year", "29,985", "year", U, "", T, "'Total Annual Fee' = tuition £15,495 + supervised boarding £14,490 (twin room)"),
    # --- Ellesmere College (fee sheet linked from the fees page; compulsory lunch billed on top)
    ("123600", Y26, "123600_2026_pdf.pdf", "senior_lower", "Y7-8", "day", "Day Pupils (School Years 6-8)", "6,186", "term", T, "5,155", F, "Lower School fee for Years 6-8; compulsory lunch £280/term extra"),
    ("123600", Y26, "123600_2026_pdf.pdf", "senior", "Y9-11", "day", "Day Pupils (School Years 9-13)", "7,740", "term", T, "6,450", F, "one Upper School fee Years 9-13; compulsory lunch £380/term extra (VAT-exempt); a footnote cites a 'full rate of £7,710' for award holders"),
    ("123600", Y26, "123600_2026_pdf.pdf", "sixth_form", "Y12-13", "day", "Day Pupils (School Years 9-13)", "7,740", "term", T, "6,450", F, "one Upper School fee Years 9-13"),
    ("123600", Y26, "123600_2026_pdf.pdf", "senior", "Y9-11", "boarding", "Full Boarders (School Years 9-13)", "16,368", "term", T, "13,640", F, "compulsory lunch £380/term extra"),
    ("123600", Y26, "123600_2026_pdf.pdf", "sixth_form", "Y12-13", "boarding", "Full Boarders (School Years 9-13)", "16,368", "term", T, "13,640", F, ""),
    # --- Warminster School
    ("126522", Y26, "126522_2026.html", "senior", "Y7-11", "day", "Years 7 & 8", "9,033", "term", T, "", U, "same day fee for Years 7-8 and 9-11"),
    ("126522", Y26, "126522_2026.html", "sixth_form", "Y12-13", "day", "6th Form A Level", "9,033", "term", T, "", U, "A level; IB £10,194/term"),
    ("126522", Y26, "126522_2026.html", "senior", "Y9-11", "boarding", "Years 9, 10 & 11", "17,187", "term", T, "", U, "full boarding; Years 7-8 £14,732"),
    ("126522", Y26, "126522_2026.html", "sixth_form", "Y12-13", "boarding", "6th Form A Level", "17,187", "term", T, "", U, "A level, full boarding; IB £18,348"),
    # --- Barnard Castle School (fee + VAT; the page prints no year, its linked image-only fee sheet does)
    ("114336", Y26, "114336_2026.html", "senior", "Y7-11", "day", "Senior Day (Year 7 to Year 13)", "6,233.00+1,246.60", "term", T, "6,233.00", F, "termly fee + VAT; compulsory lunch £467/term on top (page total £7,946.60). Year: the page prints none; its linked image-only sheet 114336_2026_pdf.pdf (read by eye) gives the same figures for the 'Academic Year to 31 August 2027, From 1 September 2026'"),
    ("114336", Y26, "114336_2026.html", "sixth_form", "Y12-13", "day", "Senior Day (Year 7 to Year 13)", "6,233.00+1,246.60", "term", T, "6,233.00", F, "one fee Years 7-13; see senior row for the year"),
    ("114336", Y26, "114336_2026.html", "senior", "Y7-11", "boarding", "Senior Boarder (Year 7 to Year 13)", "12,363.00+2,472.60", "term", T, "12,363.00", F, "British boarders; termly fee + VAT; compulsory lunch £467/term on top (page total £15,302.60)"),
    ("114336", Y26, "114336_2026.html", "sixth_form", "Y12-13", "boarding", "Senior Boarder (Year 7 to Year 13)", "12,363.00+2,472.60", "term", T, "12,363.00", F, "British boarders; one fee Years 7-13"),
    # --- LVS Ascot (fees rise from January 2027: annual = sum of the three termly fees)
    ("110159", Y26, "110159_2026.html", "senior", "Y7-11", "day", "Senior Day * (Y7-Y11)", "8,856.00+9,215.00+9,215.00", "year", T, "", T, "Autumn 2026 + Spring 2027 + Summer 2027; fees include lunch, books and exam entry"),
    ("110159", Y26, "110159_2026.html", "sixth_form", "Y12-13", "day", "Sixth Form Day ** (Y12-Y13)", "9,342.00+9,725.00+9,725.00", "year", T, "", T, "Autumn 2026 + Spring 2027 + Summer 2027"),
    ("110159", Y26, "110159_2026.html", "senior", "Y7-11", "boarding", "Senior Boarding * (Y7-Y11)", "15,492.00+16,125.00+16,125.00", "year", T, "", T, "Autumn 2026 + Spring 2027 + Summer 2027; all meals included"),
    ("110159", Y26, "110159_2026.html", "sixth_form", "Y12-13", "boarding", "Sixth Form Boarding ** (Y12-Y13)", "16,098.00+16,755.00+16,755.00", "year", T, "", T, "Autumn 2026 + Spring 2027 + Summer 2027"),
    # --- Scarborough College (fee sheet linked from the fees page)
    ("121730", Y26, "121730_2026_pdf.pdf", "senior", "Y7-11", "day", "Day Tuition for Years 7 – 11", "7,140", "term", T, "", T, "£21,420 per annum; fees include lunch and wraparound care (lunch itemised on the invoice)"),
    ("121730", Y26, "121730_2026_pdf.pdf", "sixth_form", "Y12-13", "day", "Day Tuition for Sixth Form", "7,770", "term", T, "", T, "£23,310 per annum"),
    ("121730", Y26, "121730_2026_pdf.pdf", "senior", "Y7-11", "boarding", "UK Full Boarding for Years 7 - 11", "13,300", "term", T, "", T, "UK full boarding; overseas £15,496/term"),
    ("121730", Y26, "121730_2026_pdf.pdf", "sixth_form", "Y12-13", "boarding", "UK Full Boarding for Sixth Form", "15,007", "term", T, "", T, "UK full boarding; overseas £17,193/term"),
    # --- St Joseph's College, Ipswich (fee schedule linked from the fees page; lunch extra)
    ("124883", Y26, "124883_2026_pdf.pdf", "senior_lower", "Y7", "day", "LOWER SCHOOL (Y7)", "8,325", "term", T, "", F, "lunch extra (Y7-10: £409.50/£351/£351 by term)"),
    ("124883", Y26, "124883_2026_pdf.pdf", "senior_lower", "Y8", "day", "LOWER SCHOOL (Y8)", "8,482", "term", T, "", F, ""),
    ("124883", Y26, "124883_2026_pdf.pdf", "senior", "Y9-11", "day", "UPPER SCHOOL", "9,025", "term", T, "", F, "Upper School Seniors (Y9-11); lunch extra"),
    ("124883", Y26, "124883_2026_pdf.pdf", "sixth_form", "Y12", "day", "SIXTH FORM (L6)", "8,858", "term", T, "", F, ""),
    ("124883", Y26, "124883_2026_pdf.pdf", "sixth_form", "Y13", "day", "SIXTH FORM (U6)", "9,025", "term", T, "", F, ""),
    ("124883", Y26, "124883_2026_pdf.pdf", "senior", "Y9-11", "boarding", "UPPER SCHOOL", "19,972", "term", T, "", T, "full boarding includes all meals"),
    ("124883", Y26, "124883_2026_pdf.pdf", "sixth_form", "Y12-13", "boarding", "SIXTH FORM (L6)", "19,972", "term", T, "", T, "same for L6 and U6"),
    # --- The Oratory School (non-optional lunch charge billed on top)
    ("123282", Y26, "123282_2026.html", "senior_lower", "Y7-8", "day", "1st Form & 2nd Form (Years 7 & 8):", "8,611", "term", T, "", F, "non-optional lunch charge £325/term added to the bill"),
    ("123282", Y26, "123282_2026.html", "senior", "Y9-11", "day", "Senior School & 6th Form (Years 9-13):", "11,750", "term", T, "", F, "one fee Years 9-13; non-optional lunch £325/term extra"),
    ("123282", Y26, "123282_2026.html", "sixth_form", "Y12-13", "day", "Senior School & 6th Form (Years 9-13):", "11,750", "term", T, "", F, "one fee Years 9-13"),
    ("123282", Y26, "123282_2026.html", "senior", "Y9-11", "boarding", "Senior School & 6th Form (Years 9-13):", "18,470", "term", T, "", F, "'Full Boarding & Tuition'; lunch charge £325/term applies to every bill"),
    ("123282", Y26, "123282_2026.html", "sixth_form", "Y12-13", "boarding", "Senior School & 6th Form (Years 9-13):", "18,470", "term", T, "", F, ""),
    # --- Oswestry School (the dated fee sheet; the fees web page carries no year)
    ("123613", Y26, "123613_2026_pdf.pdf", "senior_lower", "Y7-8", "day", "Forms 1 and 2", "7,222", "term", T, "", T, "gross incl. school lunch £430 (VAT-exempt)"),
    ("123613", Y26, "123613_2026_pdf.pdf", "senior", "Y9-11", "day", "Forms 3 to 5", "7,654", "term", T, "", T, "gross = net £6,020 + lunch £430 (VAT-exempt) + VAT £1,204; the undated fees web page shows the same day and full-boarding figures (its weekly-boarding figures differ from this sheet)"),
    ("123613", Y26, "123613_2026_pdf.pdf", "sixth_form", "Y12-13", "day", "Form 6", "7,654", "term", T, "", T, ""),
    ("123613", Y26, "123613_2026_pdf.pdf", "senior", "Y9-11", "boarding", "Termly full boarding", "15,554", "term", T, "", T, "Forms 3 to 5; includes breakfast, lunch and supper"),
    ("123613", Y26, "123613_2026_pdf.pdf", "sixth_form", "Y12-13", "boarding", "Termly full boarding", "15,602", "term", T, "", T, "Form 6"),
    # --- Wycliffe College (Years 7-8 in the Prep School; senior fees vary by year group)
    ("115788", Y26, "115788_2026.html", "senior_lower", "Y7-8", "day", "Year 7", "8,340", "term", T, "", T, "Years 7-8 are in the Prep School; day fee includes lunch"),
    ("115788", Y26, "115788_2026.html", "senior", "Y9", "day", "Year 9", "10,584", "term", T, "", T, "day fee all-inclusive, with lunch"),
    ("115788", Y26, "115788_2026.html", "senior", "Y10-11", "day", "Year 10", "10,956", "term", T, "", T, ""),
    ("115788", Y26, "115788_2026.html", "sixth_form", "Y12-13", "day", "Year 12", "10,956", "term", T, "", T, ""),
    ("115788", Y26, "115788_2026.html", "senior", "Y9", "boarding", "Year 9", "18,600", "term", T, "", T, ""),
    ("115788", Y26, "115788_2026.html", "senior", "Y10-11", "boarding", "Year 10", "19,260", "term", T, "", T, ""),
    ("115788", Y26, "115788_2026.html", "sixth_form", "Y12-13", "boarding", "Year 12", "19,260", "term", T, "", T, ""),
    # --- King's School, Rochester (Years 7-8 in the Preparatory School)
    ("118948", Y26, "118948_2026.html", "senior_lower", "Y7-8", "day", "11+ Year 7", "7,785", "term", T, "", T, "Years 7-8 are in the Preparatory School; includes lunch 5 days a week"),
    ("118948", Y26, "118948_2026.html", "senior", "Y9-11", "day", "13+ Year 9 (Remove)", "10,265", "term", T, "", F, "senior lunches £1,287/yr extra (£504/£418/£365 by term)"),
    ("118948", Y26, "118948_2026.html", "sixth_form", "Y12-13", "day", "16+ Year 12 (Lower Sixth)", "10,370", "term", T, "", F, ""),
    ("118948", Y26, "118948_2026.html", "senior", "Y9-11", "boarding", "Remove to Upper Fifth (Year 9 – Year 11)", "17,070", "term", T, "", U, "one 'Full & Weekly Boarding' fee"),
    ("118948", Y26, "118948_2026.html", "sixth_form", "Y12-13", "boarding", "Lower Sixth to Upper Sixth (Year 12 – Year 13)", "17,174", "term", T, "", U, ""),
    # --- Abbey Gate College
    ("111484", Y26, "111484_2026.html", "senior", "Y7-11", "day", "Senior School and Sixth Form (Year 7 – Year 13):", "6,907", "term", T, "", F, "one fee Years 7-13; compulsory lunch £382/term extra"),
    ("111484", Y26, "111484_2026.html", "sixth_form", "Y12-13", "day", "Senior School and Sixth Form (Year 7 – Year 13):", "6,907", "term", T, "", F, "one fee Years 7-13"),
    # --- Claires Court Schools (new scale from January 2027: annual = sum of the three termly fees)
    ("110153", Y26, "110153_2026.html", "senior", "Y7-11", "day", "Years 7,8,9,10,11", "8,355+8,685+8,685", "year", T, "", F, "Autumn 2026 + Spring 2027 + Summer 2027; food not included"),
    ("110153", Y26, "110153_2026.html", "sixth_form", "Y12-13", "day", "Sixth Form", "8,700+9,045+9,045", "year", T, "", F, "Autumn 2026 + Spring 2027 + Summer 2027"),
    # --- Sidcot School (replaced St Lawrence in the list; fee sheet 'FEES 2026/2027' linked from the fees page)
    ("109362", Y26, "109362_2026_pdf.pdf", "senior", "Y7-9", "day", "Senior School Day fees", "8,422", "term", T, "", T, "fees include lunch (£252/term, invoiced separately on the extras invoice)"),
    ("109362", Y26, "109362_2026_pdf.pdf", "senior", "Y10-11", "day", "Year 10 to Year 11", "8,732", "term", T, "", T, ""),
    ("109362", Y26, "109362_2026_pdf.pdf", "sixth_form", "Y12-13", "day", "Sixth Form Day fees", "9,262", "term", T, "", T, "pupils who took the two-year GCSE course at Sidcot pay the Year 10-11 rate (£8,732)"),
    ("109362", Y26, "109362_2026_pdf.pdf", "senior", "Y7-9", "boarding", "Year 7 to Year 9 UK/Non Visa Students", "14,642", "term", T, "", T, "UK/non-visa students; child-visa students £15,052"),
    ("109362", Y26, "109362_2026_pdf.pdf", "senior", "Y10-11", "boarding", "Year 10 to Year 11 UK/Non Visa Students", "15,912", "term", T, "", T, "UK/non-visa students; child-visa students £16,322"),
    ("109362", Y26, "109362_2026_pdf.pdf", "sixth_form", "Y12-13", "boarding", "Year 12 & Year 13 UK/Non Visa Students", "17,512", "term", T, "", T, "UK/non-visa students (loyalty rate £15,912); child-visa students £17,932"),
]
ROWS.extend(BOTTOM20_ROWS)

# Rows whose incl.-VAT amount is read from an image on the page: only the excl.-VAT figure is text-checked, and
# the amount must equal it x 1.2 exactly.
IMAGE_AMOUNT = {("101071", Y26)}

# School-years with no saved page carrying the fee figures (status, url checked, why)
MISSING = [
    ("101071", Y25, "no_snapshot", "https://www.emanuel.org.uk/admissions/fees/",
     "only in-window captures are 2026-07-16/20 (fees_cdx/emanuel.org.uk.json); the 07-16 capture was fetched and shows 2026/27 fees"),
    ("100003", Y25, "no_snapshot", "https://www.cityoflondonschool.org.uk/admissions/fees/",
     "only in-window captures are 2026-07-16/20 (2026/27 fees); 2025-11-05 capture is HTTP 202 (bot check)"),
    ("100001", Y25, "no_snapshot", "https://clsg.org.uk/admissions/fees/",
     "only in-window captures are 2026-07-16/20 (2026/27 fees)"),
    ("125342", Y25, "no_snapshot", "https://www.guildfordhigh.co.uk/admissions/fees/",
     "only in-window capture is 2026-07-20 (2026/27 fees)"),
    ("100370", Y25, "no_snapshot", "https://www.latymer-upper.org/admissions/fees/",
     "only in-window capture is 2026-07-20 (2026/27 fees)"),
    ("102684", Y25, "no_snapshot", "https://www.kcs.org.uk/content/fees-finance",
     "JavaScript site; its fee content endpoint (?method=url&path=/admissions/fees) was first captured 2026-07-20 (fees_cdx/kcs.org.uk_content_api.json)"),
    ("117617", Y25, "no_snapshot", "https://www.stahs.org.uk/wp-content/uploads/2025/06/Schedule-of-Fees-2025-26-1.pdf",
     "2025/26 fee page captured (2026-01-22) but the fees are in the linked schedule PDF, which the Wayback Machine does not hold (fees_cdx/stahs_schedule_2025-26_pdf.json is empty)"),
    ("101161", Y25, "no_snapshot", "https://www.fhs-sw1.org.uk/admissions/fees/",
     "captures 2025-10-14 and 2026-02-11 show the 2025/26 page, but the fee table loads by AJAX and the endpoint has no usable capture before 2026-07-20 (fees_cdx/fhs-sw1.org.uk_admin-ajax.json); the 2025-26 Information Book PDF is not archived either"),
    # bottom 20 (2026/27 only)
    ("146999", Y26, "not_published", "https://camphilleducation.co.uk/",
     "no fees page or fee figure on the site (homepage saved as 146999_2026.html); the homepage says most places are referred by the Local Authority Exclusions Team or SENAR"),
    ("101685", Y26, "blocked", "https://www.farringtons.org.uk/admissions/fees-bursaries-scholarships/",
     "HTTP 403 to the project's script on 2026-10-10 (two runs of three attempts); not fetched by other means"),
    ("118947", Y26, "not_published", "https://www.slcuk.com/admissions/school-fees/",
     "the live page (118947_2026.html) still shows 'Fees, Charges & Admissions for The Academic Year 2025/2026' (Years 9-11 day £8,838/term); GIAS (extract 2026-10-10) records the school as closed on 31-08-2026"),
    ("113912", Y26, "not_published", "https://www.clayesmore.com/admissions/senior/fees",
     "the senior and sixth-form fee URLs both serve /admissions/fees/ (113912_2026.html, 113912_2026_sixth.html), which prints a fee table with no academic year (Years 9-13 day £11,890.80/term, boarding £16,503.60) and links no dated schedule; 2026/27 fees not stated"),
]

# Senior entry points evidenced on the saved fee/admissions pages (links or text); '' = not evidenced
ENTRY = {
    "100366": "11+;16+", "102942": "11+ (prep);13+;16+", "101162": "11+ (Under School);13+;16+",
    "102257": "11+;16+", "114614": "", "102684": "11+;13+;16+", "125342": "11+;16+", "100369": "11+;16+",
    "100001": "11+;16+", "102692": "11+;16+", "123623": "Form 3;Form 4;16+", "123311": "11+;13+;16+",
    "110923": "11+;13+;16+", "100370": "11+;16+", "103585": "11+;16+", "102163": "11+;16+",
    "110547": "11+;13+;16+", "100864": "11+;16+", "100076": "11+;16+", "102932": "11+;16+",
    "100003": "10+;11+;16+", "117648": "11+;13+;16+", "101072": "11+;16+", "105595": "11+;16+",
    "117649": "11+;16+", "110158": "13+;16+", "100863": "11+;16+", "125424": "11+;16+", "102619": "11+;16+",
    "102875": "11+;16+", "118959": "13+;14+;16+", "102946": "11+;13+;16+", "101842": "10+;11+;13+;16+",
    "116532": "13+;16+", "125422": "11+;13+;16+", "118952": "11+;13+;16+", "110120": "11+;13+;16+",
    "105591": "11+;16+", "117617": "11+;16+", "117616": "11+;16+", "100065": "11+;16+",
    "123312": "11+;13+;16+", "122915": "", "101161": "11+;16+", "116534": "11+;13+;16+",
    "101071": "10+;11+;16+",
}
ENTRY.update({urn: "" for urn in {r[0] for r in BOTTOM20_ROWS} | {"146999", "101685", "118947", "113912"}})  # not collected

PERIODS = {"term": 3, "year": 1}
COLS = ["urn", "name", "fee_year", "stage", "day_or_boarding", "amount", "period", "incl_vat", "annual_incl_vat",
        "lunch_included", "source_url", "snapshot_date", "status", "years", "stage_label", "amount_excl_vat",
        "vat_basis", "entry_ages", "local_path", "note"]


def manifest():
    with (ROOT / "data" / "manifest" / "fees.csv").open(encoding="utf-8") as f:
        return {r["local_path"]: r for r in csv.DictReader(f)}


def money(s: str) -> float:
    return round(sum(float(p.replace(",", "")) for p in s.split("+")), 2)


def main():
    top = pd.read_csv(DERIVED / "top30_independent.csv", dtype={"urn": str})
    bottom = pd.read_csv(DERIVED / "bottom20_private.csv", dtype={"urn": str})
    names = dict(zip(top.urn, top.name)) | dict(zip(bottom.urn, bottom.name))
    man = manifest()
    texts, out, errors = {}, [], []
    dropped = sorted({r[0] for r in ROWS + MISSING} - set(names))
    if dropped:
        print(f"transcribed but not in top30_independent.csv or bottom20_private.csv (left out): {dropped}")
    for (urn, fy, fname, stage, years, mode, label, amount, period, incl, excl, lunch, note) in ROWS:
        if urn not in names:
            continue
        path = FEES_DIR / fname
        rel = f"data/raw/fees/{DAY}/{fname}"
        if rel not in man:
            errors.append(f"{urn} {fname}: not in manifest")
            continue
        text = texts.setdefault(fname, page_text(path))
        parts = amount.split("+") + (excl.split("+") if excl else [])
        if (urn, fy) in IMAGE_AMOUNT:
            parts = excl.split("+")
            if money(amount) != round(money(excl) * 1.2, 2):
                errors.append(f"{urn} {fy}: image amount {amount} != {excl} x 1.2")
        for part in parts:
            ok, info = near(text, label, part)
            if not ok:
                errors.append(f"{urn} {fy} {stage} {mode}: '{part}' not near '{label}' in {fname} ({info})")
        url = man[rel]["url"]
        wb = "web.archive.org/web/" in url
        snap = (dt.datetime.strptime(url.split("/web/")[1][:8], "%Y%m%d").date().isoformat() if wb
                else man[rel]["retrieved_utc"][:10])
        amt = money(amount)
        if incl is None:
            basis = "not stated on page; annual_incl_vat assumes the stated fee is the VAT-inclusive price"
        elif incl:
            basis = "stated incl. VAT" + (" (page also gives excl. VAT)" if excl else "")
        else:
            basis = "stated excl. VAT; annual_incl_vat adds 20%"
        annual = amt * PERIODS[period] * (1.2 if incl is False else 1)
        out.append({
            "urn": urn, "name": names[urn], "fee_year": fy, "stage": stage, "day_or_boarding": mode,
            "amount": amt, "period": period, "incl_vat": "" if incl is None else incl,
            "annual_incl_vat": round(annual, 2), "lunch_included": "" if lunch is None else lunch,
            "source_url": url, "snapshot_date": snap, "status": "confirmed", "years": years,
            "stage_label": label, "amount_excl_vat": money(excl) if excl else "", "vat_basis": basis,
            "entry_ages": ENTRY[urn], "local_path": rel, "note": note})
    for urn, fy, status, url, note in MISSING:
        if urn not in names:       # e.g. St Lawrence, dropped from bottom20_private.csv as closed
            continue
        out.append({"urn": urn, "name": names[urn], "fee_year": fy, "status": status, "source_url": url,
                    "entry_ages": ENTRY[urn], "note": note})
    if errors:
        print("\n".join(errors))
        raise SystemExit(f"{len(errors)} transcription checks failed")
    df = pd.DataFrame(out, columns=COLS)
    assert set(df.urn) == set(names), set(names) - set(df.urn)
    assert_unique(df[df.status == "confirmed"], ["urn", "fee_year", "stage", "years", "day_or_boarding"], "fees")
    # every school has a row (confirmed or a gap status): top 30 for both years, bottom 20 for 2026/27 only
    for fy, want in ((Y26, set(names)), (Y25, set(top.urn))):
        assert set(df[df.fee_year == fy].urn) == want, (fy, want ^ set(df[df.fee_year == fy].urn))
    df = df.sort_values(["urn", "fee_year", "day_or_boarding", "stage", "years"]).reset_index(drop=True)
    write_derived(df, "independent_fees")


if __name__ == "__main__":
    main()
