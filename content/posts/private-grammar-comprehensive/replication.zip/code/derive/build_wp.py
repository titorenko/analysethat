"""Build data/derived/wp_school_type.csv from the Widening Participation 'School Type' file (2024/25 release).

One row per cohort x entry age x A-level status x school type (school type = institution attended at age 17).

Usage: .venv/Scripts/python -I code/derive/build_wp.py
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
from common import latest_raw, read_ees, num, assert_unique, check_mapped, write_derived  # noqa: E402

AGES = {f"By Age {a}": a for a in (18, 19, 20, 25, 30)}
STATUS = {"ALevel": "a_level", "Total": "all_ks5"}
TYPES = {"Independent": "independent", "Selective State": "selective_state", "Other State": "other_state",
         "Total": "total"}


def main():
    df = read_ees(latest_raw("dfe_wp", "wp_school_type.csv"))
    check_mapped(df.entry_age, AGES, "entry_age")
    check_mapped(df.a_level_status, STATUS, "a_level_status")
    check_mapped(df.establishment_type, TYPES, "establishment_type")
    out = pd.DataFrame({
        "cohort_age15": df.time_period.str[:4] + "/" + df.time_period.str[4:],
        "by_age": df.entry_age.map(AGES),
        "student_group": df.a_level_status.map(STATUS),
        "school_type_at_17": df.establishment_type.map(TYPES),
        "he_rate": num(df.participation_rate),
        "high_tariff_rate": num(df.high_tariff_participation_rate),
        "he_students": num(df.number_of_he_students).astype("Int64"),
        "high_tariff_students": num(df.number_of_high_tariff_he_students).astype("Int64"),
        "cohort_students": num(df.number_of_students).astype("Int64"),
    })
    assert_unique(out, ["cohort_age15", "by_age", "student_group", "school_type_at_17"], "wp")
    write_derived(out, "wp_school_type")


if __name__ == "__main__":
    main()
