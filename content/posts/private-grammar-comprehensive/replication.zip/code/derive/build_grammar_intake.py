"""Build data/derived/grammar_intake.csv (long format) and data/derived/grammar_super_selective.csv for the 45
grammars in data/derived/top30_grammar.csv.

Usage: .venv/Scripts/python -I code/derive/build_grammar_intake.py

Inputs: files fetched by code/harvest/grammar_intake.py (data/raw/grammar_intake/<day>/) and
code/harvest/dfe_apps_offers.py. Rows come from four kinds of evidence:
1. CURATED (grammar_intake_curated.py): one line per value read from a downloaded file, each carrying a short
   verbatim snippet. The build FAILS unless the snippet occurs in the file's extracted text (whitespace and
   quote-normalised) and a numeric value occurs inside its snippet. Lines with status blocked / not_published /
   pending_foi / secondary_source carry the URL that was checked.
2. Parsers for structured files: KEF results tables (HTML), CSSE all-candidate score CSV/XLSX, KCC Kent Test
   score reports (XLSX), CCHS anonymised score lists (PDF), DfE applications and offers (school-level CSV).
3. Derived rows: testers_per_place = testers / places, from rows of the same school and entry year.
4. The super-selective flag (scouting C 4d, intake side only), citing row ids.
entry_year = calendar year of September Year 7 entry (a CSSE sheet "for 2026 entry" holds Sept 2025 entry
cut-offs; DfE time_period 202627 = Sept 2026 entry; the Kent Test sat in Sept 2025 is for Sept 2026 entry).
"""
import re
import sys
import pathlib
import zipfile

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
sys.path.insert(1, str(pathlib.Path(__file__).resolve().parents[1] / "harvest"))
from common import RAW, DERIVED, rel, write_derived  # noqa: E402
from extract_text import text_of, norm, tables_of  # noqa: E402
from grammar_intake import SOURCES  # noqa: E402  (harvest list: id, url, filename, note)
from grammar_intake_curated import CURATED, FLAG_OVERRIDES, MODEL_NOTES  # noqa: E402

import pandas as pd  # noqa: E402

SRC = {sid: (url, fn) for sid, url, fn, _ in SOURCES}
STATUSES = {"confirmed", "secondary_source", "not_published", "pending_foi", "blocked"}
TOP = pd.read_csv(DERIVED / "top30_grammar.csv", dtype=str).set_index("urn")["name"].to_dict()
COLS = ["row_id", "urn", "name", "entry_year", "measure", "category", "offer_round", "value", "unit", "source_url",
        "source_file", "source_location", "status", "note"]
DFE_ZIP_URL = ("https://content.explore-education-statistics.service.gov.uk/api/releases/"
               "0bf4f9cf-721d-44e3-8473-266c87e17e00/files")
DFE_MEMBER = "supporting-files/AppsandOffers_2026_SchoolLevel29062026.csv"

rows = []
_text_cache = {}


def src_file(sid):
    if sid not in SRC:
        return None
    hits = sorted((RAW / "grammar_intake").glob(f"*/{SRC[sid][1]}"))
    return hits[-1] if hits else None


def text(sid):
    if sid not in _text_cache:
        p = src_file(sid)
        _text_cache[sid] = norm(text_of(p)) if p else None
    return _text_cache[sid]


def add(urn, year, measure, category, value, unit, sid, location, status, offer_round="", note="", url=None,
        name=None):
    assert status in STATUSES, status
    p = src_file(sid) if sid else None
    rows.append({
        "urn": urn, "name": name or TOP.get(urn, ""), "entry_year": year, "measure": measure, "category": category,
        "offer_round": offer_round, "value": value, "unit": unit,
        "source_url": url if url is not None else (SRC[sid][0] if sid in SRC else ""),
        "source_file": rel(p) if p else "", "source_location": location, "status": status, "note": note})
    return rows[-1]


# ---------------------------------------------------------------- 1. curated, snippet-verified
def load_curated():
    bad = []
    for ln in CURATED.strip().splitlines():
        ln = ln.strip()
        if not ln or ln.startswith("#"):
            continue
        f = [x.strip() for x in ln.split("|")]
        if len(f) != 13:
            raise ValueError(f"curated line needs 13 fields, has {len(f)}: {ln}")
        urn, year, measure, cat, rnd, value, unit, sid, loc, snippet, status, note, name = f
        if urn and urn not in TOP:
            raise ValueError(f"urn {urn} not in top30_grammar: {ln}")
        if sid and sid not in SRC and not sid.startswith(("http", "mailto:")):
            raise ValueError(f"unknown source id {sid}: {ln}")
        if measure == "distribution_file":
            fp = src_file(sid)
            if not fp:
                bad.append(f"no file for {sid}: {ln}")
                continue
            value = rel(fp)
        elif snippet:
            t = text(sid)
            if t is None:
                bad.append(f"no file for {sid}: {ln}")
                continue
            if norm(snippet) not in t:
                bad.append(f"snippet not in {sid}: '{snippet}'")
                continue
            v = value.replace(",", "")
            if re.fullmatch(r"[\d.\-]+", v) and v not in snippet.replace(",", ""):
                bad.append(f"value {value} not inside its snippet '{snippet}'")
                continue
            loc = f"{loc}; text: \"{snippet}\"" if loc else f"text: \"{snippet}\""
        elif status == "confirmed":
            bad.append(f"confirmed row without snippet: {ln}")
            continue
        if unit == "miles":
            loc += f"; converted from {value} miles"
            value, unit = round(float(value) * 1.609344, 1), "km"
        url = sid if sid.startswith(("http", "mailto:")) else None
        add(urn, int(year) if year else "", measure, cat, value, unit, None if url else sid, loc, status, rnd,
            note, url=url, name=name or None)
    if bad:
        raise SystemExit("curated rows failed verification:\n  " + "\n  ".join(bad))


# ---------------------------------------------------------------- 2a. KEF results-and-offers tables
KEF_URN = {"Bishop Vesey": "137988", "Camp Hill School for Boys": "137045", "Camp Hill School for Girls": "137044",
           "Five Ways": "137046", "Sutton Coldfield Grammar School for Girls": "136778"}


def kef_category(desc):
    d = desc.lower()
    if "looked after" in d:
        return "looked_after"
    if "pupil premium" in d:
        if "outside the catchment" in d:
            return "pupil_premium_outside_catchment"
        if "within the catchment" in d:
            return "pupil_premium_inside_catchment"
        return "pupil_premium"
    if "224 and above" in d and "within the catchment" in d:
        return "priority_score_inside_catchment"
    if "all other applicants" in d:
        return "all_others"
    raise ValueError(desc)


def kef_cell(cell):
    """-> [(offer_round, measure, value, unit)] for one table cell."""
    c = cell.replace("*", "").strip().rstrip(".").strip()
    m = re.fullmatch(r"(\d{3}) \((\d{3})\)", c)
    if m:
        return [("national_offer_day", "lowest_score_offered", m[1], "score"),
                ("september", "lowest_score_offered", m[2], "score")]
    m = re.fullmatch(r"(\d{3}) \(All offered(?: by September)?\)", c)
    if m:
        return [("national_offer_day", "lowest_score_offered", m[1], "score"),
                ("september", "lowest_score_offered", "all_offered", "code")]
    if c == "All offered":
        return [("national_offer_day", "lowest_score_offered", "all_offered", "code")]
    if re.fullmatch(r"No offers (made )?from this category( in March or by September)?", c):
        return [("national_offer_day", "lowest_score_offered", "no_offers", "code")]
    m = re.fullmatch(r"No offers (?:made from this category )?in March \((\d{3}) by September\)", c)
    if m:
        return [("national_offer_day", "lowest_score_offered", "no_offers", "code"),
                ("september", "lowest_score_offered", m[1], "score")]
    m = re.fullmatch(r"No offers made from this category in March\. \(All offered by September\)", cell.strip())
    if m:
        return [("national_offer_day", "lowest_score_offered", "no_offers", "code"),
                ("september", "lowest_score_offered", "all_offered", "code")]
    m = re.fullmatch(r"(\d{4}) metres(?: in March)? \((\d{4}) metres\)", c)
    if m:
        return [("national_offer_day", "last_distance_offered", m[1], "metres"),
                ("september", "last_distance_offered", m[2], "metres")]
    m = re.fullmatch(r"(\d{4}) metres(?: in March)? \(All offered by September\)", c)
    if m:
        return [("national_offer_day", "last_distance_offered", m[1], "metres"),
                ("september", "last_distance_offered", "all_offered", "code")]
    raise ValueError(f"unparsed KEF cell: {cell!r}")


def parse_kef():
    p = src_file("kef_results")
    n = 0
    for t in tables_of(p):
        urn = next((u for k, u in KEF_URN.items() if k in t["heading"]), None)
        if not urn:
            continue
        years = [int(re.match(r"(\d{4}) entry", h)[1]) for h in t["rows"][0][1:]]
        for r in t["rows"][1:]:
            cat = kef_category(r[0])
            for year, cell in zip(years, r[1:]):
                for rnd, measure, value, unit in kef_cell(cell):
                    add(urn, year, measure, cat, value, unit, "kef_results",
                        f"table '{t['heading']}', row '{r[0][:60]}', column '{year} entry', cell '{cell}'",
                        "confirmed", rnd, "Birmingham test: qualifying score 205; priority score 224 (2027 entry)")
                    n += 1
    print(f"KEF tables: {n} rows")


# ---------------------------------------------------------------- 2b. CSSE all-candidate standardised scores
CSSE = "CSSE (Consortium of Selective Schools in Essex)"


def csse_scores(sid):
    """{entry_year: DataFrame(sex, score, sitting)} from a CSSE standardised-score CSV/XLSX (side-by-side
    Gender/Total column pairs, one pair per test date)."""
    p = src_file(sid)
    if p.suffix == ".csv":
        sheets = {None: pd.read_csv(p, header=None, dtype=str, keep_default_na=False, encoding="utf-8-sig",
                                    encoding_errors="replace")}
    else:
        sheets = pd.read_excel(p, sheet_name=None, header=None, dtype=str).items()
        sheets = {k: v.fillna("") for k, v in sheets}
    out = {}
    for sheet, df in sheets.items():
        hdr = next(i for i in range(len(df)) if "Gender" in df.iloc[i].tolist())
        gcols = [j for j, v in enumerate(df.iloc[hdr]) if v == "Gender"]
        recs = []
        for k, j in enumerate(gcols):
            sub = df.iloc[hdr + 1:, [j, j + 1]]
            sub.columns = ["sex", "score"]
            sub = sub[sub.sex.isin(["M", "F"])].copy()
            sub["score"] = pd.to_numeric(sub.score)
            sub["sitting"] = k + 1
            recs.append(sub)
        d = pd.concat(recs)
        assert d.score.notna().all()
        year = int(re.search(r"20\d\d", sheet)[0]) if sheet else int(re.search(r"(20\d\d)_entry", SRC[sid][1])[1])
        out[year] = (d, sheet)
    return out


def parse_csse():
    for sid in ("csse_std_scores_2019_2024", "csse_std_scores_2025", "csse_std_scores_2026"):
        for year, (d, sheet) in sorted(csse_scores(sid).items()):
            if year < 2023:
                continue
            loc = f"sheet '{sheet}'" if sheet else "csv"
            for sex, cat in ((None, "all"), ("M", "boys"), ("F", "girls")):
                sub = d if sex is None else d[d.sex == sex]
                add("", year, "testers_stage1", cat, len(sub), "candidates", sid,
                    f"{loc}: count of candidate rows with a standardised total"
                    + ("" if sex is None else f", Gender = {sex}"), "confirmed", name=CSSE,
                    note=f"all test sittings ({d.sitting.max()}) combined; one row per candidate")
                add("", year, "candidates_scoring_303_plus", cat, int((sub.score >= 303).sum()), "candidates", sid,
                    f"{loc}: count of standardised total >= 303" + ("" if sex is None else f", Gender = {sex}"),
                    "confirmed", name=CSSE, note="303 = CSSE minimum total for any offer (guidance sheets)")
    print("CSSE score files parsed")


# ---------------------------------------------------------------- 2c. Kent Test score reports
KENT = "Kent Test (Kent County Council)"


def parse_kent():
    for sid, test_year in (("kent_scores_2022_wb", 2022), ("kent_scores_2023_wb", 2023), ("kent_scores_2024_wb", 2024)):
        p = src_file(sid)
        tot = {}
        for sheet, df in pd.read_excel(p, sheet_name=None, header=None, dtype=str).items():
            df = df.fillna("")
            last = df[df.iloc[:, 0].str.strip() == "Total"].iloc[-1]
            tot[sheet] = int(float(last.iloc[-1]))
        g = [s for s in tot if "grammar" in s.lower()]
        h = [s for s in tot if "high" in s.lower()]
        assert len(g) == 1 and len(h) == 1, tot
        loc = f"sheets '{g[0]}' and '{h[0]}', final 'Total' row, last column"
        note = f"Kent Test sat Sept {test_year}; Wayback copy of the KCC file (kent.gov.uk refuses scripts)"
        add("", test_year + 1, "testers_stage1", "all", tot[g[0]] + tot[h[0]], "candidates", sid, loc,
            "confirmed", name=KENT, note=note + "; assessed grammar + assessed high school")
        add("", test_year + 1, "candidates_assessed_grammar", "all", tot[g[0]], "candidates", sid,
            f"sheet '{g[0]}', final 'Total' row, last column", "confirmed", name=KENT, note=note)
        add("", test_year + 1, "distribution_file", "all", rel(p), "file", sid,
            "candidate counts by total score (207-423) x school category x sex", "confirmed", name=KENT, note=note)
    print("Kent score reports parsed")


# ---------------------------------------------------------------- 2d. CCHS anonymised score lists (all candidates)
def parse_cchs():
    for sid, year in (("cchs_results_2025", 2025), ("cchs_scores_2026", 2026)):
        t = text_of(src_file(sid))
        recs = re.findall(r"^(Yes|No) (\d{2,3}\.\d{2}) ", t, flags=re.M)
        n_in = sum(1 for a, _ in recs if a == "Yes")
        add("136412", year, "testers_stage1", "all", len(recs), "candidates", sid,
            "count of score lines ('Yes|No <score> ...') in the anonymised list", "confirmed",
            note="list includes 'Not Marked' (creative writing not marked) and 'Not of the Standard' candidates")
        add("136412", year, "testers_stage1", "inside_priority_area", n_in, "candidates", sid,
            "count of score lines flagged 'Yes' (within the 12.5 mile priority area)", "confirmed")
        add("136412", year, "distribution_file", "all", rel(src_file(sid)), "file", sid,
            "every candidate's total standardised score, priority-area flag and creative-writing standard",
            "confirmed")
    print("CCHS anonymised lists parsed")


# ---------------------------------------------------------------- 2e. DfE applications and offers (2023-2026 entry)
DFE_MEASURES = {"times_put_as_any_preferred_school": "dfe_preferences_total",
                "times_put_as_1st_preference": "dfe_preferences_1st",
                "times_put_as_2nd_preference": "dfe_preferences_2nd",
                "times_put_as_3rd_preference": "dfe_preferences_3rd",
                "total_number_places_offered": "dfe_offers_total",
                "number_1st_preference_offers": "dfe_offers_1st_pref"}


def parse_dfe():
    zp = sorted((RAW / "dfe_apps_offers").glob("*/apps_offers_2026-27_all_files.zip"))[-1]
    with zipfile.ZipFile(zp) as z, z.open(DFE_MEMBER) as f:
        d = pd.read_csv(f, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    d = d[(d.school_phase == "Secondary") & d.time_period.isin(["202324", "202425", "202526", "202627"])]
    d = d[d.school_urn.isin(TOP)]
    for _, r in d.iterrows():
        year = int(r.time_period[:4])
        loc = f"{DFE_MEMBER}: time_period={r.time_period}, school_laestab={r.school_laestab}"
        cat = "boarding_places" if "boarding" in r.school_name.lower() else "all"   # RGS High Wycombe 2023-24
        for col, measure in DFE_MEASURES.items():
            rows.append({"urn": r.school_urn, "name": TOP[r.school_urn], "entry_year": year, "measure": measure,
                         "category": cat, "offer_round": "national_offer_day", "value": int(r[col]),
                         "unit": "count", "source_url": DFE_ZIP_URL, "source_file": rel(zp),
                         "source_location": f"{loc}, column {col}", "status": "confirmed",
                         "note": "LA coordinated preferences, not test-takers (grammar non-qualifiers may or may not "
                                 "list the school)"})
        rows.append({"urn": r.school_urn, "name": TOP[r.school_urn], "entry_year": year,
                     "measure": "dfe_preferences_per_offer", "category": cat, "offer_round": "national_offer_day",
                     "value": round(int(r.times_put_as_any_preferred_school) / int(r.total_number_places_offered), 2),
                     "unit": "ratio", "source_url": DFE_ZIP_URL, "source_file": rel(zp),
                     "source_location": f"{loc}: times_put_as_any_preferred_school / total_number_places_offered",
                     "status": "confirmed", "note": "crude oversubscription measure"})
    missing = sorted(set(TOP) - set(d[d.time_period == "202627"].school_urn))
    assert not missing, f"no DfE 2026/27 row for {missing}"
    print(f"DfE rows for {d.school_urn.nunique()} schools")
    return d


# ---------------------------------------------------------------- 2f. more structured files
BUCKS = "Buckinghamshire Secondary Transfer Test (TBGS)"
WARKS = "Warwickshire 11+ (West Midlands grammar schools test)"
SLOUGH = "Slough Consortium 11+ (Herschel, Langley, St Bernard's, Upton Court)"
BUCKS_URN = {"Chesham Grammar School": "137091", "Dr Challoner's Grammar School": "136419",
             "Dr Challoner's High School": "137219", "The Royal Grammar School": "136484",
             "The Royal Latin School": "137344", "Sir William Borlase": "136781"}


def parse_bucks():
    """Bucks allocation profiles: one sentence per school naming the last rule reached and its distance."""
    for year in (2023, 2024, 2025, 2026):
        sid = f"bucks_alloc_{year}"
        df = pd.read_excel(src_file(sid), header=None, dtype=str).fillna("")
        found = set()
        for _, r in df.iterrows():
            name = " ".join(str(r.iloc[0]).split())
            urn = next((u for k, u in BUCKS_URN.items() if name.startswith(k)), None)
            if not urn or urn in found:
                continue
            found.add(urn)
            txt = " ".join(str(r.iloc[1]).split())
            m = re.search(r"some allocated under [Rr]ule [\d{}]+ \(([^)]*)\)[^.]*?to (?:a distance of )?([\d.]+) miles",
                          txt)
            loc = f"Sheet1, row '{name}', allocation statement"
            add(urn, year, "admissions_model", "all", "qualify_then_distance", "code", sid,
                loc + f": '{txt[:150]}...'", "confirmed",
                note="qualifying score 121, then LAC / pupil premium / siblings / catchment / distance rules")
            if m:
                add(urn, year, "last_distance_offered", m[1].strip().lower(), m[2], "miles", sid,
                    loc + f": '... ({m[1]}) ... to {m[2]} miles'", "confirmed", "national_offer_day")
            add(urn, year, "test_used", "all", BUCKS, "text", sid, loc, "confirmed")
        assert found == set(BUCKS_URN.values()), (year, set(BUCKS_URN.values()) - found)
    print("Bucks allocation profiles parsed")


def parse_warks():
    """Warwickshire 11+ score rankings: one row per on-time candidate (sheets All / Male / Female)."""
    for year in (2023, 2024, 2025, 2026):
        sid = f"warks_ranking_{year}"
        sheets = pd.read_excel(src_file(sid), sheet_name=None, header=None, dtype=str)
        for key, cat in (("all", "all"), ("female", "girls"), ("male", "boys")):
            name = next(k for k in sheets if key in k.lower() and "month" not in k.lower()
                        and not (key == "male" and "female" in k.lower()))
            d = sheets[name].fillna("")
            n = int(d.iloc[:, 0].str.strip().isin(["M", "F"]).sum())
            add("", year, "testers_stage1", cat, n, "candidates", sid,
                f"sheet '{name}': count of candidate rows (Gender M/F)", "confirmed", name=WARKS,
                note="on-time candidates tested by Warwickshire; committee minutes give 2258 (2025) and 2398 (2026)")
        add("", year, "distribution_file", "all", rel(src_file(sid)), "file", sid,
            "every on-time candidate's total score and rank, by sex", "confirmed", name=WARKS)
    print("Warwickshire rankings parsed")


def parse_slough():
    for sid, year in (("lgs_scores_2024test", 2025), ("lgs_scores_2025test", 2026)):
        t = text_of(src_file(sid))
        n = len(re.findall(r"Redacted Redacted Redacted Redacted (\d{2,3})\b", t))
        add("", year, "testers_stage1", "all", n, "candidates", sid,
            "count of candidate lines 'Redacted x4 <standardised score>'", "confirmed", name=SLOUGH,
            note=f"test sat Sept {year - 1}")
        add("", year, "distribution_file", "all", rel(src_file(sid)), "file", sid,
            "every candidate's standardised score (names redacted)", "confirmed", name=SLOUGH)
    print("Slough score lists parsed")


def parse_colyton():
    sid = "colyton_scores_2025"
    n = len(re.findall(r"U-[A-Z0-9]+ \d{2,3}\.\d{2}", text_of(src_file(sid))))
    add("136366", 2025, "testers_stage1", "all", n, "candidates", sid,
        "count of 'U-xxxx <score>' entries (three per line)", "confirmed",
        note="includes in-year candidates, so an upper bound for Year 7 entry testers; entry year inferred from title")
    add("136366", 2025, "distribution_file", "all", rel(src_file(sid)), "file", sid,
        "every candidate's standardised score (anonymised user names)", "confirmed")
    snippet = "The Published Admission Number (PAN) is 160"
    assert norm(snippet) in text("colyton_policy_2025")
    add("136366", 2025, "pan", "all", 160, "places", "colyton_policy_2025",
        f'admissions criteria; text: "{snippet}"', "confirmed")


# ---------------------------------------------------------------- 2g. explicit gaps in the core measures
CORE = {"admissions_model": ["admissions_model"], "qualifying_score": ["qualifying_score"],
        "lowest_score_offered": ["lowest_score_offered", "last_distance_offered", "last_rank_offered"],
        "testers_stage1": ["testers_stage1", "test_applicants"], "pan": ["places", "pan"]}


def gap_rows(df):
    """A not_published row for every school x core measure with no row at all, naming the files read for it."""
    out = []
    for urn, name in TOP.items():
        s = df[df.urn == urn]
        read = sorted({pathlib.Path(f).name for f in s.source_file if f and "dfe_apps_offers" not in f})
        for measure, alts in CORE.items():
            if s.measure.isin(alts).any():
                continue
            note = "not found in any document fetched for this school"
            if measure in ("testers_stage1", "qualifying_score"):
                note += "; see the consortium rows (urn blank) where the test is shared"
            if measure == "pan":
                note += "; DfE offers (dfe_offers_total) are available every year"
            out.append(_row(urn, name, "", measure, "all", "", "", "documents read: " + ("; ".join(read) or "none"),
                            "not_published", note))
    return out


# ---------------------------------------------------------------- 3. derived ratios
def _row(urn, name, year, measure, cat, value, unit, loc, status, note, url="", file=""):
    return {"urn": urn, "name": name, "entry_year": year, "measure": measure, "category": cat, "offer_round": "",
            "value": value, "unit": unit, "source_url": url, "source_file": file, "source_location": loc,
            "status": status, "note": note}


def derive_testers_per_place(df):
    """School level: testers_stage1 (else test_applicants) / places (else pan, else DfE offers), same school and year."""
    out = []
    ok = df.status.isin(["confirmed", "secondary_source"]) & (df.urn != "") & (df.category == "all") & df.value.ne("")
    for num_m, out_m in (("testers_stage1", "testers_per_place"), ("test_applicants", "test_applicants_per_place")):
        for _, r in df[ok & (df.measure == num_m)].iterrows():
            same = df[ok & (df.urn == r.urn) & (df.entry_year == r.entry_year)]
            den = next((same[same.measure == m].iloc[0] for m in ("places", "pan", "dfe_offers_total")
                        if (same.measure == m).any()), None)
            if den is None:
                continue
            status = "confirmed" if r.status == den.status == "confirmed" else "secondary_source"
            out.append(_row(r.urn, r["name"], r.entry_year, out_m, "all",
                            round(float(r.value) / float(den.value), 2), "ratio",
                            f"derived: {r.row_id} / {den.row_id}", status, f"{num_m} / {den.measure}"))
    return out


CONSORTIA = {  # name -> (DfE selection of the consortium's grammar places by category, description)
    CSSE: ({"boys": {"136642", "137814", "149899", "136443", "136272"}, "girls": {"137515", "136444", "136490"}},
           "the 7 CSSE grammars (KEGS, CRGS, Southend High B/G, Westcliff High B/G, Colchester County High); "
           "partially selective schools' selective places excluded (not published separately)"),
    KENT: ({"all": ("Kent",)}, "all selective schools in Kent LA (DfE admissions_policy = Selective)"),
    WARKS: ({"all": ("Warwickshire",)}, "all selective schools in Warwickshire LA (DfE admissions_policy = Selective)"),
    SLOUGH: ({"all": ("Slough",)}, "all selective schools in Slough LA (the four consortium schools)"),
}


def derive_consortium_ratio(df):
    zp = sorted((RAW / "dfe_apps_offers").glob("*/apps_offers_2026-27_all_files.zip"))[-1]
    with zipfile.ZipFile(zp) as z, z.open(DFE_MEMBER) as f:
        d = pd.read_csv(f, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    d = d[(d.school_phase == "Secondary") & (d.admissions_policy == "Selective")]
    out = []
    for cname, (sel, desc) in CONSORTIA.items():
        for cat, key in sel.items():
            for year in (2023, 2024, 2025, 2026):
                tp = f"{year}{(year + 1) % 100:02d}"
                dy = d[d.time_period == tp]
                sub = dy[dy.school_urn.isin(key)] if isinstance(key, set) else dy[dy.la_name.isin(key)]
                t = df[(df.name == cname) & (df.urn == "") & (df.measure == "testers_stage1") & (df.category == cat)
                       & (df.entry_year == year) & df.value.ne("")]
                if not len(t) or not len(sub):
                    continue
                offers = int(sub.total_number_places_offered.astype(int).sum())
                t = t.iloc[0]
                out.append(_row("", cname, year, "dfe_offers_total", f"{cat}_grammars", offers, "count",
                                f"{DFE_MEMBER}: time_period={tp}, sum of total_number_places_offered over "
                                f"{len(sub)} schools (school_urn {', '.join(sorted(sub.school_urn))})", "confirmed",
                                desc, DFE_ZIP_URL, rel(zp)))
                out.append(_row("", cname, year, "testers_per_place", cat, round(float(t.value) / offers, 2),
                                "ratio", f"derived: {t.row_id} / DfE offers (same entry year, {cat}_grammars)",
                                "confirmed", "consortium-level: candidates per grammar offer"))
    return out


# ---------------------------------------------------------------- 4. super-selective flag (scouting C 4d)
SCORE_RANK = {"score_rank"}
AREA = {"score_rank_priority_area", "score_rank_mixed_catchment"}
QUALIFY = {"qualify_then_distance", "qualify_then_catchment", "qualify_then_catchment_distance"}


def criterion_score_ranked(s):
    """-> (result, row ids). pass / fail / area_not_radius / unknown; '_secondary' if resting on a secondary row."""
    model = s[(s.measure == "admissions_model") & s.value.ne("")].sort_values("entry_year")
    if not len(model):
        return "unknown", []
    m = model.iloc[-1]
    km = s[(s.measure == "catchment_km") & s.value.ne("")]
    ids = [m.row_id] + list(km.row_id)
    if m.value in SCORE_RANK:
        res = "pass"
    elif m.value in AREA:
        res = ("pass" if km.value.astype(float).min() >= 10 else "fail") if len(km) else "area_not_radius"
    elif m.value in QUALIFY:
        res = "fail"
    else:
        res = "unknown"      # faith categories: the rule says nothing about them
    if res in ("pass", "fail") and (m.status == "secondary_source" or (km.status == "secondary_source").any()):
        res += "_secondary"
    return res, ids


def criterion_testers(s, df, sex):
    """School-level testers per place (latest year), else test applicants per place, else the consortium figure."""
    for measure, tag in (("testers_per_place", ""), ("test_applicants_per_place", "_proxy")):
        r = s[(s.measure == measure) & s.value.ne("")].sort_values("entry_year")
        if len(r):
            b = r.iloc[-1]
            tag = tag or ("" if b.status == "confirmed" else "_secondary")
            return (("pass" if float(b.value) >= 5 else "fail") + tag, [b.row_id],
                    f"school {b.entry_year}: {b.value} ({measure})")
    test = s[(s.measure == "test_used") & s.value.ne("")]
    if len(test):
        cons = df[(df.urn == "") & (df.measure == "testers_per_place") & (df.name == test.value.iloc[-1])]
        cons = cons[cons.category == sex] if (cons.category == sex).any() else cons[cons.category == "all"]
        if len(cons):
            b = cons.sort_values("entry_year").iloc[-1]
            return (("pass" if float(b.value) >= 5 else "fail") + "_consortium", [test.row_id.iloc[-1], b.row_id],
                    f"consortium {b.entry_year} ({b.category}): {b.value}")
    return "unknown", [], ""


def super_selective(df):
    top = pd.read_csv(DERIVED / "top30_grammar.csv", dtype=str)
    # sex of the Year 7 intake from KS4 2023/24 counts (several 'Mixed' grammars are single-sex to 16; a blank
    # count means none of that sex)
    g = pd.to_numeric(top.girls_count).fillna(0)
    b = pd.to_numeric(top.boys_count).fillna(0)
    sex = dict(zip(top.urn, ["boys" if gi == 0 else "girls" if bi == 0 else "all" for gi, bi in zip(g, b)]))
    out = []
    for urn, name in TOP.items():
        s = df[df.urn == urn]
        c1, ids1 = criterion_score_ranked(s)
        c2, ids2, basis = criterion_testers(s, df, sex[urn])
        if c1 == "pass" and c2 in ("pass", "pass_consortium"):   # 4d admits school or consortium data
            flag = "yes"
        elif c1 == "fail" or c2 in ("fail", "fail_consortium"):
            flag = "no"
        elif c1 in ("pass", "pass_secondary", "area_not_radius") and c2.startswith("pass"):
            flag = "probable"
        else:
            flag = "unassessed"
        note = MODEL_NOTES.get(urn, "")
        if flag == "unassessed" and urn in FLAG_OVERRIDES:
            flag, why = FLAG_OVERRIDES[urn]
            note = f"{note} {why}".strip()
        models = s[s.measure == "admissions_model"].sort_values("entry_year")
        out.append({"urn": urn, "name": name, "flag": flag, "criterion_score_ranked": c1,
                    "criterion_testers_per_place": c2, "testers_per_place_basis": basis,
                    "admissions_model": models.value.iloc[-1] if len(models) else "",
                    "evidence_row_ids": ";".join(dict.fromkeys(ids1 + ids2)), "note": note})
    return pd.DataFrame(out)


def main():
    load_curated()
    parse_kef()
    parse_csse()
    parse_kent()
    parse_cchs()
    parse_bucks()
    parse_warks()
    parse_slough()
    parse_colyton()
    parse_dfe()
    df = pd.DataFrame(rows)
    df["value"] = df.value.astype(str)
    df.insert(0, "row_id", [f"gi{i:04d}" for i in range(1, len(df) + 1)])
    for derive in (derive_consortium_ratio, derive_testers_per_place, gap_rows):
        extra = pd.DataFrame(derive(df))
        extra["value"] = extra.value.astype(str)
        extra.insert(0, "row_id", [f"gi{i:04d}" for i in range(len(df) + 1, len(df) + len(extra) + 1)])
        df = pd.concat([df, extra], ignore_index=True)
    df["entry_year"] = df.entry_year.astype(str)
    df = df[COLS]
    assert df.row_id.is_unique
    write_derived(df, "grammar_intake")
    ss = super_selective(df)
    write_derived(ss, "grammar_super_selective")
    print(ss.flag.value_counts().to_string())


if __name__ == "__main__":
    main()
