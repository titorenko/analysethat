"""Build destination tables (DfE destination measures, 2023/24 releases):
  dest_1618_school.csv        16-18 leavers, institution level, incl. independents (any UK HE, no top-third)
  dest_ks4_school.csv         KS4 leavers, institution level (state-funded only)
  progression_school.csv      progression to level 4+ / degree / top-third HEI (state-funded only)
  dest_national_by_type.csv   national rows by institution group/type (selective splits), long format

The source files carry each observation twice (data_type 'Number of students' and 'Percentage'); here they
become <measure>_n and <measure>_pct columns. Only breakdown_topic == 'Total' rows are kept.
time_period = academic year in which the cohort finished KS4 / 16-18 study; the destination is measured in
the following year (progression: within two years).

Usage: .venv/Scripts/python -I code/derive/build_destinations.py
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
from common import latest_raw, read_ees, num, assert_unique, write_derived  # noqa: E402

M1618 = ["overall", "education", "he", "fe", "other_edu", "appren", "all_work", "all_notsust", "all_unknown"]
MKS4 = ["overall", "education", "fe", "ssf", "sfc", "other_edu", "appren", "all_work", "all_notsust", "all_unknown"]
MPROG = ["all_progressed", "all_degree", "all_top3rd", "all_appren", "all_htech", "acag_progressed",
         "tlev_progressed", "otl3_progressed"]
COUNT_TYPES = {"Number of students", "Number of pupils"}


def period(tp):
    return tp.str[:4] + "/" + tp.str[4:]


def widen(df, keys, cohort_cols, measures):
    """Pair count and percentage rows into one row with <m>_n and <m>_pct (and <m>_flag if suppressed)."""
    df = df.copy()
    df["kind"] = df.data_type.map(lambda t: "n" if t in COUNT_TYPES else ("pct" if t == "Percentage" else None))
    if df.kind.isna().any():
        raise ValueError(f"unknown data_type {set(df.data_type[df.kind.isna()])}")
    assert_unique(df, keys + ["kind"], "destinations")
    n = df[df.kind == "n"].set_index(keys)
    p = df[df.kind == "pct"].set_index(keys)
    out = pd.DataFrame(index=n.index.union(p.index))
    for c in cohort_cols:
        out[c] = num(n[c].reindex(out.index).fillna(p[c].reindex(out.index))).astype("Int64")
    for m in measures:
        raw_n = n[m].reindex(out.index).fillna("")
        out[f"{m}_n"] = num(raw_n).astype("Int64")
        out[f"{m}_pct"] = num(p[m].reindex(out.index).fillna(""))
        out[f"{m}_flag"] = raw_n.where(out[f"{m}_n"].isna(), "")
    return out.reset_index()


def school(pattern, measures, cohort_cols, extra_keys, name):
    df = read_ees(latest_raw("dfe_dest", pattern))
    df = df[df.breakdown_topic == "Total"]
    keys = ["school_urn", "school_name", "time_period", "admission_policy", "institution_group",
            "institution_type"] + extra_keys
    out = widen(df, keys, cohort_cols, measures)
    out = out.rename(columns={"school_urn": "urn"})
    out["time_period"] = period(out.time_period)
    # drop all-empty flag columns
    out = out[[c for c in out.columns if not (c.endswith("_flag") and (out[c] == "").all())]]
    write_derived(out.sort_values(["urn", "time_period"]), name)


def national():
    parts = []
    for dataset, pattern, measures, cohort_col in [
            ("dest_1618", "dest_1618_nat.csv", M1618, "cohort"),
            ("dest_ks4", "dest_ks4_nat.csv", MKS4, "cohort"),
            ("progression", "progression_nat.csv", MPROG, "all_cohort")]:
        df = read_ees(latest_raw("dfe_dest", pattern))
        df = df[df.breakdown_topic == "Total"]
        if "cohort_level" in df:
            df = df[df.cohort_level == "Total"]
        lvl = ["cohort_level_group"] if "cohort_level_group" in df else []
        keys = ["time_period", "institution_group", "institution_type"] + lvl
        w = widen(df, keys, [cohort_col], [m for m in measures if m in df.columns])
        w = w.rename(columns={cohort_col: "cohort"})
        if not lvl:
            w["cohort_level_group"] = "Total"
        long = []
        for m in [m for m in measures if m in df.columns]:
            x = w[keys[:3] + ["cohort_level_group", "cohort"]].copy()
            x["measure"], x["n"], x["pct"], x["flag"] = m, w[f"{m}_n"], w[f"{m}_pct"], w[f"{m}_flag"]
            long.append(x)
        d = pd.concat(long, ignore_index=True)
        d.insert(0, "dataset", dataset)
        parts.append(d)
    out = pd.concat(parts, ignore_index=True)
    out["time_period"] = period(out.time_period)
    write_derived(out, "dest_national_by_type")


if __name__ == "__main__":
    school("dest_1618_inst.csv", M1618, ["cohort"], ["cohort_level_group"], "dest_1618_school")
    school("dest_ks4_inst.csv", MKS4, ["cohort"], [], "dest_ks4_school")
    school("progression_inst.csv", MPROG, ["all_cohort", "acag_cohort", "tlev_cohort", "otl3_cohort"], [],
           "progression_school")
    national()
