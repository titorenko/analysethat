"""Cambridge Undergraduate Admissions Statistics, school/college-type table (Table 1.1 for 2013-2021 cycles,
Table 2.1 for 2022-2025) -> data/derived/cambridge_school_type.csv.

The table page is the one whose text has the 'Table N.1 Applications ... to Cambridge by type of
school/college' title and a 'Home applications' line. Each table row is one text line: a label followed by
Men / Women / Totals / % for applications, offers (absent in 2013) and acceptances, then the success rate.
Only the printed Totals are kept (Men + Women do not add up to Totals: other/unknown gender is in Totals only).
Internal arithmetic is asserted for every cycle: the four maintained sub-types sum to Maintained; Maintained +
Independent + Other and Overseas = Subtotals in each block; the two Subtotals sum to Totals.

    .venv/Scripts/python -I code/derive/cambridge_school_type.py
"""
import re
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import latest_raw, rel, write_derived  # noqa: E402

import pandas as pd  # noqa: E402
import pdfplumber  # noqa: E402

CYCLES = range(2013, 2026)
TITLE = re.compile(r"Table (\d+\.\d+) Applications[^\n]*?to Cambridge by type of school/college")
ROW = re.compile(r"^([A-Za-z][A-Za-z /&-]*?)\s+((?:[\d,]+(?:\.\d+)?\s*)+)$")
SUBTYPES = ["Comprehensive School", "Grammar School", "Sixth Form College", "FE and Tertiary Colleges"]
SECTORS = ["Maintained", "Independent", "Other and Overseas"]
LEVEL = {**{s: "maintained_subtype" for s in SUBTYPES}, **{s: "sector" for s in SECTORS},
         "Subtotals": "subtotal", "Totals": "total"}
SCOPE = {"home": "Home (fee-status) applicants; Maintained/Independent = UK schools/colleges",
         "other": "Non-Home applicants; Maintained/Independent = applicants resident outside the UK educated at UK schools/colleges",
         "all": "All applicants (Home + other)"}
MEASURES = ["applications", "offers", "acceptances"]


def n(s):
    return float(s.replace(",", "")) if "." in s else int(s.replace(",", ""))


def find_table(pdf):
    for i, pg in enumerate(pdf.pages, 1):
        t = pg.extract_text() or ""
        m = TITLE.search(t)
        if m and re.search(r"^Home applications$", t, re.M):
            return i, m.group(1), t
    raise ValueError("school-type table not found")


def parse(path, cycle):
    with pdfplumber.open(path) as pdf:
        pno, table, text = find_table(pdf)
    rows, block = [], None
    for line in text.split("\n"):
        if line == "Home applications":
            block = "home"
            continue
        if line == "Other applications":
            block = "other"
            continue
        m = ROW.match(line)
        if not m or block is None or m.group(1) not in LEVEL:
            continue
        label, nums = m.group(1), [n(x) for x in m.group(2).split()]
        if len(nums) == 13:      # M F T % (applications) M F T % (offers) M F T % (acceptances) success
            apps, offers, acc, rate = nums[2], nums[6], nums[10], nums[12]
        elif len(nums) == 9 and cycle == 2013:     # no offers columns in 2013
            apps, offers, acc, rate = nums[2], None, nums[6], nums[8]
        else:
            raise ValueError(f"{cycle}: {len(nums)} numbers in {line!r}")
        if label == "Totals":
            block = "all"
        rows.append({"cycle": cycle, "block": block, "school_type": label, "level": LEVEL[label],
                     "applications": apps, "offers": offers, "acceptances": acc, "success_rate_pct": rate,
                     "scope": SCOPE[block], "source_table": f"Table {table}", "source_page": pno,
                     "source_file": rel(path)})
        if label == "Totals":
            break
    df = pd.DataFrame(rows)
    expect = [("home", s) for s in ["Maintained", *SUBTYPES, "Independent", "Other and Overseas", "Subtotals"]] + \
             [("other", s) for s in [*SECTORS, "Subtotals"]] + [("all", "Totals")]
    got = list(zip(df.block, df.school_type))
    if sorted(got) != sorted(expect):
        raise ValueError(f"{cycle}: rows {got}")
    v = df.set_index(["block", "school_type"])
    for m in MEASURES:
        if cycle == 2013 and m == "offers":
            continue
        checks = [(v.loc[("home", "Maintained"), m], sum(v.loc[("home", s), m] for s in SUBTYPES), "subtypes")]
        for b in ("home", "other"):
            checks.append((v.loc[(b, "Subtotals"), m], sum(v.loc[(b, s), m] for s in SECTORS), f"{b} subtotal"))
        checks.append((v.loc[("all", "Totals"), m], v.loc[("home", "Subtotals"), m] + v.loc[("other", "Subtotals"), m], "total"))
        for printed, summed, what in checks:
            if printed != summed:
                raise ValueError(f"{cycle} {m} {what}: printed {printed} != sum {summed}")
    return df


def main():
    frames = []
    for y in CYCLES:
        path = latest_raw("cambridge_stats", f"ug_admissions_statistics_{y}_cycle.pdf")
        df = parse(path, y)
        print(y, df.source_table.iloc[0], "p", df.source_page.iloc[0], len(df), "rows")
        frames.append(df)
    df = pd.concat(frames, ignore_index=True)
    for m in MEASURES:
        df[m] = df[m].astype("Int64")
    write_derived(df, "cambridge_school_type")


if __name__ == "__main__":
    main()
