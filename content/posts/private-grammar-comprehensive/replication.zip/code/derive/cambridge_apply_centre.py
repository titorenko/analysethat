"""Cambridge 'Applications, Offers and Acceptances by UCAS Apply Centre' PDFs (2013-2025) -> tidy CSV.

Row-aware pdfplumber parser: every page is a ruled grid (8 vertical rules = 7 columns, one horizontal rule
per row). Each word (pdfplumber extract_words) is placed in the grid cell that contains its centre point, so
a row's name, postcode, sector and values come from the same ruled band by construction. Structural
assertions run on every page of every cycle and abort on any violation: exactly 8 vertical rules; no word
outside the grid except the title above it and the 'page N of M' footer below it; the header row (where
present) has the expected column order; every other band has a 5-digit centre number, a name, a sector in
{Maintained, Independent, Other and Overseas} and three values; (cycle, centre_number) is unique.

Suppression: 2013-2023 print counts 1-2 as '<3' (value left blank, *_lt3 = True); 2024-2025 print raw counts
below 5 as 5 except zeros (value 5, *_floor5 = True means the true count is 1-5).

    .venv/Scripts/python -I code/derive/cambridge_apply_centre.py
"""
import re
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import assert_unique, latest_raw, rel, write_derived  # noqa: E402

import pandas as pd  # noqa: E402
import pdfplumber  # noqa: E402

CYCLES = range(2013, 2026)
SECTORS = {"Maintained", "Independent", "Other and Overseas"}
MEASURES = ["applications", "offers", "acceptances"]
ANCHOR = re.compile(r"^\d{5}$")
VALUE = re.compile(r"^(<3|\d{1,3}(?:,\d{3})*)$")
FOOTER = re.compile(r"^page\d+of\d+$", re.I)   # matched with spaces removed


def norm_name(s: str) -> str:
    s = s.casefold().replace("&", " and ").replace("'", "").replace("’", "")
    return re.sub(r"\s+", " ", re.sub(r"[^0-9a-z]+", " ", s)).strip()


def rules(objs, vertical):
    """Sorted, merged (within 1.5pt) positions of the table's ruling lines (pdfplumber rects/lines)."""
    if vertical:
        xs = [o["x0"] for o in objs if o["x1"] - o["x0"] < 2 and o["bottom"] - o["top"] > 100]
    else:
        xs = [o["top"] for o in objs if o["bottom"] - o["top"] < 2 and o["x1"] - o["x0"] > 300]
    out = []
    for x in sorted(xs):
        if not out or x - out[-1] > 1.5:
            out.append(x)
    return out


def band(v, edges):
    """Index i such that edges[i] <= v < edges[i+1], or None outside the grid."""
    for i in range(len(edges) - 1):
        if edges[i] <= v < edges[i + 1]:
            return i
    return None


def parse_value(tok, rule):
    """-> (value or None, floor5 flag, lt3 flag)"""
    if tok == "<3":
        if rule != "lt3":
            raise ValueError(f"'<3' under rule {rule}")
        return None, False, True
    v = int(tok.replace(",", ""))
    return v, rule == "floor5" and v == 5, False


def parse_page(page, cycle, pno, rule):
    """Characters are split into the grid's columns first (so text that abuts across a rule, e.g. an overseas
    postcode '32018' printed flush against 'Other', is not merged into one word); words are then formed within
    each column and placed in the row band that contains their centre point."""
    where = f"{cycle} p{pno}"
    objs = page.rects + page.lines
    xs, ys = rules(objs, True), rules(objs, False)
    if len(xs) != 8:
        raise ValueError(f"{where}: {len(xs)} vertical rules, expected 8 (7 columns)")
    words = []
    for c in range(-1, 8):     # -1 and 7: left of / right of the grid
        lo, hi = (xs[c] if c >= 0 else -1e9), (xs[c + 1] if c < 7 else 1e9)
        sub = page.filter(lambda o, lo=lo, hi=hi: o.get("object_type") == "char"
                          and lo <= (o["x0"] + o["x1"]) / 2 < hi)
        words += [dict(w, col=c) for w in sub.extract_words()]
    cells = {}
    for w in words:
        cy = (w["top"] + w["bottom"]) / 2
        r = band(cy, ys)
        if w["col"] in (-1, 7) or r is None:     # outside the grid: only the title above or the footer below
            line = "".join(x["text"] for x in sorted(words, key=lambda x: x["x0"]) if abs(x["top"] - w["top"]) < 2)
            if not (cy < ys[0] or (cy > ys[-1] and FOOTER.match(line))):
                raise ValueError(f"{where}: stray word {w['text']!r} at ({w['x0']:.0f},{cy:.0f})")
            continue
        cells.setdefault(r, {}).setdefault(w["col"], []).append(w)
    out, header = [], False
    for r in sorted(cells):
        txt = {c: " ".join(w["text"] for w in sorted(ws, key=lambda w: (round(w["top"]), w["x0"])))
               for c, ws in cells[r].items()}
        if not ANCHOR.match(txt.get(0, "")):
            if txt.get(2) == "Postcode":   # header row: check the column order
                hdr = [txt.get(c, "") for c in range(7)]
                if (hdr[0] != "UCAS Apply Centre" or not hdr[1].endswith("Name") or hdr[3] != "School Sector"
                        or hdr[4:] != ["Applications", "Offers", "Acceptances"]):
                    raise ValueError(f"{where}: unexpected header {hdr}")
                header = True
                continue
            raise ValueError(f"{where}: grid row {r} without a centre number: {txt}")
        sector = txt.get(3, "")
        vals = [txt.get(c, "") for c in (4, 5, 6)]
        if sector not in SECTORS or not all(VALUE.match(v) for v in vals) or not txt.get(1):
            raise ValueError(f"{where}: bad row {txt}")
        rec = {"cycle": cycle, "centre_number": txt[0], "centre_name": txt[1], "postcode": txt.get(2, ""),
               "sector": sector}
        for m, v in zip(MEASURES, vals):
            rec[m], rec[f"{m}_floor5"], rec[f"{m}_lt3"] = parse_value(v, rule)
        rec["page"] = pno
        out.append(rec)
    if not out:
        raise ValueError(f"{where}: no rows")
    return out, header


def parse_cycle(path, cycle):
    rule = "floor5" if cycle >= 2024 else "lt3"
    recs = []
    with pdfplumber.open(path) as pdf:
        first = pdf.pages[0].extract_text()
        if "by UCAS Apply Centre" not in first or str(cycle) not in first[:200]:
            raise ValueError(f"{path.name}: not the {cycle} apply-centre table")
        if rule == "floor5" and "less than 5 are reported as 5" not in first:
            raise ValueError(f"{path.name}: floor-5 note missing")
        for i, pg in enumerate(pdf.pages, 1):
            rows, header = parse_page(pg, cycle, i, rule)
            if i == 1 and not header:
                raise ValueError(f"{path.name}: no header row on page 1")
            recs += rows
    return recs, rule


def main():
    frames, sources = [], []
    for y in CYCLES:
        path = latest_raw("cambridge_apply_centre", f"undergraduate_admissions_by_apply_centre_{y}_cycle.pdf")
        recs, rule = parse_cycle(path, y)
        df = pd.DataFrame(recs)
        df["suppression_rule"] = rule
        df["source_file"] = rel(path)
        frames.append(df)
        sources.append(path)
        print(y, rule, f"{len(df):,d} rows,", df["sector"].value_counts().to_dict())
    df = pd.concat(frames, ignore_index=True)
    assert_unique(df, ["cycle", "centre_number"], "apply centre")
    df.insert(3, "name_norm", df["centre_name"].map(norm_name))
    for m in MEASURES:
        df[m] = df[m].astype("Int64")
    cols = ["cycle", "centre_number", "centre_name", "name_norm", "postcode", "sector", *MEASURES,
            *[f"{m}_floor5" for m in MEASURES], *[f"{m}_lt3" for m in MEASURES], "suppression_rule",
            "page", "source_file"]
    write_derived(df[cols], "cambridge_apply_centre")


if __name__ == "__main__":
    main()
