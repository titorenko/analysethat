"""Build data/derived/school_preferences_2627.csv: Year 7 (secondary) preferences and offers per state school,
September 2026 entry, from the DfE "Primary and secondary school applications and offers" 2026/27
school-level supporting file (EES, published 18 Jun 2026; file dated 29 Jun 2026).

Usage: .venv/Scripts/python -I code/derive/build_school_preferences.py

Key: school_laestab (unique). 19 rows have school_urn "n/a": boarding/music places and second sites
reported as separate rows, plus three LA-level pseudo rows (Welsh / special / middle schools, laestab 999xxxx).
They are kept with urn blank and row_type set.
"""
import sys
import pathlib
import zipfile

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from common import RAW, rel, num, assert_unique, write_derived  # noqa: E402

import pandas as pd  # noqa: E402

MEMBER = "supporting-files/AppsandOffers_2026_SchoolLevel29062026.csv"
COLS = {  # source column -> output column
    "school_laestab": "laestab", "school_urn": "urn", "school_name": "name", "old_la_code": "la_code",
    "la_name": "la_name", "establishment_type": "establishment_type", "admissions_policy": "admissions_policy",
    "total_number_places_offered": "offers_total", "number_preferred_offers": "offers_preferred",
    "number_1st_preference_offers": "offers_1st_pref", "number_2nd_preference_offers": "offers_2nd_pref",
    "number_3rd_preference_offers": "offers_3rd_pref", "times_put_as_any_preferred_school": "prefs_any",
    "times_put_as_1st_preference": "prefs_1st", "times_put_as_2nd_preference": "prefs_2nd",
    "times_put_as_3rd_preference": "prefs_3rd", "all_applications_from_another_LA": "prefs_from_other_la",
    "offers_to_applicants_from_another_LA": "offers_to_other_la",
}
COUNTS = ["offers_total", "offers_preferred", "offers_1st_pref", "offers_2nd_pref", "offers_3rd_pref", "prefs_any",
          "prefs_1st", "prefs_2nd", "prefs_3rd", "prefs_from_other_la", "offers_to_other_la"]


def load(zpath):
    with zipfile.ZipFile(zpath) as z, z.open(MEMBER) as f:
        return pd.read_csv(f, dtype=str, keep_default_na=False, encoding="utf-8-sig")


def zip_path():
    hits = sorted((RAW / "dfe_apps_offers").glob("*/apps_offers_2026-27_all_files.zip"))
    if not hits:
        raise FileNotFoundError("run code/harvest/dfe_apps_offers.py first")
    return hits[-1]


def main():
    zp = zip_path()
    d = load(zp)
    s = d[(d.time_period == "202627") & (d.school_phase == "Secondary")].copy()
    assert (s.entry_year == "7").all()
    out = s[list(COLS)].rename(columns=COLS)
    assert_unique(out, ["laestab"], "school_preferences_2627")
    for c in COUNTS:
        out[c] = num(out[c]).astype("Int64")
    pseudo = out.laestab.str.startswith("999")
    out["row_type"] = "school"
    out.loc[out.urn == "n/a", "row_type"] = "site_or_boarding_row_no_urn"
    out.loc[pseudo, "row_type"] = "la_pseudo_row"
    out.loc[out.urn == "n/a", "urn"] = ""
    for c in ("establishment_type", "admissions_policy"):
        out.loc[out[c] == "n/a", c] = ""
    out["prefs_per_offer"] = (out.prefs_any / out.offers_total.where(out.offers_total > 0)).round(3)
    out["first_prefs_per_offer"] = (out.prefs_1st / out.offers_total.where(out.offers_total > 0)).round(3)
    out.insert(0, "time_period", "202627")
    out = out.sort_values(["la_code", "laestab"]).reset_index(drop=True)
    print(f"source: {rel(zp)} :: {MEMBER}")
    print(out.row_type.value_counts().to_string())
    write_derived(out, "school_preferences_2627")


if __name__ == "__main__":
    main()
