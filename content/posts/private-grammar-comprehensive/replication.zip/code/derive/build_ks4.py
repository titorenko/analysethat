"""Build data/derived/ks4_school_2324.csv: one row per URN with KS4 results for 2023/24, the last year with
Progress 8 and KS2 prior-attainment bands (both are 'z' in 2024/25).

Prior-attainment bands are the DfE KS2 bands (High / Mid / Low). 'none' = pupils without a KS2 result
= total - (high + mid + low); typically pupils from independent primaries or from abroad.

Usage: .venv/Scripts/python -I code/derive/build_ks4.py
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
from common import latest_raw, read_ees, num, flag, assert_unique, write_derived  # noqa: E402

YEAR = "202324"
BANDS = {"High prior attainment": "high", "Mid prior attainment": "mid", "Low prior attainment": "low"}


def main():
    p = latest_raw("dfe_ks4", "ks4_performance_v*.csv")
    k = read_ees(p)
    k = k[k.time_period == YEAR]
    tot = k[k.breakdown_topic == "Total"].set_index("school_urn")
    assert tot.index.is_unique
    out = pd.DataFrame({"urn": tot.index, "school_name": tot.school_name.values,
                        "establishment_type_group": tot.establishment_type_group.values, "time_period": "2023/24"})
    out = out.set_index("urn")
    out["pupils"] = num(tot.pupil_count).astype("Int64")
    out["attainment8"] = num(tot.attainment8_average)
    out["progress8"] = num(tot.progress8_average)
    out["progress8_flag"] = flag(tot.progress8_average)
    out["progress8_lower_ci"] = num(tot.progress8_lower_95_ci)
    out["progress8_upper_ci"] = num(tot.progress8_upper_95_ci)
    out["progress8_pupils"] = num(tot.progress8_pupil_count).astype("Int64")

    pa = k[k.breakdown_topic == "Prior attainment"]
    assert_unique(pa, ["school_urn", "breakdown"], "KS4 prior attainment")
    for band, short in BANDS.items():
        b = pa[pa.breakdown == band].set_index("school_urn")
        out[f"pa_{short}_count"] = num(b.pupil_count).astype("Int64")
        out[f"pa_{short}_pct"] = num(b.pupil_percent)
    known = out[["pa_high_count", "pa_mid_count", "pa_low_count"]].sum(axis=1, min_count=3)
    out["pa_none_count"] = (out.pupils - known).astype("Int64")
    out["pa_none_pct"] = 100 * out.pa_none_count / out.pupils
    out["pa_high_pct_of_known"] = 100 * out.pa_high_count / known

    sx = k[k.breakdown_topic == "Sex"]
    assert_unique(sx, ["school_urn", "breakdown"], "KS4 sex")
    for s in ["Boys", "Girls"]:
        out[f"{s.lower()}_count"] = num(sx[sx.breakdown == s].set_index("school_urn").pupil_count).astype("Int64")
    out = out.reset_index()
    write_derived(out.sort_values("urn", key=lambda s: s.astype(int)), "ks4_school_2324")


if __name__ == "__main__":
    main()
