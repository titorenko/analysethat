"""Build tax and long-run macro inputs from saved HTML pages:
  tax_2026_27.csv    income tax (England & NI), Class 1 NI, PA taper, student loan Plan 5 (and Plan 2) for 2026/27,
                     each value regex-extracted from gov.uk page text, with the matched text kept as evidence
  obr_longrun.csv    OBR Fiscal risks and sustainability, July 2026, Table 2.1 (50-year annual averages)

Usage: .venv/Scripts/python -I code/derive/build_rates.py
"""
import html
import re
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
from common import latest_raw, rel, assert_unique, write_derived  # noqa: E402

N = r"£([\d,]+)"


def page_text(path):
    """Visible text of the rendered <main> element (gov.uk pages also embed a JSON-escaped copy in <head>)."""
    t = path.read_text(encoding="utf-8")
    t = t[t.index("<main"):t.index("</main>")]
    t = re.sub(r"</(p|li|h[1-6]|tr|caption)>", "\n", t)
    t = re.sub(r"</t[dh]>", " | ", t)
    t = html.unescape(re.sub(r"<[^>]+>", " ", re.sub(r"<br ?/?>", " / ", t)))
    return re.sub(r"\s+", " ", t)          # all Unicode whitespace (newlines, nbsp) -> one space


def between(text, start, end):
    i = text.index(start)
    return text[i:text.index(end, i)]


def grab(rows, path, text, parameter, pattern, unit, note=""):
    m = re.search(pattern, text)
    assert m, f"{parameter}: pattern not found in {path.name}: {pattern}"
    rows.append({"parameter": parameter, "value": float(m.group(1).replace(",", "")), "unit": unit,
                 "tax_year": "2026-27", "note": note, "source_file": rel(path),
                 "evidence": re.sub(r"\s+", " ", m.group(0)).strip()})


def tax():
    rows = []
    p = latest_raw("hmt", "rates_and_thresholds_for_employers_2026-27.html")
    t = page_text(p)
    t = t[t.index("Unless otherwise stated, the following figures apply from 6 April 2026"):]   # skip the contents list
    eng = between(t, "England and Northern Ireland", "Scotland")
    grab(rows, p, eng, "personal_allowance", rf"{N} per year", "gbp_per_year")
    grab(rows, p, eng, "basic_rate", r"Basic tax rate \| (\d+)% \| Up to £[\d,]+", "pct")
    grab(rows, p, eng, "basic_rate_band_width", rf"Basic tax rate \| \d+% \| Up to {N}", "gbp_taxable_income",
         "taxable income above the personal allowance")
    grab(rows, p, eng, "higher_rate", r"Higher tax rate \| (\d+)% \| From £[\d,]+ to £[\d,]+", "pct")
    grab(rows, p, eng, "additional_rate", r"Additional tax rate \| (\d+)% \| Above £[\d,]+", "pct")
    grab(rows, p, eng, "additional_rate_threshold_gross", rf"Additional tax rate \| \d+% \| Above {N}", "gbp_per_year",
         "page states it on the taxable-income scale; equal to gross income at which the PA is fully withdrawn")
    ni = between(t, "Class 1 National Insurance thresholds", "Class 1 National Insurance rates")
    for name, label in (("ni_lower_earnings_limit", "Lower earnings limit"), ("ni_primary_threshold", "Primary threshold"),
                        ("ni_secondary_threshold", "Secondary threshold"), ("ni_upper_earnings_limit", "Upper earnings limit")):
        grab(rows, p, ni, name, rf"\| {label} \| [^|]*?{N} per year", "gbp_per_year")
    rates = between(t, "Employee (primary) contribution rates", "Director")
    grab(rows, p, rates, "ni_employee_rate_pt_to_uel", r"\| A \| 0% \| (\d+(?:\.\d+)?)% \| \d+%", "pct",
         "category A, earnings above primary threshold up to upper earnings limit")
    grab(rows, p, rates, "ni_employee_rate_above_uel", r"\| A \| 0% \| \d+% \| (\d+(?:\.\d+)?)%", "pct",
         "category A")
    emp = rates[rates.index("Employer (secondary) contribution rates"):]
    grab(rows, p, emp, "ni_employer_rate", r"\| A \| (\d+)% \|", "pct", "category A, above secondary threshold")
    sl = between(t, "Student loan and postgraduate loan recovery", "Company cars")
    grab(rows, p, sl, "plan5_repayment_threshold", rf"student loan plan 5 \| {N} per year", "gbp_per_year")
    grab(rows, p, sl, "plan2_repayment_threshold", rf"student loan plan 2 \| {N} per year", "gbp_per_year")
    grab(rows, p, sl, "student_loan_repayment_rate", r"Student loan deductions \| (\d+)%", "pct",
         "plans 1, 2, 4 and 5; applies to earnings above the plan threshold")

    p = latest_raw("hmt", "income_over_100000.html")
    t = page_text(p)
    pat = r"Your personal allowance goes down by £1 for every £2 that your adjusted net income is above {}"
    grab(rows, p, t, "pa_taper_start", pat.format(N), "gbp_adjusted_net_income")
    rows.append(dict(rows[-1], parameter="pa_taper_rate", value=0.5, unit="gbp_pa_lost_per_gbp_income",
                     note="£1 of allowance per £2 of income above the taper start"))
    grab(rows, p, t, "pa_zero_at", rf"allowance is zero if your income is {N} or above", "gbp_adjusted_net_income")

    p = latest_raw("hmt", "slc_interest_announcement_2026-08.html")
    t = page_text(p)
    grab(rows, p, t, "plan5_interest_rate", r"The interest rate for Plan 5 is RPI \((\d+(?:\.\d+)?)%\)", "pct",
         "RPI; applies 1 Sep 2026 to 31 Aug 2027 (academic year, not tax year)")
    d = pd.DataFrame(rows)
    v = d.set_index("parameter").value
    hrt = v.personal_allowance + v.basic_rate_band_width
    assert hrt == v.ni_upper_earnings_limit == 50270, hrt
    assert v.pa_zero_at == v.pa_taper_start + 2 * v.personal_allowance == v.additional_rate_threshold_gross
    d.loc[len(d)] = {"parameter": "higher_rate_threshold_gross", "value": hrt, "unit": "gbp_per_year",
                     "tax_year": "2026-27", "note": "derived: personal_allowance + basic_rate_band_width",
                     "source_file": rel(latest_raw("hmt", "rates_and_thresholds_for_employers_2026-27.html")),
                     "evidence": "derived"}
    assert_unique(d, ["parameter"], "tax")
    write_derived(d, "tax_2026_27")


def obr():
    p = latest_raw("obr", "frs_july_2026.html")
    t = p.read_text(encoding="utf-8", errors="replace")
    i = t.index("Table 2.1: Summary of baseline long-term demographic and economic assumptions")
    tb = t[t.index("<table", i):t.index("</table>", i)]
    cols = ["mar2026_efo_avg", "frs_2024", "frs_2026"]
    head = [re.sub(r"<[^>]+>", "", h).strip() for h in re.findall(r"<th[^>]*>(.*?)</th>", tb)]
    assert head[2:5] == ["Mar 2026 EFO avg.", "2024 FRS", "2026 FRS"], head
    rows, section = [], None
    for tr in re.findall(r"<tr>(.*?)</tr>", tb, re.S):
        cells = [html.unescape(re.sub(r"<[^>]+>", "", c)).strip() for c in re.findall(r"<td[^>]*>(.*?)</td>", tr, re.S)]
        if len(cells) == 1:
            section = cells[0]
        elif len(cells) == 5:
            for c, v in zip(cols, cells[1:4]):
                rows.append({"section": section, "assumption": cells[0], "column": c, "value_pct_per_year": float(v),
                             "methodology": cells[4], "source_file": rel(p)})
    d = pd.DataFrame(rows)
    assert len(d) == 27, len(d)
    write_derived(d, "obr_longrun")


if __name__ == "__main__":
    tax()
    obr()
