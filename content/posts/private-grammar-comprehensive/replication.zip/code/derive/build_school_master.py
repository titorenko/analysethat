"""Build data/derived/school_master.csv: one row per URN of secondary-relevant English establishments.

Universe = every URN in a DfE KS4, 16-18 or destinations school-level file harvested here (any year, open or
closed; dfe_sources lists which), plus
open GIAS establishments in England that are secondary-phase (Secondary, Middle deemed secondary,
All-through, 16 plus) or independent schools ('Other independent school') with statutory high age >= 16.

Sector (first rule that applies):
  1. GIAS TypeOfEstablishment 'Other independent school' (or DfE 'Independent School' if not in GIAS)
     -> independent.
  2. DfE 2024/25 admissions policy (16-18 institution info, else KS4 school information) -> selective /
     non_selective_highly_selective_area / non_selective_other.
  3. No DfE label: GIAS AdmissionsPolicy 'Selective' on a state-funded mainstream school -> selective.
  4. Otherwise -> other (special, AP, FE/sixth-form colleges, 16-19 schools, and state schools with no
     2024/25 DfE label, e.g. closed predecessor URNs). sector_basis records which rule applied.

Usage: .venv/Scripts/python -I code/derive/build_school_master.py
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
from common import latest_raw, read_ees, check_mapped, assert_unique, write_derived, rel  # noqa: E402

DFE_KS5_POLICY = {"Selective": "selective", "Non selective in highly selective area": "non_selective_highly_selective_area",
                  "Other non selective": "non_selective_other", "z": ""}
DFE_KS4_POLICY = {"selective schools": "selective",
                  "non-selective schools in highly selective areas": "non_selective_highly_selective_area",
                  "non-selective schools in other areas": "non_selective_other", "Admission type unclassified": ""}
GIAS_POLICY = {"Selective": "selective", "Non-selective": "non_selective", "Not applicable": "", "": ""}
STATE_MAINSTREAM_GROUPS = {"Local authority maintained schools", "Academies", "Free Schools"}
SPECIAL_OR_AP_TYPES = {"Community special school", "Foundation special school", "Academy special converter",
                       "Academy special sponsor led", "Free schools special", "Pupil referral unit",
                       "Academy alternative provision converter", "Academy alternative provision sponsor led",
                       "Free schools alternative provision"}
SECONDARY_PHASES = {"Secondary", "Middle deemed secondary", "All-through", "16 plus"}
NOT_ENGLAND_TYPES = {"Welsh establishment", "British schools overseas", "Offshore schools"}


def read_gias():
    path = latest_raw("gias", "edubasealldata*.csv")
    raw = path.read_bytes()
    try:
        raw.decode("utf-8")
        enc = "utf-8"
    except UnicodeDecodeError:
        enc = "cp1252"
    print(f"GIAS {rel(path)} decoded as {enc}")
    df = pd.read_csv(path, dtype=str, keep_default_na=False, encoding=enc, low_memory=False)
    return df, path, enc


def main():
    gias, gias_path, enc = read_gias()
    k5i_p = latest_raw("dfe_ks5", "ks5_institution_info_v*.csv")
    k4i_p = latest_raw("dfe_ks4", "ks4_school_info.csv")
    k5p_p = latest_raw("dfe_ks5", "ks5_performance_v*.csv")
    k4p_p = latest_raw("dfe_ks4", "ks4_performance_v*.csv")
    k5i, k4i = read_ees(k5i_p), read_ees(k4i_p)
    check_mapped(k5i.admissions_policy, DFE_KS5_POLICY, "16-18 info admissions_policy")
    check_mapped(k4i.admpol_pt, DFE_KS4_POLICY, "KS4 info admpol_pt")
    check_mapped(gias["AdmissionsPolicy (name)"], GIAS_POLICY, "GIAS AdmissionsPolicy")

    # DfE URN sets (which files mention the URN, any year)
    sources = {
        "ks5_info_2425": set(k5i.school_urn),
        "ks4_info_2425": set(k4i.school_urn),
        "ks5_perf": set(read_ees(k5p_p, usecols=["school_urn"]).school_urn),
        "ks4_perf": set(read_ees(k4p_p, usecols=["school_urn"]).school_urn),
    }
    for name, src, pat in [("ks5_subject_va", "dfe_ks5", "ks5_subject_va_v*.csv"),
                           ("ks5_subject_grades", "dfe_ks5", "ks5_subject_grades_v*.csv"),
                           ("dest_1618", "dfe_dest", "dest_1618_inst.csv"),
                           ("dest_ks4", "dfe_dest", "dest_ks4_inst.csv"),
                           ("progression", "dfe_dest", "progression_inst.csv")]:
        d = read_ees(latest_raw(src, pat), usecols=["school_urn", "school_name"])
        # KS4 destinations carry LA-level pseudo-institutions ("AP Institution:390:Gateshead", URN 9xxxxx)
        sources[name] = set(d.school_urn[~d.school_name.str.startswith("AP Institution:")])
    dfe_urns = set().union(*sources.values())

    # GIAS universe
    g = gias.rename(columns=lambda c: c.strip())
    high = pd.to_numeric(g["StatutoryHighAge"], errors="coerce")
    is_open = g["EstablishmentStatus (name)"].isin(["Open", "Open, but proposed to close"])
    england = ~g["TypeOfEstablishment (name)"].isin(NOT_ENGLAND_TYPES)
    secondary = g["PhaseOfEducation (name)"].isin(SECONDARY_PHASES) | (
        (g["TypeOfEstablishment (name)"] == "Other independent school") & (high >= 16))
    keep = g.URN.isin(dfe_urns) | (is_open & england & secondary)
    g = g[keep].copy()
    assert_unique(g, ["URN"], "GIAS")

    m = pd.DataFrame({
        "urn": g.URN,
        "name": g.EstablishmentName,
        "la_code": g["LA (code)"],
        "la_gss_code": g["GSSLACode (name)"],
        "la_name": g["LA (name)"],
        "establishment_type": g["TypeOfEstablishment (name)"],
        "establishment_type_group": g["EstablishmentTypeGroup (name)"],
        "phase": g["PhaseOfEducation (name)"],
        "status": g["EstablishmentStatus (name)"],
        "open_date": g.OpenDate,
        "close_date": g.CloseDate,
        "gias_admissions_policy": g["AdmissionsPolicy (name)"],
        "gender": g["Gender (name)"],
        "boarders": g["Boarders (name)"],
        "statutory_low_age": g.StatutoryLowAge,
        "statutory_high_age": g.StatutoryHighAge,
        "official_sixth_form": g["OfficialSixthForm (name)"],
        "pupils": g.NumberOfPupils,
        "boys": g.NumberOfBoys,
        "girls": g.NumberOfGirls,
        "census_date": g.CensusDate,
        "postcode": g.Postcode,
        "easting": g.Easting,
        "northing": g.Northing,
    })
    m["in_gias"] = True

    # DfE URNs missing from GIAS (none expected; kept with DfE fields only)
    missing = sorted(dfe_urns - set(m.urn))
    if missing:
        print(f"WARNING {len(missing)} DfE URNs not in GIAS: {missing[:10]}")
        m = pd.concat([m, pd.DataFrame({"urn": missing, "in_gias": False})], ignore_index=True)

    # DfE labels (2024/25)
    k5 = k5i.set_index("school_urn")
    k4 = k4i.set_index("school_urn")
    m["dfe_admpol_ks5"] = m.urn.map(k5.admissions_policy.map(DFE_KS5_POLICY))
    m["dfe_admpol_ks4"] = m.urn.map(k4.admpol_pt.map(DFE_KS4_POLICY))
    both = m.dfe_admpol_ks5.fillna("").ne("") & m.dfe_admpol_ks4.fillna("").ne("")
    conflict = both & (m.dfe_admpol_ks5 != m.dfe_admpol_ks4)
    if conflict.any():
        print("WARNING DfE 16-18 vs KS4 admissions policy conflicts:\n", m.loc[conflict, ["urn", "name", "dfe_admpol_ks5", "dfe_admpol_ks4"]])
    m["dfe_admissions_policy"] = m.dfe_admpol_ks5.fillna("").where(m.dfe_admpol_ks5.fillna("") != "", m.dfe_admpol_ks4.fillna(""))
    m["dfe_admissions_policy_source"] = ""
    m.loc[m.dfe_admpol_ks5.fillna("").ne(""), "dfe_admissions_policy_source"] = "ks5_info"
    m.loc[m.dfe_admpol_ks4.fillna("").ne(""), "dfe_admissions_policy_source"] += "+ks4_info"
    m["dfe_admissions_policy_source"] = m.dfe_admissions_policy_source.str.strip("+")
    m["dfe_establishment_type"] = m.urn.map(k5.establishment_type).fillna(m.urn.map(k4.establishment_type_group)).fillna("")
    m["dfe_age_range"] = m.urn.map(k5.age_range).fillna(m.urn.map(k4.agerange)).fillna("")
    m["name"] = m.name.fillna(m.urn.map(k5.school_name)).fillna(m.urn.map(k4.school_name))
    m["la_gss_code"] = m.la_gss_code.fillna(m.urn.map(k5.new_la_code)).fillna(m.urn.map(k4.new_la_code))
    m["dfe_sources"] = m.urn.map(lambda u: ";".join(k for k, s in sources.items() if u in s))

    # Sector
    gias_type = m.establishment_type.fillna("")
    indep = (gias_type == "Other independent school") | (~m.in_gias & m.dfe_establishment_type.isin(
        ["Independent School", "Independent schools"]))
    state_mainstream = m.establishment_type_group.isin(STATE_MAINSTREAM_GROUPS) & ~gias_type.isin(SPECIAL_OR_AP_TYPES)
    m["sector"], m["sector_basis"] = "other", "default_other"
    has_dfe = m.dfe_admissions_policy != ""
    m.loc[has_dfe, "sector"] = m.loc[has_dfe, "dfe_admissions_policy"]
    m.loc[has_dfe, "sector_basis"] = "dfe_" + m.loc[has_dfe, "dfe_admissions_policy_source"].str.split("+").str[0]
    gias_sel = ~has_dfe & state_mainstream & (m.gias_admissions_policy == "Selective")
    m.loc[gias_sel, ["sector", "sector_basis"]] = ["selective", "gias_admissions_policy"]
    m.loc[indep, ["sector", "sector_basis"]] = ["independent", "gias_type"]
    if (indep & has_dfe).any():
        raise ValueError("independent school with a DfE admissions label")

    # DfE vs GIAS selectivity (state schools with a DfE label)
    dfe2 = m.dfe_admissions_policy.map(lambda v: "selective" if v == "selective" else ("non_selective" if v else ""))
    gias2 = m.gias_admissions_policy.fillna("").map(GIAS_POLICY)
    dis = has_dfe & (dfe2 != gias2)
    m["selectivity_disagreement"] = ""
    m.loc[dis, "selectivity_disagreement"] = ("dfe=" + m.loc[dis, "dfe_admissions_policy"] + "; gias="
                                              + m.loc[dis, "gias_admissions_policy"].replace("", "(blank)"))

    m["london"] = m.la_gss_code.fillna("").str.startswith("E09")
    cols = ["urn", "name", "la_code", "la_gss_code", "la_name", "london", "establishment_type",
            "establishment_type_group", "dfe_establishment_type", "phase", "status", "open_date", "close_date",
            "sector", "sector_basis", "dfe_admissions_policy", "dfe_admissions_policy_source",
            "gias_admissions_policy", "selectivity_disagreement", "gender", "boarders", "statutory_low_age",
            "statutory_high_age", "dfe_age_range", "official_sixth_form", "pupils", "boys", "girls",
            "census_date", "postcode", "easting", "northing", "in_gias", "dfe_sources"]
    m = m[cols].sort_values("urn", key=lambda s: s.astype(int))
    assert_unique(m, ["urn"], "school_master")
    write_derived(m, "school_master")
    print(m.sector.value_counts().to_string())
    print(m.sector_basis.value_counts().to_string())
    print("selectivity disagreements:", (m.selectivity_disagreement != "").sum())


if __name__ == "__main__":
    main()
