"""Build ISC Census 2026 fee and bursary tables, transcribed from the PDF with pdfplumber (page regions cropped
because several tables sit side by side):
  isc_fees_2026.csv          Table 5.1, A.8 (phase x fee type, Jan 2026) and B.7 (like-for-like 2025 -> 2026)
  isc_fees_region_2026.csv   Table A.7 (region x fee type, Jan 2026) and B.6 (like-for-like 2025 -> 2026)
  isc_bursaries_2026.csv     Table 6.1 (sources of fee assistance) and 6.2 (means-tested bursaries by remission)

All fees are average weighted termly fees EXCLUDING VAT (ISC basis since 2025); specialist SEND schools excluded.
page = PDF page index (1-based); the printed page number is 2 lower.

Usage: .venv/Scripts/python -I code/derive/build_isc.py
"""
import re
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
import pdfplumber  # noqa: E402
from common import latest_raw, assert_unique, write_derived  # noqa: E402

TOKEN = r"(?:£?[\d,]+(?:\.\d+)?%?|-)"
FEE3 = ["boarding", "day_at_boarding_schools", "day_at_day_schools"]
PHASE = {"Sixth form": "sixth_form", "Senior": "senior", "Junior": "junior", "Nursery": "nursery",
         "Overall": "overall_excl_nursery", "Overall including nursery": "overall_incl_nursery"}
# (page, crop box as fractions of width / absolute y, first line of the table title)
REGIONS = {"5.1": (30, (0, 485, 1, None)), "6.1": (31, (0, 285, 1, 700)), "6.2": (32, (0, 645, 310, None)),
           "A.7": (44, (0, 375, 310, None)), "A.8": (44, (310, 375, 1, None)),
           "B.6": (62, (0, 95, 310, None)), "B.7": (62, (310, 95, 1, None))}


def val(tok):
    return None if tok == "-" else float(re.sub(r"[^\d.]", "", tok))


def lines_of(pdf, table):
    page, (x0, y0, x1, y1) = REGIONS[table]
    pg = pdf.pages[page - 1]
    box = (x0, y0, pg.width if x1 == 1 else x1, pg.height if y1 is None else y1)
    lines = pg.crop(box).extract_text().splitlines()
    assert lines[0].startswith(f"Table {table} "), (table, lines[0])
    return page, lines


def rows(lines, start_after):
    """(label, [tokens]) for table body lines. A line of tokens only has label ''; a line with no tokens is a
    label prefix for the next line. The label must be followed by whitespace (keeps footnote digits in it)."""
    i = next(k for k, ln in enumerate(lines) if ln.rstrip().endswith(start_after))
    toks = rf"{TOKEN}(?:\s+{TOKEN})*"
    out, prefix = [], ""
    for ln in lines[i + 1:]:
        ln = ln.strip()
        if ln.startswith(("Note", "1 ")):
            break
        if re.fullmatch(toks, ln):
            label, values = "", ln
        else:
            m = re.fullmatch(rf"(.*?\S)\s+({toks})", ln)
            if not m:
                prefix = (prefix + " " + ln).strip()
                continue
            label, values = m.groups()
        out.append(((prefix + " " + label).strip(), values.split()))
        prefix = ""
    return out


def fee_cols(label, toks):
    """Map fee tokens to fee types; Nursery rows have only the two day-fee columns."""
    cols = FEE3[1:] if len(toks) == 2 else FEE3
    assert len(toks) == len(cols), (label, toks)
    return zip(cols, toks)


def fees_simple(pdf, table, key_name, keymap, basis):
    page, lines = lines_of(pdf, table)
    out = []
    for label, toks in rows(lines, "(day schools)"):
        if label == "% change":       # Table 5.1: like-for-like change in the overall fee, schools in both censuses
            for col, t in fee_cols(label, toks):
                out.append({"table": table, "page": page, "basis": "like_for_like_2025_2026", key_name: "overall_excl_nursery",
                            "fee_type": col, "statistic": "pct_change", "year": "2025-2026", "value": val(t)})
            continue
        for col, t in fee_cols(label, toks):
            out.append({"table": table, "page": page, "basis": basis, key_name: keymap(label), "fee_type": col,
                        "statistic": "termly_fee_gbp_excl_vat", "year": "2026", "value": val(t)})
    return out


def fees_change(pdf, table, key_name, keymap):
    """B.6 / B.7: each entry is three lines - Jan 2026 fee (labelled), Jan 2025 fee, % change."""
    page, lines = lines_of(pdf, table)
    body = rows(lines, "(day schools)")
    assert len(body) % 3 == 0, table
    out = []
    for k in range(0, len(body), 3):
        (label, t26), (l25, t25), (lpc, tpc) = body[k:k + 3]
        assert label and not l25 and not lpc, (label, l25, lpc)
        for stat, year, toks in (("termly_fee_gbp_excl_vat", "2026", t26), ("termly_fee_gbp_excl_vat", "2025", t25),
                                 ("pct_change", "2025-2026", tpc)):
            for col, t in fee_cols(label, toks):
                out.append({"table": table, "page": page, "basis": "like_for_like_2025_2026", key_name: keymap(label),
                            "fee_type": col, "statistic": stat, "year": year, "value": val(t)})
    return out


def region(label):
    return "all" if label in ("Total", "All") else label


def bursaries(pdf):
    out = []
    page, lines = lines_of(pdf, "6.1")
    for label, toks in rows(lines, "Total value (£m)"):
        label = re.sub(r"(?<=[a-z])\d$", "", label)            # footnote markers: eligibility1, Authorities3, itrust2
        assert len(toks) == 4, (label, toks)
        for stat, t in zip(["pupils", "average_support_per_pupil_gbp", "pct_of_all_isc_pupils", "total_value_gbp_m"], toks):
            out.append({"table": "6.1", "page": page, "category": label, "statistic": stat, "value": val(t)})
    page, lines = lines_of(pdf, "6.2")       # labels such as '100%' look like values, so parse this one directly
    body = lines[next(k for k, ln in enumerate(lines) if ln.endswith("bursary pupils")) + 1:]
    for ln in body:
        m = re.fullmatch(r"(\S*\d%|Total) ([\d,]+)(?: ([\d.]+%))?", ln.strip())
        if not m:
            break
        label, n, pct = m.groups()
        for stat, t in (("pupils", n), ("pct_of_means_tested_bursary_pupils", pct)):
            if t is not None:
                out.append({"table": "6.2", "page": page, "category": f"bursary remission {label}"
                            if label != "Total" else "bursary remission total", "statistic": stat, "value": val(t)})
    return out


def main():
    path = latest_raw("isc", "isc_census_2026.pdf")
    with pdfplumber.open(path) as pdf:
        phase = fees_simple(pdf, "5.1", "phase", lambda s: PHASE[s], "all_schools_2026")
        phase += fees_simple(pdf, "A.8", "phase", lambda s: PHASE[s], "all_schools_2026")
        phase += fees_change(pdf, "B.7", "phase", lambda s: PHASE[s])
        reg = fees_simple(pdf, "A.7", "region", region, "all_schools_2026")
        reg += fees_change(pdf, "B.6", "region", region)
        bur = bursaries(pdf)
    for rows_, name, key in ((phase, "isc_fees_2026", "phase"), (reg, "isc_fees_region_2026", "region")):
        d = pd.DataFrame(rows_)
        assert_unique(d, ["table", key, "fee_type", "statistic", "year"], name)
        write_derived(d, name)
    d = pd.DataFrame(bur)
    assert_unique(d, ["table", "category", "statistic"], "isc bursaries")
    write_derived(d, "isc_bursaries_2026")


if __name__ == "__main__":
    main()
