"""Build ASHE earnings-distribution tables (UK, employee jobs; 'a' estimate files merged with 'b' CV files):
  ashe2025_age_percentiles.csv  ASHE Table 6, 2025 provisional: 6.7a annual gross pay and 6.5a hourly gross pay,
                                by sex x work pattern x age band; jobs, median, mean, P10-P90
  ashe_top_percentiles.csv      ONS ad hoc 3105 (tables J76.7a/b), annual gross pay 2024 and 2025: jobs, median,
                                mean, P90-P99 by sex x work pattern x geography x sector

Long format: one row per estimate. value is null where ONS shows a symbol (x = CV > 20% suppressed,
.. = disclosive, : = not applicable); the symbol is kept. Quality bands follow the ONS key on each sheet.

Usage: .venv/Scripts/python -I code/derive/build_ashe.py
"""
import io
import re
import zipfile
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import openpyxl  # noqa: E402
import pandas as pd  # noqa: E402
from common import latest_raw, assert_unique, write_derived  # noqa: E402

SHEETS = {"All": ("all", "all"), "Male": ("male", "all"), "Female": ("female", "all"),
          "Full-Time": ("all", "full_time"), "Part-Time": ("all", "part_time"),
          "Male Full-Time": ("male", "full_time"), "Male Part-Time": ("male", "part_time"),
          "Female Full-Time": ("female", "full_time"), "Female Part-Time": ("female", "part_time")}
SECTORS = {"public sector": "public", "private sector": "private", "non-profit body or mutual association": "non_profit"}


def quality(cv):
    if cv is None:
        return None
    return ("precise" if cv <= 5 else "reasonably_precise" if cv <= 10 else "acceptable" if cv <= 20
            else "unreliable")


def sheet_rows(zf, key, sheet):
    """(description, {stat: (raw value, raw cv)}) for each data row of one sheet of the a/b pair."""
    def load(k):
        name = [n for n in zf.namelist() if k in n]
        assert len(name) == 1, (k, name)
        return list(openpyxl.load_workbook(io.BytesIO(zf.read(name[0])), read_only=True,
                                           data_only=True)[sheet].iter_rows(values_only=True))
    a, b = load(key + "a "), load(key + "b ")
    h = next(i for i, r in enumerate(a) if r[0] == "Description")
    head = a[h]
    assert head[2:7] == ("(thousand)", "Median", "change", "Mean", "change"), head
    pcts = [c for c in head[7:] if isinstance(c, int)]
    stats = {2: "jobs_thousand", 3: "median", 5: "mean"} | {7 + j: f"p{p}" for j, p in enumerate(pcts)}
    out = []
    for ra, rb in zip(a[h + 1:], b[h + 1:]):
        if ra[0] is None or re.match(r"^[a-z]  ", ra[0]) or ra[0].startswith(("KEY", "The quality", "Source")):
            break
        assert ra[0] == rb[0], (ra[0], rb[0])
        out.append((ra[0].strip(), {s: (ra[c], rb[c]) for c, s in stats.items()}))
    return out


def tidy(keys, cells):
    rows = []
    for stat, (v, cv) in cells.items():
        num = v if isinstance(v, (int, float)) else None
        cvn = cv if isinstance(cv, (int, float)) else None
        rows.append(keys | {"statistic": stat, "value": num, "symbol": None if num is not None else str(v).strip(),
                            "cv_pct": cvn, "cv_symbol": None if cvn is not None else str(cv).strip(),
                            "quality": quality(cvn) if num is not None else None})
    return rows


def main():
    zp = latest_raw("ashe", "ashetable62025provisional.zip")
    zf = zipfile.ZipFile(zp)
    rows = []
    for key, measure in (("6.7", "annual_gross_pay_gbp"), ("6.5", "hourly_gross_pay_gbp")):
        for sheet, (sex, pattern) in SHEETS.items():
            for desc, cells in sheet_rows(zf, f"Table {key}", sheet):
                if desc == "Not Classified":
                    continue
                age = "all" if desc == "All employees" else desc.rstrip("b")
                assert re.fullmatch(r"all|\d\d-\d\d|60\+", age), desc
                rows += tidy({"edition": "2025 provisional", "measure": measure, "sex": sex, "work_pattern": pattern,
                              "age_band": age}, cells)
    d = pd.DataFrame(rows)
    assert_unique(d, ["measure", "sex", "work_pattern", "age_band", "statistic"], "ASHE table 6")
    write_derived(d, "ashe2025_age_percentiles")

    rows = []
    for year in ("2024", "2025"):
        zf = zipfile.ZipFile(latest_raw("ons_adhoc3105", f"asheadhocj76{year}.zip"))
        for sheet, (sex, pattern) in SHEETS.items():
            geo = None
            for desc, cells in sheet_rows(zf, "J76.7", sheet):
                sector = SECTORS.get(desc.lower())
                if sector is None:
                    geo, sector = desc, "all"
                rows += tidy({"year": int(year), "edition": {"2024": "2024 revised", "2025": "2025 provisional"}[year],
                              "measure": "annual_gross_pay_gbp", "sex": sex, "work_pattern": pattern,
                              "geography": geo, "sector": sector}, cells)
    d = pd.DataFrame(rows)
    assert_unique(d, ["year", "sex", "work_pattern", "geography", "sector", "statistic"], "ad hoc 3105")
    write_derived(d, "ashe_top_percentiles")


if __name__ == "__main__":
    main()
