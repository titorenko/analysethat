"""Oxford 'Applications by UCAS Apply Centre' dashboard (OCR of its table tiles) -> oxford_apply_centre*.csv.

Input: data/raw/oxford_apply_centre/<day>/ocr_<cycle>.csv, one row per table row, written by
code/harvest/oxford_tableau/ox_ocr.py from tiles_<cycle>.tar (see that folder's README).
Two cleaning rules, each checked against the tile images of every row it changes:
  1. trailing spaces/underscores the recogniser pads onto short numbers are stripped ('7___' -> '7');
  2. a postcode inward code starting with letter O is read as digit 0 ('LL13 OLU' -> 'LL13 0LU').
'NULL' postcodes are kept: the dashboard prints them. Blank count cells are Oxford's suppression
(fewer than 3), flagged in *_lt3. Validity, completeness and the three-year sum check live in
code/checks/g2_oxford_apply_centre.py.

    .venv/Scripts/python -I code/derive/oxford_apply_centre.py
"""
import re
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import latest_raw, rel, write_derived  # noqa: E402

import pandas as pd  # noqa: E402

CYCLES = ["2021", "2022", "2023", "2024", "2025"]
COUNTS = ["applications", "offers", "acceptances"]
RATES = ["offer_rate", "acceptance_rate"]


def clean(path: pathlib.Path, cycle: str) -> pd.DataFrame:
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    for c in COUNTS + RATES + ["ucas_id"]:
        df[c] = df[c].str.replace(r"[\s_]+$", "", regex=True)
    df["postcode"] = df["postcode"].str.replace(r"^([A-Z]{1,2}[0-9][0-9A-Z]?) O([A-Z]{2})$", r"\1 0\2", regex=True)
    out = pd.DataFrame({
        "cycle": cycle,
        "centre_number": df["ucas_id"].astype(int),
        "centre_name": df["school_name"].str.replace(r"\.{2,}$", "", regex=True),
        "name_truncated": df["school_name"].str.contains(r"\.{2,}$", regex=True),
        "postcode": df["postcode"],
        "school_type": df["school_type"],
    })
    for c in COUNTS:
        out[c] = pd.to_numeric(df[c].str.replace(",", ""), errors="raise").astype("Int64")
        out[f"{c}_lt3"] = df[c] == ""
    for c in RATES:
        out[f"{c}_pct"] = pd.to_numeric(df[c].str.rstrip("%"), errors="raise").astype("Int64")
    out["suppression_rule"] = "lt3"
    out["table_row"] = df["row"].astype(int)
    out["source_file"] = rel(path)
    return out


def main():
    single = pd.concat([clean(latest_raw("oxford_apply_centre", f"ocr_{c}.csv"), c) for c in CYCLES],
                       ignore_index=True)
    write_derived(single, "oxford_apply_centre")
    total = clean(latest_raw("oxford_apply_centre", "ocr_t2325.csv"), "2023-2025")
    write_derived(total, "oxford_apply_centre_2023_2025")


if __name__ == "__main__":
    main()
