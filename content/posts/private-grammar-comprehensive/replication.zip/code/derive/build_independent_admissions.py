"""Build data/derived/independent_admissions.csv: published admission facts for the 30 private schools in
data/derived/top30_independent.csv (places, applicants, intake from the school's own junior school, entry steps,
Oxbridge counts the school reports).

Usage: .venv/Scripts/python -I code/derive/build_independent_admissions.py

Input: code/derive/independent_admissions_curated.py (one line per value, with a verbatim snippet) and the files fetched
by code/harvest/independent_admissions.py (data/raw/independent_admissions/<day>/). The build FAILS unless each snippet
occurs in the file's extracted text (normalised as in build_grammar_intake.py) and a plain-number value occurs inside
its snippet. Values the source words as a range or in words ("800 - 900", "one-third") are kept as printed.
"""
import re
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
sys.path.insert(1, str(pathlib.Path(__file__).resolve().parents[1] / "harvest"))
from common import RAW, DERIVED, rel, write_derived  # noqa: E402
from extract_text import text_of, norm  # noqa: E402
from independent_admissions import SOURCES  # noqa: E402
from independent_admissions_curated import CURATED  # noqa: E402

import pandas as pd  # noqa: E402

SRC = {sid: (url, fn) for sid, url, fn, _ in SOURCES}
TOP = pd.read_csv(DERIVED / "top30_independent.csv", dtype=str).set_index("urn")["name"].to_dict()
MEASURES = {"places_total", "places_external", "from_own_junior", "applicants", "applicants_per_place", "entry_steps",
            "oxbridge_places", "oxbridge_offers"}
CATEGORIES = {"10+", "11+", "13+", "16+", "all"}
COLS = ["row_id", "urn", "name", "entry_year", "measure", "category", "value", "unit", "source_url", "source_file",
        "source_location", "status", "note"]


def src_file(sid):
    hits = sorted((RAW / "independent_admissions").glob(f"*/{SRC[sid][1]}"))
    return hits[-1] if hits else None


def main():
    texts, rows, bad = {}, [], []
    for ln in CURATED.strip().splitlines():
        ln = ln.strip()
        if not ln or ln.startswith("#"):
            continue
        f = [x.strip() for x in ln.split("|")]
        if len(f) != 13:
            raise ValueError(f"curated line needs 13 fields, has {len(f)}: {ln}")
        urn, year, measure, cat, _rnd, value, unit, sid, loc, snippet, status, note, _name = f
        if urn not in TOP or measure not in MEASURES or cat not in CATEGORIES or status != "confirmed" or sid not in SRC:
            raise ValueError(f"bad urn / measure / category / status / source: {ln}")
        p = src_file(sid)
        if p is None:
            bad.append(f"no file for {sid}")
            continue
        if sid not in texts:
            texts[sid] = norm(text_of(p))
        if norm(snippet) not in texts[sid]:
            bad.append(f"snippet not in {sid}: '{snippet}'")
            continue
        v = value.replace(",", "")
        if re.fullmatch(r"[\d.]+", v) and v not in snippet.replace(",", ""):
            bad.append(f"value {value} not inside its snippet '{snippet}'")
            continue
        rows.append({"urn": urn, "name": TOP[urn], "entry_year": year, "measure": measure, "category": cat, "value": value,
                     "unit": unit, "source_url": SRC[sid][0], "source_file": rel(p),
                     "source_location": f'{loc}; text: "{snippet}"' if loc else f'text: "{snippet}"',
                     "status": status, "note": note})
    if bad:
        raise SystemExit("curated rows failed verification:\n  " + "\n  ".join(bad))
    df = pd.DataFrame(rows)
    df.insert(0, "row_id", [f"ia{i:04d}" for i in range(1, len(df) + 1)])
    key = ["urn", "entry_year", "measure", "category", "source_url"]
    assert not df.duplicated(key + ["value"]).any(), df[df.duplicated(key + ["value"], keep=False)]
    write_derived(df[COLS], "independent_admissions")
    print(f"{df.urn.nunique()} of {len(TOP)} schools; by measure {df.measure.value_counts().to_dict()}")


if __name__ == "__main__":
    main()
