"""Hand-read admission facts for the 30 private schools, for build_independent_admissions.py. One line per value:

    urn | entry_year | measure | category | offer_round | value | unit | source | location | snippet | status | note | name

Same format and checks as grammar_intake_curated.py: the snippet must occur in the downloaded file's extracted text and
a plain-number value must occur inside its snippet. offer_round and name are blank. category = entry point (10+, 11+,
13+, 16+, all). entry_year = September entry year where the source states or clearly implies it; blank for undated
pages (the note then says when the page was read). Values keep the source's wording where it gives no single number
("800 - 900", "one-third", "several").
Measures: places_total, places_external, from_own_junior, applicants (candidates / applications / registrations, as
worded; the note says which), applicants_per_place, entry_steps (text), oxbridge_places, oxbridge_offers.
Read 2026-11-07 by two discovery agents; the build checks every line against the project's own downloads.
"""

CURATED = """
# ---------------- St Paul's Girls' School (100366): no junior school; ISEB pre-test, papers, interview
100366||places_total|11+||100|places|p7_spgs_policy_2021|p2 'Admission facts'|approximately 100 places are available each year at 11+ (to enter year 7)|confirmed|undated; policy approved 25 June 2020 (uploaded 2021-02)|
100366||places_external|16+||20|places|p7_spgs_policy_2021|p2 'Admission facts'|and 20 at 16+ (to enter year 12)|confirmed|undated; policy approved 25 June 2020; 16+ places are for external entrants|
100366||places_total|11+||110|places|p7_spgs_policy_2022|p2 §2.1|approximately 110 places are available each year at 11+ (to enter year 7)|confirmed|undated; policy approved 22 June 2022|
100366||places_external|16+||20|places|p7_spgs_policy_2022|p2 §2.1|approximately 110 places are available each year at 11+ (to enter year 7) and 20 at 16+|confirmed|undated; policy approved 22 June 2022|
100366||places_total|11+||115|places|p7_spgs_policy_2024|p3 §2.1|approximately 115 places are available each year at 11+ (to enter year 7)|confirmed|undated; policy completed April/May 2024|
100366||places_external|16+||15|places|p7_spgs_policy_2024|p3 §2.1|approximately 115 places are available each year at 11+ (to enter year 7) and 15 at 16+|confirmed|undated; policy completed April/May 2024|
100366||places_total|11+||120|places|p7_spgs_policy_2025|p3 §2.1|approximately 120 places are available each year at 11+ (to enter year 7)|confirmed|undated; policy completed June 2025|
100366||places_external|16+||15|places|p7_spgs_policy_2025|p3 §2.1|approximately 120 places are available each year at 11+ (to enter year 7) and 15 at 16+|confirmed|undated; policy completed June 2025|
100366|2027|entry_steps|11+||ISEB Common Pre-Test; three written papers (maths, English, general comprehension); 20-minute interview|text|p7_spgs_11|'Our final decisions'|the three stages of the admissions process (pre-test, written assessments, and interview)|confirmed|page dates are for Sept 2027 entry|
100366|2027|entry_steps|16+||on-screen baseline test; entrance paper in each of four A-level subjects; interview|text|p7_spgs_16|'Stage 2 written assessments'|candidates will sit an entrance assessment in each of the four subjects they are considering studying at a level|confirmed|page dates are for Sept 2027 entry|
100366|2024|oxbridge_places|all||44|places|p7_spgs_accounts_2024|trustees' report p9|of which 44 were oxbridge places|confirmed|places (UK university places on results day 2024, incl. 9 post-A-level applicants); entry_year = university start|

# ---------------- St Paul's School (102942): 13+ via ISEB pre-test in Year 6; Prep boys hold a place
102942||places_total|13+||198|places|p7_stpauls_13|intro|approximately half of the 198 boys coming from st paul's prep school|confirmed|undated; page read 2026-11-07; about half from St Paul's Prep, half from other prep schools|
102942||places_external|16+||20|places|p7_stpauls_16|intro|every year, approximately 20 pupils join st paul's school in year 12|confirmed|undated; page read 2026-11-07|
102942||entry_steps|13+||ISEB Common Pre-Test (Year 6); school English and maths exams (January); interview; offer, Year 8 assessment route or no offer|text|p7_stpauls_policy|p5 §6.3.4|1. offered a place; 2. placed on the year 8 assessment route, or 3. not offered a place|confirmed|undated; policy reviewed 01/26; St Paul's Prep pupils hold a place and transfer at end of Year 8 (§3.1.4)|
102942||entry_steps|16+||exams in each A-level subject in early November; interview late November|text|p7_stpauls_policy|p6 §6.4.1|candidates will be examined at st paul's at the start of november|confirmed|undated; policy reviewed 01/26|
102942|2025|oxbridge_places|all||44|places|p7_stpauls_accounts_2025|trustees' report p8|44 took up places at oxford or cambridge|confirmed|places taken up, 2025 leavers; entry_year = university start|

# ---------------- Westminster School (101162): ISEB pre-test, January tests, interview; just under half from the Under School
101162|2026|places_total|13+||123|pupils|p7_westminster_feeders|feeder table, 'Total pupils'|westminster under school 46 wetherby preparatory school 3 total pupils 123|confirmed|actual Year 9 joiners, Sept 2026, from 32 feeder schools|
101162|2026|from_own_junior|13+||46|pupils|p7_westminster_feeders|feeder table, Westminster Under School row|westminster under school 46 wetherby preparatory school 3 total pupils 123|confirmed|46 of 123 (37%) from Westminster Under School|
101162||places_total|13+||125|places|p7_westminster_13|intro|every year around 125 children join westminster school in the fifth form (year 9) at the 13+ entry point|confirmed|undated; page read 2026-11-07|
101162||applicants|13+||500|applications|p7_westminster_13|FAQ 'How many candidates apply for 13+ entry each year?'|the school receives around 500 applications and invites approximately 250 applicants for interview|confirmed|applications (as worded); about 250 interviewed; undated; page read 2026-11-07|
101162||entry_steps|13+||ISEB Common Pre-Test (Year 6); further maths and English tests (40 min each) in January; interview|text|p7_westminster_13|'Interview'|the interview stage comprises further tests in mathematics and english (40 minutes each)|confirmed|undated; page read 2026-11-07; page says just under half of pupils come from Westminster Under School; first girls at 13+ in 2028|
101162||applicants|16+||600 to 650|candidates|p7_westminster_16|FAQ 'How many candidates apply for sixth form entry each year?'|around 600 to 650 candidates apply and sit the entrance exams each year|confirmed|candidates who apply and sit the exams; undated; page read 2026-11-07|
101162||places_external|16+||75 to 85|offers|p7_westminster_16|same FAQ|approximately 190 candidates are invited to interview and we offer between 75 and 85 places|confirmed|places offered, with a waiting list; about 190 interviewed; undated; page read 2026-11-07|
101162|2027|entry_steps|16+||45-minute exam in each of four chosen subjects; subject and general interviews|text|p7_westminster_16|'Examinations'|candidates sit a 45-minute exam in each of the four subjects selected|confirmed|exams on 7 Nov 2026 for 2027 entry|
101162||applicants_per_place|all||5:1 to 11:1|ratio|p7_westminster_accounts_2025|governors' report p14 'Principal Activities'|applications for places continued greatly to exceed available capacity by between 5:1 and 11:1 depending upon the entry point|confirmed|accounts year ended 30 June 2025; covers Westminster School and Under School entry points; entry point not specified|
101162||applicants_per_place|all||5:1 to 11:1|ratio|p7_westminster_accounts_2024|governors' report p12|applications for places continued greatly to exceed available capacity by between 5:1 and 11:1 depending upon the entry point|confirmed|accounts year ended 30 June 2024; same wording as 2025|
101162|2026|oxbridge_places|all||69|places|p7_westminster_results|'University destinations 2026'|in 2026, 69 westminster school pupils took up places at oxford and cambridge|confirmed|places taken up; entry_year = university start|

# ---------------- North London Collegiate School (102257): own English and maths papers, interview
102257|2027|places_external|11+||70 to 75|places|p7_nlcs_11|'Admission to Year 7 (Sept 2027)'|admission to year 7 (sept 2027) around 70 to 75 places are available for external applicants joining year 7 each year|confirmed||
102257|2027|from_own_junior|11+||45|pupils|p7_nlcs_11|'Admission to Year 7 (Sept 2027)'|these students join the 45 or so girls moving up from our junior school|confirmed|'45 or so'|
102257|2027|entry_steps|11+||own English and maths papers (no VR/NVR); 30-minute interview for those invited back|text|p7_nlcs_11|'Stage 3/4'|each paper lasts 1 hour and 15 minutes|confirmed||
102257||places_external|16+||20|places|p7_nlcs_16|intro|we admit approximately 20 students each year into our sixth form|confirmed|undated; page read 2026-11-07|
102257||entry_steps|16+||three to four 1-hour papers in intended subjects; interview|text|p7_nlcs_16|'Selection process'|will sit three to four 1 hour papers on the subjects they wish to study at sixth form|confirmed|undated; page read 2026-11-07|

# ---------------- Brighton College (114614)
114614|2027|entry_steps|16+||assessment day: verbal reasoning, maths and general papers; interviews for shortlisted candidates|text|p7_brighton_16|p3 'Assessment Days'|a verbal reasoning test (45 minutes). a maths paper (45 minutes). a general paper (90 minutes)|confirmed|external candidates need a minimum 7.0 GCSE average|

# ---------------- King's College School Wimbledon (102684): 11+ and 13+ share one Year 6 pre-test
102684||places_external|11+||60|places|p7_kcs_11|metadescription|admits about 60 boys into year 7 at 11 years old|confirmed|as worded 'admits about 60'; read as new entrants (King's Junior School boys moving up not stated); undated; page read 2026-11-07|
102684||places_external|13+||20|places|p7_kcs_13|metadescription|admits about 20 boys into year 9 at 13 years old|confirmed|undated; page read 2026-11-07|
102684||places_external|16+||55|places|p7_kcs_16|metadescription|admits about 55 boys and girls into the sixth form at 16 years old|confirmed|undated; page read 2026-11-07|
102684||entry_steps|13+||pre-test in December of Year 6 (English, maths, verbal reasoning); interview; same process as 11+|text|p7_kcs_13|'The entrance examinations'|the entrance examination (pre-test) takes place in december when candidates are in year 6. there are three examinations: english, mathematics and verbal reasoning|confirmed|11+ and 13+ cannot both be applied for; undated; page read 2026-11-07|
102684||entry_steps|16+||written tests in English, maths and a general paper; three 15-minute interviews|text|p7_kcs_16|'The entrance examinations'|candidates sit written tests in english, mathematics and a general paper|confirmed|undated; page read 2026-11-07|

# ---------------- Guildford High School (125342)
125342||places_external|11+||70 to 80|places|p7_guildford_entry|'Year 7, 1. Introduction'|between 70 and 80 girls from other schools join year 7 at guildford high school each year|confirmed|undated; page read 2026-11-07; same page: 'Number of places - approximately 80 places'|
125342||applicants_per_place|11+||several|ratio|p7_guildford_entry|'Year 7, 1. Introduction'|each year we assess several candidates for every place we have available|confirmed|no number given; undated; page read 2026-11-07|
125342||places_total|11+||100|pupils|p7_guildford_faqs|FAQ 'How many places are available at 11+?'|there are just over 100 pupils in year 7|confirmed|'just over 100'; undated; page read 2026-11-07|
125342||from_own_junior|11+||40|percent|p7_guildford_faqs|same FAQ|around 40% of these places go to pupils from our own junior school|confirmed|share of Year 7 places; undated; page read 2026-11-07|
125342||entry_steps|16+||three one-hour papers; minimum seven I/GCSEs at 9-7|text|p7_guildford_entry|'Sixth Form, 4. Entrance assessment'|applicants will be asked to sit three one-hour papers from a choice of subjects|confirmed|undated; page read 2026-11-07|

# ---------------- Godolphin and Latymer (100369)
100369||entry_steps|11+||London 11+ Consortium test; interview for those selected; reference|text|p7_gl_policy|p3 §6.5.1|candidates will be required to complete the london 11+ consortium entrance test|confirmed|undated; policy reviewed May 2026|
100369||entry_steps|16+||cognitive ability test (plus maths assessment for maths); interview; reference|text|p7_gl_policy|p4, 16+ entry assessments|candidates will take a cognitive ability test|confirmed|undated; policy reviewed May 2026|

# ---------------- City of London School for Girls (100001)
100001|2027|entry_steps|11+||Cambridge Select Insight computer test (Nov); 45-min English and 45-min maths papers plus interview (Jan)|text|p7_clsg_11|'Second assessment and interview'|it will consist of a 45-minute english paper, testing creative writing and analytical skills, and a 45-minute maths paper|confirmed|first test 13-18 Nov 2026, second 6 Jan 2027|
100001|2027|entry_steps|16+||critical-thinking and written assessment (14 Oct); 10-minute subject interviews|text|p7_clsg_16|'Interviews'|candidates will have 10-minute interviews in the subjects that they are proposing to study|confirmed||

# ---------------- Wimbledon High School GDST (102692)
102692|2027|entry_steps|11+||verbal and non-verbal reasoning tests; creative assessment by invitation|text|p7_whs_senior|'Assessments, first stage'|we test verbal and non-verbal reasoning as our first stage for all 11+ candidates|confirmed|tests 17-18 Nov 2026|

# ---------------- Magdalen College School Oxford (123311)
123311|2027|entry_steps|11+||January test day (online tests 115 min, written paper 45 min); 30-minute interview|text|p7_mcs_11|'How long is the assessment?'|the online assessments last for 115 mins, split into two parts and the written paper is 45 mins|confirmed|test day 16 Jan 2027|
123311|2029|entry_steps|13+||pre-test in Year 6 with the 11+ candidates; offer conditional on Common Entrance (about 70%)|text|p7_mcs_pretest|'Pre-test entry'|all pre-test and 11+ candidates sit the same papers at the same time|confirmed|page key dates are for Sept 2029 entry|
123311||entry_steps|16+||three 45-minute written tests incl. verbal reasoning; two interviews|text|p7_mcs_sixth|'Interviews'|candidates will have two interviews|confirmed|undated; page read 2026-11-07|

# ---------------- The Perse School (110923)
110923|2025|oxbridge_places|all||22|places|p7_perse_accounts_2025|trustees' report p10|26 at medical/vet schools and 22 at oxford and cambridge|confirmed|places taken up, 2025 leavers; entry_year = university start|

# ---------------- Latymer Upper School (100370)
100370||places_external|16+||40|pupils|p7_latymer_16|intro|every year we welcome around 40 new students to our vibrant sixth form|confirmed|undated; page read 2026-11-07|
100370|2027|entry_steps|11+||maths and English papers (2 Dec); half-day interview session with a 1:2:1 interview (Jan)|text|p7_latymer_11|'Interview'|a half day of immersive learning activities in classroom settings and a 1:2:1 interview|confirmed||
100370||entry_steps|16+||three papers (maths, writing, problem solving and critical thinking); interview day|text|p7_latymer_16|'Entrance exam'|the entrance exam consists of three papers which assess|confirmed|undated; page read 2026-11-07|
100370|2025|oxbridge_places|all||35|places|p7_latymer_accounts_2025|chair's statement p6|with 35 admitted this year to oxford and cambridge alone|confirmed|places (admissions); report says total includes students from the class of 2024; entry_year = university start|
100370|2024|oxbridge_places|all||28|places|p7_latymer_accounts_2024|p7|including 28 oxbridge students|confirmed|places; entry_year = university start|

# ---------------- King Edward VI High School for Girls, Birmingham (103585)
103585|2027|entry_steps|11+||one English and one maths paper (2 Oct 2026); interviews by invitation (Nov)|text|p7_kehs_admissions|'Year 7 entry'|the entrance examination consists of one english paper and one mathematics paper|confirmed||
103585|2027|entry_steps|16+||application form and personal statement, predicted GCSEs, head's report; interview|text|p7_kehs_admissions|'Sixth Form entry process'|the entry process for the sixth form (16+) consists of an application form and personal statement|confirmed||

# ---------------- Highgate School (102163)
102163|2027|places_external|11+||80|pupils|p7_highgate_11|intro|we hope to welcome approximately 80 new children into year 7 of our senior school|confirmed|'from next September', page read 2026-11-07|
102163|2027|from_own_junior|11+||105|pupils|p7_highgate_11|intro|they will join around 105 pupils moving from year 6 of our junior school|confirmed|'from next September', page read 2026-11-07|
102163|2027|entry_steps|11+||entrance exams (1 Dec); interview|text|p7_highgate_11|'Entrance exams'|the first part of the assessment consists of our entrance exams taken at the school on tuesday 1 december|confirmed||
102163|2027|places_external|16+||30|pupils|p7_highgate_16|intro|we hope to welcome approximately 30 new pupils into year 12|confirmed|'next September', page read 2026-11-07; they join about 185 moving up from Year 11|
102163|2027|entry_steps|16+||application; interview day with subject and general interviews (14 Nov 2026)|text|p7_highgate_16|'Interviews'|candidates will be asked to attend an interview day in person at the school on saturday 14 november 2026|confirmed||
# ---------------- Wycombe Abbey (no junior school)
110547||places_total|13+||15|places|q7_wycombe_admissions|11+ assessments section, 'Deferred entry'|Deferred entry places are highly sought after with approximately 15 places awarded each year.|confirmed|13+ deferred-entry places only (girls assessed through the 11+ process in Year 6); undated; page read 2026-11-07|
110547||entry_steps|11+||ISEB Common Pre-Test; Assessment Day (interview, group tasks, English and Maths papers)|text|q7_wycombe_admissions|11+ assessments section|All registered candidates sit an online ISEB Common Pre-Test followed by an Assessment Day at Wycombe Abbey|confirmed|undated; page read 2026-11-07|
110547||entry_steps|16+||UKiset and school report; Assessment Day with entrance exams and interview|text|q7_wycombe_admissions|16+ assessments section|All registered candidates must sit a UKiset assessment and submit a Summer Term report between January and July|confirmed|undated; page read 2026-11-07|
110547|2026|oxbridge_offers|all||22|offers|q7_wycombe_oxbridge_2026|news post 11 Feb 2026, para 1-2|bringing the total number of Oxbridge offers to 22.|confirmed|offers made in the 2026 round: 14 Oxford + 6 Cambridge to current Upper Sixth, plus 2 to former pupils|

# ---------------- Alleyn's
100864||places_total|11+||150|places|q7_alleyns_11|11+ page, intro|We offer around 150 places, with two thirds of these new children joining from a wide spread of state and independent schools|confirmed|undated (page covers 2027-entry cycle); page read 2026-11-07|
100864||from_own_junior|11+||one-third|share|q7_alleyns_11|11+ page, intro|two thirds of these new children joining from a wide spread of state and independent schools, and the remaining children joining from Alleyn's Junior School|confirmed|the remaining third of ~150 come from Alleyn's Junior School (share in words; not printed as digits); undated; page read 2026-11-07|
100864||entry_steps|11+||school papers in Reasoning, English and Maths (no ISEB pre-test); group activity and one-to-one interview|text|q7_alleyns_11|11+ page, assessment section|all candidates will attend Alleyn's in early January for written assessments in Reasoning, English and Maths.|confirmed|page also says: 'The ISEB Common Pre-test does not form part of the 11+ process'; undated; page read 2026-11-07|
100864||places_external|16+||40|places|q7_alleyns_16|16+ page, intro|Each year, around 40 new students join us in Year 12 from a range of schools and backgrounds.|confirmed|new (external) Year 12 joiners; undated; page read 2026-11-07|
100864||entry_steps|16+||general papers (Reasoning, Maths, Critical Writing); general interview; two academic interviews|text|q7_alleyns_16|16+ page, process section|Two academic interviews in two of your A level subject choices.|confirmed|undated; page read 2026-11-07|

# ---------------- South Hampstead High GDST
100076|2027|entry_steps|11+||London 11+ Consortium exam (Quest); school reference; interview|text|q7_shhs_faq_11_2027|p1, 'three elements'|1. The Consortium exam: all applicants will be invited to sit the exam provided by Quest.|confirmed|FAQ for September 2027 entry|
100076||entry_steps|11+||own Junior School pupils transfer on the Junior Head's recommendation, without the entrance exam|text|q7_shhs_policy_2024|p2, 'Transfer to the Senior School (internal transfer)'|South Hampstead Junior School pupils are not required to take the entrance examination for the Senior School|confirmed|policy last reviewed August 2024|

# ---------------- Lady Eleanor Holles
102932||places_total|11+||120|places|q7_leh_11|FAQ 'How many places are available at 11+?'|There are usually around 120 places available for entry to the Senior School|confirmed|undated; page read 2026-11-07|
102932||from_own_junior|11+||one-third|share|q7_leh_11|same FAQ answer|of these approximately one-third go to pupils from our own Junior School|confirmed|share in words; remaining two-thirds go to external 11+ entrants; undated; page read 2026-11-07|
102932||entry_steps|11+||ISEB Common Pre-Test; LEH problem-solving exam; interview|text|q7_leh_11|Stage 1a / 1b / 2|Stage 1b: All applicants are invited to LEH to sit a Problem-Solving Entrance Examination.|confirmed|Stage 1a is the ISEB Common Pre-Test; Stage 2 interviews for those who perform well; undated; page read 2026-11-07|
102932||entry_steps|16+||online aptitude test and stimulus response paper; school report; interview; offer conditional on seven GCSEs at 9-7|text|q7_leh_16|FAQ on offers|Offers for students joining LEH at Sixth Form are conditional on achieving seven I/GCSEs at grades 9-7.|confirmed|undated; page read 2026-11-07|
102932||applicants|all||fallen from post-Covid record highs (no count published)|text|q7_leh_accounts_2025|Trustees' report, 'Review of achievements and academic performance for the year', p9|the number of applicants has fallen compared with the record highs following the Covid 19 pandemic|confirmed|qualitative only; accounts for year to 31 Aug 2025 (same wording in the 2024 accounts)|

# ---------------- City of London School
100003|2025|places_total|10+||40|places|q7_cls_policy_2024|Appendix 2 'Number of places available', p14|10+ in 2025 Up to 40 places|confirmed|'up to'; policy July 2024|
100003|2025|places_total|11+||85|places|q7_cls_policy_2024|Appendix 2, p14|11+ in 2025 Up to 85 places|confirmed|'up to'; 10+ entrants move up and are not counted here|
100003|2027|places_total|13+||30|places|q7_cls_policy_2024|Appendix 2, p14|13+ in 2027 Up to 30 places|confirmed|'up to'|
100003|2025|places_total|16+||20|places|q7_cls_policy_2024|Appendix 2, p14|16+ in 2025 Up to 20 places|confirmed|'up to'; external places|
100003|2025|entry_steps|11+||computerised test (Maths, English, verbal and non-verbal reasoning) plus hand-written English task; interview|text|q7_cls_policy_2024|5.4 '11+', p4|Candidates sit a computerised test covering Maths, English and Reasoning (Verbal and Non-Verbal), and complete a short hand-written English task.|confirmed|same test at 10+ (5.3); interviews per 6.3|
100003|2027|entry_steps|13+||ISEB Common Pre-test in Year 6 plus school computerised test; offers not conditional on further Year 8 assessment|text|q7_cls_policy_2024|5.5.1 '13+ entry in 2027', p4|Candidates seeking entry are required to sit the ISEB Common Pre-test in the Autumn Term when they are in Year 6.|confirmed||
100003|2025|entry_steps|16+||subject-based tests and reasoning test; interview; offer conditional on six GCSEs at 8-9|text|q7_cls_policy_2024|5.6 '16+', p4|Candidates sit subject-based tests, taken from a list of academic subjects taught by the School, in early November when they are in Year 11.|confirmed||
100003|2013|applicants|10+||169|candidates|q7_cls_governors_2013|Headmaster's Report, '10+'|169 had sat the entrance examinations this year versus 110 in 2012.|confirmed|candidates who sat; governors' minutes 22 Mar 2013|
100003|2012|applicants|10+||110|candidates|q7_cls_governors_2013|Headmaster's Report, '10+'|169 had sat the entrance examinations this year versus 110 in 2012.|confirmed|candidates who sat|
100003|2013|applicants|11+||420|candidates|q7_cls_governors_2013|Headmaster's Report, '11+'|420 had sat the entrance examinations for 46 full fee/scholarship places at 11+.|confirmed|candidates who sat for full-fee/scholarship places; separately 160 applied for sponsored awards|
100003|2013|places_total|11+||46|places|q7_cls_governors_2013|Headmaster's Report, '11+'|420 had sat the entrance examinations for 46 full fee/scholarship places at 11+.|confirmed|full-fee/scholarship places only; excludes sponsored-award places (5 offers) and boys admitted at 10+|
100003|2013|applicants|11+||160|applications|q7_cls_governors_2013|Headmaster's Report, '11+'|160 had applied via this route in 2013.|confirmed|applications for sponsored (bursary) awards at 11+ only|
100003|2013|places_total|13+||48|places|q7_cls_governors_2013|Headmaster's Report, '13+'|there were 48 places on offer at 13+ for 2013.|confirmed||
100003|2025|oxbridge_offers|all||35|offers|q7_cls_oxbridge_2025|news post 4 Feb 2025, headline|35 offers from Oxford and Cambridge|confirmed|offers in the 2025 round (announced 4 Feb 2025); 'nearly 20% of our Senior Sixth Form'|

# ---------------- Haberdashers' Boys'
117648||places_total|11+||160-170|places|q7_habsboys_11|11+ page, intro|Habs Boys has approximately 160-170 boys entering Year 7 each year.|confirmed|undated (2027-entry cycle page); page read 2026-11-07|
117648||from_own_junior|11+||60|pupils|q7_habsboys_11|11+ page, intro|Around 60 boys will automatically move up from our Prep School|confirmed|plus a small number with Preferential Pathway places from group schools; undated; page read 2026-11-07|
117648||places_total|13+||20-30|places|q7_habsboys_11|11+ deferred section|We have approximately 20-30 places for boys who join in Year 9 via the 11+ deferred route.|confirmed|11+ deferred route only (separate 13+ route not counted); undated; page read 2026-11-07|
117648||entry_steps|11+||QUEST paper-based test; about half invited to a 1-hour interview incl. group task|text|q7_habsboys_11|interview section|Around half of the boys who sit our assessment will be invited back for a 1-hour interview|confirmed|undated; page read 2026-11-07|

# ---------------- Haberdashers' Girls'
117649||entry_steps|11+||QUEST paper-based assessment; about half invited to interview and team exercise|text|q7_habsgirls_process|Senior 11+ section, 'Interview and team exercise'|Approximately half of students are invited back for an interview and team exercise.|confirmed|page also says 'We take roughly equal numbers of children from state and independent schools'; undated; page read 2026-11-07|
117649||entry_steps|16+||written exams; subject interviews; nine GCSEs required|text|q7_habsgirls_process|Sixth Form section|If you would like to join our Sixth Form, we ask for nine GCSEs including Maths and English.|confirmed|undated; page read 2026-11-07|

# ---------------- Putney High GDST
101072||applicants_per_place|all||nine|applications per place|q7_putney_results|results page, intro|With nine applications for every place, parents clearly rate the academic prowess of Putney High.|confirmed|applications per place; entry point and year not stated (marketing claim); value in words as printed; page read 2026-11-07|
101072||entry_steps|11+||online Maths and English assessment (Quest); Athena Assessment with one-to-one interview|text|q7_putney_senior|11+ process|Successful candidates will be asked to return for our second stage, the Athena Assessment which includes a one-to-one interview.|confirmed|undated (2027-entry cycle page); page read 2026-11-07|

# ---------------- Withington Girls'
105595||entry_steps|11+||own exam (verbal and non-verbal reasoning, English, Maths) sat by all, incl. own Junior School pupils, who get an automatic place; interview|text|q7_wgs_policy_2026|'Progression from Junior School to Senior School', p4|all pupils in Year 6 will automatically receive a place in Year 7, however such pupils will take the same entrance examination|confirmed|policy dated September 2026; exam = verbal and non-verbal reasoning, English and Maths papers (p3, text layer garbled there)|

# ---------------- Eton College (no junior school)
110158||places_total|16+||20|places|q7_eton_16|16+ page, intro|A limited number of places (approximately 20) will be available each year for entry into the Sixth Form.|confirmed|fee-paying route; Orwell Award route separate; undated; page read 2026-11-07|
110158||entry_steps|16+||online cognitive test and subject tests; online pastoral interview; school reference|text|q7_eton_16|16+ process|This will consist of an online cognitive test and specific subject tests.|confirmed|undated; page read 2026-11-07|
110158||entry_steps|13+||register by end of Year 5; ISEB Common Pre-Tests; interview and online test; Conditional Place confirmed by King's Scholarship, Common Entrance or Eton Entrance exam in Year 8|text|q7_eton_13|'Assessment for a Conditional Place'|We will offer boys who are successful at Stage 2 a Conditional Place, confirmed by passing King's Scholarship, Common Entrance or Eton Entrance examinations|confirmed|undated; page read 2026-11-07|
110158||places_total|13+||260|places|q7_eton_booklet_2019|p1, column text (pdf columns interleave)|about 260 talented boys each|confirmed|'a diverse intake of about 260 talented boys each year'; Admissions Information 2019/20 booklet (old)|

# ---------------- James Allen's Girls'
100863||entry_steps|11+||ISEB Common Pre-Test required (plus JAGS assessment)|text|q7_jags_apply|11+ registration steps|to freely register your daughter for the Common Pre-Test|confirmed|page: main entry is Year 7 'where we have a sizeable intake of external students'; undated; page read 2026-11-07|
100863|2025|oxbridge_places|all||16|places|q7_jags_accounts_2025|Trustees' report, 'Higher Education & Careers', p10|Highlights for this year have included 16 students taking up places at Oxford or Cambridge|confirmed|places taken up by 2025 leavers (started university autumn 2025); accounts year to 31 Aug 2025|

# ---------------- Royal Grammar School Guildford
125424||applicants|11+||400|candidates|q7_rgs_faq|FAQ on 11+ competition|We traditionally have over 400 applicants from over 130 different schools who sit the Entrance Examination|confirmed|'over 400' applicants who sit the exam; undated ('traditionally'); page read 2026-11-07|
125424||places_total|11+||150|places|q7_rgs_faq|same FAQ answer|to secure one of the 150 places available in the First Form.|confirmed|undated; page read 2026-11-07; from Sept 2028 RGS Prep pupils can get Assured Places|
125424||places_external|16+||50-60|places|q7_rgs_faq|co-ed Sixth Form FAQ|we expect roughly one third of all Sixth Form places (i.e. 50-60) to be available to external candidates.|confirmed|expected for the first co-ed Sixth Form intake (Sept 2027); page read 2026-11-07|
125424||entry_steps|11+||ISEB Common Pre-Test; interview and English creative writing task; second interview; offers unconditional|text|q7_rgs_faq|ISEB FAQ|No, the Common Pre-Tests are usually taken in Year 6 and then any offer made by the RGS is unconditional for 11+ entry.|confirmed|undated; page read 2026-11-07|

# ---------------- Kingston Grammar School
102619||applicants|11+||800 - 900|candidates|q7_kgs_faq|FAQ on ratio|At 11+, the ratio it is approximately 800 – 900 candidates for 150 places.|confirmed|range as printed; undated; page read 2026-11-07|
102619||places_total|11+||150|places|q7_kgs_faq|FAQ on ratio|At 11+, the ratio it is approximately 800 – 900 candidates for 150 places.|confirmed|undated; page read 2026-11-07|
102619||applicants|16+||200|candidates|q7_kgs_faq|FAQ on ratio|For 16+, the ratio is approximately 200+ candidates for up to 50 places.|confirmed|printed as '200+'; undated; page read 2026-11-07|
102619||places_external|16+||50|places|q7_kgs_faq|FAQ on ratio|For 16+, the ratio is approximately 200+ candidates for up to 50 places.|confirmed|'up to 50'; undated; page read 2026-11-07|
102619||entry_steps|11+||school's own English and Maths papers; interview|text|q7_kgs_11|11+ page, interviews|Candidates who demonstrate potential in the written assessments will be invited for an interview.|confirmed|undated; page read 2026-11-07|

# ---------------- Bancroft's
102875||places_external|11+||65|places|q7_bancrofts_11|11+ page, offers section|We are looking to fill around 65 places from external candidates at our 11+ entry point.|confirmed|undated (2027-entry cycle page); page read 2026-11-07|
102875||from_own_junior|11+||all|share|q7_bancrofts_faq|FAQ on Prep progression|Every pupil at Bancroft's Prep automatically progresses to the Senior School|confirmed|automatic progression, no 11+; undated; page read 2026-11-07|
102875||entry_steps|11+||online reasoning test, short English and maths papers; interview|text|q7_bancrofts_11|11+ page, assessments|Children sit three papers: an online reasoning test; a short English paper and a short maths test.|confirmed|undated; page read 2026-11-07|
102875||places_external|16+||20|places|q7_bancrofts_16|16+ page|We are looking to admit around 20 external applicants at our 16+ entry point.|confirmed|undated (2027-entry cycle page); page read 2026-11-07|
102875||entry_steps|16+||entrance examination and interview in Year 11|text|q7_bancrofts_16|16+ page|Entry to the Sixth Form is based on performance in an entrance examination and an interview, which take place while candidates are in Year 11.|confirmed|undated; page read 2026-11-07|

# ---------------- Tonbridge School (no junior school)
118959||places_total|13+||150|places|q7_tonbridge_13|13+ page, intro|The main entry point is in Year 9 when around 150 boys join the School.|confirmed|undated; page read 2026-11-07|
118959||entry_steps|13+||ISEB Pre-Test in Year 6; Experience Afternoon with one-to-one interview; unconditional offer, wait list or provisional offer|text|q7_tonbridge_13|13+ process|Boys applying in Year 6 are required to sit the ISEB Pre-Test.|confirmed|undated; page read 2026-11-07|
118959||entry_steps|16+||initial assessment; subject exams and English exam; online interview with subject teacher|text|q7_tonbridge_16|16+ process|Based on the results of these exams, applicants may be invited to an online interview with a subject specialist teacher.|confirmed|undated; page read 2026-11-07|
"""
