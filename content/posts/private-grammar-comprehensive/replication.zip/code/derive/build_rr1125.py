"""Build data/derived/rr1125_school_type.csv: every school-type split in DfE RR1125 (Anderson & Nelson, LEO,
KS4 cohorts 2001/02-2006/07), parsed from the PDF text with pdfplumber.

Tables with a 'School type' block: 5 (pathway representativeness), 6 (outcomes 15 years after GCSEs),
7 (graduate minus non-graduate), 8 (non-graduates: level 3+ minus level 2 or below), 11 (state non-selective
graduates vs selective non-graduates). No figure title mentions school type (chart images not inspected).

Usage: .venv/Scripts/python -I code/derive/build_rr1125.py
"""
import re
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
import pdfplumber  # noqa: E402
from common import latest_raw, assert_unique, write_derived  # noqa: E402

TYPE = {"State-funded (non-selective)": "non_selective", "Independent": "independent", "Selective": "selective"}
PCT, PP, GBP = r"(\d+)%", r"(\d+)", r"£([\d,]+)"
C0102 = ("2001/02", "2017-18")
# table: (row regex for the values, [(measure, unit)], subgroup, (KS4 cohort, tax year))
TABLES = {
    5: ([PCT], [("share_in_50_most_common_pathways", "pct")], "all", ("2001/02-2006/07", "2003-04 to 2017-18")),
    6: ([PCT, PCT, GBP], [("employment_rate", "pct"), ("out_of_work_benefits_rate", "pct"),
                          ("average_earnings", "gbp")], "all", C0102),
    7: ([PP, GBP], [("employment_diff_graduate_minus_nongraduate", "pp"),
                    ("average_earnings_diff_graduate_minus_nongraduate", "gbp")], "all", C0102),
    8: ([PP, GBP], [("employment_diff_level3plus_minus_level2orbelow", "pp"),
                    ("average_earnings_diff_level3plus_minus_level2orbelow", "gbp")], "non_graduates", C0102),
    11: ([PCT, PCT, GBP], [("employment_rate", "pct"), ("out_of_work_benefits_rate", "pct"),
                           ("average_earnings_in_employment", "gbp")], None, C0102),
}
T11 = {"State-funded (non-selective) graduates": ("non_selective", "graduates"),
       "Selective non-graduates": ("selective", "non_graduates")}


def main():
    path = latest_raw("rr1125", "RR1125_post16_pathways_LEO.pdf")
    with pdfplumber.open(path) as pdf:
        pages = [pg.extract_text() or "" for pg in pdf.pages]
    out = []
    for tno, (pats, measures, subgroup, (cohort, tax_year)) in TABLES.items():
        hits = [i for i, t in enumerate(pages) if re.search(rf"^Table {tno}:", t, re.M)]
        assert len(hits) == 1, (tno, hits)
        i = hits[0]
        lines = pages[i].splitlines()
        title = next(ln for ln in lines if ln.startswith(f"Table {tno}:"))
        printed = lines[-1].strip()
        assert printed == str(i + 1), f"printed page {printed} != pdf page {i + 1}"
        k = lines.index("School type")
        labels = T11 if tno == 11 else TYPE
        n = 0
        for ln in lines[k + 1:]:
            m = re.fullmatch(r"(.+?) " + " ".join(pats), ln.strip())
            if not m or m.group(1) not in labels:
                break
            school_type, sub = labels[m.group(1)] if tno == 11 else (labels[m.group(1)], subgroup)
            for (measure, unit), raw in zip(measures, m.groups()[1:]):
                out.append({"table": tno, "measure": measure, "school_type": school_type, "subgroup": sub,
                            "value": int(raw.replace(",", "")), "unit": unit, "page": i + 1,
                            "ks4_cohort": cohort, "tax_year": tax_year, "table_title": title})
            n += 1
        assert n == len(labels), f"table {tno}: parsed {n} school-type rows"
    d = pd.DataFrame(out)
    assert_unique(d, ["table", "measure", "school_type", "subgroup"], "rr1125")
    write_derived(d, "rr1125_school_type")


if __name__ == "__main__":
    main()
