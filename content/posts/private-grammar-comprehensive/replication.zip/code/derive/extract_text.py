"""Plain-text extraction of downloaded source files (untrusted data: read only, never executed).

Usage as a module:  text_of(path) -> str ; norm(text) -> whitespace-collapsed text for snippet matching.
Usage as a script:  .venv/Scripts/python -I code/derive/extract_text.py <file> [--pages]
- PDF: pdfplumber (README rule), pages separated by "\f" and headed "=== page N ===".
- HTML: stdlib html.parser; script/style/noscript dropped; block tags become newlines; tables become
  " | "-separated cells, one row per line.
- CSV/XLSX: pandas, every sheet, "=== sheet NAME ===" headers, cells " | "-separated.
- Issuu page text layer (.bin, layers.isu.pub/.../v2/page_N.bin, gzip or not): protobuf; the publisher's text runs
  (field 9 > 2 > 1), one per line, in the layer's order (a table's cells need not come in reading order).
"""
import gzip
import html
import io
import pathlib
import re
import sys
from html.parser import HTMLParser

BLOCK = {"p", "div", "br", "li", "ul", "ol", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "table", "section",
         "article", "header", "footer", "dt", "dd", "figcaption", "caption", "thead", "tbody", "summary"}
SKIP = {"script", "style", "noscript", "svg", "template"}


class _Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in SKIP:
            self.skip += 1
        elif tag in BLOCK:
            self.out.append("\n")
        elif tag in ("td", "th"):
            self.out.append(" | ")
        elif tag == "a":
            href = dict(attrs).get("href") or ""
            if re.search(r"\.(pdf|csv|xlsx?|docx?)(\?|$)", href, re.I):
                self.out.append(f" [link: {href}] ")

    def handle_endtag(self, tag):
        if tag in SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in BLOCK:
            self.out.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.out.append(data)


class _Tables(HTMLParser):
    """Every <table> as rows of cell texts, with the last text block seen before the table as `heading`."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables, self.last_text, self.cell, self.row, self.rows, self.depth, self.skip = [], "", None, None, None, 0, 0
        self.buf = []

    def handle_starttag(self, tag, attrs):
        if tag in SKIP:
            self.skip += 1
        elif tag == "table":
            self.depth += 1
            if self.depth == 1:
                self.rows, self.heading = [], self.last_text
        elif tag == "tr" and self.depth == 1:
            self.row = []
        elif tag in ("td", "th") and self.depth == 1:
            self.cell = []
        elif tag in BLOCK and self.depth == 0:
            self._flush()

    def handle_endtag(self, tag):
        if tag in SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in ("td", "th") and self.depth == 1 and self.cell is not None:
            self.row.append(re.sub(r"\s+", " ", "".join(self.cell)).strip())
            self.cell = None
        elif tag == "tr" and self.depth == 1 and self.row is not None:
            self.rows.append(self.row)
            self.row = None
        elif tag == "table":
            if self.depth == 1:
                self.tables.append({"heading": self.heading, "rows": self.rows})
            self.depth -= 1
        elif tag in BLOCK and self.depth == 0:
            self._flush()

    def _flush(self):
        t = re.sub(r"\s+", " ", "".join(self.buf)).strip()
        if t:
            self.last_text = t
        self.buf = []

    def handle_data(self, data):
        if self.skip:
            return
        if self.cell is not None:
            self.cell.append(data)
        elif self.depth == 0:
            self.buf.append(data)


def tables_of(path):
    """[{heading, rows}] for every top-level <table> in an HTML file (cells whitespace-collapsed)."""
    p = _Tables()
    p.feed(pathlib.Path(path).read_bytes().decode("utf-8", errors="replace").replace("\xa0", " "))
    return p.tables


def _html(path):
    raw = path.read_bytes().decode("utf-8", errors="replace")
    p = _Text()
    p.feed(raw)
    txt = html.unescape("".join(p.out)).replace("\xa0", " ")
    lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in txt.splitlines()]
    return "\n".join(ln for ln in lines if ln)


def _pdf(path):
    import pdfplumber
    with pdfplumber.open(path) as pdf:
        return "\f".join(f"=== page {i} ===\n{pg.extract_text() or ''}" for i, pg in enumerate(pdf.pages, 1))


def _table(path):
    import pandas as pd
    if path.suffix.lower() == ".csv":
        sheets = {"csv": pd.read_csv(path, dtype=str, keep_default_na=False, header=None, encoding="utf-8-sig",
                                     encoding_errors="replace")}
    else:
        sheets = pd.read_excel(path, sheet_name=None, dtype=str, header=None)
    out = []
    for name, df in sheets.items():
        out.append(f"=== sheet {name} ===")
        for row in df.fillna("").itertuples(index=False):
            out.append(" | ".join(str(c) for c in row))
    return "\n".join(out)


def _pb_fields(buf):
    """(field, wire type, value) of one protobuf message; stops at the first malformed field."""
    out, i = [], 0
    try:
        while i < len(buf):
            key, i = _varint(buf, i)
            f, wt = key >> 3, key & 7
            if wt == 0:
                v, i = _varint(buf, i)
            elif wt in (1, 5):
                v, i = buf[i:i + (8 if wt == 1 else 4)], i + (8 if wt == 1 else 4)
            elif wt == 2:
                n, i = _varint(buf, i)
                v, i = buf[i:i + n], i + n
            else:
                break
            out.append((f, wt, v))
    except IndexError:
        pass
    return out


def _varint(buf, i):
    r = s = 0
    while True:
        c = buf[i]
        i, r, s = i + 1, r | (c & 0x7F) << s, s + 7
        if c < 0x80:
            return r, i


def _issuu_layer(path):
    b = path.read_bytes()
    if b[:2] == b"\x1f\x8b":
        b = gzip.decompress(b)
    runs = []
    for f, wt, v in _pb_fields(b):
        if (f, wt) != (9, 2):
            continue
        for f2, wt2, v2 in _pb_fields(v):
            if (f2, wt2) == (2, 2):
                text = [v3 for f3, wt3, v3 in _pb_fields(v2) if (f3, wt3) == (1, 2)]
                if text:
                    runs.append(text[0].decode("utf-8", errors="replace"))
    return "\n".join(runs)


def text_of(path) -> str:
    path = pathlib.Path(path)
    suf = path.suffix.lower()
    if suf == ".pdf":
        return _pdf(path)
    if suf in (".html", ".htm"):
        return _html(path)
    if suf in (".csv", ".xlsx", ".xls"):
        return _table(path)
    if suf == ".bin" and path.name.startswith("issuu_"):
        return _issuu_layer(path)
    return path.read_bytes().decode("utf-8", errors="replace")


def norm(s: str) -> str:
    s = s.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    s = s.replace("–", "-").replace("—", "-").replace("\xa0", " ").replace("|", " ")  # | = table-cell joiner
    return re.sub(r"\s+", " ", s).strip().lower()


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    print(text_of(sys.argv[1]))
