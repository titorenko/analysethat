"""Build the 16-18 (KS5) derived tables:
  ks5_school.csv           urn x time_period x exam_cohort (A level, Academic), disadvantage = Total
  ks5_astar_a_school.csv   urn x time_period x qualification (GCE A level; IB Higher level component)
  national_ks5_by_type.csv national 16-18 indicators by institution type, sex, exam cohort (long)

Usage: .venv/Scripts/python -I code/derive/build_ks5.py
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
from common import latest_raw, read_ees, num, flag, assert_unique, write_derived  # noqa: E402

COHORTS = ["A level", "Academic"]
PERF_COLS = ["end1618_student_count", "aps_per_entry_student_count", "aps_per_entry", "aps_per_entry_grade",
             "best_three_alevels_student_count", "best_three_alevels_aps", "best_three_alevels_grade",
             "aab_student_count", "aab_percent", "value_added", "value_added_lower_ci", "value_added_upper_ci",
             "progress_banding"]
NUMERIC = {"end1618_student_count", "aps_per_entry_student_count", "aps_per_entry", "best_three_alevels_student_count",
           "best_three_alevels_aps", "aab_student_count", "aab_percent", "value_added", "value_added_lower_ci",
           "value_added_upper_ci"}
FLAGGED = ["aps_per_entry", "value_added"]          # keep the suppression symbol for these
# qualification -> (exam cohort, top grade, second grade); IB HL 7/6 carry the same UCAS tariff as A*/A (56/48)
TOP_GRADES = {"GCE A level": ("A level", "A*", "A"), "IBO Higher level component": ("Other academic", "7", "6")}


def period(tp: pd.Series) -> pd.Series:
    return tp.str[:4] + "/" + tp.str[4:]


def ks5_school():
    perf_p = latest_raw("dfe_ks5", "ks5_performance_v*.csv")
    va_p = latest_raw("dfe_ks5", "ks5_subject_va_v*.csv")
    gr_p = latest_raw("dfe_ks5", "ks5_subject_grades_v*.csv")
    p = read_ees(perf_p)
    p = p[(p.disadvantage_status == "Total") & p.exam_cohort.isin(COHORTS)].copy()
    assert_unique(p, ["school_urn", "time_period", "exam_cohort"], "ks5 performance")
    out = pd.DataFrame({"urn": p.school_urn, "school_name": p.school_name, "time_period": period(p.time_period),
                        "exam_cohort": p.exam_cohort})
    for c in PERF_COLS:
        out[c] = (num(p[c]).astype("Int64") if c.endswith("_count") else num(p[c])) if c in NUMERIC else p[c]
        if c in FLAGGED:
            out[c + "_flag"] = flag(p[c])
    # A-level VA entries (2024/25 only: qualification and subject VA file)
    va_all = read_ees(va_p)
    va_all = va_all[(va_all.exam_cohort == "A level") & (va_all.subject == "All subjects")]
    va = va_all[va_all.qualification_detailed == "GCE A level"]
    assert_unique(va, ["school_urn"], "A level VA all subjects")
    as_nc = va_all[va_all.qualification_detailed == "GCE AS level (Not continued to A2)"]
    assert_unique(as_nc, ["school_urn"], "AS not continued VA all subjects")
    # A-level exam entries (2024/25 only: subject entries and grades file)
    gr = read_ees(gr_p)
    gr = gr[(gr.exam_cohort == "A level") & (gr.qualification_detailed == "GCE A level") & (gr.subject == "All subjects")
            & (gr.grade == "Total exam entries")]
    assert_unique(gr, ["school_urn"], "A level total exam entries")
    sel = (out.time_period == "2024/25") & (out.exam_cohort == "A level")
    out["va_entries"] = pd.NA
    out["va_entries_flag"] = ""
    out["alevel_exam_entries"] = pd.NA
    out.loc[sel, "va_entries"] = num(out.loc[sel, "urn"].map(va.set_index("school_urn").entries_count).fillna(""))
    out.loc[sel, "va_entries_flag"] = out.loc[sel, "urn"].map(va.set_index("school_urn").entries_count).fillna("absent")
    out.loc[sel, "va_entries_flag"] = out.loc[sel, "va_entries_flag"].where(out.loc[sel, "va_entries"].isna(), "")
    out.loc[sel, "alevel_exam_entries"] = num(out.loc[sel, "urn"].map(gr.set_index("school_urn").entries_count).fillna(""))
    out["va_entries"] = pd.to_numeric(out.va_entries).astype("Int64")
    out["alevel_exam_entries"] = pd.to_numeric(out.alevel_exam_entries).astype("Int64")
    out["va_coverage"] = (out.va_entries / out.alevel_exam_entries).astype("Float64")
    # DfE's own VA entry count is size-weighted: A levels + 0.5 x AS levels not continued to A2 (see G4)
    out["va_entries_as_nc"] = pd.NA
    out.loc[sel, "va_entries_as_nc"] = num(out.loc[sel, "urn"].map(as_nc.set_index("school_urn").entries_count).fillna(""))
    out["va_entries_as_nc"] = pd.to_numeric(out.va_entries_as_nc).astype("Int64")
    out["va_entries_weighted"] = (out.va_entries + 0.5 * out.va_entries_as_nc.fillna(0)).astype("Float64")
    write_derived(out.sort_values(["urn", "time_period", "exam_cohort"]), "ks5_school")
    return gr_p


def ks5_astar_a(gr_p):
    gr = read_ees(gr_p)
    rows = []
    for qual, (cohort, top, second) in TOP_GRADES.items():
        q = gr[(gr.exam_cohort == cohort) & (gr.qualification_detailed == qual) & (gr.subject == "All subjects")]
        assert_unique(q, ["school_urn", "grade"], qual)
        w = q.pivot(index=["school_urn", "school_name", "time_period"], columns="grade", values="entries_count").fillna("")
        for col in [top, second, "Total exam entries", "Suppressed"]:
            if col not in w:
                w[col] = ""
        d = pd.DataFrame({"urn": w.index.get_level_values(0), "school_name": w.index.get_level_values(1),
                          "time_period": period(w.index.get_level_values(2).to_series()).values,
                          "qualification": qual, "astar_grade_label": top, "a_grade_label": second,
                          "astar_count": num(w[top]).values, "a_count": num(w[second]).values,
                          "total_entries": num(w["Total exam entries"]).values,
                          "suppressed_entries": num(w["Suppressed"]).values})
        for col in ["astar_count", "a_count", "total_entries", "suppressed_entries"]:
            d[col] = d[col].astype("Int64")
        d["suppressed_entries"] = d.suppressed_entries.fillna(0)
        bad = d.suppressed_entries > 0
        d.loc[bad, ["astar_count", "a_count"]] = pd.NA      # grades withheld: counts shown as 0 with a 'Suppressed' row
        d["pct_astar_a"] = 100 * (d.astar_count + d.a_count) / d.total_entries
        rows.append(d)
    out = pd.concat(rows, ignore_index=True)
    assert_unique(out, ["urn", "time_period", "qualification"], "ks5_astar_a_school")
    write_derived(out.sort_values(["urn", "qualification"]), "ks5_astar_a_school")


def national():
    specs = [("attainment_inst_sex", "ks5_nat_attainment_inst_sex_v*.csv"),
             ("va_inst_sex", "ks5_nat_va_inst_sex_v*.csv"),
             ("prior_attainment_inst_sex", "ks5_nat_prior_attainment_inst_sex_v*.csv")]
    keys = ["time_period", "establishment_type_group", "establishment_type", "sex", "exam_cohort"]
    parts = []
    for name, pat in specs:
        df = read_ees(latest_raw("dfe_ks5", pat))
        assert_unique(df, keys, name)
        ind = [c for c in df.columns if c not in keys + ["time_identifier", "geographic_level", "country_code",
                                                          "country_name", "version"]]
        long = df.melt(id_vars=keys + ["version"], value_vars=ind, var_name="indicator", value_name="value")
        long.insert(0, "dataset", name)
        parts.append(long)
    out = pd.concat(parts, ignore_index=True)
    out["time_period"] = period(out.time_period)
    out["value_num"] = num(out.value)
    out = out[["dataset", "time_period", "establishment_type_group", "establishment_type", "sex", "exam_cohort",
               "indicator", "value", "value_num", "version"]]
    write_derived(out, "national_ks5_by_type")


if __name__ == "__main__":
    gr_path = ks5_school()
    ks5_astar_a(gr_path)
    national()
