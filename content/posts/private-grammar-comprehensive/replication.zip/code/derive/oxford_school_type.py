"""Oxford Annual Admissions Statistical Reports (2018, 2020-2026 editions) -> oxford_school_type.csv, oxford_context.csv.

Table 4.1 ('UK applications to Oxford, offers made and students admitted by school type') gives five UCAS cycles
per report: state and independent applications / offers / admitted plus the printed state share of UK admitted.
Every report vintage is kept (column report_year); latest_vintage marks the row from the newest report covering
that cycle. The printed state share is asserted to equal round(state / (state + independent) admitted, 1 dp).
The CONTEXT box beside it gives the state vs independent/other split of the national AAA+ and A*A*A+ pools and
of Oxford's own UK intake.

    .venv/Scripts/python -I code/derive/oxford_school_type.py
"""
import re
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import latest_raw, rel, write_derived  # noqa: E402

import pandas as pd  # noqa: E402
import pdfplumber  # noqa: E402

REPORTS = {2018: "oxford_admissions_report_2018.pdf", 2020: "oxford_admissions_report_2020.pdf",
           2021: "oxford_admissions_report_2021.pdf", 2022: "oxford_admissions_report_2022.pdf",
           2023: "oxford_admissions_report_2023.pdf", 2024: "oxford_admissions_report_2024.pdf",
           2025: "oxford_admissions_report_2025.pdf", 2026: "oxford_ug_admissions_report_2026.pdf"}
ROW = re.compile(r"^(20\d\d) ([\d,]+) ([\d,]+) ([\d,]+) ([\d,]+) ([\d,]+) ([\d,]+) (\d+\.\d)%$", re.M)
PCT = re.compile(r"(\d+\.\d)%")
CONTEXT = [  # measure, start marker, end marker of its segment in the CONTEXT box
    ("aaa_plus_pool", "AAA or better at A-level", "A*A*A or better"),
    ("astar_astar_a_plus_pool", "A*A*A or better at A-level", "Oxford University ("),
    ("oxford_uk_admitted", "Oxford University (", None),
]


def i(s):
    return int(s.replace(",", ""))


def parse(report_year, path):
    with pdfplumber.open(path) as pdf:
        hits = [(n, pg.extract_text()) for n, pg in enumerate(pdf.pages, 1)
                if "Table 4.1: UK applications to Oxford" in (pg.extract_text() or "")]
        full = "\n".join(pg.extract_text() or "" for pg in pdf.pages)
    if len(hits) != 1:
        raise ValueError(f"{path.name}: Table 4.1 found on {len(hits)} pages")
    pno, text = hits[0]
    rows = ROW.findall(text)
    years = [int(r[0]) for r in rows]
    if years != list(range(report_year - 1, report_year - 6, -1)):
        raise ValueError(f"{path.name}: Table 4.1 years {years}")
    st, ctx = [], []
    for r in rows:
        y, sa, so, sd, ia, io, idd, share = int(r[0]), *map(i, r[1:7]), float(r[7])
        if round(100 * sd / (sd + idd), 1) != share:
            raise ValueError(f"{path.name} {y}: printed state share {share} != {100 * sd / (sd + idd):.2f}")
        for school_type, a, o, d in (("state", sa, so, sd), ("independent", ia, io, idd)):
            st.append({"report_year": report_year, "cycle": y, "school_type": school_type, "applications": a,
                       "offers": o, "admitted": d, "state_share_uk_admitted_pct_printed": share,
                       "source_table": "Table 4.1", "source_page": pno, "source_file": rel(path)})
    box = " ".join(text[text.index("CONTEXT"):].split())
    for measure, start, end in CONTEXT:
        seg = box[box.index(start): box.index(end, box.index(start)) if end else None]
        pcts = [float(p) for p in PCT.findall(seg)[:2]]
        if measure == "oxford_uk_admitted":
            ref = re.search(r"Oxford University \((\d{4}) UK intake\)", seg)
            reference, ref_year, basis = f"Oxford, {ref.group(1)} UK intake", int(ref.group(1)), \
                "Oxford Table 4.1 admitted (state vs independent; other/unclassified excluded)"
        else:
            ref = re.search(r"\(all UK universities, ?([^)]*)\)", seg)
            reference, ref_year = f"all UK universities, {ref.group(1)}", int(re.search(r"\d{4}", ref.group(1)).group())
            if "main admissions scheme acceptances" in ref.group(1):
                basis = "UCAS: UK-domiciled main-scheme acceptances to UK universities (replaces the HESA basis of earlier reports)"
            elif "UK intake" in ref.group(1) and "first-year, first-degree" in full and "HESA" in full:
                basis = "HESA Student Record: first-year first-degree UK-domiciled undergraduates; unknown school type excluded"
            else:
                raise ValueError(f"{path.name}: unknown context basis {ref.group(1)!r}")
        if len(pcts) != 2 or abs(sum(pcts) - 100) > 0.15:
            raise ValueError(f"{path.name} {measure}: percentages {pcts}")
        ctx.append({"report_year": report_year, "measure": measure, "reference": reference,
                    "reference_year": ref_year, "basis": basis, "state_pct": pcts[0],
                    "independent_other_pct": pcts[1], "source_page": pno, "source_file": rel(path)})
    return st, ctx


def main():
    st, ctx = [], []
    for y, fn in REPORTS.items():
        a, b = parse(y, latest_raw("oxford", fn))
        st += a
        ctx += b
        print(y, f"Table 4.1 cycles {a[-1]['cycle']}-{a[0]['cycle']}", "p", a[0]["source_page"])
    st = pd.DataFrame(st)
    st["latest_vintage"] = st.report_year == st.groupby("cycle").report_year.transform("max")
    # revisions between vintages
    key = ["cycle", "school_type"]
    for m in ["applications", "offers", "admitted"]:
        spread = st.groupby(key)[m].agg(["min", "max"])
        rev = spread[spread["min"] != spread["max"]]
        print(f"revisions in {m}:", "none" if rev.empty else rev.to_dict("index"))
    write_derived(st, "oxford_school_type")
    write_derived(pd.DataFrame(ctx), "oxford_context")


if __name__ == "__main__":
    main()
