"""Build glms_2024_employment.csv: DfE Graduate labour market statistics, calendar year 2024 (published 5 Jun 2025;
series discontinued). England, LFS-based. Employment rates and part-time shares by graduate type, sex and age band.
Feeds the engine's employment scenario (PLAN v2 §4.5).

Usage: .venv/Scripts/python -I code/derive/build_glms.py
"""
import io
import zipfile
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
from common import latest_raw, rel, write_derived  # noqa: E402

p = latest_raw("dfe_glms", "glms_2024_all_files.zip")
z = zipfile.ZipFile(p)


def read(name):
    return pd.read_csv(io.BytesIO(z.read(f"data/{name}")), dtype=str, keep_default_na=False)


rows = []
e = read("employment_rates_by_graduate_type3_200724.csv")
for r in e[e.time_period == "2024"].itertuples():
    rows.append(("employment_rate", r.graduate_type, "age", r.age_band, r.employment_rate,
                 "employment_rates_by_graduate_type3_200724.csv"))
b = read("graduate_breakdowns_emp_rates2_2024.csv")
for r in b[b.graduate_characteristic == "Sex"].itertuples():
    rows.append(("employment_rate", "Graduate", "sex", r.graduate_breakdown, r.employment_rate,
                 "graduate_breakdowns_emp_rates2_2024.csv"))
pt = read("pt_breakdowns_emp_rates_by_graduate_type3_200724.csv")
for r in pt[pt.time_period == "2024"].itertuples():
    rows.append(("part_time_share_of_employed", r.graduate_type, r.breakdown_topic.lower().replace(" band", ""),
                 r.breakdown, r.employment_proportion_part_time, "pt_breakdowns_emp_rates_by_graduate_type3_200724.csv"))
df = pd.DataFrame(rows, columns=["measure", "graduate_type", "breakdown_topic", "breakdown", "value_raw", "file"])
df["value_pct"] = pd.to_numeric(df.value_raw, errors="coerce")          # 'c' suppressed, 'z' no sample
df["year"] = 2024
df["source_file"] = rel(p) + "::data/" + df.pop("file")
assert df.duplicated(["measure", "graduate_type", "breakdown_topic", "breakdown"]).sum() == 0
write_derived(df, "glms_2024_employment")
