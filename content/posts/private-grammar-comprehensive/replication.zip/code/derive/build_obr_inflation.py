"""Build obr_inflation_2026_03.csv: OBR March 2026 EFO, detailed forecast tables (economy), Table 1.7, fiscal-year
RPI / CPI / CPIH growth (outturn to December 2025, so 2025-26 is part outturn; forecast 2026-27 to 2030-31), plus
Table 1.16 house price index growth. Feeds the engine's real tax-threshold path and the house-premium user cost.

Usage: .venv/Scripts/python -I code/derive/build_obr_inflation.py
"""
import re
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import openpyxl  # noqa: E402
import pandas as pd  # noqa: E402
from common import latest_raw, rel, write_derived  # noqa: E402

p = latest_raw("obr", "efo_march_2026_economy_tables.xlsx")
wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
rows = list(wb["1.7"].iter_rows(values_only=True))
head = rows[3]
assert head[2:6] == ("RPI", "RPIX", "CPI", "CPIH"), head
hp_rows = list(wb["1.16"].iter_rows(values_only=True))
assert "per cent change on a year earlier" in hp_rows[2][3], hp_rows[2][3]
hpi = {r[1]: r[3] for r in hp_rows if isinstance(r[1], str) and re.fullmatch(r"\d{4}-\d{2}", r[1])}
out = []
for r in rows:
    if isinstance(r[1], str) and re.fullmatch(r"\d{4}-\d{2}", r[1]):
        out.append({"fiscal_year": r[1], "rpi_pct": r[2], "cpi_pct": r[4], "cpih_pct": r[5],
                    "house_price_pct": hpi.get(r[1]),
                    "status": "forecast" if r[1] >= "2026-27" else "part_outturn" if r[1] == "2025-26" else "outturn",
                    "source_file": rel(p), "source_table": "1.7 Inflation; 1.16 Housing market (house prices)"})
df = pd.DataFrame(out)
assert df.fiscal_year.is_unique and df.fiscal_year.max() == "2030-31", df.fiscal_year.max()
write_derived(df, "obr_inflation_2026_03")
