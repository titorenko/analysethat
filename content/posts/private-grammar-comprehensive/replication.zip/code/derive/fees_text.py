"""Text of saved fee pages and charity accounts, and checks that a transcribed number is really on the page.

Used by build_fees.py, build_bursaries.py and checks/g_fees.py. Saved files are untrusted data: they are only
read and parsed here (HTML as text, JSON with json.loads, PDF with pdfplumber), never executed.
"""
import html
import json
import pathlib
import re

import pdfplumber

SPACES = re.compile(r"[\s   ​]+")


def _html_text(raw: str) -> str:
    raw = re.sub(r"(?is)<(script|style|noscript)[^>]*>.*?</\1>", " ", raw)
    raw = re.sub(r"(?i)</t[dh]>", " | ", raw)
    raw = re.sub(r"(?i)<br\s*/?>|</(p|div|li|tr|h\d|table|section|dt|dd)>", "\n", raw)
    return html.unescape(re.sub(r"<[^>]+>", " ", raw))


def _json_text(raw: str) -> str:
    leaves = []

    def walk(o):
        if isinstance(o, dict):
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
        elif isinstance(o, str):
            leaves.append(o)
    walk(json.loads(raw))
    return _html_text("\n".join(leaves))


def pdf_pages(path: pathlib.Path) -> list[str]:
    with pdfplumber.open(path) as pdf:
        return [pg.extract_text() or "" for pg in pdf.pages]


def page_text(path: pathlib.Path) -> str:
    """Whitespace-normalised visible text of a saved .html / JSON / .pdf / .md file."""
    path = pathlib.Path(path)
    if path.suffix == ".pdf":
        t = "\n".join(pdf_pages(path))
    else:
        raw = path.read_bytes().decode("utf-8", errors="replace").lstrip("﻿")
        if path.suffix == ".md":
            t = raw
        elif raw.lstrip().startswith("{"):
            t = _json_text(raw)
        else:
            t = _html_text(raw)
    return norm(t)


def norm(t: str) -> str:
    return SPACES.sub(" ", t).strip()


def amount_positions(text: str, amount: str) -> list[int]:
    """Start positions of `amount` (as printed, e.g. '15,451' or '9,848.40') not embedded in a longer number."""
    pat = r"(?<![\d,.])" + re.escape(amount) + r"(?![\d]|[.,]\d)"
    return [m.start() for m in re.finditer(pat, text)]


def near(text: str, label: str, amount: str, window: int = 600):
    """(ok, snippet): `amount` occurs within `window` characters after an occurrence of `label`
    (case-insensitive), or within 150 characters before it."""
    lab = [m.start() for m in re.finditer(re.escape(norm(label)), text, flags=re.I)]
    amt = amount_positions(text, amount)
    for a in amt:
        for l in lab:
            if -150 <= a - l <= window:
                lo, hi = min(a, l), max(a, l) + len(amount)
                return True, text[max(0, lo - 40): hi + 40]
    return False, f"label hits {len(lab)}, amount hits {len(amt)}"
