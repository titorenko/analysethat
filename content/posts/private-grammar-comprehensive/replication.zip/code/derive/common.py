"""Shared helpers for derived-table builders (code/derive) and gates (code/checks).

Import under -I with:
    import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
"""
import datetime as dt
import pathlib

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
RAW = ROOT / "data" / "raw"
DERIVED = ROOT / "data" / "derived"
GATES_LOG = ROOT / "logs" / "gates.md"

# EES suppression / not-applicable symbols (EES symbol guide + performance-table abbreviations)
SYMBOLS = {"c", "z", "x", "low", "u", "k", "~", ":", "SUPP", "NP", "NE", "LOWCOV", "SP", "NA", "DNS", "NEW", ""}


def latest_raw(source: str, pattern: str) -> pathlib.Path:
    """Newest snapshot file data/raw/<source>/<day>/<pattern>; error if none or ambiguous."""
    for day in sorted((RAW / source).iterdir(), reverse=True):
        hits = sorted(day.glob(pattern))
        if len(hits) > 1:
            raise RuntimeError(f"ambiguous {pattern} in {day}: {[h.name for h in hits]}")
        if hits:
            return hits[0]
    raise FileNotFoundError(f"{source}/{pattern}")


def rel(path: pathlib.Path) -> str:
    return str(path.relative_to(ROOT)).replace("\\", "/")


def read_ees(path: pathlib.Path, usecols=None) -> pd.DataFrame:
    """All columns as strings; empty cells stay '' (not NaN); BOM stripped."""
    return pd.read_csv(path, dtype=str, keep_default_na=False, encoding="utf-8-sig", usecols=usecols,
                       low_memory=False)


def num(s: pd.Series) -> pd.Series:
    """Numeric value; symbols become NaN (keep the raw string in a *_flag column where it matters)."""
    return pd.to_numeric(s.where(~s.isin(SYMBOLS)), errors="coerce")


def flag(s: pd.Series) -> pd.Series:
    """The suppression symbol if the cell is not numeric, else ''."""
    return s.where(pd.to_numeric(s, errors="coerce").isna(), "")


def check_mapped(values, mapping: dict, what: str):
    unmapped = sorted(set(values) - set(mapping))
    if unmapped:
        raise ValueError(f"unmapped {what}: {unmapped}")


def assert_unique(df: pd.DataFrame, key: list, what: str):
    dup = df.duplicated(key, keep=False)
    if dup.any():
        raise ValueError(f"{what}: {dup.sum()} rows duplicate key {key}; e.g.\n{df[dup].head(6)}")


def write_derived(df: pd.DataFrame, name: str) -> pathlib.Path:
    DERIVED.mkdir(parents=True, exist_ok=True)
    out = DERIVED / f"{name}.csv"
    df.to_csv(out, index=False, encoding="utf-8")
    print(f"wrote {rel(out)}: {len(df):,d} rows x {df.shape[1]} cols")
    return out


class Gate:
    """Collects PASS/FAIL lines, prints them, appends a section to logs/gates.md, returns exit code."""

    def __init__(self, name: str, sources: list):
        self.name, self.sources, self.lines, self.failed, self.notes = name, sources, [], 0, []

    def check(self, label: str, ok: bool, detail: str):
        self.failed += not ok
        self.lines.append(f"- {'PASS' if ok else 'FAIL'} {label}: {detail}")
        print(self.lines[-1])

    def note(self, text: str):
        self.notes.append(text)
        print(text)

    def finish(self) -> int:
        GATES_LOG.parent.mkdir(parents=True, exist_ok=True)
        stamp = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
        verdict = "FAIL" if self.failed else "PASS"
        with GATES_LOG.open("a", encoding="utf-8") as f:
            f.write(f"\n## {self.name} — {verdict} ({stamp})\n")
            f.write("Sources: " + "; ".join(rel(p) for p in self.sources) + "\n\n")
            f.write("\n".join(self.lines) + "\n")
            if self.notes:
                f.write("\n" + "\n".join(self.notes) + "\n")
        print(f"{self.name}: {verdict}")
        return 1 if self.failed else 0
