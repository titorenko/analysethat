"""Imperial College London 'Application figures by School 2020-24' -> imperial_apply_centre.csv.

Input: data/raw/imperial_apply_centre/<day>/Application-figures-by-School-2020-2024.xlsx (publication scheme,
FOI IMPFOI-25-237/276/311): an extract from UCAS End of Cycle PERS 2024, one sheet per entry year 2020-21 ...
2024-25. Sheet '2024-25' is the 2024 UCAS cycle (applications from autumn 2023), so cycle = first year of the
sheet name, the same cycle numbering as the Oxford and Cambridge tables. One row per UCAS apply centre (all
applicant domiciles); counts are not suppressed. 2024-25 splits offers into conditional and unconditional and
gives the total in 'Offers'. Checked by code/checks/g2_imperial_apply_centre.py.

    .venv/Scripts/python -I code/derive/imperial_apply_centre.py
"""
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import assert_unique, latest_raw, rel, write_derived  # noqa: E402

import pandas as pd  # noqa: E402

COLS = {"Apply centre code": "centre_number", "Apply centre name": "centre_name", "Apply centre type": "centre_type",
        "Region": "region", "Applications": "applications", "Offers": "offers", "Total Offers": "offers",
        "Rejections": "rejections", "Rejected": "rejections", "Acceptance": "acceptances",
        "Acceptance of offer": "acceptances"}


def main():
    path = latest_raw("imperial_apply_centre", "Application-figures-by-School-2020-2024.xlsx")
    out = []
    for sheet in ("2020-21", "2021-22", "2022-23", "2023-24", "2024-25"):
        raw = pd.read_excel(path, sheet_name=sheet, header=None)
        hdr = raw.index[raw.iloc[:, 0].astype(str).str.strip() == "Apply centre code"][0]
        d = raw.iloc[hdr + 1:].copy()
        d.columns = [str(c).strip() for c in raw.iloc[hdr]]
        d = d[d["Apply centre code"].notna()].rename(columns=COLS)[list(dict.fromkeys(COLS.values()))]
        d.insert(0, "cycle", int(sheet[:4]))
        out.append(d)
    df = pd.concat(out, ignore_index=True)
    df["centre_number"] = df.centre_number.astype(int)
    for c in ("applications", "offers", "rejections", "acceptances"):
        df[c] = df[c].astype(int)
    assert_unique(df, ["cycle", "centre_number"], "imperial apply centre")
    df["source_file"] = rel(path)
    write_derived(df, "imperial_apply_centre")


if __name__ == "__main__":
    main()
