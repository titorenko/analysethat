"""Build data/derived/beyond_pay.csv: outcomes other than pay, by school type, read from four PDFs.

Sources (data/raw/literature/, fetched by code/harvest/beyond_pay.py):
- IFS briefing (Britton & van der Erve), Table 1 p.9: share of the 2002 GCSE cohort (England) starting each degree by 30.
- Sutton Trust, Elitist Britain 2025: private / grammar / comprehensive shares on each profession's page (46 pages)
  and the population benchmarks on p.15.
- Sutton Trust (2009), Royal Society and British Academy fellows: Table 1 p.6, the 1950-70 school mix p.9 and the
  1950s birth cohort in Appendix 4 p.22.
- Henderson, Anders, Green & Henseke (2022): life satisfaction at 25, Table 1 p.10 (shares) and Table 3 p.11
  (Model 1 raw, Model 3 + family background).
- Sullivan, Parsons, Green, Wiggins & Ploubidis (2018), accepted manuscript (data/raw/literature/2026-10-10): Table 3
  p.31, Model 4 odds ratios of reaching the top social class at 42 (grammar, private other, private Tatler).

Every value is parsed from the pdfplumber text of the stated page (1-based); nothing is typed in. `quote` keeps the
text it was read from; code/checks/g_beyond_pay.py re-checks quotes against the pages and values against quotes.

Usage: .venv/Scripts/python -I code/derive/build_beyond_pay.py
"""
import re
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
import pdfplumber  # noqa: E402
from common import latest_raw, rel, write_derived  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
ROWS = []


def add(source, path, page, quote, group, school_type, measure, value, unit, note=""):
    ROWS.append(dict(row_id=f"{source}-{len([r for r in ROWS if r['source'] == source]) + 1:02d}", source=source,
                     group=group, school_type=school_type, measure=measure, value=float(value), unit=unit,
                     page=page, quote=" ".join(quote.split()), source_file=rel(path), note=note))


def columns(pg):
    """Whole page plus left and right halves (two-column pages)."""
    w, h = pg.width, pg.height
    return [pg.extract_text() or "", pg.crop((0, 0, w / 2, h)).extract_text() or "",
            pg.crop((w / 2, 0, w, h)).extract_text() or ""]


def find(texts, pattern):
    for t in texts:
        m = re.search(pattern, t)
        if m:
            return m
    raise AssertionError(f"not found: {pattern}")


def line(lines, start):
    hits = [ln for ln in lines if ln.startswith(start)]
    assert len(hits) == 1, (start, hits)
    return hits[0]


def nums(s):
    return [float(x) for x in re.findall(r"\d+(?:\.\d+)?", s.replace(",", ""))]


# ------------------------------------------------------------------ IFS: degrees started by age 30
p = latest_raw("literature", "ifs_pg_access.pdf")
with pdfplumber.open(p) as pdf:
    lines = pdf.pages[8].extract_text().splitlines()
assert any("2002 GCSE cohort" in ln for ln in lines)
COLS = ["first_degree", "russell_group_first_degree", "any_postgraduate", "pgce", "masters", "phd", "masters_or_phd"]
for label, group in (("SES Q1 (bottom)", "state_poorest_fifth"), ("SES Q5 (top)", "state_richest_fifth"),
                     ("Private school", "private"), ("Population", "everyone")):
    ln = line(lines, label)
    v = [float(x) for x in re.findall(r"(\d+\.\d)%", ln)]
    assert len(v) == len(COLS), ln
    for c, x in zip(COLS, v):
        add("ifs_pg", p, 9, ln, group, "private" if group == "private" else "state" if "state" in group else "all",
            f"started_{c}_by_30", x, "pct", "2002 GCSE cohort, England; starts, not completions; SES fifths are of "
            "state-school pupils only (area-based index)")

# ------------------------------------------------------------------ Elitist Britain 2025
p = latest_raw("literature", "elitist_britain_2025.pdf")
SHARE = re.compile(r"(\d+)% attended(?: an?)? (\d+)% attended(?: an?)? (\d+)% attended")
with pdfplumber.open(p) as pdf:
    for i, pg in enumerate(pdf.pages, 1):
        t = pg.extract_text() or ""
        if "School attendance" not in t or "|" not in t.split("School attendance")[0]:
            continue
        chapter, prof = (" ".join(s.split()) for s in t.split("School attendance")[0].split("|"))
        m = SHARE.search(t)
        after = t[m.end():m.end() + 120]
        assert re.search(r"Independent [Ss]chool Grammar school", after), (i, after)
        for st, x in zip(("private", "grammar", "comprehensive"), m.groups()):
            add("eb2025", p, i, m.group(0), prof, st, "share_of_group", x, "pct", f"chapter: {chapter}")
    # population benchmarks and the all-elite figure, p.15 (two columns)
    texts = columns(pdf.pages[14])
    for pat, st, measure in (
            (r"we use (\d+)% as the comparison figure", "private", "population_benchmark"),
            (r"consistent at around (\d+)% since the late 70s", "grammar", "population_benchmark_since_late_1970s"),
            (r"for whom the proportion was\s+around\s+(\d+)%", "grammar", "population_benchmark_1960s"),
            (r"Overall, (\d+)% of the\s+elite were privately educated", "private", "share_of_all_elite_uk_schooled")):
        m = find(texts, pat)
        add("eb2025", p, 15, m.group(0), "population" if "benchmark" in measure else "all elite", st, measure,
            m.group(1), "pct")
eb = [r for r in ROWS if r["source"] == "eb2025" and r["measure"] == "share_of_group"]
assert len(eb) == 3 * 46, len(eb)

# ------------------------------------------------------------------ Sutton Trust 2009: RS and BA fellows
p = latest_raw("literature", "sutton_trust_2009_scientists_scholars.pdf")
with pdfplumber.open(p) as pdf:
    lines = pdf.pages[5].extract_text().splitlines()
    assert any("Table 1: Fellows with known UK school backgrounds" in ln for ln in lines)
    for label, st in (("Independent", "private"), ("Direct Grant", "direct_grant"), ("Grammar", "grammar"),
                      ("Non-selective", "non_selective_state")):
        ln = line([x.strip() for x in lines], label + " ")
        n_rs, pct_rs, n_ba, pct_ba, n_all, pct_all = nums(ln)
        for group, n, pc in (("royal_society", n_rs, pct_rs), ("british_academy", n_ba, pct_ba),
                             ("both", n_all, pct_all)):
            add("st2009", p, 6, ln, group, st, "share_of_fellows", pc, "pct")
            add("st2009", p, 6, ln, group, st, "fellows", n, "count")
    ln = line([x.strip() for x in lines], "Total ")
    add("st2009", p, 6, ln, "both", "all", "fellows", nums(ln)[-2], "count")
    t = pdf.pages[8].extract_text()
    for pat, st in ((r"State grammar schools -- educating around (\d+)% of all school pupils", "grammar"),
                    (r"Secondary modern schools -- accounting for approximately (\d+)% of all school pupils",
                     "secondary_modern"),
                    (r"Direct grant schools8 -- making up (\d+)% of school pupils", "direct_grant"),
                    (r"Independent schools -- making up around (\d+)% of all school pupils", "private")):
        m = find([t], pat)
        add("st2009", p, 9, m.group(0), "pupils_1950_1970", st, "share_of_pupils", m.group(1), "pct")
    lines = pdf.pages[21].extract_text().splitlines()
    k = lines.index(next(ln for ln in lines if ln.strip() == "1950 -"))
    ln = lines[k + 1].strip()
    v = nums(ln)
    assert len(v) == 12 and v[0] == 59, ln       # "59" ends the "1950 - 59" label
    for st, pc in (("private", v[3]), ("direct_grant", v[7]), ("grammar", v[9]), ("non_selective_state", v[11])):
        add("st2009", p, 22, "1950 - " + ln, "both_born_1950s", st, "share_of_fellows", pc, "pct",
            "Appendix 4; shares are of the decade's total, which the school counts do not quite sum to")

# ------------------------------------------------------------------ Henderson et al. 2022: life satisfaction at 25
p = latest_raw("literature", "henderson2022_cje.pdf")
with pdfplumber.open(p) as pdf:
    lines = pdf.pages[9].extract_text().splitlines()
    ln = line(lines, "Very or fairly satisfied with life at age 25")
    v = nums(ln.split("age 25")[1])
    for (group, st), x in zip((("men", "state"), ("men", "private"), ("women", "state"), ("women", "private")), v):
        add("hagh2022", p, 10, ln, group, st, "very_or_fairly_satisfied_with_life_at_25", x, "pct",
            "Next Steps, born 1989-90; Table 1 descriptives")
    lines = pdf.pages[10].extract_text().splitlines()
    k = lines.index(next(ln for ln in lines if ln.startswith("Table 3.")))
    k = k + lines[k:].index("Age 25")
    for group in ("all", "men", "women"):
        j = k + lines[k:].index(next(ln for ln in lines[k:] if ln.startswith(f"Life satisfaction ({group})")))
        est, se = lines[j], lines[j + 1]
        e = [float(x.replace("−", "-")) for x in re.findall(r"[−-]?\d\.\d\d", est)]
        s = [float(x) for x in re.findall(r"\((\d\.\d\d)\)", se)]
        assert len(e) == len(s) == 6, (est, se)
        q = est + " " + se
        add("hagh2022", p, 11, q, group, "private_vs_state", "life_satisfaction_at_25_raw", e[0], "frac",
            "Table 3 Model 1 (no controls); linear probability of being very or fairly satisfied")
        add("hagh2022", p, 11, q, group, "private_vs_state", "life_satisfaction_at_25_background", e[2], "frac",
            "Table 3 Model 3: + ethnicity, tenure, parental class and education, region, household income")
        add("hagh2022", p, 11, q, group, "private_vs_state", "life_satisfaction_at_25_background_se", s[2], "frac",
            "Table 3 Model 3 standard error")

# ------------------------------------------------------------------ Sullivan et al. 2018: top social class at 42
p = latest_raw("literature", "sullivan2018_bjs_accepted.pdf")
with pdfplumber.open(p) as pdf:
    lines = pdf.pages[30].extract_text().splitlines()
for label, st in (("Grammar", "grammar"), ("Private – Other", "private_other"), ("Private – Tatler", "private_tatler")):
    k = lines.index(line(lines, label + " "))
    orr = re.match(re.escape(label) + r" (\d\.\d\d)", lines[k]).group(1)
    lo, hi = re.match(r"\[(\d\.\d\d),(\d\.\d\d)\]", lines[k + 1]).groups()
    q = lines[k] + " " + lines[k + 1]
    note = "Table 3 Model 4 (BCS70, both sexes pooled with a gender control; Tatler split for boys only, p.14)"
    for m, x in (("top_class_odds_ratio_m4", orr), ("top_class_odds_ratio_m4_ci_low", lo),
                 ("top_class_odds_ratio_m4_ci_high", hi)):
        add("spgwp2018", p, 31, q, "all", st, m, x, "ratio", note + "; vs comprehensive")

# ------------------------------------------------------------------ Elitist Britain: FTSE 100 among the UK-educated (p.6)
p = latest_raw("literature", "elitist_britain_2025.pdf")
with pdfplumber.open(p) as pdf:
    m = find(columns(pdf.pages[5]), r"When considering\s+only those educated in the UK, (\d+)% of\s+FTSE CEOs and (\d+)% of "
                                    r"FTSE chairs went\s+to private schools")
for group, x in (("FTSE100 CEOs", m.group(1)), ("FTSE100 Chairs", m.group(2))):
    add("eb2025", p, 6, m.group(0), group, "private", "share_of_uk_educated", x, "pct", "key findings")

# ------------------------------------------------------------------ Elitist Britain: data coverage (p.107, right column)
p = latest_raw("literature", "elitist_britain_2025.pdf")
with pdfplumber.open(p) as pdf:
    texts = columns(pdf.pages[106])
m = find(texts, r"(\d+)% was set as a minimum aim for the\s+proportion of data collected for each group")
add("eb2025", p, 107, m.group(0), "all groups", "", "school_known_target", m.group(1), "pct")
m = find(texts, r"For school\s+data, this applied local government, property/\s+land, PR consultancy CEOs, BBC executives,"
                r"\s+public body CEOs, armed forces and police\s+chiefs \(all had at least (\d+)% of data available\)")
add("eb2025", p, 107, m.group(0), "seven groups", "", "school_known_floor", m.group(1), "pct",
    "the seven groups below the target: local government, property/land, PR, BBC, public bodies, armed forces, police")

# ------------------------------------------------------------------ sentences the article quotes or relies on
for fname, page, pat in (
        ("ifs_pg_access.pdf", 15, r"we find that the\s+story is extremely similar when we look at the gaps in \(any\) "
         r"postgraduate study between\s+the privately educated and the poorest 20% of state educated students\. While "
         r"the raw\s+gaps in participation are larger, they also virtually disappear once GCSEs and A levels are\s+"
         r"controlled for"),
        ("ifs_pg_access.pdf", 15, r"we do not have any age 11\s+attainment data for many of them"),
        ("ifs_pg_access.pdf", 7, r"the HESA record includes all\s+undergraduate and postgraduate degrees done in the UK"),
        ("ifs_pg_access.pdf", 13, r"we do not have a\s+sufficiently large sample to break out PhD students separately for "
         r"this analysis"),
        ("elitist_britain_2025.pdf", 15, r"and less than\s+1% in Northern Ireland"),
        ("sullivan2018_bjs_accepted.pdf", 14, r"In the case of boys, we distinguish between the more exclusive\s+"
         r".public. schools from the Tatler list, and other private schools"),
        ("sullivan2018_bjs_accepted.pdf", 15, r"The coefficient for Tatler schools was positive but did not"),
        ("henderson2022_cje.pdf", 12, r"in the final \[and preferred\] models there is no evidence of\s+a difference by "
         r"school type for mental health at age 14 and 25 and life satisfaction for\s+either men or women at age 20 "
         r"and age 25"),
        ("elitist_britain_2025.pdf", 106, r"This includes secondary\s+moderns"),
        ("elitist_britain_2025.pdf", 106, r"so have therefore been categorised as private\s+schools"),
        ("elitist_britain_2025.pdf", 106, r"determined as where an individual spent the\s+majority of their secondary "
         r"education"),
        ("elitist_britain_2025.pdf", 15, r"Note: Excludes members of the elite schooled outside the UK"),
        ("sutton_trust_2009_scientists_scholars.pdf", 4, r"The majority were born\s+before World War 2")):
    p = latest_raw("literature", fname)
    with pdfplumber.open(p) as pdf:
        m = find(columns(pdf.pages[page - 1]), pat)
    src = {"ifs_pg_access.pdf": "ifs_pg", "henderson2022_cje.pdf": "hagh2022", "elitist_britain_2025.pdf": "eb2025",
           "sutton_trust_2009_scientists_scholars.pdf": "st2009", "sullivan2018_bjs_accepted.pdf": "spgwp2018"}[fname]
    add(src, p, page, m.group(0), "", "", "claim", "nan", "text")

df = pd.DataFrame(ROWS)
assert df.row_id.is_unique
write_derived(df, "beyond_pay")
