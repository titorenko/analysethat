"""Build data/derived/independent_bursaries.csv: fee income and fee remissions (bursaries, scholarships and other
concessions) from the latest charity accounts of the 45 independents in top30_independent.csv.

Accounts are the Charity Commission filings mirrored by OpenCharities (data/raw/charity_accounts/<day>/):
<number>_<fy end>_accounts.pdf (read with pdfplumber) and .md (OpenCharities' OCR text of the same PDF).
Values were transcribed by hand (from the PDF text, the OCR text, or the rendered page where the PDF is a scan)
and are re-checked here: every listed token must occur in the stated source, and the fee note must add up
(gross - remissions + adjustments == net as printed). Run after code/harvest/fees.py.
"""
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
from common import DERIVED, RAW, write_derived  # noqa: E402
from fees_text import norm, pdf_pages  # noqa: E402

DAY = "2026-10-10"
ACC = RAW / "charity_accounts" / DAY
OC = "https://opencharities.uk/ew/{n}"

# One entry per charity. Amounts are strings as printed; unit = 1000 for £'000 statements.
#   gross: gross fees ('a+b' = sum of printed lines); rem: remission lines deducted from gross (bursaries,
#   scholarships, allowances, staff/sibling discounts); adj: other printed lines between gross and net (add-backs
#   of restricted-fund bursaries, catering, financing discounts), signed; net: the printed subtotal the identity is
#   checked against ('' = no such line); means: means-tested bursary value as disclosed (string in £, '' = not
#   disclosed); mt / full: pupils on means-tested awards / on 100% remission ('' = not disclosed).
#   tokens: (source, text) that must occur; source = PDF page number, 'pdf' (any page) or 'md' (OCR text).
#   verify: pdf_text | ocr_text | visual (number read from the rendered scan; checked by the identity only).
#   ocr: figure -> its spelling in the OCR text, where the text layer garbles a figure that was read from the page.
C = [
    dict(n="312728", urns=["101162"], fy="2025-06-30", unit=1000, gross="39,106", rem=["2,988"], adj=[], net="36,118",
         means="", mt="60", full="45", verify="pdf_text",
         loc="Note 2 School Fees (PDF p49, printed p48); bursary counts: Governors' report (PDF p15)",
         tokens=[(49, "39,106"), (49, "(2,988)"), (49, "36,118"), ("md", "60 bursaries were awarded in 2024/25"),
                 ("md", "45 pupils received 100% remission")],
         note="'Total bursaries, scholarships and other concessions'; 'substantially all' are bursaries and "
              "scholarships; means-tested value not split out. Pupil counts cover Westminster and the Under School."),
    dict(n="1115843", urns=["102257"], fy="2025-08-31", unit=1, gross="26,185,284", rem=["136,690", "1,549,960"], adj=[],
         net="24,498,634", means="1,549,959", mt="69", full="46", verify="pdf_text",
         loc="Consolidated SOFA (PDF p43): School Fee Income, Scholarships, Bursaries; Trustees' report Bursaries (PDF p26)",
         tokens=[(43, "26,185,284"), (43, "(136,690)"), (43, "(1,549,960)"), (43, "24,498,634"), (26, "£1,549,959"),
                 (26, "69 pupils (2024: 70) in the Senior School"), (26, "46 of these pupils")],
         note="Means-tested pupils and full remissions are Senior School."),
    dict(n="307061", urns=["114614"], fy="2025-07-31", unit=1000, gross="70,264", rem=["6,067"], adj=[], net="64,197",
         means="", mt="", full="", verify="pdf_text",
         loc="Note 1 (a) charitable activities - fees (PDF p45)",
         tokens=[(45, "70,264"), (45, "(6,067)"), (45, "64,197")],
         note="'bursaries, grants and allowances'; means-tested value not disclosed (report: 978 scholarships and "
              "bursaries worth £3.1m incl. £0.7m 'Opening Doors' free places)."),
    dict(n="1119619", urns=["102942"], fy="2025-08-31", unit=1000, gross="42,251", rem=["4,229"], adj=[], net="38,022",
         means="3,499,000", mt="147", full="", verify="pdf_text", ocr={"4,229": "(4,22e)"},
         loc="Note 2 school fees receivable (PDF p33, printed p31)",
         tokens=[(33, "42,251"), (33, "(4,22e)"), (33, "38,022"), (33, "3,499,000 paid to 147 pupils")],
         note="PDF text layer is OCR ('4,22e'); 4,229 read from the rendered page and fits the identity. 63% of "
              "means-tested awards were full fee or over 75%."),
    dict(n="1119613", urns=["100366"], fy="2025-08-31", unit=1000, gross="25,131", rem=["2,652"], adj=[], net="22,479",
         means="2,500,000", mt="86", full="", verify="ocr_text", ocr={"2,652": "12.652)"},
         loc="Note School fees (OCR text); Governors' report public benefit",
         tokens=[("md", "25,131"), ("md", "12.652)"), ("md", "22,479"),
                 ("md", "£2.5m in bursaries supporled 86 students")],
         note="Scanned PDF; figures from OpenCharities OCR, consistent with the identity. Means-tested value is "
              "the report's rounded £2.5m."),
    dict(n="310024", urns=["102684"], fy="2025-07-31", unit=1000, gross="41,839", rem=["147", "277", "1,724"], adj=[],
         net="39,691", means="1,724,000", mt="75", full="46", verify="ocr_text",
         ocr={"147": "{1471", "277": "{2771", "1,724": "11,7241"},
         loc="Note Tuition fees (OCR text); Governors' report Bursaries",
         tokens=[("md", "41,839"), ("md", "11,7241"), ("md", "39,691"),
                 ("md", "bursaries to 75 pupils aggregating £1,724,000"), ("md", "awarded to 46 pupils")],
         note="Scanned PDF. Remissions = discounts and staff allowances 147 + scholarships 277 + bursaries 1,724; "
              "full = '100% and 100% plus bursaries'."),
    dict(n="1016538", urns=["125342"], fy="2025-08-31", unit=1000, gross="141,668", rem=["10,860"], adj=["+4,445"],
         net="135,253", means="1,100,000", mt="", full="", verify="pdf_text",
         loc="Note 2 school fees receivable and catering income (PDF p47); Bursary Policy (PDF p20)",
         tokens=[(47, "141,668"), (47, "(10,860)"), (47, "4,445"), (47, "135,253"), (20, "£1.1m")],
         note="United Church Schools Trust (United Learning's independent schools): many schools, not Guildford "
              "High alone. 'Scholarships, bursaries and reduced fees'; means-tested £1.1m = 0.8% of gross fees."),
    dict(n="312699", urns=["100369"], fy="2025-08-31", unit=1, gross="22,463,876", rem=["109,087", "1,870,636", "46,528"],
         adj=[], net="20,437,625", means="1,920,754", mt="77", full="", verify="pdf_text",
         loc="Note 3 net fees receivable (PDF p24); Trustees' report (PDF p7)",
         tokens=[(24, "22,463,876"), (24, "(109,087)"), (24, "(1,870,636)"), (24, "(46,528)"), (24, "20,437,625"),
                 (7, "77 means-tested bursaries"), (7, "£1,920,754")],
         note="Remissions = scholarships + bursaries + staff remission."),
    dict(n="306983", urns=["102692", "100076", "101072"], fy="2025-08-31", unit=1000, gross="", rem=[], adj=[],
         net="304,917", means="", mt="932", full="462", verify="pdf_text", status="partial",
         loc="Note 4 Income (PDF p59); 'Providing financial assistance' (PDF p16)",
         tokens=[(59, "304,917"), (16, "932 students benefited from a GDST bursary"), (16, "462 were awarded at")],
         note="Girls' Day School Trust: 24 independent senior schools plus academies. School fees are shown net of "
              "bursaries and scholarships; gross fees and remission totals are not disclosed."),
    dict(n="326279", urns=["123623"], fy="2025-08-31", unit=1, gross="25,377,577+401,745+501,346", rem=["1,023,437"],
         adj=[], net="25,257,231", means="649,575", mt="31", full="", verify="pdf_text",
         loc="Note 1 fees receivable (PDF p24)",
         tokens=[(24, "25,377,577"), (24, "401,745"), (24, "501,346"), (24, "(1,023,437)"), (24, "25,257,231"),
                 (24, "£649,575 were paid to 31 pupils")],
         note="Gross = main term + holiday stays + summer courses. Scholarships, bursaries and allowances to 129 pupils."),
    dict(n="295785", urns=["123311"], fy="2025-07-31", unit=1, gross="22,085,520", rem=["1,835,848"], adj=[],
         net="20,249,672", means="", mt="60", full="", verify="pdf_text",
         loc="Note 2(a) fee income (PDF p36); Governors' report bursaries (PDF p13)",
         tokens=[(36, "22,085,520"), (36, "(1,835,848)"), (36, "20,249,672"), (13, "awarded to 48 pupils"),
                 (13, "further 12 pupils")],
         note="mt = 48 Governors' Bursaries (5%-100%) + 12 endowment/restricted-fund bursaries; 4 more had hardship "
              "assistance. Means-tested value not disclosed."),
    dict(n="1120654", urns=["110923"], fy="2025-08-31", unit=1000, gross="36,295", rem=["2,006"], adj=[], net="34,289",
         means="1,182,000", mt="74", full="", verify="pdf_text",
         loc="Note 2 school fees (PDF p35); Bursary and scholarship awards (PDF p14)",
         tokens=[(35, "36,295"), (35, "(2,006)"), (35, "34,289"), (14, "£1,182k"), (14, "74 (2023/24: 71) children")],
         note="Means-tested awards equated to 54.3 full-fee places."),
    dict(n="312714", urns=["100370"], fy="2025-08-31", unit=1000, gross="36,161", rem=["6,044"], adj=[], net="30,117",
         means="5,900,000", mt="275", full="", verify="pdf_text",
         loc="Note 2 net school fees receivable (PDF p33); Financial review (PDF p18)",
         tokens=[(33, "36,161"), (33, "(6,044)"), (33, "30,117"), (18, "£5.9m spent on means-tested"),
                 (18, "275 pupils across both Schools")],
         note="Latymer Foundation: Upper School and Prep. Means-tested value is the report's rounded £5.9m."),
    dict(n="529051", urns=["103585"], fy="2025-08-31", unit=1000, gross="26,978", rem=["2,860", "1,381"], adj=[],
         net="22,737", means="2,860,000", mt="217", full="79", verify="pdf_text",
         loc="Note 5 fees (PDF p54); Assisted Places table (PDF p16)",
         tokens=[(54, "26,978"), (54, "(2,860)"), (54, "(1,381)"), (54, "22,737"), (54, "£2.9m were paid"),
                 (54, "to 217 pupils"), (16, "Pupils receiving a 100% AP 79")],
         note="Schools of King Edward VI in Birmingham: King Edward's School and KEHS together. Gross is 'net of bad "
              "debts'. Means-tested = Governors' Assisted Places Scheme deduction (note: '£2.9m ... to 217 pupils')."),
    dict(n="312765", urns=["102163"], fy="2025-07-31", unit=1, gross="47,235,215+807,747",
         rem=["421,569", "1,725,177", "494,749", "40,566"], adj=[], net="45,360,901", means="2,293,358", mt="103",
         full="", verify="visual",
         loc="Note 1 Fees (PDF p35, printed p33)",
         tokens=[("md", "103 pupils received means-tested fee")],
         note="Scanned PDF, OCR unusable for the table; values read from the rendered page and fit the identity. "
              "Gross = tuition + music fees. Remissions = allowances + bursaries (unrestricted and restricted funds) "
              "+ scholarships."),
    dict(n="310638", urns=["110547"], fy="2025-08-31", unit=1000, gross="30,780", rem=["1,801"], adj=[], net="28,979",
         means="1,700,000", mt="41", full="15", verify="ocr_text", ocr={"1,801": "11.8011"},
         loc="Note Income from charitable activities (OCR text); Chair's statement and objectives",
         tokens=[("md", "30,780"), ("md", "11.8011"), ("md", "28,979"),
                 ("md", "£1.7m in bursarie5 which 5UPPOrted 41 pupils"), ("md", "who benefitted from full fee bursaries")],
         note="Scanned PDF. Means-tested value is 'over £1.7m' (lower bound). 116 pupils had some fee reduction."),
    dict(n="1161864", urns=["100864"], fy="2025-07-31", unit=1000, gross="35,987+422", rem=["996", "707", "3,120"],
         adj=[], net="31,586", means="3,120,000", mt="148", full="", verify="visual",
         loc="Note 2 charitable activities - fees receivable (PDF p57, printed p58)",
         tokens=[("md", "35,987")],
         note="Scanned PDF; values read from the rendered page and fit the identity. Gross = day fees + other "
              "fees; remissions = allowances + scholarships + means-tested bursaries (incl. hardship), the last "
              "'£3.1m ... to 148 pupils'."),
    dict(n="1130254", urns=["102932"], fy="2025-08-31", unit=1, gross="24,471,933", rem=["2,136,031"], adj=[],
         net="22,335,902", means="1,683,126", mt="70", full="37", verify="visual",
         loc="Note 2 fees receivable (PDF p27, table is an image); Governors' report (PDF p10-11)",
         tokens=[(27, "means-tested awards were provided to 70 pupils"), ("pdf", "£1,683,000"),
                 ("pdf", "of which 37 were 100% bursaries")],
         note="Fee table is an image in the PDF; values read from it fit the identity and the report's rounded "
              "£1,683,000 and '8.7% of gross fee income'."),
    dict(n="313996", urns=["117648", "117649"], fy="2025-08-31", unit=1000, gross="62,829", rem=["1,180", "3,684", "1,186"],
         adj=[], net="56,779", means="3,684,000", mt="162", full="", verify="visual",
         loc="Note 3 Tuition (PDF p37)",
         tokens=[],
         note="Haberdashers' Aske's Charity runs both Elstree schools (Boys' and Girls'). Scanned PDF; values read "
              "from the rendered page and fit the identity. Remissions = scholarships + bursaries + staff remission."),
    dict(n="1158226", urns=["105595"], fy="2025-08-31", unit=1, gross="", rem=[], adj=[], net="", means="1,023,476",
         mt="100", full="26", verify="pdf_text", status="partial",
         loc="Governors' report, bursaries (PDF text)",
         tokens=[("pdf", "£1,023,476"), ("pdf", "100 pupils in receipt of bursaries"),
                 ("pdf", "Twenty-six pupils in the Senior School")],
         note="Fees are reported net of allowances and remissions; gross fees and the remission total are not "
              "disclosed. No scholarships offered. full = Senior School."),
    dict(n="1139086", urns=["110158"], fy="2025-08-31", unit=1000, gross="71,088", rem=["10,061"], adj=["-1,480"],
         net="59,547", means="10,061,000", mt="300", full="89", verify="pdf_text",
         loc="Consolidated SOFA (PDF p22); 'Making Eton accessible through Financial Aid' (Trustees' report)",
         tokens=[(22, "71,088"), (22, "(10,061)"), (22, "(1,480)"), (22, "59,547"), ("pdf", "£10,061k"),
                 ("pdf", "A total of 300 or 22% of boys"), ("pdf", "89 paid no")],
         note="Financial Aid is means-tested; 300 boys includes 84 helped with the VAT increase. Discount on pre-paid "
              "fees (1,480) is not a remission."),
    dict(n="1124853", urns=["100863"], fy="2025-08-31", unit=1, gross="27,842,362", rem=["2,839,591"], adj=["+539,979"],
         net="25,542,750", means="2,839,591", mt="140", full="77", verify="pdf_text",
         loc="Note 2 School Fees (PDF p43); Bursary policy (PDF p20)",
         tokens=[(43, "27,842,362"), (43, "(2,839,591)"), (43, "539,979"), (43, "25,542,750"),
                 (20, "140 (2023-24: 149)"), (20, "77 (2023-24: 75) receiving 100% support")],
         note="The note labels the starting line 'Net Tuition Fees'; it is before the bursary reductions and is "
              "used as gross. Adjustment = Saturday School income."),
    dict(n="1177353", urns=["125424"], fy="2025-07-31", unit=1000, gross="27,542", rem=["1,719"], adj=[], net="25,823",
         means="1,200,000", mt="74", full="35", verify="pdf_text",
         loc="Note 2 school fees receivable (PDF p27); Public benefit (PDF p6)",
         tokens=[(27, "27,542"), (27, "(1,719)"), (27, "25,823"), (6, "74 pupils received bursarial support totalling £1.2 million"),
                 (6, "35 boys who were granted full fee remission")],
         note="Includes RGS Prep. full = full fee remission 'for at least one term'."),
    dict(n="1078461", urns=["102619"], fy="2025-07-31", unit=1000, gross="22,927", rem=["2,607"], adj=[], net="20,320",
         means="878,000", mt="43", full="23", verify="ocr_text",
         loc="Note fee income (OCR text); Governors' report grants",
         tokens=[("md", "22,927"), ("md", "(2,607)"), ("md", "20,320"), ("md", "£878k"), ("md", "43 students"),
                 ("md", "23 students")],
         note="Means-tested = fee assistance awarded at entry (£878k, 43 students, 23 at 100%); the report lists "
              "other categories within the £2,607k."),
    dict(n="1068532", urns=["102875"], fy="2025-08-31", unit=1, gross="26,847,429", rem=["1,662,344"], adj=["+187,211"],
         net="25,372,296", means="", mt="27", full="", verify="pdf_text",
         loc="Note 5 school fees receivable (PDF p29); Governors' report (PDF p10)",
         tokens=[(29, "26,847,429"), (29, "(1,662,344)"), (29, "187,211"), (29, "25,372,296"),
                 (10, "27 are in receipt of a means-tested bursary")],
         note="'Total scholarships and other allowances'; means-tested value not disclosed."),
    dict(n="1097977", urns=["118959"], fy="2025-06-30", unit=1, gross="41,576,132", rem=["3,675,725"], adj=[],
         net="37,900,407", means="2,311,000", mt="72", full="25", verify="pdf_text",
         loc="Note 3 school fees receivable (PDF p55); Foundation Awards (PDF p29)",
         tokens=[(55, "41,576,132"), (55, "(3,675,725)"), (55, "37,900,407"), (29, "£2,311k"),
                 (29, "25boys received 100.0% funding")],
         note="Means-tested = Foundation Awards to 72 boys."),
    dict(n="1120005", urns=["102946"], fy="2025-08-31", unit=1, gross="36,025,295",
         rem=["3,168,302", "1,041,549", "502,061"], adj=[], net="31,313,383", means="3,168,302", mt="135", full="98",
         verify="pdf_text", loc="Note 2 school fees receivable (PDF p27); Governors' report (PDF p9)",
         tokens=[(27, "36,025,295"), (27, "(3,168,302)"), (27, "(1,041,549)"), (27, "(502,061)"), (27, "31,313,383"),
                 (27, "provided to a total of 135 pupils"), (9, "98 pupils received a 100% bursary")],
         note="Charity includes Hampton's prep school."),
    dict(n="312612", urns=["101842"], fy="2025-08-31", unit=1, gross="64,628,982", rem=["11,732,976"], adj=[],
         net="52,896,006", means="5,860,000", mt="318", full="", verify="pdf_text",
         loc="Note 2 fees (PDF p28); Bursary scheme (Trustees' report)",
         tokens=[(28, "64,628,982"), (28, "(11,732,976)"), (28, "52,896,006"), ("pdf", "318 pupils across our schools"),
                 ("pdf", "£5.86m")],
         note="Whitgift Foundation: Whitgift, Trinity and Old Palace together. Means-tested = the Foundation's "
              "bursary contribution (£5.86m, rounded); a further £0.5m came from the Trinity School Bursary Fund."),
    dict(n="1139000", urns=["116532"], fy="2025-08-31", unit=1000, gross="36,032", rem=["5,529"], adj=[], net="30,503",
         means="5,200,000", mt="142", full="33", verify="pdf_text",
         loc="Note 2 school fees (PDF p30); Education & public benefit (PDF p8, printed pp14-15)",
         tokens=[(30, "36,032"), (30, "(5,529)"), (30, "30,503"), (30, "granted to 142 pupils"), (8, "£5.2m"),
                 (8, "33 received awards")],
         note="Means-tested assistance £5.2m (rounded); 33 awards of 100%."),
    dict(n="1081898", urns=["125422"], fy="2025-08-31", unit=1, gross="41,906,937", rem=["5,632,401"],
         adj=["+1,375,000", "+143,884"], net="37,793,420", means="2,591,214", mt="", full="", verify="pdf_text",
         loc="Note 1 school fees (PDF p35); Bursaries (PDF p7)",
         tokens=[(35, "41,906,937"), (35, "(5,632,401)"), (35, "1,375,000"), (35, "143,884"), (35, "£37,793,420"),
                 (7, "£2,591,214")],
         note="Adjustments add back bursaries funded by the 1675 Fund and external funds. Includes the prep school."),
    dict(n="1101358", urns=["118952"], fy="2025-07-31", unit=1000, gross="47,423", rem=["3,349"], adj=[], net="44,074",
         means="2,186,000", mt="71", full="", verify="pdf_text",
         loc="Note 2 school fees receivable (PDF p31)",
         tokens=[(31, "47,423"), (31, "(3,349)"), (31, "44,074"), (31, "£2.186m were paid to 71 pupils")],
         note="Sevenoaks Education Group."),
    dict(n="290286", urns=["110120"], fy="2025-08-31", unit=1000, gross="19,909", rem=["1,331"], adj=[], net="18,578",
         means="", mt="", full="", verify="visual",
         loc="Note 3 fees receivable (PDF p33)",
         tokens=[("md", "19,909"), ("md", "18.578")],
         note="Scanned PDF; 1,331 read from the rendered page (OCR drops it) and fits the identity."),
    dict(n="529909", urns=["105591"], fy="2025-07-31", unit=1, gross="25,382,012", rem=["506,351", "2,921,951"], adj=[],
         net="21,953,710", means="2,921,951", mt="212", full="161", verify="pdf_text",
         loc="Note 2a/2b fees (PDF p25); Public benefit (PDF p7)",
         tokens=[(25, "25,382,012"), (25, "(506,351)"), (25, "(2,921,951)"), (25, "21,953,710"),
                 (7, "212 boys benefitted from fee assistance"), (7, "161 of which received 100% fee assistance")],
         note="Means-tested = fee assistance (note 2b). Remissions = fee discounts + bursaries/scholarships/awards."),
    dict(n="311065", urns=["117617"], fy="2025-08-31", unit=1000, gross="25,430+1,495", rem=["1,495"], adj=[],
         net="25,430", means="", mt="", full="", verify="pdf_text",
         loc="Accounting policy, fees receivable (remissions); SOFA tuition fees receivable",
         tokens=[("pdf", "of £1,495k"), ("pdf", "25,430")],
         note="St Albans Education Group (STAHS and Stormont). Gross not printed: computed as tuition fees "
              "receivable + the remissions stated in the accounting policy."),
    dict(n="1063740", urns=["117616"], fy="2025-08-31", unit=1, gross="31,882,196", rem=["2,638,807"], adj=[],
         net="29,243,389", means="1,105,076", mt="63", full="", verify="visual",
         loc="Note 2 school fees (PDF p32); Governors' report bursaries",
         tokens=[("md", "29.243.389"), ("md", "63 boys received"), ("md", "£1,105,076")],
         note="Scanned PDF; note values read from the rendered page. 31 bursary holders had 80%-100%."),
    dict(n="312748", urns=["100065"], fy="2025-08-31", unit=1000, gross="33,509", rem=["1,569", "510", "200"], adj=[],
         net="31,230", means="1,537,365", mt="60", full="", verify="pdf_text",
         loc="Note 2 school fee income (PDF p30); Fee assistance table (Report of Council)",
         tokens=[(30, "33,509"), (30, "(1,569)"), (30, "(510)"), (30, "(200)"), (30, "31,230"), ("pdf", "£1,537,365"),
                 ("pdf", "Number of bursary awards of 75% or more 45"), ("pdf", "Number of bursary awards of up to 75% 15")],
         note="mt = 45 awards of 75%+ and 15 below 75%."),
    dict(n="1071298", urns=["123312"], fy="2025-08-31", unit=1000, gross="31,894", rem=["718", "1,277"], adj=[],
         net="29,899", means="1,277,000", mt="", full="", verify="ocr_text", ocr={"718": "1718", "1,277": "11.2771"},
         loc="Note School fees (OCR text)",
         tokens=[("md", "31,894"), ("md", "11.2771"), ("md", "29.899")],
         note="Scanned PDF. Remissions = scholarships, Foundation grants and commissions 718 + bursaries 1,277 "
              "(unrestricted 1,029 + restricted 248); bursaries are means-tested annually (report). Includes the prep."),
    dict(n="1104251", urns=["122915"], fy="2025-08-31", unit=1000, gross="20,435", rem=["1,634", "81", "248"], adj=[],
         net="", means="1,634,000", mt="102", full="28", verify="ocr_text",
         loc="Note 3 income from charitable activities; Governors' report bursary tables (OCR text)",
         tokens=[("md", "|Fees|20,435|"), ("md", "|Meanstestedbursary|1,634|102|"), ("md", "|100 — 105%%|28|"),
                 ("md", "£81,000"), ("md", "£248,000")],
         note="Fees are stated gross; remissions = means-tested bursaries + scholarships (£81,000) + fee discounts "
              "(£248,000), from the Governors' report. full = 100-105% awards."),
    dict(n="312745", urns=["101161"], fy="2025-08-31", unit=1000, gross="37,364", rem=["1,337", "292", "148"],
         adj=["+79"], net="35,666", means="1,337,000", mt="67", full="37", verify="visual",
         loc="Note 5 fees (PDF p27); Trustees' report public benefit",
         tokens=[("md", "37,364"), ("md", "67 means-tested"), ("md", "£1.337,000")],
         note="Francis Holland (C of E) Schools Trust: Sloane Square and Regent's Park. Scanned PDF; note values "
              "read from the rendered page."),
    dict(n="1181012", urns=["101071"], fy="2025-08-31", unit=1000, gross="62,071", rem=["6,860"], adj=["+718"],
         net="55,929", means="", mt="", full="48", verify="pdf_text",
         loc="Note 3 income from charitable activities (PDF p36); Public benefit (PDF p6)",
         tokens=[(36, "62,071"), (36, "(6,860)"), (36, "718"), (36, "55,929"),
                 (6, "we funded 48 pupils Bursaries receiving awards of 100%")],
         note="United Westminster and Grey Coat Foundation: independent Emanuel School and Sutton Valence School "
              "(fees) plus two academies (grants). Full remissions are across both independent schools."),
    dict(n="307335", urns=["116534"], fy="2025-07-31", unit=1, gross="20,244,844", rem=["287,719", "1,828,741", "380,733"],
         adj=[], net="17,747,651", means="", mt="55", full="", verify="ocr_text",
         loc="Note school earnings (OCR text)",
         tokens=[("md", "20,244,844"), ("md", "17.747,651"), ("md", "means tested bursaries were paid to 55 pupils")],
         note="Scanned PDF. Remissions = scholarships + bursaries + staff and sibling discount. The report's "
              "wording ('£1.8m ... to some 55 pupils, of which 23 were means tested and 32 were 100% of fees') conflicts "
              "with the note's 55 means-tested pupils; the means-tested value and full remissions are left blank "
              "(the bursaries line, 1,828,741, is not all means-tested on the report's reading)."),
]

NOT_CHARITY = {
    "100003": "City of London School is run by the City of London Corporation (not a registered charity). Its "
              "bursaries are part-funded by The City of London School Charitable Trust (1020824), whose filing for "
              "FY 2025-08-31 is an audit findings report with no fee-remission figures.",
    "100001": "City of London School for Girls is run by the City of London Corporation (not a registered charity); "
              "no bursary charity found by name or postcode.",
}
COLS = ["urn", "name", "charity_number", "fy_end", "gross_fees", "total_remissions", "means_tested_amount",
        "means_tested_pupils", "full_remission_pupils", "remission_share", "means_tested_share", "source_url",
        "source_location", "status", "charity_name", "charity_scope", "verification", "local_path", "note"]


def money(s: str) -> float:
    return round(sum(float(p.replace(",", "")) for p in s.split("+")), 2) if s else None


def charity_names():
    import zipfile
    z = zipfile.ZipFile(RAW / "charity_commission" / DAY / "publicextract.charity.zip")
    c = pd.read_csv(z.open("publicextract.charity.txt"), sep="\t", dtype=str, keep_default_na=False, quoting=3,
                    encoding="utf-8-sig", usecols=["registered_charity_number", "linked_charity_number", "charity_name"])
    c = c[c.linked_charity_number == "0"]
    return dict(zip(c.registered_charity_number, c.charity_name))


def main():
    top = pd.read_csv(DERIVED / "top30_independent.csv", dtype={"urn": str})
    names = dict(zip(top.urn, top.name))
    cnames = charity_names()
    rows, errors = [], []
    for c in C:
        pdf = ACC / f"{c['n']}_{c['fy']}_accounts.pdf"
        pages = [norm(t) for t in pdf_pages(pdf)]
        md = norm(pdf.with_suffix(".md").read_text(encoding="utf-8", errors="replace"))
        for src, tok in c["tokens"]:
            hay = md if src == "md" else " ".join(pages) if src == "pdf" else pages[src - 1]
            if norm(tok) not in hay:
                errors.append(f"{c['n']}: token '{tok}' not found in {src}")
        g, rem = money(c["gross"]), sum(money(r) for r in c["rem"])
        if c["net"] and g is not None:
            calc = g - rem + sum(money(a.lstrip("+-")) * (-1 if a.startswith("-") else 1) for a in c["adj"])
            if abs(calc - money(c["net"])) > 0.5:
                errors.append(f"{c['n']}: identity fails: gross - remissions + adj = {calc:,.0f} vs net {c['net']}")
        u = c["unit"]
        gross = g * u if g is not None else None
        total = rem * u if c["rem"] else None
        means = money(c["means"])
        scope = "school" if len(c["urns"]) == 1 else f"group of {len(c['urns'])} schools in this list"
        if c["n"] in ("1016538", "306983", "312612", "529051", "1181012", "312745"):
            scope = "multi-school trust"
        for urn in [u for u in c["urns"] if u in names]:
            rows.append({
                "urn": urn, "name": names[urn], "charity_number": c["n"], "fy_end": c["fy"],
                "gross_fees": gross, "total_remissions": total, "means_tested_amount": means,
                "means_tested_pupils": c["mt"] or None, "full_remission_pupils": c["full"] or None,
                "remission_share": round(total / gross, 4) if gross and total is not None else None,
                "means_tested_share": round(means / gross, 4) if gross and means else None,
                "source_url": OC.format(n=c["n"]), "source_location": c["loc"],
                "status": c.get("status", "confirmed"), "charity_name": cnames.get(c["n"], ""),
                "charity_scope": scope, "verification": c["verify"],
                "local_path": f"data/raw/charity_accounts/{DAY}/{pdf.name}", "note": c["note"]})
    for urn, note in NOT_CHARITY.items():
        rows.append({"urn": urn, "name": names[urn], "status": "not_charity", "note": note,
                     "charity_scope": "", "source_url": "https://register-of-charities.charitycommission.gov.uk/"})
    if errors:
        print("\n".join(errors))
        raise SystemExit(f"{len(errors)} checks failed")
    df = pd.DataFrame(rows, columns=COLS)
    assert sorted(df.urn) == sorted(names), set(names) ^ set(df.urn)
    write_derived(df.sort_values("urn").reset_index(drop=True), "independent_bursaries")


if __name__ == "__main__":
    main()
