"""Build data/derived/coed_entry.csv: the ages at which girls and boys can join 16 independents that DfE lists as
"Mixed" (several take girls only into the sixth form, or are phasing co-education in).

Entry year: September 2027, the cycle every school's admissions pages cover when saved on 2026-10-10 (the brief:
September 2026, or 2027 if that is what the page now covers). Only Trinity differs between the two years (see note).
Entry points are the main/usual points of entry into this URN at 10+ and above. Junior/pre-prep points, feeder
routes through another establishment, and occasional places are in `note`.

Every quote was copied by hand from a page saved by code/harvest/fetch.py (data/raw/school_docs/<day>/) and is
re-checked here. The quote is split on " … " and each fragment must occur, in order, in the file's extracted text
after normalising tags, whitespace, case and curly quotes, or the build fails. Extra evidence from other files
(`extra`) is checked the same way and cited in `note`.
Run:  .venv/Scripts/python -I code/derive/build_coed_entry.py
"""
import csv
import html
import json
import pathlib
import re
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
import pandas as pd  # noqa: E402
from common import RAW, ROOT, assert_unique, rel, write_derived  # noqa: E402
from extract_text import _Text, norm, text_of  # noqa: E402

DAY = "2026-10-10"
DOCS = RAW / "school_docs" / DAY
MANIFEST = ROOT / "data" / "manifest" / "school_docs.csv"
SEP = " … "

ROWS = [
    dict(urn="101162", name="Westminster School", girls="11+;16+",
         boys="11+;13+;16+", flag="yes",
         file="101162_coed_coeducation.html",
         quote="September 2026: Girls will also join boys at Westminster Under School in Years 3 and 7. "
               "September 2028: Girls will join boys in Westminster School’s Year 9 Fifth Form. … For over 400 "
               "years the School educated only boys before, in 1973, its sixth form became co-educational.",
         note="For 2027 entry: girls (from 2026) and boys enter at 11+ via Westminster Under School, a separate "
              "establishment outside this URN's DfE age range (12-19), and move up to Westminster School at 13+ "
              "without reapplying; direct 13+ entry for girls from September 2028. Flag corrected to yes in review "
              "round 3 (was no).",
         extra=[("101162_coed_13entry.html", "Now, in becoming co-educational, the first girls will enter the "
                                             "School in Year 9 in 2028.")]),
    dict(urn="102684", name="King's College School", girls="16+", boys="11+;13+;16+", flag="no",
         file="102684_coed_16plus.json",
         quote="Each September, King's College School admits about 55 boys and girls into the sixth form at 16 "
               "years old.",
         note="Girls at 11+ from September 2033 and at 13+ from September 2035. school_master.csv gives DfE "
              "gender 'Boys' for this URN, not 'Mixed'.",
         extra=[("102684_coed_11plus.json", "Each September, King's College School admits about 60 boys into year "
                                            "7 at 11 years old. … Girls and boys will be admitted to year 7 of the "
                                            "senior school at 11+ from September 2033."),
                ("102684_coed_13plus.json", "Each September, King's College School admits about 20 boys into year "
                                            "9 at 13 years old. … Girls and boys will be admitted to year 9 (fourth "
                                            "form) of the senior school at 13+ from September 2035.")]),
    dict(urn="123311", name="Magdalen College School", girls="16+", boys="11+;13+;16+", flag="no",
         file="123311_coed_admissions_policy_2026-04.pdf",
         quote="Magdalen College School is an independent day school for boys from ages 7 to 16 and boys and "
               "girls in the Sixth Form. … Second Form (Year 7) in September 2030 … Lower Fourth (Year 9) in "
               "September 2032 … The main points of entry are at 7+ (Year 3), 11+ (Year 7), 13+ (Year 9) and 16+ "
               "(Year 12). … At present, Magdalen College School does not admit girls in Years 3-11 (but they are "
               "admitted in Sixth Form)",
         note="Admissions Policy April 2026. Girls at 11+ from September 2030 and at 13+ from September 2032; "
              "girls join the junior years (Years 3-4, 7+) from September 2027. 7+ is junior entry (out of scope)."),
    dict(urn="110923", name="The Perse School", girls="11+;13+;16+", boys="11+;13+;16+", flag="yes",
         file="110923_coed_upper_joining.html",
         quote="The Upper is a co-educational day school for pupils aged 11-18 years. … Our main entry points are "
               "Year 7, where we have around 70 places and Year 9 where we have around 40 places.",
         note="Pelican/Prep (3-11) entry out of scope.",
         extra=[("110923_coed_sixth_joining.html", "Within our co-educational day school, Sixth Form students are a "
                                                   "diverse, intelligent and creative group … Each year between "
                                                   "30-40 external students join us")]),
    dict(urn="100370", name="Latymer Upper School", girls="11+;16+", boys="11+;16+", flag="yes",
         file="100370_coed_admissions_policy.pdf",
         quote="Latymer Upper School (the School) is a co-educational, independent, selective school for boys and "
               "girls from ages 11 to 18. … The usual points of entry are at 11+ (Year 7), and 16+ (Year 12)",
         note="URN also covers Latymer Prep (7+), out of scope."),
    dict(urn="102163", name="Highgate School", girls="11+;16+", boys="11+;16+", flag="yes",
         file="102163_coed_admissions_policy_11_2027.pdf",
         quote="For entry in 2027, places will be available for approximately 80 (girls and boys) who will join "
               "upwards of 100 pupils",
         note="Admissions Policy 11+ 2027 entry. 4+ and 7+ are pre-prep/junior entry (out of scope). The 13+ "
              "admissions URL now serves the Occasional Places page.",
         extra=[("102163_coed_admissions_policy_16_2027.pdf", "For entry in 2027, it is anticipated that places will "
                                                              "be available for approximately 30 to 40 pupils (girls "
                                                              "and boys)"),
                ("102163_coed_admissions-13.html", "The main points of entry to Highgate are at 4+, 7+, 11+ and "
                                                   "16+.")]),
    dict(urn="100864", name="Alleyn's School", girls="11+;16+", boys="11+;16+", flag="yes",
         file="100864_coed_admissions_policy_ss_2026-27.pdf",
         quote="Alleyn’s is an independent, fee-paying, academically selective, fully co-educational HMC day "
               "school. … outside of the formal 11+ and 16+ entry periods.",
         note="Senior School Admissions Policy 2026-27. Junior schools (Alleyn's Junior School, Alleyn's Oakfield) "
              "take 4+, 7+ and 9+ (out of scope)."),
    dict(urn="102619", name="Kingston Grammar School", girls="11+;16+", boys="11+;16+", flag="yes",
         file="102619_coed_admissions_policy.pdf",
         quote="Kingston Grammar School is a co-educational, academically selective school … The usual points of "
               "entry are at 11+ (Year 7) and 16+ (Sixth Form).",
         note="Occasional places at other ages."),
    dict(urn="102875", name="Bancroft's School", girls="11+;16+", boys="11+;16+", flag="yes",
         file="102875_coed_admissions_policy.pdf",
         quote="as part of a co-educational environment … There are two main ages of entry to Bancroft's: at 7+ "
               "(into Year 3) and at 11+ (into Year 7); in addition, we admit smaller numbers at 16+ (into Year "
               "12).",
         note="7+ is into the Prep School, outside this URN's DfE age range (11-18)."),
    dict(urn="101842", name="Trinity School", girls="10+;11+;16+", boys="10+;11+;13+;16+", flag="yes",
         file="101842_coed_coeducation.html",
         quote="We will welcome our first co-educational intake in Year 6 and Year 7 in September 2027 … we are "
               "welcoming applications from boys and girls for entry in Year 6 (10+), Year 7 (11+) and Sixth Form "
               "(16+). … We will not be introducing a 13+ entry point for girls until 2029",
         note="Answer is for September 2027 entry. For September 2026 entry girls joined at 16+ only (flag would "
              "be 'no'). Girls at 13+ from 2029; 13+ entry in 2027 is therefore boys only.",
         extra=[("101842_coed_13admissions.html", "When your child joins us at 13+ … Applications for entry in 2027 "
                                                  "are now open")]),
    dict(urn="116532", name="Winchester College", girls="16+", boys="13+;16+", flag="no",
         file="116532_coed_admissions.html",
         quote="Entry at 13+ for boys … Entry at 11+ is designed for boys finishing their current school in Year "
               "6. This route supports entry into The Pilgrims’ School in Year 7 with onward progression to "
               "Winchester College in Year 9. … Entry at 16+ for boys & girls",
         note="11+ (boys) is into The Pilgrims' School, outside this URN's DfE age range (13-19). No co-education "
              "date found on the admissions pages checked.",
         extra=[("116532_coed_13entry.html", "Winchester College offers full boarding for boys aged 13-18.")]),
    dict(urn="125422", name="Reigate Grammar School", girls="11+;13+;16+", boys="11+;13+;16+", flag="yes",
         file="125422_coed_admissions_process.html",
         quote="Most of our students join RGS at one of our three main entry points; 11+, 13+ and 16+. … Each "
               "year, we welcome boys and girls into Year 7",
         note="Key dates on the page are for 2027 entry."),
    dict(urn="118952", name="Sevenoaks School", girls="11+;13+;16+", boys="11+;13+;16+", flag="yes",
         file="118952_coed_admissions.html",
         quote="We have entry points for boarders and day pupils at 16+ and 13+, and for day pupils only at 11+. … "
               "Sevenoaks is a co-educational school of around 1200 students with an even mix of boys and girls.",
         note=""),
    dict(urn="100065", name="University College School", girls="16+", boys="11+;16+", flag="no",
         file="100065_coed_sixthform.html",
         quote="We offer approximately 60 places to girls aged 16 or over each year. The successful candidates "
               "will join the vast majority of our current Year 11 boys as they continue into the Sixth Form. A "
               "small number of places will also be available for boys of the same age.",
         note="No co-education date found on the admissions pages. Pre-prep/Junior Branch entry out of scope.",
         extra=[("100065_coed_year7.html", "Boys admitted at 11+ will join the approximately 60 boys who transfer "
                                           "from the UCS Junior Branch to the Senior School. … Applications to join "
                                           "Year 7 in September 2027 are now open.")]),
    dict(urn="122915", name="Nottingham High School", girls="11+;16+", boys="11+;16+", flag="yes",
         file="122915_coed_mission_values.html",
         quote="Nottingham High School is an independent day school for boys and girls aged 3-18. … we welcomed "
               "girls into our school and become a co-educational institution in 2015.",
         note="Entry points from the admissions page (extra). Years 8-10 (12+-14+) are taken subject to "
              "availability. Nursery/infant/junior entry out of scope.",
         extra=[("122915_coed_senior_sixth.html", "Nottingham High Senior School educates children from Year 7 to "
                                                  "Year 13, and welcome new students in Years 7-10, and into Year "
                                                  "12, subject to availability.")]),
    dict(urn="114614", name="Brighton College", girls="11+;13+;16+", boys="11+;13+;16+", flag="yes",
         file="114614_coed_lower_school.html",
         quote="Year 7 is a wonderful entry point to Brighton College … Years 7 and 8 have their own purpose-built "
               "Common Room in the stunning Yeoh Building, where boys and girls can socialise, work and play.",
         note="The 2027 admissions timeline also lists 12+ and 14+ entry.",
         extra=[("114614_coed_college_join.html", "Whether you're considering Brighton College for Year 7 or Year 9 "
                                                  "entry"),
                ("114614_coed_college.html", "Brighton College pupils achieve some of the best results of any "
                                             "co-educational school in the country."),
                ("114614_coed_overseas_timeline_2027.pdf", "Registration for 13+, 14+ and 16+")]),
]


def doc_text(path: pathlib.Path) -> str:
    """Normalised visible text of a saved page; .json = KCS content API (HTML fragments in JSON string leaves)."""
    if path.suffix == ".json":
        leaves = []

        def walk(o):
            if isinstance(o, dict):
                for v in o.values():
                    walk(v)
            elif isinstance(o, list):
                for v in o:
                    walk(v)
            elif isinstance(o, str):
                leaves.append(o)
        walk(json.loads(path.read_bytes().decode("utf-8")))
        p = _Text()
        p.feed("\n<p>".join(leaves))
        txt = html.unescape("".join(p.out))
    else:
        txt = text_of(path)
    return norm(re.sub(r"=== page \d+ ===", " ", txt))


def check(file: str, quote: str):
    text, pos = doc_text(DOCS / file), 0
    for frag in quote.split(SEP):
        i = text.find(norm(frag), pos)
        if i < 0:
            raise AssertionError(f"{file}: quote fragment not found (in order): {frag!r}")
        pos = i + len(norm(frag))


def main():
    with MANIFEST.open(encoding="utf-8") as f:
        urls = {r["local_path"]: r["url"] for r in csv.DictReader(f)}
    out = []
    for r in ROWS:
        evidence = [(r["file"], r["quote"])] + r.get("extra", [])
        for file, quote in evidence:
            check(file, quote)
        assert r["flag"] in ("yes", "no", "unverified"), r["urn"]
        assert (r["flag"] == "yes") == bool({"11+", "13+"} & set(r["girls"].split(";"))), r["urn"]
        note = " ".join([r["note"]] + [f'Also {f}: "{q}"' for f, q in r.get("extra", [])]).strip()
        out.append({"urn": r["urn"], "name": r["name"], "girls_entry_points": r["girls"],
                    "boys_entry_points": r["boys"], "girls_at_11_or_13_for_2027_entry": r["flag"],
                    "source_url": urls[rel(DOCS / r["file"])], "source_file": rel(DOCS / r["file"]),
                    "quote": r["quote"], "note": note})
    df = pd.DataFrame(out)
    assert_unique(df, ["urn"], "coed_entry")
    assert len(df) == 16, len(df)
    write_derived(df, "coed_entry")
    print(df[["urn", "name", "girls_entry_points", "boys_entry_points", "girls_at_11_or_13_for_2027_entry"]]
          .to_string(index=False))


if __name__ == "__main__":
    main()
