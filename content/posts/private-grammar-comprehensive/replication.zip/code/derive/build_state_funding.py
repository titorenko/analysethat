"""Build data/derived/state_funding_per_pupil.csv: state per-pupil funding/spending in England, 2025-26, for the
social-cost paragraph (the state cost avoided when a pupil goes private). Four measures, each with its status:
  - IFS secondary school spending per pupil (recommended; includes school sixth forms)
  - IFS further-education spending per 16-18 student (comparator for Years 12-13 outside school sixth forms)
  - DfE revenue funding per pupil aged 5-16 (official allocation series, all phases)
  - NFF 2025-26 schools-block secondary unit of funding, pupil-weighted national mean (derived here)

Usage: .venv/Scripts/python -I code/derive/build_state_funding.py
"""
import re
import zipfile
import xml.etree.ElementTree as ET
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
import pdfplumber  # noqa: E402
from common import latest_raw, read_ees, rel, write_derived  # noqa: E402

O = "{urn:oasis:names:tc:opendocument:xmlns:office:1.0}"
T = "{urn:oasis:names:tc:opendocument:xmlns:table:1.0}"


def ods_rows(path, sheet):
    """Cell values (office:value if numeric, else text) of one ODS sheet; repeated cells expanded (capped)."""
    root = ET.fromstring(zipfile.ZipFile(path).read("content.xml"))
    tb = next(t for t in root.iter(T + "table") if t.get(T + "name") == sheet)
    out = []
    for row in tb.iter(T + "table-row"):
        vals = []
        for c in row.findall(T + "table-cell"):
            v = c.get(O + "value") or "".join(c.itertext())
            vals.extend([v] * min(int(c.get(T + "number-columns-repeated", "1")), 30))
        out.append(vals)
    return out


def main():
    out = []
    p = latest_raw("school_funding", "ifs_annual_report_education_spending_2025-26.pdf")
    with pdfplumber.open(p) as pdf:
        pages = [pg.extract_text() or "" for pg in pdf.pages]
    for measure, pat, coverage in (
            ("ifs_secondary_school_spending_per_pupil", r"Secondary schools: £([\d,]+) per pupil[^\n]*",
             "spending by state secondary schools per pupil, incl. school sixth forms; excl. central LA and MAT spending"),
            ("ifs_fe_spending_per_student_16_18", r"Further education: £([\d,]+) per student aged 16.18[^\n]*",
             "FE and sixth-form colleges, per student aged 16-18")):
        hits = [(i, m) for i, t in enumerate(pages) for m in [re.search(pat, t)] if m]
        i, m = hits[0]
        out.append({"measure": measure, "value_gbp": float(m.group(1).replace(",", "")), "year": "2025-26",
                    "price_base": "2025-26 prices (HMT GDP deflator, Nov 2025)", "coverage": coverage,
                    "status": "IFS projection for 2025-26 (school-level actuals to 2023-24)",
                    "source": "IFS, Annual report on education spending in England: 2025-26 (Jan 2026)",
                    "source_file": rel(p), "page": i + 1, "evidence": m.group(0).strip()})

    p = latest_raw("school_funding", "dfe_revenue_funding_5to16_2010-11_to_2026-27.csv")
    d = read_ees(p)
    r = d[d.time_period == "202526"].iloc[0]
    out.append({"measure": "dfe_revenue_funding_per_pupil_5_16", "value_gbp": float(r.per_pupil_funding_cashterms_gbp),
                "year": "2025-26", "price_base": "cash (= 2025-26 prices)",
                "coverage": "revenue funding to state-funded schools, pupils aged 5-16, all phases; "
                            f"{int(r.pupil_number_fte):,} FTE pupils",
                "status": "DfE allocation-based estimate (published allocations, SR2024 settlement, some estimates)",
                "source": "DfE School funding statistics, financial year 2025-26 release (EES data set ce1e4917)",
                "source_file": rel(p), "page": None, "evidence": f"time_period 202526: per_pupil_funding_cashterms_gbp "
                f"{r.per_pupil_funding_cashterms_gbp}, per_pupil_funding_202526terms_gbp {r.per_pupil_funding_202526terms_gbp}"})

    p = latest_raw("school_funding", "NFF_LA_summary_tables_2025-26.ods")
    rows = ods_rows(p, "2025-26_Allocations")
    head = next(r for r in rows if r[:1] == ["Region(alphabetical order)"])
    assert head[4] == "Actual secondary unit of funding (SUF)" and head[6].startswith("Secondary pupil numbers"), head[:7]
    england = next(r for r in rows if r[:1] == ["England total"])
    las = [r for r in rows if len(r) > 6 and r[1].isdigit()]
    pupils = sum(float(r[6]) for r in las)
    assert len(las) == 151 and abs(pupils - float(england[6])) < 1, (len(las), pupils, england[6])
    suf = sum(float(r[4]) * float(r[6]) for r in las) / pupils
    out.append({"measure": "nff_secondary_unit_of_funding_weighted_mean", "value_gbp": round(suf, 2), "year": "2025-26",
                "price_base": "cash", "coverage": "schools block only, Years 7-11 (excl. premises, growth, high needs, "
                "pupil premium, 16-19 funding); 151 LAs weighted by 2024-25 DSG secondary pupil numbers",
                "status": "derived here from DfE LA-level SUFs (DfE publishes no national SUF in this file)",
                "source": "DfE NFF tables for schools and high needs 2025 to 2026, LA summary (Dec 2024)",
                "source_file": rel(p), "page": None,
                "evidence": f"sum(SUF x secondary pupils) / {pupils:,.2f} pupils; SUF range "
                            f"{min(float(r[4]) for r in las):,.0f}-{max(float(r[4]) for r in las):,.0f}"})
    d = pd.DataFrame(out)
    d["page"] = d.page.astype("Int64")
    d.insert(1, "recommended", d.measure == "ifs_secondary_school_spending_per_pupil")
    write_derived(d, "state_funding_per_pupil")


if __name__ == "__main__":
    main()
