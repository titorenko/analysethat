"""Build data/derived/evidence_table.csv: one row per published estimate the write-up may use (PLAN §3, §4.2).

Covers the private-school and grammar-school effects on HE entry, elite (Russell Group) entry, degree and adult
earnings, plus the channel estimates for the cohort bridge (PLAN §4.2.6): first stages (school type -> degree,
HE, Russell Group, GCSE, occupation), published decomposition sequences, and IFS 2026 second stages.

Rules
- Estimates are kept in the source's own units. The only derived column is estimate_pct = exp(estimate) - 1
  (a proportion, not x100), added here for measure == log_points rows and nowhere else.
- Every row with a source PDF has its `quote` asserted against the pdfplumber text of the stated page
  ("PDF p.N" in table_or_page, 1-based). Matching deletes all whitespace (several journals extract with no
  inter-word spaces) and NULs, maps per-file (cid:N) minus glyphs and U+2212 to "-", and is tried against the
  whole page, left/right column crops (as code/checks/g_quotes.py) and the character-reversed page (for the
  rotated GHV 2017 Table 3).
- Every row's printed number (`tok`, default the estimate as printed) must occur inside its quote, and so must
  the printed SE. Rows whose estimate is a difference of two printed numbers, or a number written in words,
  are flagged "[derived]" / "[worded]" in `note` and skip the token check. "[signed]" marks a sign taken from
  the wording ("2.1 percentage points ... lower"); the token is then the unsigned number.
- status: verified = primary source, quote matched; unverified_other = number quoted second-hand (quote still
  matched in the citing PDF); unverified_paywalled = no open copy (none needed in this build).

Usage: .venv/Scripts/python -I code/derive/build_evidence_table.py
"""
import csv
import math
import re
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pandas as pd  # noqa: E402
import pdfplumber  # noqa: E402
from common import ROOT, latest_raw, rel, write_derived  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------- sources and citations
FILES = {  # key -> (raw source dir, exact filename)
    "gmmz": ("literature", "gmmz_iza_dp5018.pdf"),
    "ghv": ("literature", "ghv2017_berj.pdf"),
    "gpsw": ("literature", "gpsw2018_cje.pdf"),
    "hagh": ("literature", "henderson2020_ore.pdf"),
    "gahh": ("literature", "gahh2020_jsp_accepted.pdf"),
    "aghh": ("literature", "anders2024_cje.pdf"),
    "cv": ("literature", "cv2014_ifs_wp1430.pdf"),
    "bdsv": ("literature", "bdsv2016_ifs_wp1606.pdf"),
    "mtv": ("literature", "mtv2015_cmpo_briefing.pdf"),
    "sull": ("literature", "sullivan2018_bjs_accepted.pdf"),
    "ifs": ("ifs", "ifs_2026_degrees_lifetime_earnings.pdf"),
    "cdb": ("literature", "cdb_iza_dp8617.pdf"),
    "clark": ("literature", "clark_iza_dp3182.pdf"),
    "bckk": ("literature", "birkelund2021_bjs_accepted.pdf"),
    "pj": ("literature", "pj2023_econmod.pdf"),
    "dfm": ("literature", "dfm2002_restat.pdf"),
    "bdm": ("literature", "bdm2020_oep.pdf"),
    "grv": ("literature", "grv2005_ceedp52.pdf"),
    "mp": ("literature", "mp_iza_dp2072.pdf"),
    "gmm": ("literature", "gmm2012_jhr.pdf"),
    "sw": ("literature", "sw2018_npjscilearn.pdf"),
    "hepi": ("literature", "hepi2020_op22.pdf"),
}
# (cid:N) glyphs that pdfplumber cannot map, per file (checked by eye against the printed tables)
CID = {"ghv2017_berj.pdf": {"(cid:3)": "-"}, "dfm2002_restat.pdf": {"(cid:11)": "-", "(cid:12)": "x"},
       "bdm2020_oep.pdf": {"(cid:4)": "-"}}

CITE = {
    "GMMZ2012": "Green, Machin, Murphy & Zhu (2010) The changing economic advantage from private schools, IZA DP 5018; "
                "published Economica 79(316): 658-679 (2012)",
    "GHV2017": "Green, Henseke & Vignoles (2017) Private schooling and labour market outcomes, BERJ 43(1): 7-28",
    "GPSW2018": "Green, Parsons, Sullivan & Wiggins (2018) Dreaming big? Self-valuations, aspirations, networks and "
                "the private-school earnings premium, Cambridge J Econ 42(3): 757-778",
    "HAGH2020": "Henderson, Anders, Green & Henseke (2020) Private schooling, subject choice, upper secondary "
                "attainment and progression to university, Oxford Rev Educ 46(3): 295-312",
    "GAHH2020": "Green, Anders, Henderson & Henseke (2020) Private benefits? External benefits? Outcomes of private "
                "schooling in 21st century Britain, J Social Policy 49(4) (accepted manuscript)",
    "AGHH2024": "Anders, Green, Henderson & Henseke (2024) Private school pupils' performance in GCSEs (and IGCSEs), "
                "Cambridge J Educ 54(6): 795-813",
    "CV2014": "Crawford & Vignoles (2014) Heterogeneity in graduate earnings by socio-economic background, "
              "IFS WP W14/30",
    "DV2000": "Dolton & Vignoles (2000), as cited in Britton, Dearden, Shephard & Vignoles (2016) IFS WP W16/06",
    "NSM2002": "Naylor, Smith & McKnight (2002), as cited in Britton, Dearden, Shephard & Vignoles (2016) IFS WP W16/06",
    "MTV2015": "Macmillan, Tyler & Vignoles (2015) Who gets the top jobs?, J Social Policy 44(3): 487-515; "
               "CMPO Research in Public Policy briefing",
    "SPGWP2018": "Sullivan, Parsons, Green, Wiggins & Ploubidis (2018) The path from social origins to top jobs, "
                 "BJS 69(3): 776-798 (accepted manuscript)",
    "SULLIVAN2020": "Sullivan (2020) BCS70 chapter in Furlong & Lunt (eds) Social Mobility and Higher Education: Are grammar schools the answer?, HEPI Occasional Paper 22",
    "BCM2019": "Burgess, Crawford & Macmillan (2019) Selective education and university outcomes: the winners and losers (mimeo), as reported by Dickson & Macmillan in HEPI Occasional Paper 22 (2020)",
    "MANSFIELD2019": "Mansfield (2019) The impact of selective secondary education on progression to higher education, HEPI Occasional Paper 19; table as reproduced in HEPI Occasional Paper 22 (2020)",
    "IFS2026": "Britton, Ogden, Ornadel & Waltmann (2026) New estimates of the impact of undergraduate degrees on "
               "lifetime earnings, IFS report for DfE, June 2026",
    "CDB2016": "Clark & Del Bono (2014) The long-run effects of attending an elite school: evidence from the UK, "
               "IZA DP 8617; published AEJ: Applied 8(1): 150-176 (2016)",
    "CLARK2010": "Clark (2007) Selective schools and academic achievement, IZA DP 3182; published B.E. J Econ Anal "
                 "Policy 10(1) (2010)",
    "BCBK2021": "Birkelund, Capsada-Munsech, Boliver & Karlson (2021) Lives on track? Long-term earnings returns to "
                "selective school placement in England and Denmark, BJS 72(3): 672-692 (accepted manuscript)",
    "PJ2023": "Pastore & Jones (2023) Human capital consequences of missing out on a grammar school education, "
              "Economic Modelling 126: 106414",
    "DFM2002": "Dearden, Ferri & Meghir (2002) The effect of school quality on educational attainment and wages, "
               "REStat 84(1): 1-20",
    "BDM2020": "Burgess, Dickson & Macmillan (2020) Do selective schooling systems increase inequality?, "
               "Oxford Econ Papers 72(1): 1-24",
    "GRV2005": "Galindo-Rueda & Vignoles (2005) The heterogeneous effect of selection in secondary schools, "
               "CEE DP 52",
    "MP2006": "Manning & Pischke (2006) Comprehensive versus selective schooling in England in Wales: what do we know?, "
              "IZA DP 2072 / NBER WP 12176",
    "GMM2012": "Guyon, Maurin & McNally (2012) The effect of tracking students by ability into different schools: "
               "a natural experiment, J Human Resources 47(3): 684-721",
    "SW2018": "Smith-Woolley et al. (2018) Differences in exam performance between pupils attending selective and "
              "non-selective schools mirror the genetic differences between them, npj Science of Learning 3: 3",
}

COLS = ["row_id", "study", "citation", "comparison", "cohort", "birth_years", "country", "outcome", "measure", "age",
        "sex", "estimand", "controls", "spec_order", "estimate", "se", "ci_low", "ci_high", "n", "table_or_page",
        "quote", "source_url", "source_file", "status", "note", "estimate_pct"]
MEASURES = {"log_points", "pp", "pct", "frac", "sd", "grade", "points", "gbp", "ratio", "elasticity"}
ESTIMANDS = {"RAW", "ADJ-PRE", "ADJ-MED"}
SEXES = {"all", "men", "women"}

E = []  # evidence rows, built by add()


def add(common, quote, page, where, *cells):
    """One quote -> one or more estimate rows. `common` holds the shared fields; each cell overrides them."""
    for c in cells:
        E.append({**common, "quote": quote, "page": page, "where": where, **c})


# ---------------------------------------------------------------- private: GMMZ 2012 (NCDS 1958, BCS70)
G_BKG = ("family background: parents' UK nationality, natural parents, parents' school-leaving age, age, social "
         "status, region, ethnicity, siblings, birth order")
G_TEST = G_BKG + " + early tests (age 5/7 vocabulary and drawing; age 10/11 reading, maths, word and pattern tests)"
G_NC = G_TEST + " + non-cognitive scales (internalising, externalising)"
G_HQ = G_TEST + " + highest qualification"
G_TREAT = ("school-type age not defined in DP 5018; Green et al. 2020 call it private primary schooling, so the "
           "age-10/11 tests may be post-treatment")
gm = dict(study="GMMZ2012", src="gmmz", comparison="private_vs_state", country="GB", measure="log_points",
          outcome="log_hourly_pay")
NCDS = dict(cohort="NCDS58", birth_years="1958", age="33 (1991)")
BCS = dict(cohort="BCS70", birth_years="1970", age="34 (2004)")
NN = {("NCDS58", "all"): 4869, ("NCDS58", "men"): 2742, ("NCDS58", "women"): 2127,
      ("BCS70", "all"): 4778, ("BCS70", "men"): 2573, ("BCS70", "women"): 2111}


def gmmz_seq(sex, quote, ests, ses, page, where, table_specs, outcome="log_hourly_pay", ages=None):
    """ests/ses: printed strings in table column order NCDS, BCS, change, NCDS, BCS, change, ... (changes skipped)."""
    cells = []
    for j, (spec_order, estimand, controls) in enumerate(table_specs):
        for k, coh in enumerate((NCDS, BCS)):
            i = 3 * j + k
            age = (ages or {}).get(coh["cohort"], coh["age"])
            cells.append(dict(coh, age=age, sex=sex, outcome=outcome, spec_order=spec_order, estimand=estimand,
                              controls=controls, est=ests[i], se=ses[i], n=NN[(coh["cohort"], sex)],
                              note=G_TREAT + ("; All column includes a gender dummy" if sex == "all" else "")))
    add(gm, quote, page, where, *cells)


T2 = [(1, "RAW", "none"), (2, "ADJ-PRE", G_BKG + " (no ability)"), (3, "ADJ-PRE", G_TEST)]
for sex, q in (("all", "Private .228 .348 .120 .078 .202 .124 .070 .197 .127 School (.034) (.039) (.052) (.035) "
                        "(.039) (.052) (.034) (.039) (.051)"),
               ("men", "Private .230 .313 .083 .083 .170 .087 .077 .184 .107 School (.044) (.053) (.069) (.045) "
                       "(.053) (.070) (.044) (.053) (.069)"),
               ("women", "Private .227 .386 .159 .074 .261 .187 .064 .246 .182 School (.052) (.059) (.078) (.053) "
                         "(.058) (.078) (.052) (.058) (.077)")):
    nums = re.findall(r"\(?(\.\d+)\)?", q)
    gmmz_seq(sex, q, nums[:9], nums[9:], 29, "Table 2", T2)
T5 = [(4, "ADJ-PRE", G_NC)]
for sex, q in (("all", "Private .070 .197 .127 .072 .201 .129 School (.034) (.039) (.051) (.034) (.039) (.051)"),
               ("men", "Private .077 .184 .107 .077 .184 .107 School (.044) (.053) (.069) (.045) (.053) (.069)"),
               ("women", "Private .064 .246 .182 .065 .244 .179 School (.052) (.058) (.077) (.052) (.057) (.077)")):
    nums = re.findall(r"\(?(\.\d+)\)?", q)
    gmmz_seq(sex, q, nums[3:6], nums[9:12], 32, "Table 5", T5)
T4 = [(5, "ADJ-MED", G_HQ)]
for sex, q in (("all", "Private .070 .197 .127 .041 .100 .059 School (.035) (.039) (.051) (.032) (.037) (.049)"),
               ("men", "Private .075 .177 .102 .038 .081 .043 School (.045) (.053) (.069) (.043) (.050) (.066)"),
               ("women", "Private .064 .246 .182 .042 .146 .104 School (.052) (.058) (.077) (.049) (.054) (.072)")):
    nums = re.findall(r"\(?(\.\d+)\)?", q)
    gmmz_seq(sex, q, nums[3:6], nums[9:12], 31, "Table 4 (nested on spec 3, not spec 4)", T4)
DEG = {"NCDS58": "degree by 23 (1981)", "BCS70": "degree by 23 (1993)"}
for sex, q in (("all", "Private .250 .393 .143 .061 .226 .165 .055 .222 .167 School (.028) (.033) (.042) (.028) "
                        "(.032) (.041) (.027) (.031) (.041)"),
               ("men", "Private .275 .439 .164 .088 .260 .172 .082 .259 .177 School (.037) (.045) (.057) (.037) "
                       "(.043) (.057) (.037) (.043) (.056)"),
               ("women", "Private .219 .341 .122 .026 .188 .162 .021 .177 .156 School (.039) (.048) (.062) (.041) "
                         "(.047) (.061) (.041) (.046) (.06)")):
    nums = re.findall(r"\(?(\.\d+)\)?", q)
    E_before = len(E)
    gmmz_seq(sex, q, nums[:9], nums[9:], 30, "Table 3 (linear probability)", T2, outcome="degree", ages=DEG)
    for r in E[E_before:]:
        r["measure"] = "frac"

# ---------------------------------------------------------------- private: GHV 2017 (BCS70 at 42; SES 2006/2012)
GHV_NOTE = ("Table 3 is printed rotated: quote matched against the character-reversed page text, which lists SEs "
            "before the label and coefficients. n pooled across sexes (gender-specific coefficients)")
H_SOC_B = ("cognitive skills at 5 and 10; introversion at 10; parents' education and class; household income and FSM "
           "at 10; broadsheet; birth weight, breastfeeding, mother's age; ethnicity; region; tenure; overcrowding")
H_EDU_B = H_SOC_B + " + age-16 GCSE score, A-C A levels, facilitating A levels, highest qualification, degree " \
                    "subject x elite university x class (one block)"
H_JOB = " + job facets (leadership task intensity, participation, work intensity)"
H_SOC_S = ("ethnicity, marital status, dependent children, age, childhood financial situation, parental interest "
           "(no ability)")
H_EDU_S = H_SOC_S + " + education level, degree subject, HEI type (Oxbridge/old universities), degree class, " \
                    "maths qualification (one block)"
ghv = dict(study="GHV2017", src="ghv", comparison="private_vs_state", country="GB", measure="log_points",
           outcome="log_hourly_pay")
BCS42 = dict(cohort="BCS70", birth_years="1970", age="42 (2012)", n=6136)
SES = dict(cohort="SES2006_2012", birth_years="c.1946-1987 (ages 25-60)", age="25-60 (2006, 2012)", n=6547)
GHV_SPECS_B = [(1, "RAW", "none"), (2, "ADJ-PRE", H_SOC_B), (3, "ADJ-MED", H_EDU_B), (4, "ADJ-MED", H_EDU_B + H_JOB)]
GHV_SPECS_S = [(1, "RAW", "none"), (2, "ADJ-PRE", H_SOC_S), (3, "ADJ-MED", H_EDU_S), (4, "ADJ-MED", H_EDU_S + H_JOB),
               (5, "ADJ-MED", H_EDU_S + H_JOB + " + industry")]
for sex, q in (("men", "(0.0574) (0.0460) (0.0539) (0.0473) (0.0524) (0.0458) (0.0467) (0.0436) (0.0464) "
                       "Private school 0.399*** 0.584*** 0.292*** 0.297*** 0.106** 0.173*** 0.081* 0.146*** 0.045 "
                       "Males"),
               ("women", "(0.0466) (0.0471) (0.0448) (0.0474) (0.0435) (0.0455) (0.0427) (0.0417) (0.0411) "
                         "Private school 0.287*** 0.477*** 0.173*** 0.192*** 0.0254 0.058 -0.007 0.064 -0.027 "
                         "Females")):
    ses = re.findall(r"\((0\.\d+)\)", q)
    ests = re.findall(r"(-?0\.\d+)\**(?= |$)", q.split("Private school")[1])
    # printed column order: Raw SES, Raw BCS, +Socio SES, +Socio BCS, +Educ SES, +Educ BCS, +Facets SES,
    # +Facets BCS, +Industry SES (9 dataset tokens; the industry model is SES only)
    order = [("S", 0), ("B", 0), ("S", 1), ("B", 1), ("S", 2), ("B", 2), ("S", 3), ("B", 3), ("S", 4)]
    cells = []
    for (d, j), e, s in zip(order, ests, ses):
        spec_order, estimand, controls = (GHV_SPECS_B if d == "B" else GHV_SPECS_S)[j]
        cells.append(dict(**(BCS42 if d == "B" else SES), sex=sex, spec_order=spec_order, estimand=estimand,
                          controls=controls, est=e, se=s, note=GHV_NOTE + (
                              "; SES school type = last school attended (self-report)" if d == "S" else
                              "; school attended at the age-16 survey")))
    add(ghv, q, 14, "Table 3 (rotated)", *cells)

# ---------------------------------------------------------------- private: GPSW 2018 'Dreaming big?' (BCS70 at 42)
P_PRIOR = ("prior controls: cognitive skills at 5 and 10, introversion at 10, parents' education and class, "
           "income and FSM at 10, tenure, birth and family characteristics, region")
gp = dict(study="GPSW2018", src="gpsw", comparison="private_vs_state", country="GB (excl. Scotland)",
          cohort="BCS70", birth_years="1970", age="42 (2012)", measure="log_points", outcome="log_hourly_pay")
for sex, n, q, ests, ses in (
        ("men", 3108, "Private school 0.294*** 0.248*** 0.171*** (0.0588) (0.0583) (0.0560)",
         ("0.294", "0.248", "0.171"), ("0.0588", "0.0583", "0.0560")),
        ("women", 3028, "Private school 0.187*** 0.142** 0.0688 (0.0572) (0.0576) (0.0548)",
         ("0.187", "0.142", "0.0688"), ("0.0572", "0.0576", "0.0548"))):
    add(gp, q, 15, "Table 5 cols 3-5", *[
        dict(sex=sex, n=n, est=e, se=s, spec_order=k + 1, estimand=est_, controls=ctl, note=nt)
        for k, (e, s, est_, ctl, nt) in enumerate(zip(ests, ses, ("ADJ-PRE", "ADJ-MED", "ADJ-MED"), (
            P_PRIOR,
            P_PRIOR + " + age-16 self-esteem, locus of control, aspirations, high-value network",
            P_PRIOR + " + age-16 self-evaluations/aspirations/networks + age-16 cognition, exam score, A levels, "
                      "facilitating A levels, highest qualification, degree subject x elite x class, share of "
                      "months employed"), (
            "school at 16; no raw column in Table 5",
            "age-16 attributes are potential mediators of private schooling",
            "women: 0.0688 here vs 0.05 in the 2015 working paper")))])

# ---------------------------------------------------------------- private: Henderson et al. 2020 (Next Steps, sixth form)
HA_NOTE = ("treatment = private school at 16-18 among A-level students with GCSE results; LPM coefficients "
           "(the paper calls them 'percentile points'; they are percentage points on a 0-1 scale)")
HA_BG = "GCSE results; region; gender; ethnicity; equivalised household income; social class; parental education; tenure"
hagh = dict(study="HAGH2020", src="hagh", comparison="private_vs_state", country="England", cohort="NextSteps89",
            birth_years="1989-90", measure="frac")
add(hagh, "University attendance 0.67 0.88 0.67 5,852", 7, "Table 1 (means: state, private, overall, N)",
    dict(outcome="he_participation", age="19-20", sex="all", estimand="RAW", controls="none", spec_order=1,
         est="0.21", n=5852, note=HA_NOTE + "; [derived] 0.88 - 0.67 from Table 1 means (weighted)"))
add(hagh, "Russell group university attendance 0.20 0.39 0.21 3,816", 7, "Table 1 (means)",
    dict(outcome="russell_group_or_elite", age="19-20", sex="all", estimand="ADJ-MED", controls="none; sample = "
         "university entrants (conditions on HE entry)", spec_order=1, est="0.19", n=3816,
         note=HA_NOTE + "; [derived] 0.39 - 0.20 from Table 1 means; among university entrants only"))
HA_STEPS = [HA_BG, HA_BG + " + number of A levels", HA_BG + " + number of A levels + A-level rank deciles",
            HA_BG + " + number and rank of facilitating and non-facilitating A levels (disaggregated)"]
add(hagh, "Private schooling 16–18 0.09** (0.03) 0.08* (0.03) 0.07* (0.03) 0.06* (0.03)", 11, "Table 4",
    *[dict(outcome="he_participation", age="19-20", sex="all", estimand="ADJ-MED", controls=c, spec_order=k + 2,
           est=e, se="0.03", n=5852, note=HA_NOTE + ("; GCSE is pre-treatment only for a sixth-form-only route"
                                                     if k == 0 else ""))
      for k, (c, e) in enumerate(zip(HA_STEPS, ("0.09", "0.08", "0.07", "0.06")))])
add(hagh, "Private schooling 16–18 0.10** (0.03) 0.10** (0.03) 0.06+ (0.03) 0.02 (0.03)", 13, "Table 5",
    *[dict(outcome="russell_group_or_elite", age="19-20", sex="all", estimand="ADJ-MED",
           controls=c + "; sample = university entrants", spec_order=k + 2, est=e, se="0.03", n=3816,
           note=HA_NOTE + "; among university entrants only")
      for k, (c, e) in enumerate(zip(HA_STEPS, ("0.10", "0.10", "0.06", "0.02")))])
add(hagh, "Private schooling 16–18 0.16*** (0.02) 0.10*** (0.01) 0.08*** (0.01)", 10, "Table 3a",
    *[dict(outcome="a_level_rank", age="18", sex="all", estimand=es, controls=c, spec_order=k + 1, est=e, se=s,
           n=5852, note="OLS on total A-level percentile rank (0-1 scale); " + HA_NOTE.split(";")[0])
      for k, (es, c, e, s) in enumerate(zip(("RAW", "ADJ-MED", "ADJ-MED"), ("none", "GCSE results", HA_BG),
                                            ("0.16", "0.10", "0.08"), ("0.02", "0.01", "0.01")))])
add(hagh, "Private School 16–18 0.63*** (0.04) 0.34*** (0.04) 0.27*** (0.05)", 8, "Table 2b",
    *[dict(outcome="n_facilitating_a_levels", measure="log_points", age="18", sex="all", estimand=es, controls=c,
           spec_order=k + 1, est=e, se=s, n=5852,
           note="Poisson coefficient on number of facilitating A levels (log-rate); " + HA_NOTE.split(";")[0])
      for k, (es, c, e, s) in enumerate(zip(("RAW", "ADJ-MED", "ADJ-MED"), ("none", "GCSE results", HA_BG),
                                            ("0.63", "0.34", "0.27"), ("0.04", "0.04", "0.05")))])

# ---------------------------------------------------------------- private: Green, Anders, Henderson & Henseke 2020 (Next Steps at 25)
GA_BG = ("parental social class, log permanent family income, parents' education, region, IDACI, gender, ethnicity, "
         "home-disruption index to 13 (no prior attainment)")
GA_ED = GA_BG + " + highest qualification + Russell Group university"
GA_NOTE = "treatment = private school at 13 (2003); parentheses are t statistics: t = "
ga = dict(study="GAHH2020", src="gahh", comparison="private_vs_state", country="England", cohort="NextSteps89",
          birth_years="1989-90", age="25 (2015)", sex="all")


def ga_rows(outcome, measure, n, ests, ts, extra=""):
    return [dict(outcome=outcome, measure=measure, n=n, est=e, spec_order=k + 1, estimand=es, controls=c,
                 note=GA_NOTE + t + extra)
            for k, (e, t, es, c) in enumerate(zip(ests, ts, ("RAW", "ADJ-PRE", "ADJ-MED"), ("none", GA_BG, GA_ED)))]


add(ga, "4. Log of Weekly Pay n=4814 0.346** 0.159** 0.0975+ (6.06) (2.83) (1.84)", 22, "Table 3 panel 4",
    *ga_rows("log_weekly_pay", "log_points", 4814, ("0.346", "0.159", "0.0975"), ("6.06", "2.83", "1.84"),
             "; employees; the text's '10 percent' is this 0.0975; the discussion's '5.5 percent' is the "
             "occupation coefficient, not pay"))
add(ga, "1. High-status occupational attainment n=6129 0.279** 0.120** 0.0552+ (7.77) (3.54) (1.91)", 22,
    "Table 3 panel 1", *ga_rows("top_occupation", "frac", 6129, ("0.279", "0.120", "0.0552"),
                                ("7.77", "3.54", "1.91"), "; NS-SEC 1-2; probit average marginal effects"))
add(ga, "3. Downward mobility n=2773 - 0.200** - 0.116** - 0.0626+ (5.65) (3.33) (1.77)", 22, "Table 3 panel 3",
    *ga_rows("downward_mobility", "frac", 2773, ("-0.200", "-0.116", "-0.0626"), ("5.65", "3.33", "1.77"),
             "; not reaching NS-SEC 1-2 given parents in NS-SEC 1-2; probit AMEs"))
add(ga, "the median pay premium is somewhat higher, at 43 percent", 12, "text (Table 1)",
    dict(outcome="median_weekly_pay", measure="pct", n=None, est="43", spec_order=1, estimand="RAW",
         controls="none", note="raw median gap; mean raw gap 35 percent (Table 1 means 557.2 vs 401.1)"))

# ---------------------------------------------------------------- private: Anders et al. 2024 (MCS, GCSE)
AG_NOTE = "parentheses are p-values, not SEs: p = "
A_CTL = ["none", "SES: permanent equivalised income (piecewise), family NS-SEC, home ownership",
         "SES + gender, ethnicity", "SES + demographics + cognitive tests at age 3 (Bracken, BAS vocabulary)",
         "... + parental values", "... + region, distance to nearest private and outstanding school"]
ag = dict(study="AGHH2024", src="aghh", comparison="private_vs_state", country="England", cohort="MCS01",
          birth_years="2000-02", age="16 (GCSE 2016/17 self-report)", sex="all", measure="grade")


def ag_rows(outcome, n, ests, ps, keep, extra=""):
    return [dict(outcome=outcome, n=n, est=ests[k], spec_order=k + 1, estimand="RAW" if k == 0 else "ADJ-PRE",
                 controls=A_CTL[k], note=AG_NOTE + ps[k] + "; treatment = private at 14; 297 private pupils" + extra)
            for k in keep]


add(ag, "Attended private school 0.87 0.05 −0.06 −0.12 −0.16 −0.18 (0.00)*** (0.73) (0.69) (0.43) (0.30) (0.23)", 12,
    "Table 2 (best 8, per-GCSE grade)", *ag_rows(
        "gcse_grade_best8", 4420, ["0.87", "0.05", "−0.06", "−0.12", "−0.16", "−0.18"],
        ["0.00", "0.73", "0.69", "0.43", "0.30", "0.23"], range(6),
        "; text says 0.83 for M0, table prints 0.87"))
for page, where, outcome, n, q in (
        (12, "Table 3 (English)", "gcse_grade_english", 4263,
         "Attended private school 0.34 −0.17 −0.27 −0.32 −0.36 −0.38 (0.05) (0.33) (0.13) (0.08) (0.04)* (0.04)*"),
        (13, "Table 4 (Maths)", "gcse_grade_maths", 4148,
         "Attended private school −0.10 −0.66 −0.72 −0.77 −0.80 −0.84 (0.62) (0.00)** (0.00)*** (0.00)*** (0.00)*** "
         "(0.00)***"),
        (13, "Table 5 (Science)", "gcse_grade_science", 4043,
         "Attended private school 0.05 −0.41 −0.48 −0.52 −0.54 −0.57 (0.81) (0.02)* (0.01)** (0.00)** (0.00)** "
         "(0.00)**"),
        (13, "Table 6 (Arts)", "gcse_grade_arts", 1128,
         "Attended private school 1.31 0.54 0.44 0.38 0.36 0.30 (0.00)*** (0.00)** (0.02)* (0.04)* (0.05)* (0.10)")):
    body = q.split("school ")[1]
    ests = body.split(" (")[0].split()
    ps = re.findall(r"\((\d\.\d\d)\)", body)
    add(ag, q, page, where, *ag_rows(outcome, n, ests, ps, (0, 1, 3, 5)))

# ---------------------------------------------------------------- private: Crawford & Vignoles 2014 (DLHE graduates)
CV_STEPS = [(1, "ADJ-MED", "graduates only; none"),
            (2, "ADJ-MED", "graduates only; parents' class, POLAR participation quintile, gender, age, ethnicity, region"),
            (3, "ADJ-MED", "graduates only; background + A-level attainment, degree class, institution FE, degree "
                           "subject (one block)"),
            (6, "ADJ-MED", "graduates only; ... + activity at survey [+ qualifications since degree at 3.5y] + own "
                           "NS-SEC at survey (occupation)")]
CV_NOTE = ("treatment = private school at 18; sample = 2006/07 UK first-degree graduates in work, so every row is "
           "ADJ-MED (conditions on graduating) and spec_order gives the within-graduate sequence; coefficients on "
           "log gross annual earnings (the text reads them as %, e.g. '12.8%')")
cv = dict(study="CV2014", src="cv", comparison="private_vs_state", country="UK", cohort="DLHE2006_07",
          birth_years="c.1985 (graduated 2006/07)", measure="log_points", outcome="log_annual_earnings")
for page, where, sex, age, n, q in (
        (19, "Table 3", "all", "6 months after graduation", 74188,
         "Attended private school 0.128*** 0.117*** 0.067*** 0.067*** 0.058*** [0.010] [0.007] [0.006] [0.006] [0.006]"),
        (20, "Table 4", "all", "3.5 years after graduation", 23574,
         "Attended private school 0.172*** 0.127*** 0.068*** 0.068*** 0.071*** 0.060*** [0.017] [0.014] [0.013] "
         "[0.012] [0.012] [0.011]"),
        (22, "Appendix Table 1", "men", "6 months after graduation", 30248,
         "Attended private school 0.140*** 0.134*** 0.080*** 0.080*** N/A 0.067*** [0.011] [0.009] [0.007] [0.007] "
         "[0.007]"),
        (22, "Appendix Table 1", "women", "6 months after graduation", 43940,
         "Attended private school 0.107*** 0.103*** 0.055*** 0.055*** N/A 0.049*** [0.011] [0.008] [0.009] [0.009] "
         "[0.009]"),
        (22, "Appendix Table 1", "men", "3.5 years after graduation", 9663,
         "Attended private school 0.192*** 0.148*** 0.091*** 0.092*** 0.091*** 0.080*** [0.024] [0.021] [0.020] "
         "[0.020] [0.019] [0.018]"),
        (22, "Appendix Table 1", "women", "3.5 years after graduation", 13911,
         "Attended private school 0.141*** 0.108*** 0.046*** 0.046*** 0.051*** 0.041*** [0.016] [0.014] [0.012] "
         "[0.012] [0.011] [0.011]")):
    cols = re.findall(r"(\d\.\d+|N/A)", q.split("[")[0])          # printed columns, N/A included
    pos = [j for j, e in enumerate(cols) if e != "N/A"]             # SEs are printed for these columns only
    ses = re.findall(r"\[(\d\.\d+)\]", q)
    picks = [0, 1, 2, len(pos) - 1]                                 # raw, +background, +attainment block, +occupation
    add(cv, q, page, where, *[dict(sex=sex, age=age, n=n, est=cols[pos[i]], se=ses[i], spec_order=pos[i] + 1,
                                   estimand=s[1], controls=s[2], note=CV_NOTE)
                              for i, s in zip(picks, CV_STEPS)])

# second-hand graduate premiums (quoted in Britton et al. 2016, which itself has no school-type variable)
sec = dict(src="bdsv", comparison="private_vs_state", country="UK", measure="pct", outcome="log_annual_earnings",
           status="unverified_other", estimand="ADJ-MED", spec_order=1)
add(sec, "the private school wage premium for graduates was 7% for males and 0% for females, conditional on "
         "subject of degree and institution", 8, "text",
    dict(study="DV2000", cohort="graduates1980", birth_years="c.1958", age="c.6 years after graduation",
         sex="men", est="7", tok="7%", controls="graduates only; degree subject + institution",
         note="secondary: as cited by BDSV2016 (original not opened)"),
    dict(study="DV2000", cohort="graduates1980", birth_years="c.1958", age="c.6 years after graduation",
         sex="women", est="0", tok="0%", controls="graduates only; degree subject + institution",
         note="secondary: as cited by BDSV2016 (original not opened)"))
add(sec, "Naylor (2002) for a cohort of 1993 graduates (3% wage premium)", 8, "text",
    dict(study="NSM2002", cohort="graduates1993", birth_years="c.1971", age="early career", sex="all", est="3",
         tok="3%", controls="graduates only; occupation-based earnings", note="secondary: as cited by BDSV2016"))

# ---------------------------------------------------------------- private: Macmillan, Tyler & Vignoles 2015 (graduates, top jobs)
mtv = dict(study="MTV2015", src="mtv", comparison="private_vs_state", country="UK", cohort="DLHE2006_07",
           birth_years="c.1985 (graduated 2006/07)", age="3.5 years after graduation", sex="all", measure="pp",
           outcome="top_occupation", n=None)
MTV_NOTE = ("top NS-SEC occupation 3.5 years after graduation; graduates only; baseline 30 per cent; CMPO "
            "briefing text (JSP article not opened)")
add(mtv, "graduates are 9.5 percentage points more", 2, "text (Figure 1), 3-column page: single-line quote",
    dict(est="9.5", spec_order=1, estimand="ADJ-MED", controls="graduates only; none",
         note=MTV_NOTE + "; ADJ-MED because the sample conditions on graduating"))
add(mtv, "adding prior attainment reduces this to six", 2, "text (Figure 1), single-line quote",
    dict(est="6", tok="six", spec_order=3, estimand="ADJ-MED",
         controls="graduates only; family background, gender, ethnicity + UCAS tariff, degree subject and class",
         note=MTV_NOTE + "; [worded]"))
add(mtv, "school graduate is 2.5 percentage points (on", 3, "text (Figure 1), single-line quote",
    dict(est="2.5", spec_order=5, estimand="ADJ-MED",
         controls="graduates only; ... + institution + postgraduate qualifications", note=MTV_NOTE))

# ---------------------------------------------------------------- private and grammar: Sullivan et al. 2018 (BCS70 at 42, NS-SEC 1)
su = dict(study="SPGWP2018", src="sull", country="GB", cohort="BCS70", birth_years="1970", age="42 (2012)",
          outcome="top_occupation", n=None)
SU_RAW = ("people who had been to secondary modern schools had the lowest chance of being in class 1 (9%), followed by "
          "comprehensive pupils (14%), grammar pupils (24%), and non-Tatler private schools (35%). Those who had "
          "been to top private schools were most likely to be in the top social class in mid-life (39%)")
SU_NOTE = "NS-SEC class 1 at 42; school type in 1986; [derived] difference of printed shares: "
add(su, SU_RAW, 11, "text (descriptives)",
    dict(comparison="grammar_vs_comprehensive", sex="all", measure="pp", est="10", spec_order=1, estimand="RAW",
         controls="none", note=SU_NOTE + "24% - 14%"),
    dict(comparison="grammar_vs_secondary_modern", sex="all", measure="pp", est="15", spec_order=1, estimand="RAW",
         controls="none", note=SU_NOTE + "24% - 9%"),
    dict(comparison="private_vs_comprehensive", sex="all", measure="pp", est="21", spec_order=1, estimand="RAW",
         controls="none", note=SU_NOTE + "35% - 14% (non-Tatler private)"),
    dict(comparison="private_vs_comprehensive", sex="all", measure="pp", est="25", spec_order=1, estimand="RAW",
         controls="none", note=SU_NOTE + "39% - 14% (Tatler 'top' private)"))
SU_CTL = "parental education, class, income; gender; cognition at 5 and 10"
add(su, "Men who had attended non-Tatler private schools had 1.7 times the odds of being in the top social class at "
        "42 compared to those who had attended comprehensives", 15, "text (Table 3 model 4)",
    dict(comparison="private_vs_comprehensive", sex="men", measure="ratio", est="1.7", spec_order=4,
         estimand="ADJ-PRE", controls=SU_CTL, note="odds ratio, non-Tatler private; Tatler coefficient positive "
                                                   "but not significant (not printed in text)"))
add(su, "There was no statistically significant grammar school advantage, or secondary modern disadvantage", 16,
    "text (Table 3 model 4)",
    dict(comparison="grammar_vs_comprehensive", sex="all", measure="ratio", est=None, spec_order=4,
         estimand="ADJ-PRE", controls=SU_CTL, note="not significant; odds ratio not printed in the text (Table 3 "
                                                   "cells scrambled in extraction)"))

# ---------------------------------------------------------------- grammar and private: HEPI 2020 (elite HE entry)
SH_NOTE = "BCS70 at 42; elite = degree from a university now in the Russell Group; [derived] difference of printed shares: "
sh = dict(study="SULLIVAN2020", src="hepi", country="GB", cohort="BCS70", birth_years="1970", age="42 (2012)",
          sex="all", measure="pp", n=None, spec_order=1, estimand="RAW", controls="none")
add(sh, "64 per cent of individuals who had been to private schools had a degree by age 42, compared to 37 per cent "
        "of those who had attended grammar schools, 21 per cent from comprehensives and just 12 per cent from "
        "secondary moderns", 33, "text (Figure 1)",
    dict(comparison="grammar_vs_comprehensive", outcome="degree", est="16", note=SH_NOTE.replace(
        "elite = degree from a university now in the Russell Group; ", "") + "37 - 21"),
    dict(comparison="grammar_vs_secondary_modern", outcome="degree", est="25", note=SH_NOTE.replace(
        "elite = degree from a university now in the Russell Group; ", "") + "37 - 12"),
    dict(comparison="private_vs_comprehensive", outcome="degree", est="43", note=SH_NOTE.replace(
        "elite = degree from a university now in the Russell Group; ", "") + "64 - 21"))
add(sh, "29 per cent of private school pupils got degrees from elite universities, compared to 12 per cent of those "
        "from grammars, 5 per cent from comprehensives and just 3 per cent from secondary moderns", 33,
    "text (Figure 1)",
    dict(comparison="grammar_vs_comprehensive", outcome="russell_group_or_elite", est="7", note=SH_NOTE + "12 - 5"),
    dict(comparison="grammar_vs_secondary_modern", outcome="russell_group_or_elite", est="9", note=SH_NOTE + "12 - 3"),
    dict(comparison="private_vs_comprehensive", outcome="russell_group_or_elite", est="24", note=SH_NOTE + "29 - 5"))
SH_CTL = "socio-economic background and test scores up to age 10"
add(sh, "Once we had controlled for these factors, there was no advantage in the chances of accessing a ‘top’ "
        "university for people who had been to grammar schools compared to those who had been to comprehensives", 34,
    "text", dict(comparison="grammar_vs_comprehensive", outcome="russell_group_or_elite", measure="frac", est=None,
                 spec_order=2, estimand="ADJ-PRE", controls=SH_CTL, note="no grammar advantage; no number printed"))
add(sh, "private schools appeared to confer a genuine advantage in the chances of attending an elite university", 35,
    "text", dict(comparison="private_vs_comprehensive", outcome="russell_group_or_elite", measure="frac", est=None,
                 spec_order=2, estimand="ADJ-PRE", controls=SH_CTL, note="private advantage persists; no number printed"))
BCM_NOTE = ("secondary: Burgess, Crawford & Macmillan (2019) mimeo as reported by Dickson & Macmillan (HEPI 2020); "
            "high-status HE = Russell Group + institutions with 2001 RAE above the lowest RG (41 of 163)")
bcm = dict(study="BCM2019", src="hepi", country="England", cohort="NPD_HESA", birth_years="n/a (not stated in HEPI)",
           age="18-20 (HE entry)", sex="all", measure="pp", n=None, outcome="russell_group_or_elite", spec_order=1,
           estimand="ADJ-PRE", status="unverified_other",
           controls="individual matching of selective-area pupils to non-selective-area peers (KS2 and characteristics)")
add(bcm, "grammar school pupils are on average only 7 percentage points more likely to attend a high- status institution "
         "that their non-selective peers", 21, "text (Dickson & Macmillan chapter)",
    dict(comparison="grammar_vs_comprehensive", est="7", note=BCM_NOTE + "; grammar pupils vs matched pupils in "
                                                                          "non-selective areas"))
add(bcm, "attaining KS2 students in selective areas have a 2.1 percentage points (p<0.001) lower probability of "
         "attending an elite HE institution than the equivalent comprehensive area student", 48, "endnote 14",
    dict(comparison="selective_system_vs_comprehensive_system", est="-2.1", tok="2.1",
         note=BCM_NOTE + "; low-KS2 pupils in selective areas vs comprehensive-area equivalents; [signed] sign "
                         "from 'lower'"))
add(bcm, "miss out on a grammar place have a 7.0 percentage point (p<0.001) lower probability of attending an elite HE "
         "institution than their comprehensive area equivalents", 48, "endnote 14",
    dict(comparison="selective_system_vs_comprehensive_system", est="-7.0", tok="7.0",
         note=BCM_NOTE + "; higher-KS2 pupils who missed a grammar place vs comprehensive-area equivalents; [signed] sign "
                         "from 'lower'"))
MF_NOTE = ("area-level raw comparison, DfE destinations 2016, KS5 students only (Boliver & Capsada-Munsech: early "
           "secondary-modern leavers missing); not area-matched; [derived] difference of printed per cents: ")
mf = dict(study="MANSFIELD2019", src="hepi", comparison="selective_system_vs_comprehensive_system", country="England",
          cohort="DfE_destinations2016", birth_years="c.1997", age="19 (destinations)", sex="all", measure="pp",
          spec_order=1, estimand="RAW", controls="none", status="unverified_other", n=None)
add(mf, "Grammar Schools 35,090 65 39 3 and Secondary Moderns Comprehensives 147,785 59 23 1", 19,
    "table (reproduced from Mansfield 2019)",
    dict(outcome="he_participation", est="6", note=MF_NOTE + "65 - 59"),
    dict(outcome="russell_group_or_elite", est="16", note=MF_NOTE + "39 - 23 (highly selective HE)"),
    dict(outcome="oxbridge", est="2", note=MF_NOTE + "3 - 1"))

# ---------------------------------------------------------------- channel second stage: IFS 2026 (LEO, 2002 GCSE cohort)
IFS_CTL = ("HE (full-time degree started before 21) vs no HE; counterfactual from KS2, GCSE, KS5 points and subjects, "
           "region, ethnicity, FSM, IDACI, private school at GCSE, SEN, EAL")
IFS_NOTE = "2025/26 CPI prices, Green Book discounting to age 18; mean unless stated"
ifs = dict(study="IFS2026", src="ifs", comparison="channel_second_stage", country="England", cohort="LEO_GCSE2002",
           birth_years="1985-86", age="lifetime 17-67 (actual to 37, simulated after)", measure="gbp", n=None,
           estimand="ADJ-PRE", controls=IFS_CTL, note=IFS_NOTE)
add(ifs, "Difference in pre-tax lifetime earnings £288k 48% £388k 44% £317k 42% between those who do and do not go "
         "to university", 38, "Table 5.1",
    dict(outcome="raw_lifetime_earnings_gap_gbp__all_he", sex="women", est="288000", tok="288k", spec_order=1,
         estimand="RAW", controls="none (HE vs no HE)"),
    dict(outcome="raw_lifetime_earnings_gap_gbp__all_he", sex="men", est="388000", tok="388k", spec_order=1,
         estimand="RAW", controls="none (HE vs no HE)"))
add(ifs, "Difference in pre-tax lifetime earnings £148k 20% £215k 20% £179k 20% not explained by observable "
         "characteristics (gross earnings return)", 38, "Table 5.1",
    dict(outcome="gross_lifetime_return_gbp__all_he", sex="women", est="148000", tok="148k", spec_order=2),
    dict(outcome="gross_lifetime_return_gbp__all_he", sex="men", est="215000", tok="215k", spec_order=2))
add(ifs, "Net lifetime individual return £90k 16% £109k 15% £99k 15%", 38, "Table 5.1",
    dict(outcome="net_lifetime_return_gbp__all_he", sex="women", est="90000", tok="90k", spec_order=3),
    dict(outcome="net_lifetime_return_gbp__all_he", sex="men", est="109000", tok="109k", spec_order=3))
add(ifs, "Median return (£k) 67 60 63 16 39 24", 43, "Table 5.2",
    dict(outcome="net_lifetime_return_gbp__all_he_median", sex="women", est="67000", tok="67", spec_order=3,
         note=IFS_NOTE.replace("mean unless stated", "median")),
    dict(outcome="net_lifetime_return_gbp__all_he_median", sex="men", est="60000", tok="60", spec_order=3,
         note=IFS_NOTE.replace("mean unless stated", "median")))
RG_Q = ("differences in average returns between men at Russell Group universities (£178,000), pre-1992 universities "
        "(£109,000) and other universities (£60,000 and £64,000 amongst more and less selective)")
add(ifs, RG_Q, 44, "text (Figure 5.9)", *[
    dict(outcome="net_lifetime_return_gbp__" + inst, sex="men", est=v, tok=t, spec_order=3,
         note=IFS_NOTE + "; vs no HE, not vs another institution type; the RG premium over other types is a "
                         "difference of these rows and mixes student composition")
    for inst, v, t in (("russell_group", "178000", "178,000"), ("pre1992_non_rg", "109000", "109,000"),
                       ("other_more_selective", "60000", "60,000"), ("other_less_selective", "64000", "64,000"))])
add(ifs, "The high average returns for men who studied at Russell Group universities are pulled up by some "
         "individuals with very high returns (the median is £93,000)", 44, "footnote 31",
    dict(outcome="net_lifetime_return_gbp__russell_group_median", sex="men", est="93000", tok="93,000", spec_order=3,
         note=IFS_NOTE.replace("mean unless stated", "median")))
add(ifs, "with average returns for women at Russell Group universities around a quarter higher (£107,000)", 44,
    "text (Figure 5.9)",
    dict(outcome="net_lifetime_return_gbp__russell_group", sex="women", est="107000", tok="107,000", spec_order=3,
         note=IFS_NOTE + "; women's other institution types are only described as 'fairly similar' (about a "
                         "quarter lower than RG); no number printed in text"))
add(ifs, "over £300,000 for economics and over £400,000 for medicine", 43, "text (Figure 5.6)",
    dict(outcome="net_lifetime_return_gbp__economics", sex="women", est="300000", tok="300,000", spec_order=3,
         note=IFS_NOTE + "; lower bound ('over')"),
    dict(outcome="net_lifetime_return_gbp__medicine", sex="women", est="400000", tok="400,000", spec_order=3,
         note=IFS_NOTE + "; lower bound ('over')"))
add(ifs, "close to £200,000 for business, medical sciences and law", 43, "text (Figure 5.6)",
    dict(outcome="net_lifetime_return_gbp__business_medsci_law", sex="women", est="200000", tok="200,000",
         spec_order=3, note=IFS_NOTE + "; approximate ('close to')"))
add(ifs, "men are medicine (close to £500,000) and economics (over £650,000)", 44, "text (Figure 5.7)",
    dict(outcome="net_lifetime_return_gbp__medicine", sex="men", est="500000", tok="500,000", spec_order=3,
         note=IFS_NOTE + "; approximate ('close to')"),
    dict(outcome="net_lifetime_return_gbp__economics", sex="men", est="650000", tok="650,000", spec_order=3,
         note=IFS_NOTE + "; lower bound ('over')"))
add(ifs, "(compared with the median of around £450,000)", 44, "text (Figure 5.7)",
    dict(outcome="net_lifetime_return_gbp__economics_median", sex="men", est="450000", tok="450,000", spec_order=3,
         note=IFS_NOTE.replace("mean unless stated", "median") + "; approximate ('around')"))

# ---------------------------------------------------------------- grammar: Clark & Del Bono 2016 (Aberdeen, fuzzy RD)
CD_SPECS = [(1, "RAW", "none"),
            (2, "ADJ-PRE", "cubic in the 11+ assignment score + school/grade in 1962, father's occupation, mother's "
                           "SES, age in grade, quartic in age-7 and age-9 tests"),
            (3, "ADJ-PRE", "2SLS (fuzzy RD): cubic in the assignment score only"),
            (4, "ADJ-PRE", "2SLS (fuzzy RD): cubic in the assignment score + the OLS+X covariates")]
cd = dict(study="CDB2016", src="cdb", comparison="grammar_vs_secondary_modern", country="Scotland (Aberdeen)",
          cohort="Aberdeen1950s", birth_years="1950-56")
CD_NOTE = ("elite 'senior secondary' vs non-elite school; 2SLS rows are LATEs at the assignment threshold "
           "(marginal entrant, c. 80th ability percentile); IZA DP 8617 numbers (AEJ version paywalled)")
for page, where, outcome, measure, age, ns, q, extra in (
        (50, "Table 2", "log_annual_income", "log_points", "late 40s (2001)", (2035, 2344),
         "Log Annual 0.422 0.0296 -0.0655 -0.0521 0.490 0.222 0.158 0.172 Income (0.0322) (0.0560) (0.0652) (0.0660) "
         "(0.0415) (0.0812) (0.0974) (0.101)", "; income recorded in 8 bands, about 20% of men top-coded"),
        (50, "Table 2", "log_hourly_wage_imputed", "log_points", "late 40s (2001)", (1862, 2110),
         "Imputed log 0.356 0.0668 -0.0279 -0.00798 0.356 0.0625 0.0741 0.0679 hourly wage (0.0230) (0.0396) (0.0511) "
         "(0.0544) (0.0250) (0.0369) (0.0490) (0.0458)", "; hourly wage imputed from occupation"),
        (49, "Table 1", "a_level", "frac", "17", (2072, 2397),
         "0.523 0.201 0.107 0.128 0.601 0.243 0.230 0.198 A levels (0.0265) (0.0427) (0.0592) (0.0554) (0.0250) "
         "(0.0381) (0.0519) (0.0508)", "; control mean men 0.46, women 0.41"),
        (49, "Table 1", "degree", "frac", "adult (2001)", (2072, 2397),
         "0.425 0.179 0.162 0.157 0.325 0.0416 0.0332 0.0251 Degree (0.0283) (0.0411) (0.0508) (0.0475) (0.0245) "
         "(0.0317) (0.0409) (0.0411)", "; control mean men 0.14, women 0.18")):
    ests = re.findall(r"(?<![(\d])(-?\d\.\d+)(?![)\d])", q)
    ses = re.findall(r"\((\d\.\d+)\)", q)
    add(cd, q, page, where, *[
        dict(outcome=outcome, measure=measure, age=age, sex=("men", "women")[i // 4], n=ns[i // 4], est=ests[i],
             se=ses[i], spec_order=CD_SPECS[i % 4][0], estimand=CD_SPECS[i % 4][1], controls=CD_SPECS[i % 4][2],
             note=CD_NOTE + extra) for i in range(8)])

# ---------------------------------------------------------------- grammar: Clark 2010 (East Riding)
cl = dict(study="CLARK2010", src="clark", comparison="grammar_vs_secondary_modern", country="England (East Riding)",
          cohort="EastRiding1969_71", birth_years="n/a (grade 9 in 1969-71)", sex="all")
add(cl, "Selective 0.199 0.057 0.057 0.031 0.052 0.062 0.044 (0.050) (0.088) (0.090) (0.082) (0.154) (0.156) (0.148)",
    48, "Table 3 (boys, mean 6%)",
    dict(outcome="university_enrolment", measure="frac", age="18+", sex="men", n=359, est="0.199", se="0.050",
         spec_order=1, estimand="RAW", controls="none (probit)", note="column (1); boys only (girls' enrolment too low)"),
    dict(outcome="university_enrolment", measure="frac", age="18+", sex="men", n=359, est="0.057", se="0.088",
         spec_order=2, estimand="ADJ-PRE", controls="probit + assignment test score (Test_11)", note="column (2)"),
    dict(outcome="university_enrolment", measure="frac", age="18+", sex="men", n=359, est="0.052", se="0.154",
         spec_order=3, estimand="ADJ-PRE", controls="IV on assignment test score", note="column labelled (6); IV "
                                                                                        "columns (6)-(8) span 0.044-0.062"))
add(cl, "Ordinary least squares estimates suggest effects of around one third of a standard deviation", 6, "text",
    dict(outcome="test_score_age16", measure="sd", age="16", n=None, est="0.33", tok="one third", spec_order=2,
         estimand="ADJ-PRE", controls="OLS conditional on assignment test score",
         note="[worded] 'around one third of a standard deviation'"))
add(cl, "estimates suggest effects of around one sixth of a standard deviation, with confidence intervals failing to "
        "rule out zero effects", 7, "text",
    dict(outcome="test_score_age16", measure="sd", age="16", n=None, est="0.17", tok="one sixth", spec_order=3,
         estimand="ADJ-PRE", controls="IV on assignment test score",
         note="[worded] 'around one sixth of a standard deviation'; CI includes zero"))

# ---------------------------------------------------------------- grammar: Birkelund et al. 2021 (NCDS, lifetime earnings)
bk = dict(study="BCBK2021", src="bckk", comparison="grammar_vs_other_state", country="England and Wales",
          cohort="NCDS58", birth_years="1958", age="23-55 cumulative (6 sweeps, interpolated)", measure="gbp",
          outcome="lifetime_earnings_gbp")
BK_NOTE = "2018 prices, pre-tax, top 1% censored at P99; comparator = secondary modern + comprehensive; private excluded"
BK_CTL = "gender, three age-11 ability tests (and squares), parental education, class, income, family type, " \
         "siblings, region"
add(bk, "The first model only adjusting for gender displays a comparable gross between-school earnings gaps of "
        "255,000 GBP in England", 28, "text (Figure 3)",
    dict(sex="all", est="255000", tok="255,000", spec_order=1, estimand="RAW", controls="gender only", note=BK_NOTE))
add(bk, "Lifetime cumulative earnings gap 38,746 19,372 2.00 0.046 738 76,754", 43, "Table C1",
    dict(sex="all", est="38746", tok="38,746", se="19372", se_tok="19,372", ci_low="738", ci_high="76754",
         spec_order=3, estimand="ADJ-PRE", controls=BK_CTL, note=BK_NOTE + "; text rounds to 39,000"))
add(bk, "Men 82,265 31,425 2.62 0.009 20,603 143,927", 43, "Table C1",
    dict(sex="men", est="82265", tok="82,265", se="31425", se_tok="31,425", ci_low="20603", ci_high="143927",
         spec_order=3, estimand="ADJ-PRE", controls=BK_CTL, note=BK_NOTE + "; gender interaction model"))
add(bk, "Women 5,537 21,453 0.26 0.796 -36,553 47,628", 43, "Table C1",
    dict(sex="women", est="5537", tok="5,537", se="21453", se_tok="21,453", ci_low="-36553", ci_high="47628",
         spec_order=3, estimand="ADJ-PRE", controls=BK_CTL, note=BK_NOTE + "; gender interaction model"))
add(bk, "excluding these measures from the model increases the between-school gap in lifetime earnings to 88,000 GBP "
        "in England", 45, "text (robustness)",
    dict(sex="all", est="88000", tok="88,000", spec_order=2, estimand="ADJ-PRE",
         controls="gender, general ability at 11 only (reading and maths tests dropped), family background",
         note=BK_NOTE + "; shows how much the measured filter matters"))
add(bk, "Subsequent educational pathways mediate 65 percent of the modest gap in England, leaving only a small "
        "residual and statistically insignificant gap", 28, "text (Figure 3)",
    dict(sex="all", outcome="lifetime_earnings_share_mediated_by_education", measure="pct", est="65", spec_order=4,
         estimand="ADJ-MED", controls=BK_CTL + " + final educational attainment",
         note=BK_NOTE + "; share of the ADJ-PRE gap mediated; residual gap not printed, n.s."))
add(bk, "the former only reaching statistical significance at ages 23 (about 700 GBP per year) and 55 (about 3,200 GBP "
        "per year)", 28, "text (Figure 2)",
    dict(sex="all", outcome="annual_earnings_gbp", age="23", est="700", spec_order=3, estimand="ADJ-PRE",
         controls=BK_CTL, note=BK_NOTE + "; approximate ('about'); only significant ages"),
    dict(sex="all", outcome="annual_earnings_gbp", age="55", est="3200", tok="3,200", spec_order=3,
         estimand="ADJ-PRE", controls=BK_CTL, note=BK_NOTE + "; approximate ('about'); only significant ages"))

# ---------------------------------------------------------------- grammar: Pastore & Jones 2023 (NCDS, fuzzy RD)
pj = dict(study="PJ2023", src="pj", comparison="grammar_vs_secondary_modern", country="England and Wales",
          cohort="NCDS58", birth_years="1958", sex="all")
PJ_CTL = "fuzzy RD at LEA thresholds estimated from age-11 tests; local linear, MSE-optimal bandwidth; five covariates"
PJ_NOTE = "LATE for the marginal entrant; SEs clustered at LEA"
add(pj, "Grammar 0.2607*** 0.1461* 0.0027 −0.0454 0.0693 (0.0753) (0.0678) (0.0442) (0.0504) (0.1665)", 10, "Table 2",
    dict(outcome="a_level", measure="frac", age="by 33", n=1599, est="0.2607", se="0.0753", spec_order=2,
         estimand="ADJ-PRE", controls=PJ_CTL, note=PJ_NOTE + "; n = obs in bandwidth"),
    dict(outcome="degree", measure="frac", age="by 33", n=1538, est="0.1461", se="0.0678", spec_order=2,
         estimand="ADJ-PRE", controls=PJ_CTL, note=PJ_NOTE + "; n = obs in bandwidth"),
    dict(outcome="log_hourly_pay", measure="log_points", age="33 (1991)", n=791, est="0.0693", se="0.1665",
         spec_order=2, estimand="ADJ-PRE", controls=PJ_CTL, note=PJ_NOTE + "; n = obs in bandwidth; n.s."))
add(pj, "dance increases the probability of obtaining A-levels by 25 percentage points (𝑝 < 0.01) and the "
        "probability of obtaining a university degree by 19 percentage points", 10, "text (CCT bias-corrected)",
    dict(outcome="a_level", measure="pp", age="by 33", n=None, est="25", spec_order=3, estimand="ADJ-PRE",
         controls=PJ_CTL + "; CCT bias-corrected", note=PJ_NOTE),
    dict(outcome="degree", measure="pp", age="by 33", n=None, est="19", spec_order=3, estimand="ADJ-PRE",
         controls=PJ_CTL + "; CCT bias-corrected", note=PJ_NOTE))
add(pj, "a higher chance of getting A-levels (50% vs. 3%) and a university degree (31% vs. 2%)", 7, "text (Table 1)",
    dict(outcome="a_level", measure="pp", age="by 33", n=None, est="47", spec_order=1, estimand="RAW",
         controls="none", note="[derived] 50% - 3%, grammar vs secondary modern"),
    dict(outcome="degree", measure="pp", age="by 33", n=None, est="29", spec_order=1, estimand="RAW",
         controls="none", note="[derived] 31% - 2%, grammar vs secondary modern"))

# ---------------------------------------------------------------- grammar and private: Dearden, Ferri & Meghir 2002 (NCDS)
DF_ED = ("highest qualification, local area and enumeration-district characteristics, family background, region, "
         "tests at 7 and 11, pupil-teacher ratio, single-sex school")
DF_NOED = DF_ED.replace("highest qualification, ", "")
df = dict(study="DFM2002", src="dfm", country="England and Wales", cohort="NCDS58", birth_years="1958",
          measure="log_points", outcome="log_hourly_pay")
DF_NOTE = "school type in 1974 (age 16); comprehensive is the omitted category"
for page, sex, ages_n, q_g, q_p in (
        (10, "men", (("23 (1981)", 1700), ("33 (1991)", 1523)),
         "Grammar school 0.029 0.024 Grammar school 0.058 0.086 (0.029) (0.028) (0.035) (0.036)",
         "Private school -0.006 -0.010 Private school 0.195 0.22 (0.043) (0.044) (0.052) (0.054)"),
        (11, "women", (("23 (1981)", 1486), ("33 (1991)", 1324)),
         "Grammar school -0.008 0.030 Grammar school -0.026 0.057 (0.024) (0.026) (0.040) (0.043)",
         "Private school -0.012 0.011 Private school -0.026 0.037 (0.040) (0.042) (0.059) (0.065)")):
    for comp, q in (("grammar_vs_comprehensive", q_g), ("private_vs_comprehensive", q_p)):
        ests = re.findall(r"(?<![(\d])(-?\d\.\d+)(?![)\d])", q)
        ses = re.findall(r"\((\d\.\d+)\)", q)
        cells = []
        for i in range(4):
            age, n = ages_n[i // 2]
            spec3 = i % 2 == 0
            cells.append(dict(comparison=comp, sex=sex, age=age, n=n, est=ests[i], se=ses[i],
                              spec_order=2 if spec3 else 1, estimand="ADJ-MED" if spec3 else "ADJ-PRE",
                              controls=DF_ED if spec3 else DF_NOED,
                              note=DF_NOTE + ("; spec 3 (with qualifications)" if spec3 else
                                              "; spec 4 (no qualifications)")))
        add(df, q, page, "Tables 7-10 (age 23 | age 33)", *cells)
DF_PSM = ("propensity-score matching (kernel, nearest neighbour) on family background, local characteristics, tests "
          "at 7 and 11, region, pupil-teacher ratio, single-sex; not on qualifications")
add(df, "selective school of 0.0987 0.0352 0.0823", 13, "Table 12 (ATT)",
    *[dict(comparison="school_quality_other", sex=s, age="33 (1991)", n=n, est=e, se=se_, se_tok=None, ci_low=lo,
           ci_high=hi, spec_order=3, estimand="ADJ-PRE", controls=DF_PSM,
           note="selective = grammar and private pooled vs non-selective; ATT; bootstrap SD and 95% CI from the "
                "same table (SD row: (0.0799) (0.0790) (0.0567))")
      for s, n, e, se_, lo, hi in (("men", 237, "0.0987", "0.0799", "-0.127", "0.218"),
                                   ("women", 240, "0.0352", "0.0790", "-0.210", "0.124"),
                                   ("all", 486, "0.0823", "0.0567", "-0.074", "0.150"))])
add(df, "selective school on 0.2080 0.0821 0.1248", 13, "Table 12 (ATNT)",
    *[dict(comparison="school_quality_other", sex=s, age="33 (1991)", n=n, est=e, se=se_, se_tok=None, ci_low=lo,
           ci_high=hi, spec_order=4, estimand="ADJ-PRE", controls=DF_PSM,
           note="selective = grammar and private pooled; ATNT (effect on those attending non-selective schools); "
                "SD row: (0.0644) (0.0736) (0.0508)")
      for s, n, e, se_, lo, hi in (("men", 645, "0.2080", "0.0644", "0.081", "0.349"),
                                   ("women", 557, "0.0821", "0.0736", "-0.123", "0.166"),
                                   ("all", 1272, "0.1248", "0.0508", "0.018", "0.209"))])

# ---------------------------------------------------------------- selective system: Burgess, Dickson & Macmillan 2020 (USoc)
BD_CTL = "gender, age (gender-specific quadratic), ethnicity, parental occupational class at 14, parental education, " \
         "current county"
bd = dict(study="BDM2020", src="bdm", comparison="selective_system_vs_comprehensive_system", country="England",
          cohort="USoc_born1961_83", birth_years="1961-83", age="25-50 (2009-12)", measure="gbp")
BD_NOTE = "hourly wage in 2000 £; selective-area (LEA of birth) effect at the quantile; area-matched design"
add(bd, "Hourly wage: mean 8.75 8.76", 15, "Table 4",
    dict(outcome="hourly_wage_mean", sex="all", n=2033, est="-0.01", spec_order=1, estimand="RAW", controls="none",
         note=BD_NOTE.replace("at the quantile", "on the mean") + "; [derived] 8.75 - 8.76"))
for q in ("10 -2.195 0.559 -3.93*** 10 -1.019 0.399 -2.56**", "25 -0.308 0.233 -1.32 25 -0.284 0.259 -1.09",
          "50 -0.227 0.151 -1.50 50 -0.494 0.259 -1.91*", "75 0.699 0.394 1.77* 75 0.103 0.361 0.29",
          "90 1.574 0.637 2.47** 90 1.312 0.559 2.35**"):
    t = q.split()
    add(bd, q, 16, "Table 5", *[dict(outcome=f"hourly_wage_p{t[0]}", sex="all", n=2033, est=t[k + 1], se=t[k + 2],
                                     spec_order=1 if k == 0 else 2, estimand="RAW" if k == 0 else "ADJ-PRE",
                                     controls="age x gender only" if k == 0 else BD_CTL, note=BD_NOTE)
                                for k in (0, 4)])
add(bd, "90–10 15.66 3.768 0.808*** 24.06 12.07 2.331 0.615*** 19.31", 17, "Table 6",
    dict(outcome="hourly_wage_90_10_gap", sex="all", n=2033, est="3.768", se="0.808", spec_order=1, estimand="RAW",
         controls="age x gender only", note=BD_NOTE + "; = 24.06% of the sample 90-10 gap"),
    dict(outcome="hourly_wage_90_10_gap", sex="all", n=2033, est="2.331", se="0.615", spec_order=2,
         estimand="ADJ-PRE", controls=BD_CTL, note=BD_NOTE + "; = 19.31% of the sample 90-10 gap"))
for q in ("10 -0.057 0.568 -0.10 10 -1.069 0.552 -1.94*", "50 0.706 0.382 1.85* 50 -0.994 0.218 -4.56***",
          "90 2.386 0.917 2.60*** 90 0.111 0.524 0.210"):
    t = q.split()
    add(bd, q, 18, "Table 7 (conditional, by gender)",
        dict(outcome=f"hourly_wage_p{t[0]}", sex="men", n=912, est=t[1], se=t[2], spec_order=2, estimand="ADJ-PRE",
             controls=BD_CTL, note=BD_NOTE),
        dict(outcome=f"hourly_wage_p{t[0]}", sex="women", n=1121, est=t[5], se=t[6], spec_order=2,
             estimand="ADJ-PRE", controls=BD_CTL, note=BD_NOTE))

# ---------------------------------------------------------------- selective system: Galindo-Rueda & Vignoles 2005 (NCDS, matching)
gr = dict(study="GRV2005", src="grv", comparison="selective_system_vs_comprehensive_system", country="England and Wales",
          cohort="NCDS58", birth_years="1958", n=None, estimand="ADJ-PRE")
GR_CTL = "propensity-score matching (caliper 0.005) on predicted probability of a selective-system school"
GR_NOTE = ("selective system = grammar or secondary modern vs comprehensive; by age-11 ability quintile (Q1 lowest, "
           "Q5 highest); subject to the Manning-Pischke placebo critique")
for q, outcome, measure, age, extra in (
        ("A-level or higher academic 0.013 0.143 -0.054 0.129 qualification. (0.029) (0.065) (0.032) (0.063)",
         "a_level", "frac", "by 33", ""),
        ("Maths score 16 0.973 1.916 -0.203 3.016 (0.524) (0.725) (0.545) (0.691)", "math_score_age16", "points", "16",
         ""),
        ("Maths score 11 0.517 2.573 0.119 2.851 (0.799) (0.913) (0.885) (0.940)", "math_score_age11_placebo", "points",
         "11", "; PLACEBO: measured at entry to secondary school, so any 'effect' is selection")):
    ests = re.findall(r"(?<![(\d])(-?\d\.\d+)(?![)\d])", q)
    ses = re.findall(r"\((\d\.\d+)\)", q)
    add(gr, q, 42, "Table 3", *[
        dict(outcome=outcome, measure=measure, age=age, sex=("men", "men", "women", "women")[i], est=ests[i],
             se=ses[i], spec_order=1, controls=GR_CTL + ("; ability Q1" if i % 2 == 0 else "; ability Q5"),
             note=GR_NOTE + extra) for i in range(4)])

# ---------------------------------------------------------------- selective system: Manning & Pischke 2006 (NCDS placebo)
mp = dict(study="MP2006", src="mp", comparison="selective_system_vs_comprehensive_system", country="England and Wales",
          cohort="NCDS58", birth_years="1958", sex="all", measure="points")
MP_NOTE = ("sign = comprehensive minus selective (grammar + secondary modern) LEAs; math test points (age-16 SD 22.4)")
MP_C = ["none", "math test at entry", "+ other entry tests", "+ Kerkhoff-type background", "+ large background set"]
for page, outcome, age, ns, q, extra in (
        (24, "math_score_age16", "16", (6734,) * 4 + (5747,),
         "-7.74 -2.18 -2.07 -1.80 -1.48 Attends Comprehensive School (0.54) (0.35) (0.34) (0.34) (0.37)",
         "; value-added design, controls measured at 11"),
        (24, "math_score_age11_placebo", "11", (6734,) * 4 + (6223,),
         "-8.39 -6.01 -4.91 -3.96 -3.29 Attends Comprehensive School (0.62) (0.52) (0.46) (0.45) (0.45)",
         "; PLACEBO: age-11 outcome on age-7 controls, before secondary school")):
    ests = re.findall(r"-\d\.\d+", q)
    ses = re.findall(r"\((\d\.\d+)\)", q)
    add(mp, q, page, "Table 1" if age == "16" else "Table 2", *[
        dict(outcome=outcome, age=age, n=ns[k], est=ests[k], se=ses[k], spec_order=k + 1,
             estimand="RAW" if k == 0 else "ADJ-PRE",
             controls=MP_C[k].replace("entry", "11" if age == "16" else "7"), note=MP_NOTE + extra)
        for k in range(5)])

# ---------------------------------------------------------------- grammar expansion: Guyon, Maurin & McNally 2012 (Northern Ireland)
gm2 = dict(study="GMM2012", src="gmm", comparison="school_quality_other", country="Northern Ireland",
           cohort="NI1977_80", birth_years="1977-80", sex="all", n=None, estimand="ADJ-PRE")
GM_NOTE = ("system-level: 1989 transfer reform raised grammar entry ~15% (1979 cohort); includes effects on "
           "non-grammar pupils; per 10% increase in grammar entrants")
add(gm2, "a 10 percent increase in the proportion of students selected into elite schools generates a 4.1 percent "
         "increase in the number of successful students at age 16 and a 7.5 percent increase at age 18", 17,
    "text (Table 2 cols 4-5, 2SLS)",
    dict(outcome="n_gcse_successes", measure="pct", age="16", est="4.1", spec_order=1,
         controls="2SLS on the reform discontinuity; cohort size", note=GM_NOTE + "; five or more GCSEs A*-C"),
    dict(outcome="n_three_a_levels", measure="pct", age="18", est="7.5", spec_order=1,
         controls="2SLS on the reform discontinuity; cohort size", note=GM_NOTE + "; three or more A levels"))
add(gm2, "generates a 5 percent difference across areas in the increase in university attendance between the same "
         "period (0.53 elasticity significant at the 1 percent level)", 25, "text (Table 4 model 3)",
    dict(outcome="university_attendance", measure="elasticity", age="18-19", est="0.53", spec_order=1,
         controls="area long differences 1977-78 vs 1979-80", note=GM_NOTE))

# ---------------------------------------------------------------- grammar and private: Smith-Woolley et al. 2018 (TEDS)
sw = dict(study="SW2018", src="sw", country="UK", cohort="TEDS94_96", birth_years="1994-96", age="16 (GCSE)",
          sex="all", measure="sd", outcome="gcse_sd", n=4814)
SW_CTL = "family SES, prior ability, prior achievement, EduYears polygenic score"
add(sw, "those attending grammar schools (d=1.05, 95% CIs=0.83–1.28)", 4, "text",
    dict(comparison="grammar_vs_comprehensive", est="1.05", ci_low="0.83", ci_high="1.28", spec_order=1,
         estimand="RAW", controls="none", note="Cohen's d vs state non-selective schools"))
add(sw, "and private school students (d=0.92, 95% CIs=0.75–1.09)", 4, "text",
    dict(comparison="private_vs_comprehensive", est="0.92", ci_low="0.75", ci_high="1.09", spec_order=1,
         estimand="RAW", controls="none", note="Cohen's d vs state non-selective schools"))
add(sw, "GCSE grade increase of just 0.026 of a standard deviation and for private schools, 0.070 of a standard "
        "deviation", 5, "text (Supplementary Table S6)",
    dict(comparison="grammar_vs_comprehensive", est="0.026", spec_order=2, estimand="ADJ-PRE", controls=SW_CTL,
         note="standardised beta vs state non-selective; school type explains 0.5% of GCSE variance (7.1% raw)"),
    dict(comparison="private_vs_comprehensive", est="0.070", spec_order=2, estimand="ADJ-PRE", controls=SW_CTL,
         note="standardised beta vs state non-selective"))


# ---------------------------------------------------------------- verification
def cid_map(text, fname):
    for k, v in CID.get(fname, {}).items():
        text = text.replace(k, v)
    return text


def norm(s, fname=""):
    s = cid_map(s or "", fname).replace("\x00", "").replace("−", "-")
    return re.sub(r"\s+", "", s)


def page_texts(pg, fname):
    """Whole page, left/right column crops (split at a vertical gap no word crosses), and the reversed page."""
    full = pg.extract_text() or ""
    texts = [full]
    words = pg.extract_words()
    gaps = [x for x in range(150, 346, 2) if not any(w["x0"] < x < w["x1"] for w in words)]
    if gaps:
        x = gaps[len(gaps) // 2]
        texts += [pg.crop((0, 0, x, pg.height)).extract_text() or "",
                  pg.crop((x, 0, pg.width, pg.height)).extract_text() or ""]
    texts.append(cid_map(full, fname)[::-1])  # rotated landscape tables extract back to front
    return [norm(t, fname) for t in texts]


_cache = {}


def quote_found(path, page, quote):
    key = (path, page)
    if key not in _cache:
        with pdfplumber.open(path) as pdf:
            _cache[key] = page_texts(pdf.pages[page - 1], path.name)
    q = norm(quote, path.name)
    return any(q in t for t in _cache[key])


def num(s):
    return None if s in (None, "") else float(str(s).replace("−", "-").replace(",", ""))


def manifest_urls():
    urls = {}
    for src in ("literature", "ifs"):
        with (ROOT / "data" / "manifest" / f"{src}.csv").open(encoding="utf-8") as f:
            for r in csv.DictReader(f):
                urls[r["local_path"]] = r["url"]
    return urls


def main():
    urls = manifest_urls()
    out, failures, counters = [], [], {}
    for r in E:
        path = latest_raw(*FILES[r["src"]])
        fname = path.name
        study = r["study"]
        counters[study] = counters.get(study, 0) + 1
        q = r["quote"]
        derived = "[derived]" in r.get("note", "") or "[worded]" in r.get("note", "")
        if not quote_found(path, r["page"], q):
            failures.append(f"{study} p.{r['page']}: quote not found: {q[:90]}")
        if r.get("est") is not None and not derived:
            tok = r.get("tok", r["est"])
            if norm(tok, fname) not in norm(q, fname):
                failures.append(f"{study}: estimate token {tok!r} not in quote {q[:60]!r}")
        se_tok = r.get("se_tok", r.get("se"))
        if r.get("se") and se_tok and norm(se_tok, fname) not in norm(q, fname):
            failures.append(f"{study}: SE token {se_tok!r} not in quote {q[:60]!r}")
        assert r["measure"] in MEASURES and r["estimand"] in ESTIMANDS and r["sex"] in SEXES, r
        est = num(r.get("est"))
        row = {
            "row_id": f"{study}-{counters[study]:02d}", "study": study, "citation": CITE[study],
            "comparison": r["comparison"], "cohort": r["cohort"], "birth_years": r["birth_years"],
            "country": r["country"], "outcome": r["outcome"], "measure": r["measure"], "age": r["age"],
            "sex": r["sex"], "estimand": r["estimand"], "controls": r["controls"], "spec_order": r["spec_order"],
            "estimate": est, "se": num(r.get("se")), "ci_low": num(r.get("ci_low")), "ci_high": num(r.get("ci_high")),
            "n": r.get("n"), "table_or_page": f"PDF p.{r['page']}; {r['where']}", "quote": q,
            "source_url": urls.get(rel(path), ""), "source_file": rel(path), "status": r.get("status", "verified"),
            "note": r.get("note", ""),
            "estimate_pct": round(math.exp(est) - 1, 4) if r["measure"] == "log_points" and est is not None else None,
        }
        out.append(row)
    if failures:
        print("\n".join(failures))
        raise SystemExit(f"{len(failures)} verification failure(s); nothing written")
    df = pd.DataFrame(out, columns=COLS)
    df["n"] = df["n"].astype("Int64")
    assert df["row_id"].is_unique
    write_derived(df, "evidence_table")
    print(df.groupby(["study", "status"]).size().to_string())


if __name__ == "__main__":
    main()
