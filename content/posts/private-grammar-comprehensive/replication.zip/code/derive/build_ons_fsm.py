"""Build the ONS 2022 'Why free school meal recipients earn less than their peers' tables (LEO, PAYE earnings):
  ons_fsm_percentiles.csv   Fig 1: earnings at age 30, percentiles 1-99, by group
  ons_fsm_age_ks4.csv       Fig 5: mean earnings by age (18-30) x KS4 points quintile x group
  ons_fsm_gaps.csv          Fig 6: raw and adjusted % gaps vs FSM recipients at age 30, by sex

Groups: Independent, Non-FSM (state, not FSM), FSM (state, FSM). Values are kept at full file precision.

Usage: .venv/Scripts/python -I code/derive/build_ons_fsm.py
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import openpyxl  # noqa: E402
import pandas as pd  # noqa: E402
from common import latest_raw, assert_unique, write_derived  # noqa: E402

GROUPS = {"Independent": "independent", "Non-FSM": "state_non_fsm", "FSM": "state_fsm"}


def rows(path, header):
    """Data rows below the header row whose first cell is a known label; the header row is matched exactly."""
    ws = openpyxl.load_workbook(path, data_only=True).active
    all_rows = [r for r in ws.iter_rows(values_only=True)]
    start = next(i for i, r in enumerate(all_rows) if [str(c).strip() if c is not None else None for c in r[:len(header)]] == header)
    out = []
    for r in all_rows[start + 1:]:
        if r[0] in (None, "Source:"):
            continue
        out.append(r[:len(header)])
    return out


def main():
    p1 = latest_raw("ons_fsm", "Fig_1_Earnings_percentiles.xlsx")
    d = pd.DataFrame(rows(p1, ["Free school meal status", "Earnings at age 30", "Percentile"]),
                     columns=["group", "earnings_gbp", "percentile"])
    d["group"] = d.group.map(GROUPS)
    assert d.group.notna().all() and sorted(set(d.percentile)) == list(range(1, 100)), "Fig 1 shape"
    assert_unique(d, ["group", "percentile"], "Fig 1")
    d.insert(0, "age", 30)
    write_derived(d[["group", "age", "percentile", "earnings_gbp"]], "ons_fsm_percentiles")

    p5 = latest_raw("ons_fsm", "Fig_5_Earnings_age_KS4.xlsx")
    d = pd.DataFrame(rows(p5, ["Free school meal status", "Age", "Key stage 4 points (quintiles)", "Mean earnings"]),
                     columns=["group", "age", "ks4_quintile", "mean_earnings_gbp_apr2019"])
    d["group"] = d.group.map(GROUPS)
    d["ks4_quintile"] = d.ks4_quintile.map({"Bottom quintile": 1, "Quintile 2": 2, "Quintile 3": 3,
                                            "Quintile 4": 4, "Top quintile": 5})
    assert d.notna().all().all() and sorted(set(d.age)) == list(range(18, 31)), "Fig 5 shape"
    assert_unique(d, ["group", "age", "ks4_quintile"], "Fig 5")
    write_derived(d, "ons_fsm_age_ks4")

    p6 = latest_raw("ons_fsm", "Fig_6_Raw_adjusted_gaps.xlsx")
    d = pd.DataFrame(rows(p6, ["Gap type", "Free school meal status", "Gender", "Gap with FSM recipients"]),
                     columns=["gap_type", "group", "sex", "gap_vs_fsm_pct"])
    d["group"] = d.group.map(GROUPS)
    d["gap_type"] = d.gap_type.str.lower()
    d["sex"] = d.sex.str.lower()
    assert d.notna().all().all() and len(d) == 8, "Fig 6 shape"
    assert_unique(d, ["gap_type", "group", "sex"], "Fig 6")
    d.insert(0, "age", 30)
    write_derived(d[["group", "sex", "age", "gap_type", "gap_vs_fsm_pct"]], "ons_fsm_gaps")


if __name__ == "__main__":
    main()
