"""Hand-read observations for build_grammar_intake.py. One line per value:

    urn | entry_year | measure | category | offer_round | value | unit | source | location | snippet | status | note | name

- source: an id from code/harvest/grammar_intake.py SOURCES (file in data/raw/grammar_intake), or a bare URL
  for rows whose page could not be fetched (status blocked / not_published / pending_foi).
- snippet: short verbatim text from the extracted file; the build fails if it is not found (whitespace, case,
  curly quotes and dashes normalised), or if a numeric value is not inside its snippet.
- unit "miles" on a catchment_km row: the value is converted to km by the build (snippet keeps the miles).
- urn blank = a consortium / LA-level row; then `name` names the consortium (must match test_used values).
- admissions_model codes: score_rank (places by test-score rank, no area); score_rank_priority_area (score rank
  inside a priority area or quota, the rest by score from anywhere); qualify_then_distance (qualifying score,
  then distance / catchment); qualify_then_catchment_distance (KEF: LAC, pupil premium, then qualifiers above
  a priority score inside a ward catchment by distance, then others by score).
"""

CSSE = "CSSE (Consortium of Selective Schools in Essex)"
KENT = "Kent Test (Kent County Council)"
BHAM = "West Midlands grammar schools test (GL; Birmingham qualifying score)"
SLOUGH = "Slough Consortium 11+ (Herschel, Langley, St Bernard's, Upton Court)"
BUCKS = "Buckinghamshire Secondary Transfer Test (TBGS)"
TRAFFORD = "Trafford Grammar Schools test (GL)"
WARKS = "Warwickshire 11+ (West Midlands grammar schools test)"
SET = "Sutton Selective Eligibility Test (SET)"

CURATED = f"""
# ---------------- Tiffin School (Kingston): own two-stage test, 10 km priority area
136910|2026|testers_stage1|all||1866|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage One', col 2026|Applicants tested at Stage One 1866 1675 1654|confirmed||
136910|2025|testers_stage1|all||1675|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage One', col 2025|Applicants tested at Stage One 1866 1675 1654|confirmed||
136910|2024|testers_stage1|all||1654|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage One', col 2024|Applicants tested at Stage One 1866 1675 1654|confirmed||
136910|2026|testers_stage2|all||665|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage Two', col 2026|Applicants tested at Stage Two 665 653 666|confirmed||
136910|2025|testers_stage2|all||653|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage Two', col 2025|Applicants tested at Stage Two 665 653 666|confirmed||
136910|2024|testers_stage2|all||666|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage Two', col 2024|Applicants tested at Stage Two 665 653 666|confirmed||
136910|2026|places|all|national_offer_day|186|places|tiffin_poa_2026|p1, row 'Places offered initially', col 2026|Places offered initially 186 186 186|confirmed||
136910|2025|places|all|national_offer_day|186|places|tiffin_poa_2026|p1, row 'Places offered initially', col 2025|Places offered initially 186 186 186|confirmed||
136910|2024|places|all|national_offer_day|186|places|tiffin_poa_2026|p1, row 'Places offered initially', col 2024|Places offered initially 186 186 186|confirmed||
136910|2026|lowest_score_offered|all|national_offer_day|100|Tiffin School test score (school's own scale)|tiffin_poa_2026|p1, row 'Initial qualifying score (lowest score offered on 1st March)', col 2026|(the lowest score achieved by a student 100 100 104|confirmed||
136910|2025|lowest_score_offered|all|national_offer_day|100|Tiffin School test score (school's own scale)|tiffin_poa_2026|p1, same row, col 2025|(the lowest score achieved by a student 100 100 104|confirmed||
136910|2024|lowest_score_offered|all|national_offer_day|104|Tiffin School test score (school's own scale)|tiffin_poa_2026|p1, same row, col 2024|(the lowest score achieved by a student 100 100 104|confirmed||
136910|2025|lowest_score_offered|all|end_of_year7|98|Tiffin School test score (school's own scale)|tiffin_poa_2026|p1, row 'Cut off score (lowest score offered a place by the end of Y7)', col 2025 (2026: tbc)|(the lowest score achieved by a student tbc 98 102|confirmed||
136910|2024|lowest_score_offered|all|end_of_year7|102|Tiffin School test score (school's own scale)|tiffin_poa_2026|p1, same row, col 2024|(the lowest score achieved by a student tbc 98 102|confirmed||
136910|2026|offers|pupil_premium|national_offer_day|15|offers|tiffin_poa_2026|p1, row 'Number of students eligible for Pupil Premium ... offered a place', col 2026|15** 11 6|confirmed|18 PP candidates were eligible but only 15 listed Tiffin first|
136910|2025|offers|pupil_premium|national_offer_day|11|offers|tiffin_poa_2026|p1, same row, col 2025|15** 11 6|confirmed||
136910|2024|offers|pupil_premium|national_offer_day|6|offers|tiffin_poa_2026|p1, same row, col 2024|15** 11 6|confirmed||
136910|2026|admissions_model|all||score_rank_priority_area|code|tiffin_poa_2026|p1 footnote|For 2024, 2025, and 2026, all places were offered to those in the Priority Area (10km). No places were offered to those outside the Priority Area.|confirmed|all 2024-2026 places went to the 10 km priority area|
136910|2026|catchment_km|all||10|km|tiffin_poa_2026|p1 footnote|all places were offered to those in the Priority Area (10km)|confirmed||
136910|2026|test_used|all||Tiffin School own two-stage test|text|tiffin_poa_2026|p1|Applicants tested at Stage One|confirmed||

# ---------------- CSSE guidance sheets (lowest score on national offer day; 303 = minimum for any offer)
|2025|qualifying_score|minimum_any_offer||303|CSSE total standardised score|csse_guidance_2026|p1 footer|not made to any child who has scored under a total standardised score of 303|confirmed|minimum for any CSSE offer; schools may set higher pass marks|{CSSE}
|2024|qualifying_score|minimum_any_offer||303|CSSE total standardised score|csse_guidance_2025|p1 footer|not made to any child who has scored under a total standardised score of 303|confirmed||{CSSE}
136642|2025|lowest_score_offered|inside_priority_area|national_offer_day|355|CSSE total standardised score|csse_guidance_2026|p1 'Essex grammar schools', KEGS row, 'Inside Priority Area' col|King Edward VI Grammar School (Boys) 355 372|confirmed|sheet 'for 2026 entry' = offers of 1 March 2025 for Sept 2025 entry|
136642|2025|lowest_score_offered|outside_priority_area|national_offer_day|372|CSSE total standardised score|csse_guidance_2026|p1, KEGS row, 'Outside Priority Area' col|King Edward VI Grammar School (Boys) 355 372|confirmed||
136642|2024|lowest_score_offered|inside_priority_area|national_offer_day|340|CSSE total standardised score|csse_guidance_2025|p1, KEGS row, 'Inside Priority Area' col|King Edward VI Grammar School (Boys) 340 376|confirmed|sheet 'for 2025 entry' = offers of 1 March 2024 for Sept 2024 entry|
136642|2024|lowest_score_offered|outside_priority_area|national_offer_day|376|CSSE total standardised score|csse_guidance_2025|p1, KEGS row, 'Outside Priority Area' col|King Edward VI Grammar School (Boys) 340 376|confirmed||
149899|2025|lowest_score_offered|all|national_offer_day|343|CSSE total standardised score|csse_guidance_2026|p1, CRGS row (no priority area)|Colchester Royal 343 Grammar School (Boys)*|confirmed||
149899|2024|lowest_score_offered|all|national_offer_day|337|CSSE total standardised score|csse_guidance_2025|p1, CRGS row (no priority area)|Colchester Royal 337 Grammar School (Boys)*|confirmed||
149899|2025|priority_area|all||none|text|csse_guidance_2026|p1 footnote|Colchester Royal Grammar School - No priority area.|confirmed|single CSSE ranking, no area quota|
136272|2025|lowest_score_offered|inside_priority_area|national_offer_day|309|CSSE total standardised score|csse_guidance_2026|p1 'Southend grammar schools', WHSB row|Westcliff High School for Boys 309 351|confirmed||
136272|2025|lowest_score_offered|outside_priority_area|national_offer_day|351|CSSE total standardised score|csse_guidance_2026|p1, WHSB row|Westcliff High School for Boys 309 351|confirmed||
136272|2024|lowest_score_offered|inside_priority_area|national_offer_day|303|CSSE total standardised score|csse_guidance_2025|p1, WHSB row|Westcliff High School for Boys 303 355|confirmed||
136272|2024|lowest_score_offered|outside_priority_area|national_offer_day|355|CSSE total standardised score|csse_guidance_2025|p1, WHSB row|Westcliff High School for Boys 303 355|confirmed||
|2023|lowest_score_offered|all||||csse_guidance_2019_2024|whole file||not_published|published, image-only PDF (sheets for 2019-2024 entry, i.e. Sept 2018-2023 offers); no text layer, not machine-readable|{CSSE}
|2025|candidate_totals_file|all||||csse_candidates|whole file||not_published|published, image-only PDF (total CSSE candidates 2010-2025 entry); no text layer, not machine-readable; counts taken from the score files instead|{CSSE}
|2026|standardisation_report|all||||csse_std_report_2026|whole file||not_published|published, image-only PDF; not machine-readable|{CSSE}
|2026|distribution_file|all||file|file|csse_raw_scores_2026|every candidate's raw English and maths marks by sex and birth month||confirmed|first line of the standardised-score file for 2026 entry reads '2025Entry' but its test dates are Sept 2025|{CSSE}
|2026|distribution_file|all||file|file|csse_std_scores_2026|every candidate's total standardised score by sex and test date||confirmed|first line reads '2025Entry' but the test dates are 20 and 30 Sept 2025, i.e. 2026 entry|{CSSE}
|2024|distribution_file|all||file|file|csse_std_scores_2019_2024|every candidate's standardised score, one sheet per entry year 2019-2024||confirmed|raw marks in csse_raw_scores_2019_to_2024_entry.xlsx|{CSSE}
|2025|distribution_file|all||file|file|csse_std_scores_2025|every candidate's total standardised score by sex and test date||confirmed||{CSSE}

# ---------------- KEGS Chelmsford (CSSE): own published cut-offs, 12.5-mile priority area
136642|2026|lowest_score_offered|inside_priority_area|national_offer_day|353.5|CSSE total standardised score|kegs_faq|FAQ 'What 11+ score gets a place at KEGS?', 'September 2026 admission'|the lowest score obtained by an 'in area' applicant, who was neither in receipt of the Pupil Premium payment nor classified as a looked after child, was 353.5|confirmed|excludes pupil premium and looked-after applicants|
136642|2026|lowest_score_offered|outside_priority_area|national_offer_day|370.1|CSSE total standardised score|kegs_faq|same section|the lowest score obtained by an 'out of area' applicant, who was neither in receipt of the Pupil Premium payment nor classified as a looked after child, was 370.1|confirmed|excludes pupil premium and looked-after applicants|
136642|2026|lowest_score_offered|inside_priority_area|september|353|CSSE total standardised score (rounded)|kegs_faq|same section, students starting Sept 2026|For the students starting Year 7 at KEGS in September 2026, the lowest score obtained by an 'in area' applicant, who was neither in receipt of the Pupil Premium payment nor classified as a looked after child, was 353|confirmed||
136642|2026|lowest_score_offered|outside_priority_area|september|368|CSSE total standardised score (rounded)|kegs_faq|same section, students starting Sept 2026|For the students starting Year 7 at KEGS in September 2026, the lowest score obtained by an 'out of area' applicant, who was neither in receipt of the Pupil Premium payment nor classified as a looked after child, was 368|confirmed||
136642|2026|pan|all||150|places|kegs_faq|FAQ|We admit 150 boys into Year 7.|confirmed||
136642|2027|admissions_model|all||score_rank_priority_area|code|kegs_priority_area|page text|the first 120 places will be offered to the highest scoring boys, who permanently and continuously live within this area|confirmed|remaining places to the highest scorers regardless of address; 2024-2026 cut-offs also split in/out of area|
136642|2027|priority_area_places|all||120|places|kegs_priority_area|page text|the first 120 places will be offered to the highest scoring boys|confirmed||
136642|2027|catchment_km|all||12.5|miles|kegs_priority_area|page text|KEGS has a priority area, for Year 7 admissions, of 12.5 miles from the school.|confirmed||
136642|2026|test_used|all||{CSSE}|text|kegs_faq|FAQ|Results are rank ordered for each individual school by the CSSE|confirmed||
136642|2026|distribution_file|all||file|file|kegs_scores_2026|scores and in/out area of admitted students (pupil premium removed)||confirmed||
136642|2025|distribution_file|all||file|file|kegs_scores_2025|scores and in/out area of admitted students||confirmed||
136642|2024|distribution_file|all||file|file|kegs_scores_2024|scores and in/out area of admitted students||confirmed||
136642|2023|distribution_file|all||file|file|kegs_scores_2023|scores and in/out area of admitted students||confirmed||

# ---------------- Colchester RGS (CSSE): score rank, no priority area
149899|2025|pan|all||128|places|crgs_policy_2025|p2 'Admissions Arrangements - Academic Year 2025-2026'|The published admission number for Year 7 is 128.|confirmed||
149899|2025|admissions_model|all||score_rank|code|crgs_policy_2025|p2 'Admissions Priority 2'|The remaining places will then be offered in descending rank order of marks to the boys scoring highest in the selection tests|confirmed|up to 12 places first to LAC / pupil premium boys scoring above 320|
149899|2025|qualifying_score|pupil_premium_or_looked_after||320|CSSE total standardised score|crgs_policy_2025|p1 'Admissions Priority 1'|achieve a score greater than 320 in the selection tests|confirmed|threshold for the up-to-12 priority places only|
149899|2025|test_used|all||{CSSE}|text|crgs_policy_2025|p1|selection procedure organised by the Consortium of Selective Schools in Essex (CSSE)|confirmed||

# ---------------- Westcliff High School for Boys (CSSE): score rank inside SS0-SS9 quota
136272|2026|pan|all||185|places|whsb_doc_a|'Admission Criteria and Arrangements for Entry 2026', para 7|For the September 2026 intake, the School's Published Admission Number (PAN) is 185.|confirmed||
136272|2023|pan|all||185|places|whsb_doc_b|'Admission Criteria and Arrangements for Entry 2023', para 7|For the September 2023 intake, the School's Published Admission Number (PAN) is 185.|confirmed||
136272|2026|admissions_model|all||score_rank_priority_area|code|whsb_doc_a|para 9-10|In each category, places are allocated in order of the mark achieved, higher passing candidates first.|confirmed|local quota of up to 80% of PAN (148) for SS0-SS9 residents, then others by score|
136272|2026|priority_area|all||postcode areas SS0-SS9 (Southend LA booklet definition)|text|whsb_doc_a|para 10(ii)|lies within the catchment area postcode areas SS0, SS1, SS2, SS3, SS4, SS5, SS6, SS7, SS8 and SS9|confirmed|a postcode-district area, not a radius|
136272|2026|priority_area_places|all||148|places|whsb_doc_a|para 10(ii)|is reserved at this School for children in this category (148)|confirmed||
136272|2026|test_used|all||{CSSE}|text|whsb_doc_a|para 3|selection procedure administered by the Consortium of Selective Schools in Essex (CSSE)|confirmed||

# ---------------- Chelmsford County High School for Girls: own test (FSCE), 12.5-mile priority area
136412|2026|lowest_score_offered|inside_priority_area|national_offer_day|106-107|CCHS total standardised score (range released)|cchs_foi|'For September 2026 intake' (correct at 20 Mar 2026)|For the 12.5-mile priority area (Policy 1.5 3a), the last student offered scored in the range of 106-107.|confirmed|school releases a 1-point range, not the score|
136412|2026|lowest_score_offered|outside_priority_area|national_offer_day|118-119|CCHS total standardised score (range released)|cchs_foi|same section|For outside the 12.5-mile priority area (Policy 1.5 3b), the last student offered scored in the range of 118-119.|confirmed||
136412|2025|lowest_score_offered|inside_priority_area|september|107-108|CCHS total standardised score (range released)|cchs_foi|'For September 2025 intake' (correct at 4 Mar 2026)|For the 12.5 mile priority area (Policy 1.5 3a), the last student offered scored in the range of 107-108|confirmed|stated after 15 post-offer rejections, so a final (not national offer day) cut-off|
136412|2025|lowest_score_offered|outside_priority_area|september|116-117|CCHS total standardised score (range released)|cchs_foi|same section|For outside the 12.5 mile priority area (Policy 1.5 3b), the last student offered scored in the range of 116-117|confirmed||
136412|2024|lowest_score_offered|inside_priority_area||108-109|CCHS total standardised score (range released)|cchs_foi|'For September 2024 intake'|For the 12.5 mile priority area, the last student offered scored in the range of 108-109|confirmed|round not stated|
136412|2024|lowest_score_offered|outside_priority_area||113-114|CCHS total standardised score (range released)|cchs_foi|same section|For outside the 12.5 mile priority area, the last student offered scored in the range of 113-114|confirmed|round not stated|
136412|2023|lowest_score_offered|inside_priority_area|national_offer_day|107-108|CCHS total standardised score (range released)|cchs_foi|'For September 2023 intake'|The last student offered a place on the National Offer Day scored in the range of 107-108 for the 12.5 mile priority area|confirmed||
136412|2023|lowest_score_offered|outside_priority_area|national_offer_day|116-117|CCHS total standardised score (range released)|cchs_foi|same section|and the range of 116-117 for outside the 12.5 mile priority area. Between the period of March 2023|confirmed||
136412|2026|pan|all||180|places|cchs_policy_2026|p1|The School's published admission number is 180 places for admission in Year 7 in 2026.|confirmed||
136412|2026|admissions_model|all||score_rank_priority_area|code|cchs_policy_2026|1.5 'Allocation of places on over-subscription'|places will be allocated in descending score order from the Ranked List of Applicants|confirmed|144 places for the 12.5-mile priority area (up to 30 of them pupil/service premium), up to 36 to anyone by score|
136412|2026|priority_area_places|all||144|places|cchs_policy_2026|1.5 (3)|3. Of the next 144, places will be allocated as follows|confirmed||
136412|2026|catchment_km|all||12.5|miles|cchs_policy_2026|1.5 (3b)|living at a permanent home address within the 12.5-mile priority area of the School|confirmed||
136412|2026|test_used|all||CCHS own test (Future Stories Community Enterprise)|text|cchs_guide_2026|p1|CCHS will be using an Entrance Test supplied by Future Stories Community Enterprise (FSCE).|confirmed||

# ---------------- Birmingham (KEF schools + Bishop Vesey's + Sutton Coldfield Girls)
|2027|qualifying_score|all||205|Birmingham test standardised score|kef_results|'Cut-Off Scores'|The Qualifying Score for all of the Birmingham grammar schools for 2027 entry is 205.|confirmed||{BHAM}
|2027|qualifying_score|priority_score_kef||224|Birmingham test standardised score|kef_results|'Cut-Off Scores'|The Priority Score for all of the King Edward VI Grammar Schools for 2027 entry is 224.|confirmed|KEF schools only|{BHAM}
|2027|testers_stage1|all||||kef_the_test|whole page||not_published|no candidate counts on the KEF results, test or grammar-schools pages|{BHAM}
137045|2027|pan|all||120|places|kef_chb_policy_2027|p1|Admission Number: 120|confirmed|DfE offers 2026: 150|
137045|2027|admissions_model|all||qualify_then_catchment_distance|code|kef_chb_policy_2027|p1 criterion 4|Applicants who achieve the priority score and live within the school catchment area*. Applicants in this category will be given priority if they have an older sibling** at the school; then ranked by distance|confirmed|criterion 5 (others) ranked by score; in 2025 entry category 4 filled every place|
137045|2027|priority_area|all||electoral wards listed in the policy|text|kef_chb_policy_2027|p2 footnote|The catchment area consists of home addresses that are within the following electoral wards in Birmingham|confirmed|ward list, not a radius|
137045|2027|test_used|all||{BHAM}|text|kef_the_test|page text|The test is provided by GL Assessment.|confirmed|test shared with the 19 West Midlands grammar schools|
137044|2027|pan|all||150|places|kef_chg_policy_2027|p1|Admission Number: 150|confirmed||
137044|2027|admissions_model|all||qualify_then_catchment_distance|code|kef_chg_policy_2027|p1 criterion 4|they have an older sibling** at the school; then ranked by distance|confirmed|same five-category structure as Camp Hill Boys|
137044|2027|test_used|all||{BHAM}|text|kef_the_test|page text|The test is provided by GL Assessment.|confirmed||
137046|2027|pan|all||180|places|kef_fws_policy_2027|p1|Admission Number: 180|confirmed||
137046|2027|admissions_model|all||qualify_then_catchment_distance|code|kef_fws_policy_2027|p1 criterion 4|they have an older sibling** at the school; then ranked by distance|confirmed|in 2024-2026 no 'all others' offers in March|
137046|2027|test_used|all||{BHAM}|text|kef_the_test|page text|The test is provided by GL Assessment.|confirmed||
137988|2027|pan|all||192|places|bv_policy_2027_proposed|p1|Admission Number 192|confirmed|proposed arrangements|
137988|2027|admissions_model|all||score_rank_priority_area|code|bv_policy_2027_proposed|p2 criterion 3|Other children who achieve the qualifying score by rank order of standardised score living within Zone 1|confirmed|proposed 2027 arrangements; 2023-2026 KEF table shows no zone category (LAC, pupil premium, all others)|
137988|2027|catchment_km|all||12|miles|bv_policy_2027_proposed|p1|Zone 1 is determined as a straight-line measurement of up to 12 miles|confirmed||
137988|2027|test_used|all||{BHAM}|text|bv_policy_2027_proposed|p1|on standardised tests of verbal, numerical and non-verbal reasoning ability|confirmed||

# ---------------- Kent Test (county threshold)
|2025|qualifying_score|total||332|Kent Test total of three standardised scores (each 69-141, max 423)|kent_results_wayback_20250907|'Grammar school threshold 2024' (test sat Sept 2024)|children needed a total score of 332 or more, with no single score lower than 106|confirmed|Wayback capture 2025-09-07 of the KCC page|{KENT}
|2025|qualifying_score|minimum_each_test||106|Kent Test standardised score (69-141)|kent_results_wayback_20250907|same paragraph|children needed a total score of 332 or more, with no single score lower than 106|confirmed||{KENT}
|2026|qualifying_score|total||||https://www.kent.gov.uk/education-and-children/schools/school-places/kent-test/kent-test-results|KCC page||blocked|HTTP 403 to scripts (Cloudflare); no Wayback capture after 2025-09-07|{KENT}

|2026|qualifying_score|total||332|Kent Test total of three standardised scores (max 423)|judd_history_2026|p1 row 'Kent Test Pass Mark', column 2026 (entry year)|Kent Test 320 320 320 320 323 330 332 332 332 332 332 332 Pass Mark|confirmed|KCC page blocked; value from The Judd School's own historical table (columns are entry years 2015-2026)|{KENT}
|2026|qualifying_score|minimum_each_test||108|Kent Test standardised score (69-141)|judd_history_2026|p1 row 'Minimum Pass Mark Per Paper', column 2026|Minimum 106 106 106 106 107 110 108 109 109 107 108 108 Pass Mark Per Paper|confirmed||{KENT}
|2025|qualifying_score|minimum_each_test||108|Kent Test standardised score (69-141)|judd_history_2026|p1 same row, column 2025|Minimum 106 106 106 106 107 110 108 109 109 107 108 108 Pass Mark Per Paper|confirmed|CONFLICT: the KCC page (Wayback) gives 106 for the test sat Sept 2024 (2025 entry)|{KENT}
|2024|qualifying_score|minimum_each_test||107|Kent Test standardised score (69-141)|judd_history_2026|p1 same row, column 2024|Minimum 106 106 106 106 107 110 108 109 109 107 108 108 Pass Mark Per Paper|confirmed||{KENT}
|2023|qualifying_score|minimum_each_test||109|Kent Test standardised score (69-141)|judd_history_2026|p1 same row, column 2023|Minimum 106 106 106 106 107 110 108 109 109 107 108 108 Pass Mark Per Paper|confirmed||{KENT}
|2026|testers_stage1|all||||https://www.kent.gov.uk/education-and-children/schools/school-places/kent-test/kent-test-results|KCC 'Report of Kent Test scores 2025' (test sat Sept 2025)||blocked|file link only on the KCC page, which returns 403 to scripts; not captured by Wayback|{KENT}

# ---------------- The Judd School (Kent Test): score rank in Inner (postcode) / Outer area
118843|2026|lowest_score_offered|inside_priority_area|national_offer_day|389|Kent Test total (max 423)|judd_year7|'Admissions Update - March 2026'|The cut-off score for our inner area was 389 (2025: 371) with the outer area being 403 (2025: 398)|confirmed|inner area = postcode list|
118843|2026|lowest_score_offered|outside_priority_area|national_offer_day|403|Kent Test total (max 423)|judd_year7|same|The cut-off score for our inner area was 389 (2025: 371) with the outer area being 403 (2025: 398)|confirmed||
118843|2025|lowest_score_offered|inside_priority_area|national_offer_day|371|Kent Test total (max 423)|judd_year7|same (2025 in brackets)|The cut-off score for our inner area was 389 (2025: 371)|confirmed||
118843|2025|lowest_score_offered|outside_priority_area|national_offer_day|398|Kent Test total (max 423)|judd_year7|same (2025 in brackets)|with the outer area being 403 (2025: 398)|confirmed||
118843|2024|lowest_score_offered|inside_priority_area|national_offer_day|383|Kent Test total (max 423)|judd_history_2026|p1 row 'Judd Cut-off: March', Inner, 2024 (11 values 2016-2026)|362 364 364 376 385 387 387 381 383 371 389|confirmed||
118843|2023|lowest_score_offered|inside_priority_area|national_offer_day|381|Kent Test total (max 423)|judd_history_2026|p1 same row, Inner, 2023|362 364 364 376 385 387 387 381 383 371 389|confirmed||
118843|2024|lowest_score_offered|outside_priority_area|national_offer_day|412|Kent Test total (max 423)|judd_history_2026|p1 same row, Outer, 2024|391 400 395 402 407 408 409 406 412 398 403|confirmed||
118843|2023|lowest_score_offered|outside_priority_area|national_offer_day|406|Kent Test total (max 423)|judd_history_2026|p1 same row, Outer, 2023|391 400 395 402 407 408 409 406 412 398 403|confirmed||
118843|2026|lowest_score_offered|inside_priority_area|april_reallocation|386|Kent Test total (max 423)|judd_history_2026|p1 row 'Judd Cut-off: April Reallocation', Inner, 2026|357 361 361 373 384 384 384 376 380 367 386|confirmed||
118843|2026|places|inside_priority_area|national_offer_day|157|places|judd_year7|'Admissions Update - March 2026'|The number of places available for the inner area is 157; the outer area is 23.|confirmed||
118843|2026|places|all|national_offer_day|180|offers|judd_year7|same|On 02 March 2026 - 180 offers were made.|confirmed||
118843|2026|admissions_model|all||score_rank_priority_area|code|judd_areas|page text|157 places will be allocated to students resident in the Inner Area, which is defined by the following postcodes|confirmed|23 outer-area places; both lists ranked by Kent Test score|
118843|2026|priority_area|all||Inner Area (postcode list)|text|judd_areas|page text|157 places will be allocated to students resident in the Inner Area, which is defined by the following postcodes|confirmed|postcode list, not a radius|
118843|2026|test_used|all||{KENT}|text|judd_history_2026|p1|Kent Test 320 320 320 320 323 330 332 332 332 332 332 332 Pass Mark|confirmed||

# ---------------- The Skinners' School (Kent Test + 40): qualify, then distance
140595|2027|pan|all||160|places|skinners_policy_2027|p1|The School intends to offer 160 places each year for boys aged 11.|confirmed||
140595|2027|admissions_model|all||qualify_then_distance|code|skinners_policy_2027|West Kent Area 2(b)|those living in the West Kent Area with a PESE (11+) score of at least 40 points higher than the KCC|confirmed|ranked siblings, staff, then shortest distance; up to 16 governors' places by highest score|
140595|2027|qualifying_score|main_criteria||40|points above the Kent Test threshold|skinners_questions|page text|We have set a qualifying score of 40 points higher than the Kent Test threshold score|confirmed|e.g. 372 if the Kent threshold is 332|
140595|2025|last_distance_offered|inside_priority_area||11|miles|skinners_questions|page text|our West Kent area to 11 miles for 2025 admission|confirmed|West Kent area|
140595|2025|last_distance_offered|outside_priority_area||18|miles|skinners_questions|page text|The furthest distance offered in the Outer Area for 2025 was 18 miles.|confirmed||
140595|2025|applications|grammar_assessed||702|applications|skinners_questions|page text|There were 702 grammar school assessed SCAF applications to Skinners' for 2025 Year 7 entry|confirmed|grammar-assessed preferences, not testers|
140595|2025|applications|first_preference_grammar_assessed||198|applications|skinners_questions|page text|198 of them put Skinners' as first choice|confirmed||
140595|2026|lowest_score_offered|all||||https://www.skinners-school.co.uk/38/2026-year-7-admission-information-updated-2nd-march|school update page||not_published|page removed; the Oct-2025 Kent Test page returns '404 Error' (fetched 2026-10-10); value seen only in search snippets|
140595|2027|test_used|all||{KENT}|text|skinners_policy_2027|West Kent Area 2(b)|PESE (11+) score of at least 40 points higher than the KCC|confirmed||

# ---------------- Tonbridge Grammar School (Kent Test): Area / Trustee lists by score
136417|2026|pan|all||180|places|tgs_guidance_2026|para 3|Our Published Admission Number (PAN) for September 2026 is 180.|confirmed||
136417|2026|admissions_model|all||score_rank_priority_area|code|tgs_guidance_2026|para 6-7|We will offer 135 places to Area children. These will be allocated by listing children in order of the highest score first|confirmed|30 Trustee (outside area) places also by score; 15 pupil premium places by distance|
136417|2026|priority_area|all||Tonbridge and Malling, Tunbridge Wells and Sevenoaks districts|text|tgs_guidance_2026|para 4|girls who live in Tonbridge and Malling Borough, Tunbridge Wells Borough and Sevenoaks District areas (Area places)|confirmed|three local-authority districts, not a radius|
136417|2026|priority_area_places|all||135|places|tgs_guidance_2026|para 6|We will offer 135 places to Area children.|confirmed||
136417|2026|lowest_score_offered|inside_priority_area|national_offer_day|378|Kent Test total (max 423)|tgs_guidance_2027|'Historical scores' row 2026 (Area/Trustee: 1st round, 2nd round, waiting list)|2026 378/400 377/397 376/397|confirmed||
136417|2026|lowest_score_offered|outside_priority_area|national_offer_day|400|Kent Test total (max 423)|tgs_guidance_2027|same row, Trustee|2026 378/400 377/397 376/397|confirmed|Trustee = outside the area|
136417|2025|lowest_score_offered|inside_priority_area|national_offer_day|368|Kent Test total (max 423)|tgs_guidance_2026|'Historical scores' row 2025|2025 368/395 366/389 365/388|confirmed||
136417|2025|lowest_score_offered|outside_priority_area|national_offer_day|395|Kent Test total (max 423)|tgs_guidance_2026|same row|2025 368/395 366/389 365/388|confirmed||
136417|2024|lowest_score_offered|inside_priority_area|national_offer_day|375|Kent Test total (max 423)|tgs_guidance_2026|row 2024|2024 375/396 373/414 373/396|confirmed||
136417|2024|lowest_score_offered|outside_priority_area|national_offer_day|396|Kent Test total (max 423)|tgs_guidance_2026|row 2024|2024 375/396 373/414 373/396|confirmed||
136417|2023|lowest_score_offered|inside_priority_area|national_offer_day|378|Kent Test total (max 423)|tgs_guidance_2026|row 2023|2023 378/393 375/392 377/383|confirmed||
136417|2023|lowest_score_offered|outside_priority_area|national_offer_day|393|Kent Test total (max 423)|tgs_guidance_2026|row 2023|2023 378/393 375/392 377/383|confirmed||
136417|2026|test_used|all||{KENT}|text|tgs_guidance_2026|para 4|(Grammar assessed) through the Kent PESE 11+ Test|confirmed||

# ---------------- Langley Grammar School (Slough consortium)
136521|2026|applications|all||1052|applications naming the school|lgs_alloc_2026|table row 'Langley Grammar School Academy' (PAN, applications, eligible)|Academy 180 1052 775|confirmed|any CAF naming the school, irrespective of score|
136521|2026|applications|eligible_111_plus||775|applications|lgs_alloc_2026|same row|Academy 180 1052 775|confirmed|applicants scoring 111+|
136521|2026|pan|all||180|places|lgs_alloc_2026|same row|Academy 180 1052 775|confirmed||
136521|2026|lowest_score_offered|priority_area_1|national_offer_day|113|Slough consortium standardised score|lgs_alloc_2026|'Information on 2026 entry'|Academy 180 1052 775 down to 113 admitted.|confirmed||
136521|2026|lowest_score_offered|priority_area_2|national_offer_day|119|Slough consortium standardised score|lgs_alloc_2026|same|area with a rank score down to 119.|confirmed||
136521|2025|applications|all||1121|applications naming the school|lgs_alloc_2025|table row|Academy 180 1121 805|confirmed||
136521|2025|applications|eligible_111_plus||805|applications|lgs_alloc_2025|table row|Academy 180 1121 805|confirmed||
136521|2025|pan|all||180|places|lgs_alloc_2025|table row|Academy 180 1121 805|confirmed||
136521|2025|lowest_score_offered|priority_area_1|national_offer_day|113|Slough consortium standardised score|lgs_alloc_2025|'Information on 2025 entry'|Academy 180 1121 805 down to 113 admitted.|confirmed||
136521|2025|lowest_score_offered|priority_area_2|national_offer_day|118|Slough consortium standardised score|lgs_alloc_2025|'Information on 2025 entry'|area with a rank score down to 118.|confirmed||
136521|2024|applications|all||1211|applications naming the school|lgs_alloc_2024|table row|Academy 180 1211 825|confirmed||
136521|2024|pan|all||180|places|lgs_alloc_2024|table row|Academy 180 1211 825|confirmed||
136521|2024|lowest_score_offered|priority_area_1|national_offer_day|113|Slough consortium standardised score|lgs_alloc_2024|'Information on 2024 entry'|Langley Grammar score down to 113 admitted.|confirmed||
136521|2024|lowest_score_offered|priority_area_2|national_offer_day|117|Slough consortium standardised score|lgs_alloc_2024|same|admissions area with a rank score down to 117.|confirmed||
|2026|qualifying_score|all||111|Slough consortium standardised score|lgs_page_2026|page text|Children who scored 111 or above in the test, are eligible to be considered|confirmed|111 = top 35% of the cohort per the arrangements|{SLOUGH}
136521|2026|admissions_model|all||score_rank_priority_area|code|lgs_policy_2026|oversubscription (a)-(b)|within the school's Priority Area 1, up to a maximum of 100 places|confirmed|PA1 (SL3 sectors) up to 100 by rank, then PA2 postcode districts by rank, then others|
136521|2026|priority_area|all||Priority Areas 1-3 (postcode sectors/districts)|text|lgs_policy_2026|oversubscription (a)|within the school's Priority Area 1, up to a maximum of 100 places|confirmed|postcode lists, not a radius|
136521|2026|test_used|all||{SLOUGH}|text|lgs_alloc_2026|p1|11+ Testing Consortium of Herschel Grammar School, Langley Grammar School,|confirmed||
136521|2027|pan|all||180|places|lgs_policy_2027|para 1|The School's planned admission number (PAN) for entry into Year 7 in September 2027 is 180.|confirmed||

# ---------------- Buckinghamshire (qualify 121, then catchment/distance)
|2026|qualifying_score|all||121|Bucks Secondary Transfer Test standardised score|bucks_11plus|page text|Children who achieve a score of at least 121 in the test are considered qualified for a Buckinghamshire grammar school.|confirmed||{BUCKS}
|2026|testers_stage1|all||||bucks_stt_results|page text||not_published|no candidate counts on the council's 11+ pages|{BUCKS}

# ---------------- Trafford (Trafford Grammar Schools test; qualify 334, then area / score)
136458|2025|pan|all||202|places|agsb_booklet_2025|p1|for the year commencing 1 September 2025 will be 202 at age 11|confirmed||
136458|2025|qualifying_score|all||334|Trafford test total standardised score|agsb_booklet_2025|section 8|with a total standardised score of 334 and above|confirmed|324-333 for up to 20 Trafford pupil-premium places|
136458|2025|admissions_model|all||qualify_then_catchment|code|agsb_booklet_2025|section 8|school's priority admission area with a total standardised score of 334 and above|confirmed|qualifiers in WA13/WA14/WA15/M33/M23 (Trafford) first; outside area by score|
136458|2025|priority_area|all||WA13/WA14/WA15/M33/M23 within Trafford|text|agsb_booklet_2025|8.2|postal addresses of WA13/WA14/WA15/M33 and M23 postcodes which lie within the Trafford Local Authority|confirmed||
136458|2025|lowest_score_offered|outside_priority_area|national_offer_day|377|Trafford test total standardised score|trafford_outcomes_2025|table row 'Altrincham Grammar School for Boys'|Some Category 5. Score of 377 and above for out of area candidates|confirmed||
136458|2026|lowest_score_offered|outside_priority_area|national_offer_day|373|Trafford test total standardised score|trafford_outcomes_2026|table row 'Altrincham Grammar School for Boys'|Some Category 5. Score of 373 and above for out of area candidates|confirmed||
136458|2026|pan|all||202|places|trafford_outcomes_2026|table row (PAN, total offers)|Altrincham Grammar School for Boys 202 217|confirmed||
137289|2024|pan|all||204|places|aggs_booklet_2024|p1|The proposed admission number for 2024 is 204.|confirmed||
137289|2024|qualifying_score|all||334|Trafford test total standardised score|aggs_booklet_2024|p1|The qualifying score will be achieved by those candidates who score 334 and above in the exam.|confirmed||
137289|2024|admissions_model|all||qualify_then_distance|code|aggs_booklet_2024|criteria 4|priority shall be given to those applicants residing closer to the school|confirmed|catchment qualifiers by distance, then outside catchment|
137289|2025|last_distance_offered|catchment|national_offer_day|5.47|miles|trafford_outcomes_2025|table row 'Altrincham Grammar School for Girls'|Some Category 4 to 5.47 miles|confirmed||
137289|2026|last_distance_offered|catchment|national_offer_day|6.067|miles|trafford_outcomes_2026|table row 'Altrincham Grammar School for Girls'|Some Category 4 to 6.067 miles|confirmed||
136498|2026|pan|all||190|places|sale_2026|page text|the intended admission number for 2026 is 190|confirmed||
136498|2026|qualifying_score|all||334|Trafford test total standardised score|sale_policy_2026|application procedure|All those who attain the qualifying score of 334 or above will be deemed eligible|confirmed||
136498|2026|admissions_model|all||qualify_then_catchment|code|sale_policy_2026|oversubscription|Applicants from outside the priority admission area will be placed in rank order as determined by their scores|confirmed|priority admission area (M33 + Trafford M23/WA14/WA15) before outside applicants|
136498|2025|lowest_score_offered|outside_priority_area|national_offer_day|353|Trafford test total standardised score|trafford_outcomes_2025|table row 'Sale Grammar School'|Some Category 4. Score 353 and above for out of area candidates|confirmed||
136498|2026|lowest_score_offered|outside_priority_area|national_offer_day|373|Trafford test total standardised score|trafford_outcomes_2026|table row 'Sale Grammar School'|Score 373 and above for out of area candidates to 5.907 miles|confirmed||
138464|2026|admissions_model|all||faith_categories|code|loreto_policy_2026|admission categories|Baptised Roman Catholic girls who have sisters|confirmed|Catholic categories first|
138464|2025|pan|all||150|places|trafford_outcomes_2025|table row 'Loreto Grammar School'|Loreto Grammar School 150 160|confirmed||
138464|2025|lowest_score_offered|all||||trafford_outcomes_2025|table row 'Loreto Grammar School'||not_published|outcome given only as 'Some Category 4'|
137289|2024|test_used|all||{TRAFFORD}|text|aggs_booklet_2024|p1|AGGS is part of the Trafford Gra|confirmed||
136458|2024|test_used|all||{TRAFFORD}|text|aggs_booklet_2024|p1|AGGS is part of the Trafford Gra|confirmed|shared Trafford test|
136498|2024|test_used|all||{TRAFFORD}|text|aggs_booklet_2024|p1|AGGS is part of the Trafford Gra|confirmed|shared Trafford test|

# ---------------- Warwickshire (KES Stratford, Stratford Girls'): qualify, then priority circles by score
137302|2026|pan|all||87|places|kes_policy_2026|2.1|Published Admission Number (PAN) in Year 7 will be 87|confirmed||
137302|2026|admissions_model|all||score_rank_priority_area|code|kes_policy_2026|2.2|Those with the highest scores in each category will be given highest priority for a place.|confirmed|up to 70 places inner circle (13 miles), then outer circle (16.885 miles), then outside|
137302|2026|catchment_km|all||13|miles|kes_policy_2026|2.2|The inner priority circle is 13 miles and the outer priority circle is 16.885 miles|confirmed||
137302|2026|qualifying_score|all||239|Warwickshire 11+ standardised score|warks_leaflet_2026|p2 table (PAN, offers, QS, waiting-list minimum)|King Edward VI School 87 87 239 230|confirmed|automatic qualifying score, set each year|
137302|2025|qualifying_score|all||233|Warwickshire 11+ standardised score|warks_leaflet_2025|p2 table (offers, QS, WL minimum)|King Edward VI School 87 233 231|confirmed||
137302|2024|qualifying_score|all||232|Warwickshire 11+ standardised score|warks_leaflet_2024|p2 table|King Edward VI School 87 232 230|confirmed||
137302|2023|qualifying_score|all||232|Warwickshire 11+ standardised score|warks_leaflet_2023|p2 table|King Edward VI School 87 232 224|confirmed||
137302|2026|lowest_score_offered|inside_priority_area|national_offer_day|239|Warwickshire 11+ standardised score|warks_leaflet_2026|p3 Category 3 (inner circle): offers, lowest score|Up to 70 places will be allocated to children who live within the inner 67 239|confirmed|67 offers|
137302|2026|lowest_score_offered|outside_priority_area|national_offer_day|254|Warwickshire 11+ standardised score|warks_leaflet_2026|p3 Category 4 (outer circle)|Children who live within the outer priority circle (including those living 13 254|confirmed|13 offers; 'outside' = outer circle|
137302|2025|lowest_score_offered|inside_priority_area|national_offer_day|235|Warwickshire 11+ standardised score|warks_leaflet_2025|p3 Category 3|Up to 70 places will be allocated to children who live within the inner 70 235|confirmed||
137302|2025|lowest_score_offered|outside_priority_area|national_offer_day|263|Warwickshire 11+ standardised score|warks_leaflet_2025|p3 Category 4|Children who live within the outer priority circle (including those living in 7 263|confirmed||
137302|2024|lowest_score_offered|inside_priority_area|national_offer_day|232|Warwickshire 11+ standardised score|warks_leaflet_2024|p3 Category 3|Category 3 68 232|confirmed||
137302|2024|lowest_score_offered|outside_priority_area|national_offer_day|252|Warwickshire 11+ standardised score|warks_leaflet_2024|p3 Category 4|Category 4 15 252|confirmed||
137302|2023|lowest_score_offered|inside_priority_area|national_offer_day|232|Warwickshire 11+ standardised score|warks_leaflet_2023|p3 Category 3 (offers, lowest)|Up to 70 places for children in the inner priority 67 232|confirmed||
137302|2023|lowest_score_offered|outside_priority_area|national_offer_day|245|Warwickshire 11+ standardised score|warks_leaflet_2023|p3 Category 4|Children living in the outer priority area who 17 245|confirmed||
137302|2026|test_used|all||{WARKS}|text|warks_leaflet_2026|p1|11+ Test and Grammar School Offers|confirmed||
137235|2026|qualifying_score|all||227|Warwickshire 11+ standardised score|warks_leaflet_2026|p2 table|Stratford Girls' Grammar School 120 120 227 224|confirmed||
137235|2023|qualifying_score|all||224|Warwickshire 11+ standardised score|warks_leaflet_2023|p2 table|Stratford Girls' Grammar School 120 224 220|confirmed||
137235|2026|pan|all||120|places|warks_leaflet_2026|p2 table|Stratford Girls' Grammar School 120 120 227 224|confirmed||
137235|2026|lowest_score_offered|inside_priority_area|national_offer_day|232|Warwickshire 11+ standardised score|warks_leaflet_2026|p4 Category 3 (priority circle)|Children who live within the priority circle who achieve the Automatic 110 232|confirmed|110 offers; none outside the circle|
137235|2025|lowest_score_offered|inside_priority_area|national_offer_day|232|Warwickshire 11+ standardised score|warks_leaflet_2025|p4 Category 3|Children who live within the priority circle who achieve the Automatic 114 232|confirmed||
137235|2024|lowest_score_offered|inside_priority_area|national_offer_day|226|Warwickshire 11+ standardised score|warks_leaflet_2024|p4 Category 3|Category 3 116 226|confirmed||
137235|2023|lowest_score_offered|inside_priority_area|national_offer_day|225|Warwickshire 11+ standardised score|warks_leaflet_2023|p4 Category 3|Category 3 116 225|confirmed||
137235|2026|admissions_model|all||score_rank_priority_area|code|warks_leaflet_2026|p4 categories|Children living outside of the priority circle who achieve the Automatic 0 N/A|confirmed|priority circle first, then outside (0 offers outside 2023-2026); circle radius not in a fetched SGGS document|
137235|2026|test_used|all||{WARKS}|text|warks_leaflet_2026|p1|11+ Test and Grammar School Offers|confirmed||

# ---------------- Gloucestershire (Pate's, Sir Thomas Rich's)
136353|2026|pan|all||150|places|pates_policy_2026|p1|for Year 7 entry in 2026, is 150|confirmed||
136353|2026|admissions_model|all||score_rank_priority_area|code|pates_policy_2026|criteria|Non-Priority Places (Local) totals 105 places|confirmed|qualifying group = top 250 ranks; up to 15 priority places; local (Gloucestershire + listed postcodes) until 105, rest UK-wide by test rank|
136353|2026|qualifying_score|rank||250|test rank|pates_policy_2026|qualifying group|our standard 'Qualifying Group' will be the highest ranking 250 students|confirmed|a rank, not a score|
136353|2026|lowest_score_offered|all||||glos_summary_2026|row 'Pate's Grammar School'||not_published|council summary says 'Please check with school'; no figure on the school documents fetched|
136306|2026|pan|all||150|places|str_policy_2026|p1|150 places (also referred to as the Published Admissions Number (PAN))|confirmed|council 2026 allocation shows 155|
136306|2027|pan|all||155|places|str_policy_2027|p1|155 places (also referred to as the Published Admissions Number (PAN))|confirmed||
136306|2026|admissions_model|all||score_rank|code|str_policy_2026|oversubscription (c)|c. Other qualifying boys in test rank order|confirmed|after LAC and pupil premium; no catchment|
136306|2026|last_rank_offered|all|national_offer_day|332|test rank|glos_summary_2026|row 'Sir Thomas Rich's School'|Sir Thomas Rich's School 155 0 Last rank in - 332|confirmed|a test rank position, not a score|

# ---------------- Singletons
137916|2027|pan|all||180|places|bluecoat_policy_2027|p1|It admits 180 students to Year 7|confirmed||
137916|2027|admissions_model|all||score_rank|code|bluecoat_policy_2027|criteria|The remaining places will be available to all other highest scoring applicants who meet the eligible score.|confirmed|up to 27 places first to FSM-eligible highest scorers; no catchment|
137916|2024|testers_stage1|all||1089|candidates|bluecoat_faq_2026|FAQ 'How many candidates sat the entrance test ... entry in September 2024'|A total of 1089 candidates sat the test at The Blue Coat School.|confirmed|question text says 'entry in September 2024' inside the 2026-entry FAQ: entry year uncertain|
136366|2026|pan|all||160|places|colyton_policy_2026|admissions criteria|The Published Admission Number (PAN) is 160|confirmed||
136366|2026|admissions_model|all||score_rank|code|colyton_policy_2026|criteria 3|Rank order based on the total score achieved in the tests of children on the eligible list.|confirmed|no catchment|
137166|2026|pan|all||174|places|kings_lincs_record|directory record|Published admission number 174|confirmed||
137166|2026|admissions_model|all||score_rank_priority_area|code|kings_lincs_record|2026 oversubscription criteria|reside within 30 miles of the academy at the time of application|confirmed|within 30 miles by rank of standardised score, then others by rank|
137166|2026|catchment_km|all||30|miles|kings_lincs_record|2026 oversubscription criteria|reside within 30 miles of the academy at the time of application|confirmed||
137166|2026|lowest_score_offered|all||||kings_policy|school admissions page||not_published|no qualifying or lowest score on the LA record or school page|

# ---------------- Kendrick (own test; postcode priority areas)
136448|2026|testers_stage1|all||704|candidates|kendrick_results_2026|Q5|for entry in September 2026? A 704 candidates.|confirmed||
136448|2025|testers_stage1|all||774|candidates|kendrick_results_2025|Q6|for entry in September 2025? A 774 candidates.|confirmed||
136448|2024|testers_stage1|all||747|candidates|kendrick_results_2024|Q6|for entry in September 2024? A 747 candidates.|confirmed||
136448|2023|testers_stage1|all||775|candidates|kendrick_results_2023|Q5|A 775 candidates sat the test at Kendrick School and a further 307 candidates sat the test at another venue|confirmed|plus 307 who sat elsewhere and had results sent|
136448|2026|qualifying_score|all||99.00|Kendrick total standardised score (Paper 1 + Paper 2)|kendrick_results_2026|Q2|previously in care is 99.00|confirmed||
136448|2026|qualifying_score|pupil_premium||94.00|Kendrick total standardised score|kendrick_results_2026|Q3|previously in care is 94.00|confirmed||
136448|2025|qualifying_score|all||100.00|Kendrick total standardised score|kendrick_results_2025|Q2|previously in care is 100.00|confirmed||
136448|2025|qualifying_score|pupil_premium||95.00|Kendrick total standardised score|kendrick_results_2025|Q3|previously in care is 95.00|confirmed||
136448|2024|qualifying_score|all||99.00|Kendrick total standardised score|kendrick_results_2024|Q2|previously in care is 99.00|confirmed||
136448|2023|qualifying_score|all||101.00|Kendrick total standardised score|kendrick_results_2023|Q2|designated area is 101.00|confirmed||
136448|2026|candidates_qualified|all_others||347|candidates|kendrick_results_2026|Q6|or above from Categories 3-5? A 347 candidates|confirmed||
136448|2025|candidates_qualified|all_others||325|candidates|kendrick_results_2025|Q7|or above from Categories 3-5? A 325 candidates|confirmed||
136448|2024|candidates_qualified|all_others||338|candidates|kendrick_results_2024|Q7|or above from Categories 3-5? A 338 candidates|confirmed||
136448|2023|candidates_qualified|all_others||364|candidates|kendrick_results_2023|Q6|or above from Categories 3-6? A 364 candidates|confirmed||
136448|2026|pan|all||128|places|kendrick_results_2026|Q3|more applicants than the 128 places available|confirmed||
136448|2025|pan|all||128|places|kendrick_results_2025|Q3|more applicants than the 128 places available|confirmed||
136448|2024|pan|all||128|places|kendrick_results_2024|Q3|more applicants than the 128 places available|confirmed||
136448|2023|pan|all||128|places|kendrick_results_2023|Q3|more applicants than the 128 places available|confirmed||
136448|2025|lowest_score_offered|all||||kendrick_results_2025|Q23||not_published|'We do not disclose the lowest score.'|
136448|2026|admissions_model|all||score_rank_priority_area|code|kendrick_policy_2026|oversubscription 3-4|until up to 75% (96) of places have been offered|confirmed|Priority Areas 1-2 (postcode sectors) by rank; no out-of-area offers since 2013|
136448|2026|priority_area|all||designated area: Priority Areas 1 and 2 (postcode sectors)|text|kendrick_policy_2026|Appendix 1|The designated area is made up of Priority Area 1 and Priority Area 2 and each area is determined by the postcode|confirmed|postcode lists, not a radius|
136448|2026|test_used|all||Kendrick own test (Paper 1 + Paper 2)|text|kendrick_results_2026|Q2|This is a total standardised score of Paper 1 and P|confirmed||

# ---------------- Reading School (own test; postcode catchment)
136449|2026|testers_stage1|all||991|candidates|rs_results_faq_2026|FAQ|A total of 991 candidates sat the test for Reading School.|confirmed||
136449|2026|candidates_qualified|all||471|candidates|rs_results_faq_2026|FAQ|471 candidates achieved the eligible score.|confirmed|annual data release gives 470 eligible for 2026|
136449|2026|pan|all||150|places|rs_policy_2026_day|PAN|The School admits 150 boys into Year 7 each year|confirmed|138 day + 12 boarding|
136449|2026|registrations|all||987|registrants|rs_annual_release_2026|'Total Registrants' row, 2026 column (2022-2027)|Total Registrants 913 966 1126 1077 987 1298|confirmed|2027 = 1298 registrants (test Sept 2026)|
136449|2025|registrations|all||1077|registrants|rs_annual_release_2026|same row, 2025|Total Registrants 913 966 1126 1077 987 1298|confirmed||
136449|2024|registrations|all||1126|registrants|rs_annual_release_2026|same row, 2024|Total Registrants 913 966 1126 1077 987 1298|confirmed||
136449|2023|registrations|all||966|registrants|rs_annual_release_2026|same row, 2023|Total Registrants 913 966 1126 1077 987 1298|confirmed||
136449|2025|candidates_qualified|all||354|candidates|rs_annual_release_2026|'Total Eligible' row, 2025|Total Eligible 350 336 395 354 470|confirmed||
136449|2024|candidates_qualified|all||395|candidates|rs_annual_release_2026|'Total Eligible' row, 2024|Total Eligible 350 336 395 354 470|confirmed||
136449|2023|candidates_qualified|all||336|candidates|rs_annual_release_2026|'Total Eligible' row, 2023|Total Eligible 350 336 395 354 470|confirmed||
136449|2026|admissions_model|all||score_rank_priority_area|code|rs_policy_2026_day|criteria|Places will be offered to students who are ranked high enough according to the entrance test scores and who reside within the catchment area|confirmed|catchment = postcode list; outside-catchment boys rarely offered day places|
136449|2026|lowest_score_offered|all||||rs_faq|Year 7 entry page||not_published|eligible-score value and last offer not published|
136449|2025|distribution_file|all||file|file|rs_scores_2025|one row per candidate: English, Maths, creative writing, catchment flag||confirmed|text extraction partly garbled|
136449|2026|distribution_file|all||file|file|rs_scores_summer_2026|FOI release Summer 2026: per-candidate standardised scores||confirmed|year inferred (not stated)|
136449|2026|test_used|all||Reading School own test|text|rs_results_faq_2026|FAQ|Students have been ranked based on their weighted total scores of all four subjects|confirmed||

# ---------------- Tiffin Girls' (own test; Inner + Designated Area)
136615|2026|testers_stage1|all||1468|candidates|tgs_poa_2024_26|table, col 2026|Candidates tested at stage one 1468 1498 1485|confirmed||
136615|2025|testers_stage1|all||1498|candidates|tgs_poa_2024_26|table, col 2025|Candidates tested at stage one 1468 1498 1485|confirmed||
136615|2024|testers_stage1|all||1485|candidates|tgs_poa_2024_26|table, col 2024|Candidates tested at stage one 1468 1498 1485|confirmed||
136615|2026|testers_stage2|all||474|candidates|tgs_poa_2024_26|table, col 2026|Candidates tested at stage two 474 475 465|confirmed||
136615|2025|testers_stage2|all||475|candidates|tgs_poa_2024_26|table, col 2025|Candidates tested at stage two 474 475 465|confirmed||
136615|2024|testers_stage2|all||465|candidates|tgs_poa_2024_26|table, col 2024|Candidates tested at stage two 474 475 465|confirmed||
136615|2026|testers_stage1|inside_priority_area||1322|candidates|tgs_poa_2024_26|'Designated Area stage one', col 2026|Designated Area stage one 1322 1364 1294|confirmed|includes Inner Area|
136615|2026|pan|all||180|places|tgs_poa_2024_26|'Number of places in Year 7 (PAN)', col 2026|(published admission number) 180 180 180|confirmed||
136615|2025|pan|all||180|places|tgs_poa_2024_26|col 2025|(published admission number) 180 180 180|confirmed||
136615|2024|pan|all||180|places|tgs_poa_2024_26|col 2024|(published admission number) 180 180 180|confirmed||
136615|2026|admissions_model|all||score_rank_priority_area|code|tgs_policy_2027|5.1|in rank order of the combined mark within the appropriate category|confirmed|Inner Area and Designated Area (44 postal districts) first; all 2024-26 places went to these areas|
136615|2026|priority_area|all||Inner Area + Designated Area (44 postal districts)|text|tgs_y7|page text|The Designated Area is made up of 44 postal districts|confirmed|postcode districts, not a radius|
136615|2026|lowest_score_offered|all||||tgs_poa_2024_26|whole table||not_published|patterns-of-admission table has no lowest score|
136615|2026|test_used|all||Tiffin Girls' own two-stage test|text|tgs_poa_2024_26|table|Candidates tested at stage one|confirmed||

# ---------------- QE Barnet (FOI pending): own test, no catchment
136290|2027|qualifying_score|all||225|QE combined standardised score|qe_faq|FAQ|Those candidates achieving a combined score of 225 or higher|confirmed||
136290|2027|pan|all||180|places|qe_faq|FAQ|The School's Published Admission Number (PAN) is 180.|confirmed||
136290|2027|admissions_model|all||score_rank|code|qe_faq|FAQ 23|Queen Elizabeth's School has no catchment.|confirmed|distance only as tie-break|
136290|2026|waiting_list_position_reached|all||24|position|qe_admissions|page text|The waiting list for entry into Year 7 in September 2026 has reached position 24.|confirmed||
136290|2025|testers_stage1|all||3433|candidates|qe_secondary_lt|table 'September 2025' (attributed to the school's admissions guide)|September 2025 3,433 764 809 235|secondary_source|school's own guide PDF not located; FOI pending|
136290|2025|lowest_score_offered|all||235|QE combined standardised score|qe_secondary_lt|table 'September 2025'|September 2025 3,433 764 809 235|secondary_source||
136290|2024|testers_stage1|all||3294|candidates|qe_secondary_lt|table 'September 2024'|September 2024 3,294 742 839 235|secondary_source||
136290|2024|lowest_score_offered|all||235|QE combined standardised score|qe_secondary_lt|table 'September 2024'|September 2024 3,294 742 839 235|secondary_source||
136290|2023|testers_stage1|all||3106|candidates|qe_secondary_lt|table 'September 2023'|September 2023 3,106 1,111 990 232|secondary_source||
136290|2023|lowest_score_offered|all||232|QE combined standardised score|qe_secondary_lt|table 'September 2023'|September 2023 3,106 1,111 990 232|secondary_source||
136290|2026|testers_stage1|all||||mailto:enquiries@qebarnet.co.uk|FOI sent 2026-10-10 (requests/SENT.md #10)||pending_foi||
136290|2026|lowest_score_offered|all||||mailto:enquiries@qebarnet.co.uk|FOI sent 2026-10-10 (requests/SENT.md #10)||pending_foi||

# ---------------- Henrietta Barnett (FOI pending)
138051|2027|pan|all||120|places|hbs_admissions|page text|The Published Admission Number (PAN) for September 2027 entry is 120.|confirmed||
138051|2027|testers_stage2|all||300|candidates (cap)|hbs_admissions|page text|The top 300 candidates will be invited to sit Round Two|confirmed|cap, not a count|
138051|2026|waiting_list_position_reached|all||47|position|hbs_admissions|page text (as of 4 September)|As of 4th September we have offered up to number 47 on the waiting list.|confirmed||
138051|2025|applications|all||3121|applications|hbs_secondary_lt|quote attributed to the school's appeals disclosure|In 2025, 3121 applications were received for 104 places in Year 7.|secondary_source|'applications' as quoted; whether test registrations is unclear|
138051|2027|admissions_model|all||||hbs_policy_2027|admissions policy 2027-28 (13 pages, image-only)||not_published|published, image-only PDFs (policy 2027-28, admission FAQs 2026); no text layer, not machine-readable|
138051|2026|testers_stage1|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||
138051|2026|lowest_score_offered|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||

# ---------------- St Michael's, Latymer, St Olave's, Newstead Wood
101361|2026|admissions_model|all||faith_categories_score_rank|code|stm_policy_2026|oversubscription|a. Baptised Catholic girls in rank order (in the entrance test) beginning with the highest.|confirmed|faith categories, test rank within each|
101361|2026|lowest_score_offered|all||||stm_policy_2026|policy||not_published|no statistics found|
102055|2025|pan|all||192|places|lat_procedures_2025|normal admissions round|The Published Admission Number (PAN) is 192.|confirmed||
102055|2025|admissions_model|all||score_rank_priority_area|code|lat_procedures_2025|Inner Area|The school will only admit students from the published Inner Area|confirmed|ranked by age-standardised score; top 700 deemed selective; 20 music places|
102055|2025|priority_area|all||Inner Area (postcode districts E2-N22)|text|lat_procedures_2025|Inner Area|The school will only admit students from the published Inner Area|confirmed|postcode list, not a radius|
102055|2026|lowest_score_offered|all||||lat_y7_2026|Year 7 2026 page||not_published|only the rank-700 eligibility rule is published|
101676|2026|pan|all||124|places|sto_faq|FAQ|The PAN (published admission number) is 124 plus up to 4 places|confirmed|+ up to 4 Wakeham choristers|
101676|2026|admissions_model|all||score_rank|code|sto_faq|FAQ|Does St. Olave's have a catchment area? No|confirmed|top 450 at stage 1 go to stage 2|
101676|2026|test_applicants|all||1600|applicants (approx., average of 2025 and 2026)|sto_faq|FAQ|an average of around 1600 applicants for the 2025 and 2026 application seasons|confirmed|approximate; registrations for the test, not a count of testers|
101676|2026|testers_stage2|all||450|candidates (cap)|sto_faq|FAQ|the top 450 performing boys will be invited to proceed to our Stage 2 test|confirmed||
136551|2026|pan|all||168|places|nw_policy_2026|1.3|The School's Planned Admission Number (PAN) into Year 7 for September 2026 is 168.|confirmed||
136551|2026|admissions_model|all||score_rank_priority_area|code|nw_policy_2026|3.3|The remaining places will be allocated strictly from the rank order list of the total score|confirmed|9-mile radius first, then outside; no places beyond 9 miles historically|
136551|2026|catchment_km|all||9|miles|nw_policy_2026|3.3.1|within a 9-mile radius of the school|confirmed||
136551|2026|testers_stage1|all||||nw_faq_2026|FAQ||not_published|no candidate counts or required-standard value published|

# ---------------- Sutton SET schools (FOI pending for all five)
|2026|testers_stage1|all||||sutton_set|council page||not_published|Sutton publishes test dates only; previous-years page shows N/A for grammars|{SET}
136621|2026|pan|all||186|places|wilsons_criteria|page text|a selective boys' school with an admission number for Year 7 of 186|confirmed||
136621|2026|admissions_model|all||score_rank|code|wilsons_faq|FAQ|our admissions criteria are not based on catchment areas, post codes or distance criteria|confirmed|14 FSM, 9 sport, 9 music places, rest by rank of standardised score|
136621|2026|test_used|all||{SET}|text|wilsons_faq|FAQ|What is the pass mark for the Selective Eligibility Test?|confirmed|plus own second stage|
136787|2026|pan|all||150|places|sgs_policy_2026|admission number|Included in the School's admission number of 150|confirmed||
136787|2026|admissions_model|all||score_rank_priority_area|code|sgs_policy_2026|criterion 4|75 places by rank order of the combined scores in the SET and the School's second stage test where the home addres|confirmed|75 for listed Sutton-area postcodes, rest any postcode, all by score|
136787|2026|priority_area|all||postcodes SM1-7, KT4, KT17, CR0 4, CR4|text|sgs_policy_2026|criterion 3-4|is one of the following postcodes: SM1-7, KT4, KT17, CR0 4--, CR4|confirmed|postcode list|
136787|2026|test_used|all||{SET}|text|sgs_policy_2026|criteria|combined scores in the SET and the School's second stage test|confirmed||
136795|2026|pan|all||210|places|nonsuch_policy_2026|3.3|The Published Admission Number (PAN) for entry to Year 7 is 210.|confirmed||
136795|2026|admissions_model|all||score_rank_mixed_catchment|code|nonsuch_policy_2026|5.2.2-5.2.4|85 places on the basis of the score in the Entrance Test in order of highest score, irrespective of home add|confirmed|85 open by score; up to 35 FSM/PP; up to 125 by score inside a 5.25 km circle|
136795|2026|catchment_km|all||5.25|km|nonsuch_policy_2026|5.2.4|is 5.25 km or less from the front door of Nonsuch|confirmed||
136795|2026|test_used|all||{SET}|text|wilsons_faq|FAQ|What is the pass mark for the Selective Eligibility Test?|confirmed|plus NWSSEE second stage|
136798|2027|admissions_model|all||score_rank|code|wcgs_secondary_lt|blog quoting 2027 determined arrangements|The other 110, nearly three-quarters of the intake, are allocated purely by test score|secondary_source|up to 15 places for Sutton postcodes ranked fifth; primary policy not located|
136798|2027|pan|all||150|places|wcgs_secondary_lt|blog|has no designated area or catchment for its 150 Year 7 places|secondary_source||
136798|2027|test_used|all||{SET}|text|wcgs_secondary_lt|blog|Selective Eligibility Test (SET)|secondary_source||
136789|2027|admissions_model|all||score_rank_mixed_catchment|code|whsg_secondary_lt|blog quoting 2027 policy 5.2.2|on the basis of the score in the Entrance Test in order of highest score, irrespective of home address.|secondary_source|100 open by score, up to 35 PP, up to 110 inside a 6.7 km circle|
136789|2027|catchment_km|all||6.7|km|whsg_secondary_lt|blog|a 6.7km radius circle around the school's Woodcote Road entrance|secondary_source||
136789|2027|pan|all||210|places|whsg_secondary_lt|blog|with a Published Admission Number of 210 for Year 7 entry in 2027|secondary_source||
# ---------------- Barnet LA allocation table (only LA source for QE, HBS, St Michael's): 403 to scripts
136290|2024|lowest_score_offered|all||||barnet_alloc_2024|Barnet allocation table 2024||blocked|HTTP 403 to scripts|
138051|2024|lowest_score_offered|all||||barnet_alloc_2024|Barnet allocation table 2024||blocked|HTTP 403 to scripts|
101361|2024|lowest_score_offered|all||||barnet_alloc_2024|Barnet allocation table 2024||blocked|HTTP 403 to scripts|
# ---------------- FOI pending (requests/SENT.md): testers, offers, lowest score per entry year
136621|2023|testers_stage1|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2023|offers|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2023|lowest_score_offered|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2024|testers_stage1|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2024|offers|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2024|lowest_score_offered|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2025|testers_stage1|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2025|offers|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2025|lowest_score_offered|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2026|testers_stage1|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2026|offers|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2026|lowest_score_offered|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136787|2023|testers_stage1|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2023|offers|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2023|lowest_score_offered|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2024|testers_stage1|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2024|offers|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2024|lowest_score_offered|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2025|testers_stage1|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2025|offers|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2025|lowest_score_offered|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2026|testers_stage1|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2026|offers|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2026|lowest_score_offered|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136798|2023|testers_stage1|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2023|offers|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2023|lowest_score_offered|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2024|testers_stage1|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2024|offers|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2024|lowest_score_offered|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2025|testers_stage1|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2025|offers|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2025|lowest_score_offered|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2026|testers_stage1|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2026|offers|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2026|lowest_score_offered|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136789|2023|testers_stage1|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136789|2023|offers|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136789|2023|lowest_score_offered|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136789|2024|testers_stage1|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136789|2024|offers|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136789|2024|lowest_score_offered|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136789|2025|testers_stage1|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136789|2025|offers|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136789|2025|lowest_score_offered|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136789|2026|testers_stage1|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136789|2026|offers|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136789|2026|lowest_score_offered|all||||mailto:info@wallingtongirls.org.uk|FOI sent 2026-10-10 (requests/SENT.md #7)||pending_foi||
136795|2023|testers_stage1|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136795|2023|offers|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136795|2023|lowest_score_offered|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136795|2024|testers_stage1|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136795|2024|offers|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136795|2024|lowest_score_offered|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136795|2025|testers_stage1|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136795|2025|offers|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136795|2025|lowest_score_offered|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136795|2026|testers_stage1|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136795|2026|offers|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136795|2026|lowest_score_offered|all||||mailto:office@nonsuchschool.org|FOI sent 2026-10-10 (requests/SENT.md #8)||pending_foi||
136290|2023|offers|all||||mailto:enquiries@qebarnet.co.uk|FOI sent 2026-10-10 (requests/SENT.md #10)||pending_foi||
136290|2024|offers|all||||mailto:enquiries@qebarnet.co.uk|FOI sent 2026-10-10 (requests/SENT.md #10)||pending_foi||
136290|2025|offers|all||||mailto:enquiries@qebarnet.co.uk|FOI sent 2026-10-10 (requests/SENT.md #10)||pending_foi||
136290|2026|offers|all||||mailto:enquiries@qebarnet.co.uk|FOI sent 2026-10-10 (requests/SENT.md #10)||pending_foi||
138051|2023|testers_stage1|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||
138051|2023|offers|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||
138051|2023|lowest_score_offered|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||
138051|2024|testers_stage1|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||
138051|2024|offers|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||
138051|2024|lowest_score_offered|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||
138051|2025|testers_stage1|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||
138051|2025|offers|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||
138051|2025|lowest_score_offered|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||
138051|2026|offers|all||||mailto:office@hbschool.org.uk|FOI sent 2026-10-10 (requests/SENT.md #9)||pending_foi||

"""

MODEL_NOTES = {
    "136910": "All 2024-2026 places went inside the 10 km priority area.",
    "136642": "12.5-mile (20.1 km) priority area for the first 120 places; consortium testers per place only.",
    "136412": "Own test; 144 places for a 12.5-mile priority area, 36 open; school-level candidates from the anonymised list.",
    "137045": "Ward catchment, priority-score applicants ranked by distance.",
    "137044": "Ward catchment, priority-score applicants ranked by distance.",
    "137046": "Ward catchment, priority-score applicants ranked by distance.",
}
