"""Hand-read observations for build_grammar_intake.py. One line per value:

    urn | entry_year | measure | category | offer_round | value | unit | source | location | snippet | status | note | name

- source: an id from code/harvest/grammar_intake.py SOURCES (file in data/raw/grammar_intake), or a bare URL
  for rows whose page could not be fetched (status blocked / not_published / pending_foi).
- snippet: short verbatim text from the extracted file; the build fails if it is not found (whitespace, case,
  curly quotes and dashes normalised), or if a numeric value is not inside its snippet.
- unit "miles" on a catchment_km row: the value is converted to km by the build (snippet keeps the miles).
- urn blank = a consortium / LA-level row; then `name` names the consortium (must match test_used values).
- admissions_model codes: score_rank (places by test-score rank, no area); score_rank_priority_area (score rank
  inside a priority area or quota, the rest by score from anywhere); qualify_then_distance (qualifying score,
  then distance / catchment); qualify_then_catchment_distance (KEF: LAC, pupil premium, then qualifiers above
  a priority score inside a ward catchment by distance, then others by score).
"""

CSSE = "CSSE (Consortium of Selective Schools in Essex)"
KENT = "Kent Test (Kent County Council)"
BHAM = "West Midlands grammar schools test (GL; Birmingham qualifying score)"
SLOUGH = "Slough Consortium 11+ (Herschel, Langley, St Bernard's, Upton Court)"
BUCKS = "Buckinghamshire Secondary Transfer Test (TBGS)"
TRAFFORD = "Trafford Grammar Schools test (GL)"
WARKS = "Warwickshire 11+ (West Midlands grammar schools test)"
SET = "Sutton Selective Eligibility Test (SET)"

CURATED = f"""
# ---------------- Tiffin School (Kingston): own two-stage test, 10 km priority area
136910|2026|testers_stage1|all||1866|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage One', col 2026|Applicants tested at Stage One 1866 1675 1654|confirmed||
136910|2025|testers_stage1|all||1675|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage One', col 2025|Applicants tested at Stage One 1866 1675 1654|confirmed||
136910|2024|testers_stage1|all||1654|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage One', col 2024|Applicants tested at Stage One 1866 1675 1654|confirmed||
136910|2026|testers_stage2|all||665|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage Two', col 2026|Applicants tested at Stage Two 665 653 666|confirmed||
136910|2025|testers_stage2|all||653|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage Two', col 2025|Applicants tested at Stage Two 665 653 666|confirmed||
136910|2024|testers_stage2|all||666|candidates|tiffin_poa_2026|p1, row 'Applicants tested at Stage Two', col 2024|Applicants tested at Stage Two 665 653 666|confirmed||
136910|2026|places|all|national_offer_day|186|places|tiffin_poa_2026|p1, row 'Places offered initially', col 2026|Places offered initially 186 186 186|confirmed||
136910|2025|places|all|national_offer_day|186|places|tiffin_poa_2026|p1, row 'Places offered initially', col 2025|Places offered initially 186 186 186|confirmed||
136910|2024|places|all|national_offer_day|186|places|tiffin_poa_2026|p1, row 'Places offered initially', col 2024|Places offered initially 186 186 186|confirmed||
136910|2026|lowest_score_offered|all|national_offer_day|100|Tiffin School test score (school's own scale)|tiffin_poa_2026|p1, row 'Initial qualifying score (lowest score offered on 1st March)', col 2026|(the lowest score achieved by a student 100 100 104|confirmed||
136910|2025|lowest_score_offered|all|national_offer_day|100|Tiffin School test score (school's own scale)|tiffin_poa_2026|p1, same row, col 2025|(the lowest score achieved by a student 100 100 104|confirmed||
136910|2024|lowest_score_offered|all|national_offer_day|104|Tiffin School test score (school's own scale)|tiffin_poa_2026|p1, same row, col 2024|(the lowest score achieved by a student 100 100 104|confirmed||
136910|2025|lowest_score_offered|all|end_of_year7|98|Tiffin School test score (school's own scale)|tiffin_poa_2026|p1, row 'Cut off score (lowest score offered a place by the end of Y7)', col 2025 (2026: tbc)|(the lowest score achieved by a student tbc 98 102|confirmed||
136910|2024|lowest_score_offered|all|end_of_year7|102|Tiffin School test score (school's own scale)|tiffin_poa_2026|p1, same row, col 2024|(the lowest score achieved by a student tbc 98 102|confirmed||
136910|2026|offers|pupil_premium|national_offer_day|15|offers|tiffin_poa_2026|p1, row 'Number of students eligible for Pupil Premium ... offered a place', col 2026|15** 11 6|confirmed|18 PP candidates were eligible but only 15 listed Tiffin first|
136910|2025|offers|pupil_premium|national_offer_day|11|offers|tiffin_poa_2026|p1, same row, col 2025|15** 11 6|confirmed||
136910|2024|offers|pupil_premium|national_offer_day|6|offers|tiffin_poa_2026|p1, same row, col 2024|15** 11 6|confirmed||
136910|2026|admissions_model|all||score_rank_priority_area|code|tiffin_poa_2026|p1 footnote|For 2024, 2025, and 2026, all places were offered to those in the Priority Area (10km). No places were offered to those outside the Priority Area.|confirmed|all 2024-2026 places went to the 10 km priority area|
136910|2026|catchment_km|all||10|km|tiffin_poa_2026|p1 footnote|all places were offered to those in the Priority Area (10km)|confirmed||
136910|2026|test_used|all||Tiffin School own two-stage test|text|tiffin_poa_2026|p1|Applicants tested at Stage One|confirmed||

# ---------------- CSSE guidance sheets (lowest score on national offer day; 303 = minimum for any offer)
|2025|qualifying_score|minimum_any_offer||303|CSSE total standardised score|csse_guidance_2026|p1 footer|not made to any child who has scored under a total standardised score of 303|confirmed|minimum for any CSSE offer; schools may set higher pass marks|{CSSE}
|2024|qualifying_score|minimum_any_offer||303|CSSE total standardised score|csse_guidance_2025|p1 footer|not made to any child who has scored under a total standardised score of 303|confirmed||{CSSE}
136642|2025|lowest_score_offered|inside_priority_area|national_offer_day|355|CSSE total standardised score|csse_guidance_2026|p1 'Essex grammar schools', KEGS row, 'Inside Priority Area' col|King Edward VI Grammar School (Boys) 355 372|confirmed|sheet 'for 2026 entry' = offers of 1 March 2025 for Sept 2025 entry|
136642|2025|lowest_score_offered|outside_priority_area|national_offer_day|372|CSSE total standardised score|csse_guidance_2026|p1, KEGS row, 'Outside Priority Area' col|King Edward VI Grammar School (Boys) 355 372|confirmed||
136642|2024|lowest_score_offered|inside_priority_area|national_offer_day|340|CSSE total standardised score|csse_guidance_2025|p1, KEGS row, 'Inside Priority Area' col|King Edward VI Grammar School (Boys) 340 376|confirmed|sheet 'for 2025 entry' = offers of 1 March 2024 for Sept 2024 entry|
136642|2024|lowest_score_offered|outside_priority_area|national_offer_day|376|CSSE total standardised score|csse_guidance_2025|p1, KEGS row, 'Outside Priority Area' col|King Edward VI Grammar School (Boys) 340 376|confirmed||
149899|2025|lowest_score_offered|all|national_offer_day|343|CSSE total standardised score|csse_guidance_2026|p1, CRGS row (no priority area)|Colchester Royal 343 Grammar School (Boys)*|confirmed||
149899|2024|lowest_score_offered|all|national_offer_day|337|CSSE total standardised score|csse_guidance_2025|p1, CRGS row (no priority area)|Colchester Royal 337 Grammar School (Boys)*|confirmed||
149899|2025|priority_area|all||none|text|csse_guidance_2026|p1 footnote|Colchester Royal Grammar School - No priority area.|confirmed|single CSSE ranking, no area quota|
136272|2025|lowest_score_offered|inside_priority_area|national_offer_day|309|CSSE total standardised score|csse_guidance_2026|p1 'Southend grammar schools', WHSB row|Westcliff High School for Boys 309 351|confirmed||
136272|2025|lowest_score_offered|outside_priority_area|national_offer_day|351|CSSE total standardised score|csse_guidance_2026|p1, WHSB row|Westcliff High School for Boys 309 351|confirmed||
136272|2024|lowest_score_offered|inside_priority_area|national_offer_day|303|CSSE total standardised score|csse_guidance_2025|p1, WHSB row|Westcliff High School for Boys 303 355|confirmed||
136272|2024|lowest_score_offered|outside_priority_area|national_offer_day|355|CSSE total standardised score|csse_guidance_2025|p1, WHSB row|Westcliff High School for Boys 303 355|confirmed||
|2023|lowest_score_offered|all||||csse_guidance_2019_2024|whole file||not_published|published, image-only PDF (sheets for 2019-2024 entry, i.e. Sept 2018-2023 offers); no text layer, not machine-readable|{CSSE}
|2025|candidate_totals_file|all||||csse_candidates|whole file||not_published|published, image-only PDF (total CSSE candidates 2010-2025 entry); no text layer, not machine-readable; counts taken from the score files instead|{CSSE}
|2026|standardisation_report|all||||csse_std_report_2026|whole file||not_published|published, image-only PDF; not machine-readable|{CSSE}
|2026|distribution_file|all||file|file|csse_raw_scores_2026|every candidate's raw English and maths marks by sex and birth month||confirmed|first line of the standardised-score file for 2026 entry reads '2025Entry' but its test dates are Sept 2025|{CSSE}
|2026|distribution_file|all||file|file|csse_std_scores_2026|every candidate's total standardised score by sex and test date||confirmed|first line reads '2025Entry' but the test dates are 20 and 30 Sept 2025, i.e. 2026 entry|{CSSE}
|2024|distribution_file|all||file|file|csse_std_scores_2019_2024|every candidate's standardised score, one sheet per entry year 2019-2024||confirmed|raw marks in csse_raw_scores_2019_to_2024_entry.xlsx|{CSSE}
|2025|distribution_file|all||file|file|csse_std_scores_2025|every candidate's total standardised score by sex and test date||confirmed||{CSSE}

# ---------------- KEGS Chelmsford (CSSE): own published cut-offs, 12.5-mile priority area
136642|2026|lowest_score_offered|inside_priority_area|national_offer_day|353.5|CSSE total standardised score|kegs_faq|FAQ 'What 11+ score gets a place at KEGS?', 'September 2026 admission'|the lowest score obtained by an 'in area' applicant, who was neither in receipt of the Pupil Premium payment nor classified as a looked after child, was 353.5|confirmed|excludes pupil premium and looked-after applicants|
136642|2026|lowest_score_offered|outside_priority_area|national_offer_day|370.1|CSSE total standardised score|kegs_faq|same section|the lowest score obtained by an 'out of area' applicant, who was neither in receipt of the Pupil Premium payment nor classified as a looked after child, was 370.1|confirmed|excludes pupil premium and looked-after applicants|
136642|2026|lowest_score_offered|inside_priority_area|september|353|CSSE total standardised score (rounded)|kegs_faq|same section, students starting Sept 2026|For the students starting Year 7 at KEGS in September 2026, the lowest score obtained by an 'in area' applicant, who was neither in receipt of the Pupil Premium payment nor classified as a looked after child, was 353|confirmed||
136642|2026|lowest_score_offered|outside_priority_area|september|368|CSSE total standardised score (rounded)|kegs_faq|same section, students starting Sept 2026|For the students starting Year 7 at KEGS in September 2026, the lowest score obtained by an 'out of area' applicant, who was neither in receipt of the Pupil Premium payment nor classified as a looked after child, was 368|confirmed||
136642|2026|pan|all||150|places|kegs_faq|FAQ|We admit 150 boys into Year 7.|confirmed||
136642|2027|admissions_model|all||score_rank_priority_area|code|kegs_priority_area|page text|the first 120 places will be offered to the highest scoring boys, who permanently and continuously live within this area|confirmed|remaining places to the highest scorers regardless of address; 2024-2026 cut-offs also split in/out of area|
136642|2027|priority_area_places|all||120|places|kegs_priority_area|page text|the first 120 places will be offered to the highest scoring boys|confirmed||
136642|2027|catchment_km|all||12.5|miles|kegs_priority_area|page text|KEGS has a priority area, for Year 7 admissions, of 12.5 miles from the school.|confirmed||
136642|2026|test_used|all||{CSSE}|text|kegs_faq|FAQ|Results are rank ordered for each individual school by the CSSE|confirmed||
136642|2026|distribution_file|all||file|file|kegs_scores_2026|scores and in/out area of admitted students (pupil premium removed)||confirmed||
136642|2025|distribution_file|all||file|file|kegs_scores_2025|scores and in/out area of admitted students||confirmed||
136642|2024|distribution_file|all||file|file|kegs_scores_2024|scores and in/out area of admitted students||confirmed||
136642|2023|distribution_file|all||file|file|kegs_scores_2023|scores and in/out area of admitted students||confirmed||

# ---------------- Colchester RGS (CSSE): score rank, no priority area
149899|2025|pan|all||128|places|crgs_policy_2025|p2 'Admissions Arrangements - Academic Year 2025-2026'|The published admission number for Year 7 is 128.|confirmed||
149899|2025|admissions_model|all||score_rank|code|crgs_policy_2025|p2 'Admissions Priority 2'|The remaining places will then be offered in descending rank order of marks to the boys scoring highest in the selection tests|confirmed|up to 12 places first to LAC / pupil premium boys scoring above 320|
149899|2025|qualifying_score|pupil_premium_or_looked_after||320|CSSE total standardised score|crgs_policy_2025|p1 'Admissions Priority 1'|achieve a score greater than 320 in the selection tests|confirmed|threshold for the up-to-12 priority places only|
149899|2025|test_used|all||{CSSE}|text|crgs_policy_2025|p1|selection procedure organised by the Consortium of Selective Schools in Essex (CSSE)|confirmed||

# ---------------- Westcliff High School for Boys (CSSE): score rank inside SS0-SS9 quota
136272|2026|pan|all||185|places|whsb_doc_a|'Admission Criteria and Arrangements for Entry 2026', para 7|For the September 2026 intake, the School's Published Admission Number (PAN) is 185.|confirmed||
136272|2023|pan|all||185|places|whsb_doc_b|'Admission Criteria and Arrangements for Entry 2023', para 7|For the September 2023 intake, the School's Published Admission Number (PAN) is 185.|confirmed||
136272|2026|admissions_model|all||score_rank_priority_area|code|whsb_doc_a|para 9-10|In each category, places are allocated in order of the mark achieved, higher passing candidates first.|confirmed|local quota of up to 80% of PAN (148) for SS0-SS9 residents, then others by score|
136272|2026|priority_area|all||postcode areas SS0-SS9 (Southend LA booklet definition)|text|whsb_doc_a|para 10(ii)|lies within the catchment area postcode areas SS0, SS1, SS2, SS3, SS4, SS5, SS6, SS7, SS8 and SS9|confirmed|a postcode-district area, not a radius|
136272|2026|priority_area_places|all||148|places|whsb_doc_a|para 10(ii)|is reserved at this School for children in this category (148)|confirmed||
136272|2026|test_used|all||{CSSE}|text|whsb_doc_a|para 3|selection procedure administered by the Consortium of Selective Schools in Essex (CSSE)|confirmed||

# ---------------- Chelmsford County High School for Girls: own test (FSCE), 12.5-mile priority area
136412|2026|lowest_score_offered|inside_priority_area|national_offer_day|106-107|CCHS total standardised score (range released)|cchs_foi|'For September 2026 intake' (correct at 20 Mar 2026)|For the 12.5-mile priority area (Policy 1.5 3a), the last student offered scored in the range of 106-107.|confirmed|school releases a 1-point range, not the score|
136412|2026|lowest_score_offered|outside_priority_area|national_offer_day|118-119|CCHS total standardised score (range released)|cchs_foi|same section|For outside the 12.5-mile priority area (Policy 1.5 3b), the last student offered scored in the range of 118-119.|confirmed||
136412|2025|lowest_score_offered|inside_priority_area|september|107-108|CCHS total standardised score (range released)|cchs_foi|'For September 2025 intake' (correct at 4 Mar 2026)|For the 12.5 mile priority area (Policy 1.5 3a), the last student offered scored in the range of 107-108|confirmed|stated after 15 post-offer rejections, so a final (not national offer day) cut-off|
136412|2025|lowest_score_offered|outside_priority_area|september|116-117|CCHS total standardised score (range released)|cchs_foi|same section|For outside the 12.5 mile priority area (Policy 1.5 3b), the last student offered scored in the range of 116-117|confirmed||
136412|2024|lowest_score_offered|inside_priority_area||108-109|CCHS total standardised score (range released)|cchs_foi|'For September 2024 intake'|For the 12.5 mile priority area, the last student offered scored in the range of 108-109|confirmed|round not stated|
136412|2024|lowest_score_offered|outside_priority_area||113-114|CCHS total standardised score (range released)|cchs_foi|same section|For outside the 12.5 mile priority area, the last student offered scored in the range of 113-114|confirmed|round not stated|
136412|2023|lowest_score_offered|inside_priority_area|national_offer_day|107-108|CCHS total standardised score (range released)|cchs_foi|'For September 2023 intake'|The last student offered a place on the National Offer Day scored in the range of 107-108 for the 12.5 mile priority area|confirmed||
136412|2023|lowest_score_offered|outside_priority_area|national_offer_day|116-117|CCHS total standardised score (range released)|cchs_foi|same section|and the range of 116-117 for outside the 12.5 mile priority area. Between the period of March 2023|confirmed||
136412|2026|pan|all||180|places|cchs_policy_2026|p1|The School's published admission number is 180 places for admission in Year 7 in 2026.|confirmed||
136412|2026|admissions_model|all||score_rank_priority_area|code|cchs_policy_2026|1.5 'Allocation of places on over-subscription'|places will be allocated in descending score order from the Ranked List of Applicants|confirmed|144 places for the 12.5-mile priority area (up to 30 of them pupil/service premium), up to 36 to anyone by score|
136412|2026|priority_area_places|all||144|places|cchs_policy_2026|1.5 (3)|3. Of the next 144, places will be allocated as follows|confirmed||
136412|2026|catchment_km|all||12.5|miles|cchs_policy_2026|1.5 (3b)|living at a permanent home address within the 12.5-mile priority area of the School|confirmed||
136412|2026|test_used|all||CCHS own test (Future Stories Community Enterprise)|text|cchs_guide_2026|p1|CCHS will be using an Entrance Test supplied by Future Stories Community Enterprise (FSCE).|confirmed||

# ---------------- Birmingham (KEF schools + Bishop Vesey's + Sutton Coldfield Girls)
|2027|qualifying_score|all||205|Birmingham test standardised score|kef_results|'Cut-Off Scores'|The Qualifying Score for all of the Birmingham grammar schools for 2027 entry is 205.|confirmed||{BHAM}
|2027|qualifying_score|priority_score_kef||224|Birmingham test standardised score|kef_results|'Cut-Off Scores'|The Priority Score for all of the King Edward VI Grammar Schools for 2027 entry is 224.|confirmed|KEF schools only|{BHAM}
|2027|testers_stage1|all||||kef_the_test|whole page||not_published|no candidate counts on the KEF results, test or grammar-schools pages|{BHAM}
137045|2027|pan|all||120|places|kef_chb_policy_2027|p1|Admission Number: 120|confirmed|DfE offers 2026: 150|
137045|2027|admissions_model|all||qualify_then_catchment_distance|code|kef_chb_policy_2027|p1 criterion 4|Applicants who achieve the priority score and live within the school catchment area*. Applicants in this category will be given priority if they have an older sibling** at the school; then ranked by distance|confirmed|criterion 5 (others) ranked by score; in 2025 entry category 4 filled every place|
137045|2027|priority_area|all||electoral wards listed in the policy|text|kef_chb_policy_2027|p2 footnote|The catchment area consists of home addresses that are within the following electoral wards in Birmingham|confirmed|ward list, not a radius|
137045|2027|test_used|all||{BHAM}|text|kef_the_test|page text|The test is provided by GL Assessment.|confirmed|test shared with the 19 West Midlands grammar schools|
137044|2027|pan|all||150|places|kef_chg_policy_2027|p1|Admission Number: 150|confirmed||
137044|2027|admissions_model|all||qualify_then_catchment_distance|code|kef_chg_policy_2027|p1 criterion 4|they have an older sibling** at the school; then ranked by distance|confirmed|same five-category structure as Camp Hill Boys|
137044|2027|test_used|all||{BHAM}|text|kef_the_test|page text|The test is provided by GL Assessment.|confirmed||
137046|2027|pan|all||180|places|kef_fws_policy_2027|p1|Admission Number: 180|confirmed||
137046|2027|admissions_model|all||qualify_then_catchment_distance|code|kef_fws_policy_2027|p1 criterion 4|they have an older sibling** at the school; then ranked by distance|confirmed|in 2024-2026 no 'all others' offers in March|
137046|2027|test_used|all||{BHAM}|text|kef_the_test|page text|The test is provided by GL Assessment.|confirmed||
137988|2027|pan|all||192|places|bv_policy_2027_proposed|p1|Admission Number 192|confirmed|proposed arrangements|
137988|2027|admissions_model|all||score_rank_priority_area|code|bv_policy_2027_proposed|p2 criterion 3|Other children who achieve the qualifying score by rank order of standardised score living within Zone 1|confirmed|proposed 2027 arrangements; 2023-2026 KEF table shows no zone category (LAC, pupil premium, all others)|
137988|2027|catchment_km|all||12|miles|bv_policy_2027_proposed|p1|Zone 1 is determined as a straight-line measurement of up to 12 miles|confirmed||
137988|2027|test_used|all||{BHAM}|text|bv_policy_2027_proposed|p1|on standardised tests of verbal, numerical and non-verbal reasoning ability|confirmed||

# ---------------- Kent Test (county threshold)
|2025|qualifying_score|total||332|Kent Test total of three standardised scores (each 69-141, max 423)|kent_results_wayback_20250907|'Grammar school threshold 2024' (test sat Sept 2024)|children needed a total score of 332 or more, with no single score lower than 106|confirmed|Wayback capture 2025-09-07 of the KCC page|{KENT}
|2025|qualifying_score|minimum_each_test||106|Kent Test standardised score (69-141)|kent_results_wayback_20250907|same paragraph|children needed a total score of 332 or more, with no single score lower than 106|confirmed||{KENT}
|2026|qualifying_score|total||||https://www.kent.gov.uk/education-and-children/schools/school-places/kent-test/kent-test-results|KCC page||blocked|HTTP 403 to scripts (Cloudflare); no Wayback capture after 2025-09-07|{KENT}

|2026|qualifying_score|total||332|Kent Test total of three standardised scores (max 423)|judd_history_2026|p1 row 'Kent Test Pass Mark', column 2026 (entry year)|Kent Test 320 320 320 320 323 330 332 332 332 332 332 332 Pass Mark|confirmed|KCC page blocked; value from The Judd School's own historical table (columns are entry years 2015-2026)|{KENT}
|2026|qualifying_score|minimum_each_test||108|Kent Test standardised score (69-141)|judd_history_2026|p1 row 'Minimum Pass Mark Per Paper', column 2026|Minimum 106 106 106 106 107 110 108 109 109 107 108 108 Pass Mark Per Paper|confirmed||{KENT}
|2025|qualifying_score|minimum_each_test||108|Kent Test standardised score (69-141)|judd_history_2026|p1 same row, column 2025|Minimum 106 106 106 106 107 110 108 109 109 107 108 108 Pass Mark Per Paper|confirmed|CONFLICT: the KCC page (Wayback) gives 106 for the test sat Sept 2024 (2025 entry)|{KENT}
|2024|qualifying_score|minimum_each_test||107|Kent Test standardised score (69-141)|judd_history_2026|p1 same row, column 2024|Minimum 106 106 106 106 107 110 108 109 109 107 108 108 Pass Mark Per Paper|confirmed||{KENT}
|2023|qualifying_score|minimum_each_test||109|Kent Test standardised score (69-141)|judd_history_2026|p1 same row, column 2023|Minimum 106 106 106 106 107 110 108 109 109 107 108 108 Pass Mark Per Paper|confirmed||{KENT}
|2026|testers_stage1|all||||https://www.kent.gov.uk/education-and-children/schools/school-places/kent-test/kent-test-results|KCC 'Report of Kent Test scores 2025' (test sat Sept 2025)||blocked|file link only on the KCC page, which returns 403 to scripts; not captured by Wayback|{KENT}

# ---------------- The Judd School (Kent Test): score rank in Inner (postcode) / Outer area
118843|2026|lowest_score_offered|inside_priority_area|national_offer_day|389|Kent Test total (max 423)|judd_year7|'Admissions Update - March 2026'|The cut-off score for our inner area was 389 (2025: 371) with the outer area being 403 (2025: 398)|confirmed|inner area = postcode list|
118843|2026|lowest_score_offered|outside_priority_area|national_offer_day|403|Kent Test total (max 423)|judd_year7|same|The cut-off score for our inner area was 389 (2025: 371) with the outer area being 403 (2025: 398)|confirmed||
118843|2025|lowest_score_offered|inside_priority_area|national_offer_day|371|Kent Test total (max 423)|judd_year7|same (2025 in brackets)|The cut-off score for our inner area was 389 (2025: 371)|confirmed||
118843|2025|lowest_score_offered|outside_priority_area|national_offer_day|398|Kent Test total (max 423)|judd_year7|same (2025 in brackets)|with the outer area being 403 (2025: 398)|confirmed||
118843|2024|lowest_score_offered|inside_priority_area|national_offer_day|383|Kent Test total (max 423)|judd_history_2026|p1 row 'Judd Cut-off: March', Inner, 2024 (11 values 2016-2026)|362 364 364 376 385 387 387 381 383 371 389|confirmed||
118843|2023|lowest_score_offered|inside_priority_area|national_offer_day|381|Kent Test total (max 423)|judd_history_2026|p1 same row, Inner, 2023|362 364 364 376 385 387 387 381 383 371 389|confirmed||
118843|2024|lowest_score_offered|outside_priority_area|national_offer_day|412|Kent Test total (max 423)|judd_history_2026|p1 same row, Outer, 2024|391 400 395 402 407 408 409 406 412 398 403|confirmed||
118843|2023|lowest_score_offered|outside_priority_area|national_offer_day|406|Kent Test total (max 423)|judd_history_2026|p1 same row, Outer, 2023|391 400 395 402 407 408 409 406 412 398 403|confirmed||
118843|2026|lowest_score_offered|inside_priority_area|april_reallocation|386|Kent Test total (max 423)|judd_history_2026|p1 row 'Judd Cut-off: April Reallocation', Inner, 2026|357 361 361 373 384 384 384 376 380 367 386|confirmed||
118843|2026|places|inside_priority_area|national_offer_day|157|places|judd_year7|'Admissions Update - March 2026'|The number of places available for the inner area is 157; the outer area is 23.|confirmed||
118843|2026|places|all|national_offer_day|180|offers|judd_year7|same|On 02 March 2026 - 180 offers were made.|confirmed||
118843|2026|admissions_model|all||score_rank_priority_area|code|judd_areas|page text|157 places will be allocated to students resident in the Inner Area, which is defined by the following postcodes|confirmed|23 outer-area places; both lists ranked by Kent Test score|
118843|2026|priority_area|all||Inner Area (postcode list)|text|judd_areas|page text|157 places will be allocated to students resident in the Inner Area, which is defined by the following postcodes|confirmed|postcode list, not a radius|
118843|2026|test_used|all||{KENT}|text|judd_history_2026|p1|Kent Test 320 320 320 320 323 330 332 332 332 332 332 332 Pass Mark|confirmed||

# ---------------- The Skinners' School (Kent Test + 40): qualify, then distance
140595|2027|pan|all||160|places|skinners_policy_2027|p1|The School intends to offer 160 places each year for boys aged 11.|confirmed||
140595|2027|admissions_model|all||qualify_then_distance|code|skinners_policy_2027|West Kent Area 2(b)|those living in the West Kent Area with a PESE (11+) score of at least 40 points higher than the KCC|confirmed|ranked siblings, staff, then shortest distance; up to 16 governors' places by highest score|
140595|2027|qualifying_score|main_criteria||40|points above the Kent Test threshold|skinners_questions|page text|We have set a qualifying score of 40 points higher than the Kent Test threshold score|confirmed|e.g. 372 if the Kent threshold is 332|
140595|2025|last_distance_offered|inside_priority_area||11|miles|skinners_questions|page text|our West Kent area to 11 miles for 2025 admission|confirmed|West Kent area|
140595|2025|last_distance_offered|outside_priority_area||18|miles|skinners_questions|page text|The furthest distance offered in the Outer Area for 2025 was 18 miles.|confirmed||
140595|2025|applications|grammar_assessed||702|applications|skinners_questions|page text|There were 702 grammar school assessed SCAF applications to Skinners' for 2025 Year 7 entry|confirmed|grammar-assessed preferences, not testers|
140595|2025|applications|first_preference_grammar_assessed||198|applications|skinners_questions|page text|198 of them put Skinners' as first choice|confirmed||
140595|2026|lowest_score_offered|all||||https://www.skinners-school.co.uk/38/2026-year-7-admission-information-updated-2nd-march|school update page||not_published|page removed; the Oct-2025 Kent Test page returns '404 Error' (fetched 2026-10-10); value seen only in search snippets|
140595|2027|test_used|all||{KENT}|text|skinners_policy_2027|West Kent Area 2(b)|PESE (11+) score of at least 40 points higher than the KCC|confirmed||

# ---------------- Tonbridge Grammar School (Kent Test): Area / Trustee lists by score
136417|2026|pan|all||180|places|tgs_guidance_2026|para 3|Our Published Admission Number (PAN) for September 2026 is 180.|confirmed||
136417|2026|admissions_model|all||score_rank_priority_area|code|tgs_guidance_2026|para 6-7|We will offer 135 places to Area children. These will be allocated by listing children in order of the highest score first|confirmed|30 Trustee (outside area) places also by score; 15 pupil premium places by distance|
136417|2026|priority_area|all||Tonbridge and Malling, Tunbridge Wells and Sevenoaks districts|text|tgs_guidance_2026|para 4|girls who live in Tonbridge and Malling Borough, Tunbridge Wells Borough and Sevenoaks District areas (Area places)|confirmed|three local-authority districts, not a radius|
136417|2026|priority_area_places|all||135|places|tgs_guidance_2026|para 6|We will offer 135 places to Area children.|confirmed||
136417|2026|lowest_score_offered|inside_priority_area|national_offer_day|378|Kent Test total (max 423)|tgs_guidance_2027|'Historical scores' row 2026 (Area/Trustee: 1st round, 2nd round, waiting list)|2026 378/400 377/397 376/397|confirmed||
136417|2026|lowest_score_offered|outside_priority_area|national_offer_day|400|Kent Test total (max 423)|tgs_guidance_2027|same row, Trustee|2026 378/400 377/397 376/397|confirmed|Trustee = outside the area|
136417|2025|lowest_score_offered|inside_priority_area|national_offer_day|368|Kent Test total (max 423)|tgs_guidance_2026|'Historical scores' row 2025|2025 368/395 366/389 365/388|confirmed||
136417|2025|lowest_score_offered|outside_priority_area|national_offer_day|395|Kent Test total (max 423)|tgs_guidance_2026|same row|2025 368/395 366/389 365/388|confirmed||
136417|2024|lowest_score_offered|inside_priority_area|national_offer_day|375|Kent Test total (max 423)|tgs_guidance_2026|row 2024|2024 375/396 373/414 373/396|confirmed||
136417|2024|lowest_score_offered|outside_priority_area|national_offer_day|396|Kent Test total (max 423)|tgs_guidance_2026|row 2024|2024 375/396 373/414 373/396|confirmed||
136417|2023|lowest_score_offered|inside_priority_area|national_offer_day|378|Kent Test total (max 423)|tgs_guidance_2026|row 2023|2023 378/393 375/392 377/383|confirmed||
136417|2023|lowest_score_offered|outside_priority_area|national_offer_day|393|Kent Test total (max 423)|tgs_guidance_2026|row 2023|2023 378/393 375/392 377/383|confirmed||
136417|2026|test_used|all||{KENT}|text|tgs_guidance_2026|para 4|(Grammar assessed) through the Kent PESE 11+ Test|confirmed||

# ---------------- Langley Grammar School (Slough consortium)
136521|2026|applications|all||1052|applications naming the school|lgs_alloc_2026|table row 'Langley Grammar School Academy' (PAN, applications, eligible)|Academy 180 1052 775|confirmed|any CAF naming the school, irrespective of score|
136521|2026|applications|eligible_111_plus||775|applications|lgs_alloc_2026|same row|Academy 180 1052 775|confirmed|applicants scoring 111+|
136521|2026|pan|all||180|places|lgs_alloc_2026|same row|Academy 180 1052 775|confirmed||
136521|2026|lowest_score_offered|priority_area_1|national_offer_day|113|Slough consortium standardised score|lgs_alloc_2026|'Information on 2026 entry'|Academy 180 1052 775 down to 113 admitted.|confirmed||
136521|2026|lowest_score_offered|priority_area_2|national_offer_day|119|Slough consortium standardised score|lgs_alloc_2026|same|area with a rank score down to 119.|confirmed||
136521|2025|applications|all||1121|applications naming the school|lgs_alloc_2025|table row|Academy 180 1121 805|confirmed||
136521|2025|applications|eligible_111_plus||805|applications|lgs_alloc_2025|table row|Academy 180 1121 805|confirmed||
136521|2025|pan|all||180|places|lgs_alloc_2025|table row|Academy 180 1121 805|confirmed||
136521|2025|lowest_score_offered|priority_area_1|national_offer_day|113|Slough consortium standardised score|lgs_alloc_2025|'Information on 2025 entry'|Academy 180 1121 805 down to 113 admitted.|confirmed||
136521|2025|lowest_score_offered|priority_area_2|national_offer_day|118|Slough consortium standardised score|lgs_alloc_2025|'Information on 2025 entry'|area with a rank score down to 118.|confirmed||
136521|2024|applications|all||1211|applications naming the school|lgs_alloc_2024|table row|Academy 180 1211 825|confirmed||
136521|2024|pan|all||180|places|lgs_alloc_2024|table row|Academy 180 1211 825|confirmed||
136521|2024|lowest_score_offered|priority_area_1|national_offer_day|113|Slough consortium standardised score|lgs_alloc_2024|'Information on 2024 entry'|Langley Grammar score down to 113 admitted.|confirmed||
136521|2024|lowest_score_offered|priority_area_2|national_offer_day|117|Slough consortium standardised score|lgs_alloc_2024|same|admissions area with a rank score down to 117.|confirmed||
|2026|qualifying_score|all||111|Slough consortium standardised score|lgs_page_2026|page text|Children who scored 111 or above in the test, are eligible to be considered|confirmed|111 = top 35% of the cohort per the arrangements|{SLOUGH}
136521|2026|admissions_model|all||score_rank_priority_area|code|lgs_policy_2026|oversubscription (a)-(b)|within the school's Priority Area 1, up to a maximum of 100 places|confirmed|PA1 (SL3 sectors) up to 100 by rank, then PA2 postcode districts by rank, then others|
136521|2026|priority_area|all||Priority Areas 1-3 (postcode sectors/districts)|text|lgs_policy_2026|oversubscription (a)|within the school's Priority Area 1, up to a maximum of 100 places|confirmed|postcode lists, not a radius|
136521|2026|test_used|all||{SLOUGH}|text|lgs_alloc_2026|p1|11+ Testing Consortium of Herschel Grammar School, Langley Grammar School,|confirmed||
136521|2027|pan|all||180|places|lgs_policy_2027|para 1|The School's planned admission number (PAN) for entry into Year 7 in September 2027 is 180.|confirmed||

# ---------------- Buckinghamshire (qualify 121, then catchment/distance)
|2026|qualifying_score|all||121|Bucks Secondary Transfer Test standardised score|bucks_11plus|page text|Children who achieve a score of at least 121 in the test are considered qualified for a Buckinghamshire grammar school.|confirmed||{BUCKS}

# ---------------- Trafford (Trafford Grammar Schools test; qualify 334, then area / score)
136458|2025|pan|all||202|places|agsb_booklet_2025|p1|for the year commencing 1 September 2025 will be 202 at age 11|confirmed||
136458|2025|qualifying_score|all||334|Trafford test total standardised score|agsb_booklet_2025|section 8|with a total standardised score of 334 and above|confirmed|324-333 for up to 20 Trafford pupil-premium places|
136458|2025|admissions_model|all||qualify_then_catchment|code|agsb_booklet_2025|section 8|school's priority admission area with a total standardised score of 334 and above|confirmed|qualifiers in WA13/WA14/WA15/M33/M23 (Trafford) first; outside area by score|
136458|2025|priority_area|all||WA13/WA14/WA15/M33/M23 within Trafford|text|agsb_booklet_2025|8.2|postal addresses of WA13/WA14/WA15/M33 and M23 postcodes which lie within the Trafford Local Authority|confirmed||
136458|2025|lowest_score_offered|outside_priority_area|national_offer_day|377|Trafford test total standardised score|trafford_outcomes_2025|table row 'Altrincham Grammar School for Boys'|Some Category 5. Score of 377 and above for out of area candidates|confirmed||
136458|2026|lowest_score_offered|outside_priority_area|national_offer_day|373|Trafford test total standardised score|trafford_outcomes_2026|table row 'Altrincham Grammar School for Boys'|Some Category 5. Score of 373 and above for out of area candidates|confirmed||
136458|2026|pan|all||202|places|trafford_outcomes_2026|table row (PAN, total offers)|Altrincham Grammar School for Boys 202 217|confirmed||
137289|2024|pan|all||204|places|aggs_booklet_2024|p1|The proposed admission number for 2024 is 204.|confirmed||
137289|2024|qualifying_score|all||334|Trafford test total standardised score|aggs_booklet_2024|p1|The qualifying score will be achieved by those candidates who score 334 and above in the exam.|confirmed||
137289|2024|admissions_model|all||qualify_then_distance|code|aggs_booklet_2024|criteria 4|priority shall be given to those applicants residing closer to the school|confirmed|catchment qualifiers by distance, then outside catchment|
137289|2025|last_distance_offered|catchment|national_offer_day|5.47|miles|trafford_outcomes_2025|table row 'Altrincham Grammar School for Girls'|Some Category 4 to 5.47 miles|confirmed||
137289|2026|last_distance_offered|catchment|national_offer_day|6.067|miles|trafford_outcomes_2026|table row 'Altrincham Grammar School for Girls'|Some Category 4 to 6.067 miles|confirmed||
136498|2026|pan|all||190|places|sale_2026|page text|the intended admission number for 2026 is 190|confirmed||
136498|2026|qualifying_score|all||334|Trafford test total standardised score|sale_policy_2026|application procedure|All those who attain the qualifying score of 334 or above will be deemed eligible|confirmed||
136498|2026|admissions_model|all||qualify_then_catchment|code|sale_policy_2026|oversubscription|Applicants from outside the priority admission area will be placed in rank order as determined by their scores|confirmed|priority admission area (M33 + Trafford M23/WA14/WA15) before outside applicants|
136498|2025|lowest_score_offered|outside_priority_area|national_offer_day|353|Trafford test total standardised score|trafford_outcomes_2025|table row 'Sale Grammar School'|Some Category 4. Score 353 and above for out of area candidates|confirmed||
136498|2026|lowest_score_offered|outside_priority_area|national_offer_day|373|Trafford test total standardised score|trafford_outcomes_2026|table row 'Sale Grammar School'|Score 373 and above for out of area candidates to 5.907 miles|confirmed||
138464|2026|admissions_model|all||faith_categories|code|loreto_policy_2026|admission categories|Baptised Roman Catholic girls who have sisters|confirmed|Catholic categories first|
138464|2025|pan|all||150|places|trafford_outcomes_2025|table row 'Loreto Grammar School'|Loreto Grammar School 150 160|confirmed||
138464|2025|lowest_score_offered|all||||trafford_outcomes_2025|table row 'Loreto Grammar School'||not_published|outcome given only as 'Some Category 4'|
137289|2024|test_used|all||{TRAFFORD}|text|aggs_booklet_2024|p1|AGGS is part of the Trafford Gra|confirmed||
136458|2024|test_used|all||{TRAFFORD}|text|aggs_booklet_2024|p1|AGGS is part of the Trafford Gra|confirmed|shared Trafford test|
136498|2024|test_used|all||{TRAFFORD}|text|aggs_booklet_2024|p1|AGGS is part of the Trafford Gra|confirmed|shared Trafford test|

# ---------------- Warwickshire (KES Stratford, Stratford Girls'): qualify, then priority circles by score
137302|2026|pan|all||87|places|kes_policy_2026|2.1|Published Admission Number (PAN) in Year 7 will be 87|confirmed||
137302|2026|admissions_model|all||score_rank_priority_area|code|kes_policy_2026|2.2|Those with the highest scores in each category will be given highest priority for a place.|confirmed|up to 70 places inner circle (13 miles), then outer circle (16.885 miles), then outside|
137302|2026|catchment_km|all||13|miles|kes_policy_2026|2.2|The inner priority circle is 13 miles and the outer priority circle is 16.885 miles|confirmed||
137302|2026|qualifying_score|all||239|Warwickshire 11+ standardised score|warks_leaflet_2026|p2 table (PAN, offers, QS, waiting-list minimum)|King Edward VI School 87 87 239 230|confirmed|automatic qualifying score, set each year|
137302|2025|qualifying_score|all||233|Warwickshire 11+ standardised score|warks_leaflet_2025|p2 table (offers, QS, WL minimum)|King Edward VI School 87 233 231|confirmed||
137302|2024|qualifying_score|all||232|Warwickshire 11+ standardised score|warks_leaflet_2024|p2 table|King Edward VI School 87 232 230|confirmed||
137302|2023|qualifying_score|all||232|Warwickshire 11+ standardised score|warks_leaflet_2023|p2 table|King Edward VI School 87 232 224|confirmed||
137302|2026|lowest_score_offered|inside_priority_area|national_offer_day|239|Warwickshire 11+ standardised score|warks_leaflet_2026|p3 Category 3 (inner circle): offers, lowest score|Up to 70 places will be allocated to children who live within the inner 67 239|confirmed|67 offers|
137302|2026|lowest_score_offered|outside_priority_area|national_offer_day|254|Warwickshire 11+ standardised score|warks_leaflet_2026|p3 Category 4 (outer circle)|Children who live within the outer priority circle (including those living 13 254|confirmed|13 offers; 'outside' = outer circle|
137302|2025|lowest_score_offered|inside_priority_area|national_offer_day|235|Warwickshire 11+ standardised score|warks_leaflet_2025|p3 Category 3|Up to 70 places will be allocated to children who live within the inner 70 235|confirmed||
137302|2025|lowest_score_offered|outside_priority_area|national_offer_day|263|Warwickshire 11+ standardised score|warks_leaflet_2025|p3 Category 4|Children who live within the outer priority circle (including those living in 7 263|confirmed||
137302|2024|lowest_score_offered|inside_priority_area|national_offer_day|232|Warwickshire 11+ standardised score|warks_leaflet_2024|p3 Category 3|Category 3 68 232|confirmed||
137302|2024|lowest_score_offered|outside_priority_area|national_offer_day|252|Warwickshire 11+ standardised score|warks_leaflet_2024|p3 Category 4|Category 4 15 252|confirmed||
137302|2023|lowest_score_offered|inside_priority_area|national_offer_day|232|Warwickshire 11+ standardised score|warks_leaflet_2023|p3 Category 3 (offers, lowest)|Up to 70 places for children in the inner priority 67 232|confirmed||
137302|2023|lowest_score_offered|outside_priority_area|national_offer_day|245|Warwickshire 11+ standardised score|warks_leaflet_2023|p3 Category 4|Children living in the outer priority area who 17 245|confirmed||
137302|2026|test_used|all||{WARKS}|text|warks_leaflet_2026|p1|11+ Test and Grammar School Offers|confirmed||
137235|2026|qualifying_score|all||227|Warwickshire 11+ standardised score|warks_leaflet_2026|p2 table|Stratford Girls' Grammar School 120 120 227 224|confirmed||
137235|2023|qualifying_score|all||224|Warwickshire 11+ standardised score|warks_leaflet_2023|p2 table|Stratford Girls' Grammar School 120 224 220|confirmed||
137235|2026|pan|all||120|places|warks_leaflet_2026|p2 table|Stratford Girls' Grammar School 120 120 227 224|confirmed||
137235|2026|lowest_score_offered|inside_priority_area|national_offer_day|232|Warwickshire 11+ standardised score|warks_leaflet_2026|p4 Category 3 (priority circle)|Children who live within the priority circle who achieve the Automatic 110 232|confirmed|110 offers; none outside the circle|
137235|2025|lowest_score_offered|inside_priority_area|national_offer_day|232|Warwickshire 11+ standardised score|warks_leaflet_2025|p4 Category 3|Children who live within the priority circle who achieve the Automatic 114 232|confirmed||
137235|2024|lowest_score_offered|inside_priority_area|national_offer_day|226|Warwickshire 11+ standardised score|warks_leaflet_2024|p4 Category 3|Category 3 116 226|confirmed||
137235|2023|lowest_score_offered|inside_priority_area|national_offer_day|225|Warwickshire 11+ standardised score|warks_leaflet_2023|p4 Category 3|Category 3 116 225|confirmed||
137235|2026|admissions_model|all||score_rank_priority_area|code|warks_leaflet_2026|p4 categories|Children living outside of the priority circle who achieve the Automatic 0 N/A|confirmed|priority circle first, then outside (0 offers outside 2023-2026); circle radius not in a fetched SGGS document|
137235|2026|test_used|all||{WARKS}|text|warks_leaflet_2026|p1|11+ Test and Grammar School Offers|confirmed||

# ---------------- Gloucestershire (Pate's, Sir Thomas Rich's)
136353|2026|pan|all||150|places|pates_policy_2026|p1|for Year 7 entry in 2026, is 150|confirmed||
136353|2026|admissions_model|all||score_rank_priority_area|code|pates_policy_2026|criteria|Non-Priority Places (Local) totals 105 places|confirmed|qualifying group = top 250 ranks; up to 15 priority places; local (Gloucestershire + listed postcodes) until 105, rest UK-wide by test rank|
136353|2026|qualifying_score|rank||250|test rank|pates_policy_2026|qualifying group|our standard 'Qualifying Group' will be the highest ranking 250 students|confirmed|a rank, not a score|
136353|2026|lowest_score_offered|all||||glos_summary_2026|row 'Pate's Grammar School'||not_published|council summary says 'Please check with school'; no figure on the school documents fetched|
136306|2026|pan|all||150|places|str_policy_2026|p1|150 places (also referred to as the Published Admissions Number (PAN))|confirmed|council 2026 allocation shows 155|
136306|2027|pan|all||155|places|str_policy_2027|p1|155 places (also referred to as the Published Admissions Number (PAN))|confirmed||
136306|2026|admissions_model|all||score_rank|code|str_policy_2026|oversubscription (c)|c. Other qualifying boys in test rank order|confirmed|after LAC and pupil premium; no catchment|
136306|2026|last_rank_offered|all|national_offer_day|332|test rank|glos_summary_2026|row 'Sir Thomas Rich's School'|Sir Thomas Rich's School 155 0 Last rank in - 332|confirmed|a test rank position, not a score|

# ---------------- Singletons
137916|2027|pan|all||180|places|bluecoat_policy_2027|p1|It admits 180 students to Year 7|confirmed||
137916|2027|admissions_model|all||score_rank|code|bluecoat_policy_2027|criteria|The remaining places will be available to all other highest scoring applicants who meet the eligible score.|confirmed|up to 27 places first to FSM-eligible highest scorers; no catchment|
137916|2024|testers_stage1|all||1089|candidates|bluecoat_faq_2026|FAQ 'How many candidates sat the entrance test ... entry in September 2024'|A total of 1089 candidates sat the test at The Blue Coat School.|confirmed|question text says 'entry in September 2024' inside the 2026-entry FAQ: entry year uncertain|
136366|2026|pan|all||160|places|colyton_policy_2026|admissions criteria|The Published Admission Number (PAN) is 160|confirmed||
136366|2026|admissions_model|all||score_rank|code|colyton_policy_2026|criteria 3|Rank order based on the total score achieved in the tests of children on the eligible list.|confirmed|no catchment|
137166|2026|pan|all||174|places|kings_lincs_record|directory record|Published admission number 174|confirmed||
137166|2026|admissions_model|all||score_rank_priority_area|code|kings_lincs_record|2026 oversubscription criteria|reside within 30 miles of the academy at the time of application|confirmed|within 30 miles by rank of standardised score, then others by rank|
137166|2026|catchment_km|all||30|miles|kings_lincs_record|2026 oversubscription criteria|reside within 30 miles of the academy at the time of application|confirmed||
137166|2026|lowest_score_offered|all||||kings_policy|school admissions page||not_published|no qualifying or lowest score on the LA record or school page|

# ---------------- Kendrick (own test; postcode priority areas)
136448|2026|testers_stage1|all||704|candidates|kendrick_results_2026|Q5|for entry in September 2026? A 704 candidates.|confirmed||
136448|2025|testers_stage1|all||774|candidates|kendrick_results_2025|Q6|for entry in September 2025? A 774 candidates.|confirmed||
136448|2024|testers_stage1|all||747|candidates|kendrick_results_2024|Q6|for entry in September 2024? A 747 candidates.|confirmed||
136448|2023|testers_stage1|all||775|candidates|kendrick_results_2023|Q5|A 775 candidates sat the test at Kendrick School and a further 307 candidates sat the test at another venue|confirmed|plus 307 who sat elsewhere and had results sent|
136448|2026|qualifying_score|all||99.00|Kendrick total standardised score (Paper 1 + Paper 2)|kendrick_results_2026|Q2|previously in care is 99.00|confirmed||
136448|2026|qualifying_score|pupil_premium||94.00|Kendrick total standardised score|kendrick_results_2026|Q3|previously in care is 94.00|confirmed||
136448|2025|qualifying_score|all||100.00|Kendrick total standardised score|kendrick_results_2025|Q2|previously in care is 100.00|confirmed||
136448|2025|qualifying_score|pupil_premium||95.00|Kendrick total standardised score|kendrick_results_2025|Q3|previously in care is 95.00|confirmed||
136448|2024|qualifying_score|all||99.00|Kendrick total standardised score|kendrick_results_2024|Q2|previously in care is 99.00|confirmed||
136448|2023|qualifying_score|all||101.00|Kendrick total standardised score|kendrick_results_2023|Q2|designated area is 101.00|confirmed||
136448|2026|candidates_qualified|all_others||347|candidates|kendrick_results_2026|Q6|or above from Categories 3-5? A 347 candidates|confirmed||
136448|2025|candidates_qualified|all_others||325|candidates|kendrick_results_2025|Q7|or above from Categories 3-5? A 325 candidates|confirmed||
136448|2024|candidates_qualified|all_others||338|candidates|kendrick_results_2024|Q7|or above from Categories 3-5? A 338 candidates|confirmed||
136448|2023|candidates_qualified|all_others||364|candidates|kendrick_results_2023|Q6|or above from Categories 3-6? A 364 candidates|confirmed||
136448|2026|pan|all||128|places|kendrick_results_2026|Q3|more applicants than the 128 places available|confirmed||
136448|2025|pan|all||128|places|kendrick_results_2025|Q3|more applicants than the 128 places available|confirmed||
136448|2024|pan|all||128|places|kendrick_results_2024|Q3|more applicants than the 128 places available|confirmed||
136448|2023|pan|all||128|places|kendrick_results_2023|Q3|more applicants than the 128 places available|confirmed||
136448|2025|lowest_score_offered|all||||kendrick_results_2025|Q23||not_published|'We do not disclose the lowest score.'|
136448|2026|admissions_model|all||score_rank_priority_area|code|kendrick_policy_2026|oversubscription 3-4|until up to 75% (96) of places have been offered|confirmed|Priority Areas 1-2 (postcode sectors) by rank; no out-of-area offers since 2013|
136448|2026|priority_area|all||designated area: Priority Areas 1 and 2 (postcode sectors)|text|kendrick_policy_2026|Appendix 1|The designated area is made up of Priority Area 1 and Priority Area 2 and each area is determined by the postcode|confirmed|postcode lists, not a radius|
136448|2026|test_used|all||Kendrick own test (Paper 1 + Paper 2)|text|kendrick_results_2026|Q2|This is a total standardised score of Paper 1 and P|confirmed||

# ---------------- Reading School (own test; postcode catchment)
136449|2026|testers_stage1|all||991|candidates|rs_results_faq_2026|FAQ|A total of 991 candidates sat the test for Reading School.|confirmed||
136449|2026|candidates_qualified|all||471|candidates|rs_results_faq_2026|FAQ|471 candidates achieved the eligible score.|confirmed|annual data release gives 470 eligible for 2026|
136449|2026|pan|all||150|places|rs_policy_2026_day|PAN|The School admits 150 boys into Year 7 each year|confirmed|138 day + 12 boarding|
136449|2026|registrations|all||987|registrants|rs_annual_release_2026|'Total Registrants' row, 2026 column (2022-2027)|Total Registrants 913 966 1126 1077 987 1298|confirmed|2027 = 1298 registrants (test Sept 2026)|
136449|2025|registrations|all||1077|registrants|rs_annual_release_2026|same row, 2025|Total Registrants 913 966 1126 1077 987 1298|confirmed||
136449|2024|registrations|all||1126|registrants|rs_annual_release_2026|same row, 2024|Total Registrants 913 966 1126 1077 987 1298|confirmed||
136449|2023|registrations|all||966|registrants|rs_annual_release_2026|same row, 2023|Total Registrants 913 966 1126 1077 987 1298|confirmed||
136449|2025|candidates_qualified|all||354|candidates|rs_annual_release_2026|'Total Eligible' row, 2025|Total Eligible 350 336 395 354 470|confirmed||
136449|2024|candidates_qualified|all||395|candidates|rs_annual_release_2026|'Total Eligible' row, 2024|Total Eligible 350 336 395 354 470|confirmed||
136449|2023|candidates_qualified|all||336|candidates|rs_annual_release_2026|'Total Eligible' row, 2023|Total Eligible 350 336 395 354 470|confirmed||
136449|2026|admissions_model|all||score_rank_priority_area|code|rs_policy_2026_day|criteria|Places will be offered to students who are ranked high enough according to the entrance test scores and who reside within the catchment area|confirmed|catchment = postcode list; outside-catchment boys rarely offered day places|
136449|2026|lowest_score_offered|all||||rs_faq|Year 7 entry page||not_published|eligible-score value and last offer not published|
136449|2025|distribution_file|all||file|file|rs_scores_2025|one row per candidate: English, Maths, creative writing, catchment flag||confirmed|text extraction partly garbled|
136449|2026|distribution_file|all||file|file|rs_scores_summer_2026|FOI release Summer 2026: per-candidate standardised scores||confirmed|year inferred (not stated)|
136449|2026|test_used|all||Reading School own test|text|rs_results_faq_2026|FAQ|Students have been ranked based on their weighted total scores of all four subjects|confirmed||

# ---------------- Tiffin Girls' (own test; Inner + Designated Area)
136615|2026|testers_stage1|all||1468|candidates|tgs_poa_2024_26|table, col 2026|Candidates tested at stage one 1468 1498 1485|confirmed||
136615|2025|testers_stage1|all||1498|candidates|tgs_poa_2024_26|table, col 2025|Candidates tested at stage one 1468 1498 1485|confirmed||
136615|2024|testers_stage1|all||1485|candidates|tgs_poa_2024_26|table, col 2024|Candidates tested at stage one 1468 1498 1485|confirmed||
136615|2026|testers_stage2|all||474|candidates|tgs_poa_2024_26|table, col 2026|Candidates tested at stage two 474 475 465|confirmed||
136615|2025|testers_stage2|all||475|candidates|tgs_poa_2024_26|table, col 2025|Candidates tested at stage two 474 475 465|confirmed||
136615|2024|testers_stage2|all||465|candidates|tgs_poa_2024_26|table, col 2024|Candidates tested at stage two 474 475 465|confirmed||
136615|2026|testers_stage1|inside_priority_area||1322|candidates|tgs_poa_2024_26|'Designated Area stage one', col 2026|Designated Area stage one 1322 1364 1294|confirmed|includes Inner Area|
136615|2026|pan|all||180|places|tgs_poa_2024_26|'Number of places in Year 7 (PAN)', col 2026|(published admission number) 180 180 180|confirmed||
136615|2025|pan|all||180|places|tgs_poa_2024_26|col 2025|(published admission number) 180 180 180|confirmed||
136615|2024|pan|all||180|places|tgs_poa_2024_26|col 2024|(published admission number) 180 180 180|confirmed||
136615|2026|admissions_model|all||score_rank_priority_area|code|tgs_policy_2027|5.1|in rank order of the combined mark within the appropriate category|confirmed|Inner Area and Designated Area (44 postal districts) first; all 2024-26 places went to these areas|
136615|2026|priority_area|all||Inner Area + Designated Area (44 postal districts)|text|tgs_y7|page text|The Designated Area is made up of 44 postal districts|confirmed|postcode districts, not a radius|
136615|2026|lowest_score_offered|all||||tgs_poa_2024_26|whole table||not_published|patterns-of-admission table has no lowest score|
136615|2026|test_used|all||Tiffin Girls' own two-stage test|text|tgs_poa_2024_26|table|Candidates tested at stage one|confirmed||

# ---------------- QE Barnet (FOI pending): own test, no catchment
136290|2027|qualifying_score|all||225|QE combined standardised score|qe_faq|FAQ|Those candidates achieving a combined score of 225 or higher|confirmed||
136290|2027|pan|all||180|places|qe_faq|FAQ|The School's Published Admission Number (PAN) is 180.|confirmed||
136290|2027|admissions_model|all||score_rank|code|qe_faq|FAQ 23|Queen Elizabeth's School has no catchment.|confirmed|distance only as tie-break|
136290|2026|waiting_list_position_reached|all||24|position|qe_admissions|page text|The waiting list for entry into Year 7 in September 2026 has reached position 24.|confirmed||
136290|2025|testers_stage1|all||3433|candidates|qe_guide_2027_p14|guide for Sept 2027 entry p.14, 'Will my son receive a place?', row 2025, col 'Number taking entrance tests' (text layer order per row: lowest score, year, number taking tests, applicants, number reaching standard)|235 2025 3433 809 764|confirmed||
136290|2025|lowest_score_offered|all|final_excluding_appeals|235|QE combined standardised score|qe_guide_2027_p14|guide for Sept 2027 entry p.14, 'Will my son receive a place?', row 2025, col 'Lowest score gaining admission (excluding appeals)'|235 2025 3433 809 764|confirmed|after waiting-list offers; the national offer day cut-off is higher (FOI reply)|
136290|2024|testers_stage1|all||3294|candidates|qe_guide_2027_p14|guide for Sept 2027 entry p.14, 'Will my son receive a place?', row 2024, col 'Number taking entrance tests' (text layer order per row: lowest score, year, number taking tests, applicants, number reaching standard)|235 2024 3294 839 742|confirmed||
136290|2024|lowest_score_offered|all|final_excluding_appeals|235|QE combined standardised score|qe_guide_2027_p14|guide for Sept 2027 entry p.14, 'Will my son receive a place?', row 2024, col 'Lowest score gaining admission (excluding appeals)'|235 2024 3294 839 742|confirmed|after waiting-list offers; the national offer day cut-off is higher (FOI reply)|
136290|2023|testers_stage1|all||3106|candidates|qe_guide_2027_p14|guide for Sept 2027 entry p.14, 'Will my son receive a place?', row 2023, col 'Number taking entrance tests' (text layer order per row: lowest score, year, number taking tests, applicants, number reaching standard)|232 2023 3106 990 1111|confirmed||
136290|2023|lowest_score_offered|all|final_excluding_appeals|232|QE combined standardised score|qe_guide_2027_p14|guide for Sept 2027 entry p.14, 'Will my son receive a place?', row 2023, col 'Lowest score gaining admission (excluding appeals)'|232 2023 3106 990 1111|confirmed|after waiting-list offers; the national offer day cut-off is higher (FOI reply)|
136290|2025|lowest_score_offered|all|national_offer_day|237|QE combined standardised score|qe_foi_reply|FOI reply 2026-10-12, 'The lowest standardised score to which an offer was made on national offer day'|2025 entry 237|confirmed||
136290|2024|lowest_score_offered|all|national_offer_day|238|QE combined standardised score|qe_foi_reply|FOI reply 2026-10-12, 'The lowest standardised score to which an offer was made on national offer day'|2024 entry 238|confirmed||
136290|2023|lowest_score_offered|all|national_offer_day|234|QE combined standardised score|qe_foi_reply|FOI reply 2026-10-12, 'The lowest standardised score to which an offer was made on national offer day'|2023 entry 234|confirmed||
136290|2026|testers_stage1|all||||qe_foi_reply|FOI reply 2026-10-12|Information on that year will be made available to the public in the Spring Term|not_published|withheld while the 2026 admission process is live; to be published in the Spring Term|
136290|2026|lowest_score_offered|all||||qe_foi_reply|FOI reply 2026-10-12|Information on that year will be made available to the public in the Spring Term|not_published|withheld while the 2026 admission process is live; to be published in the Spring Term|

# ---------------- Henrietta Barnett (FOI answered 2026-10-19)
138051|2027|pan|all||120|places|hbs_admissions|page text|The Published Admission Number (PAN) for September 2027 entry is 120.|confirmed||
138051|2027|testers_stage2|all||300|candidates (cap)|hbs_admissions|page text|The top 300 candidates will be invited to sit Round Two|confirmed|cap, not a count|
138051|2026|waiting_list_position_reached|all||47|position|hbs_admissions|page text (as of 4 September)|As of 4th September we have offered up to number 47 on the waiting list.|confirmed||
138051|2025|applications|all||3121|applications|hbs_secondary_lt|quote attributed to the school's appeals disclosure|In 2025, 3121 applications were received for 104 places in Year 7.|secondary_source|'applications' as quoted; whether test registrations is unclear|
138051|2027|admissions_model|all||||hbs_policy_2027|admissions policy 2027-28 (13 pages, image-only)||not_published|published, image-only PDFs (policy 2027-28, admission FAQs 2026); no text layer, not machine-readable|
138051|2026|testers_stage1|all||2637|candidates (Round 1 attendees)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Attendees R1'|Attendees R1 2637 2686 2649 2545|confirmed||
138051|2025|testers_stage1|all||2686|candidates (Round 1 attendees)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Attendees R1'|Attendees R1 2637 2686 2649 2545|confirmed||
138051|2024|testers_stage1|all||2649|candidates (Round 1 attendees)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Attendees R1'|Attendees R1 2637 2686 2649 2545|confirmed||
138051|2023|testers_stage1|all||2545|candidates (Round 1 attendees)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Attendees R1'|Attendees R1 2637 2686 2649 2545|confirmed||
138051|2026|testers_stage2|all||300|candidates (Round 2 attendees)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Attendees R2'|Attendees R2 300 300 300 300|confirmed|the top 300 Round 1 candidates are invited to Round Two|
138051|2025|testers_stage2|all||300|candidates (Round 2 attendees)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Attendees R2'|Attendees R2 300 300 300 300|confirmed|the top 300 Round 1 candidates are invited to Round Two|
138051|2024|testers_stage2|all||300|candidates (Round 2 attendees)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Attendees R2'|Attendees R2 300 300 300 300|confirmed|the top 300 Round 1 candidates are invited to Round Two|
138051|2023|testers_stage2|all||300|candidates (Round 2 attendees)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Attendees R2'|Attendees R2 300 300 300 300|confirmed|the top 300 Round 1 candidates are invited to Round Two|
138051|2026|qualifying_score|round1_cutoff||345.05|HBS Round 1 score|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Cut off Round 1'|Cut off Round 1 345.05 347.65 348.49 348.04|confirmed|the school's label; read as the Round 1 score of the 300th candidate (the cut-off for Round Two), not explained in the reply|
138051|2025|qualifying_score|round1_cutoff||347.65|HBS Round 1 score|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Cut off Round 1'|Cut off Round 1 345.05 347.65 348.49 348.04|confirmed|the school's label; read as the Round 1 score of the 300th candidate (the cut-off for Round Two), not explained in the reply|
138051|2024|qualifying_score|round1_cutoff||348.49|HBS Round 1 score|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Cut off Round 1'|Cut off Round 1 345.05 347.65 348.49 348.04|confirmed|the school's label; read as the Round 1 score of the 300th candidate (the cut-off for Round Two), not explained in the reply|
138051|2023|qualifying_score|round1_cutoff||348.04|HBS Round 1 score|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Cut off Round 1'|Cut off Round 1 345.05 347.65 348.49 348.04|confirmed|the school's label; read as the Round 1 score of the 300th candidate (the cut-off for Round Two), not explained in the reply|
138051|2026|lowest_score_offered|all||563.73|HBS combined score (Rounds 1 and 2)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Lowest combined score 1/3'|Lowest combined score 1/3 563.73 578.25 569.14 574.98|confirmed|offer round not stated: the school's label is 'Lowest combined score 1/3' (the request asked for national offer day); how the two rounds are combined is not explained|
138051|2025|lowest_score_offered|all||578.25|HBS combined score (Rounds 1 and 2)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Lowest combined score 1/3'|Lowest combined score 1/3 563.73 578.25 569.14 574.98|confirmed|offer round not stated: the school's label is 'Lowest combined score 1/3' (the request asked for national offer day); how the two rounds are combined is not explained|
138051|2024|lowest_score_offered|all||569.14|HBS combined score (Rounds 1 and 2)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Lowest combined score 1/3'|Lowest combined score 1/3 563.73 578.25 569.14 574.98|confirmed|offer round not stated: the school's label is 'Lowest combined score 1/3' (the request asked for national offer day); how the two rounds are combined is not explained|
138051|2023|lowest_score_offered|all||574.98|HBS combined score (Rounds 1 and 2)|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Lowest combined score 1/3'|Lowest combined score 1/3 563.73 578.25 569.14 574.98|confirmed|offer round not stated: the school's label is 'Lowest combined score 1/3' (the request asked for national offer day); how the two rounds are combined is not explained|
138051|2026|offers|all||120|offers|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Offers'|Offers 120 104 104 104|confirmed|as the school reports them; whether waiting-list offers are included is not stated|
138051|2025|offers|all||104|offers|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Offers'|Offers 120 104 104 104|confirmed|as the school reports them; whether waiting-list offers are included is not stated|
138051|2024|offers|all||104|offers|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Offers'|Offers 120 104 104 104|confirmed|as the school reports them; whether waiting-list offers are included is not stated|
138051|2023|offers|all||104|offers|hbs_foi_reply|FOI reply 2026-10-19, attached sheet row 'Offers'|Offers 120 104 104 104|confirmed|as the school reports them; whether waiting-list offers are included is not stated|

# ---------------- St Michael's, Latymer, St Olave's, Newstead Wood
101361|2026|admissions_model|all||faith_categories_score_rank|code|stm_policy_2026|oversubscription|a. Baptised Catholic girls in rank order (in the entrance test) beginning with the highest.|confirmed|faith categories, test rank within each|
101361|2026|lowest_score_offered|all||||stm_policy_2026|policy||not_published|no statistics found|
102055|2025|pan|all||192|places|lat_procedures_2025|normal admissions round|The Published Admission Number (PAN) is 192.|confirmed||
102055|2025|admissions_model|all||score_rank_priority_area|code|lat_procedures_2025|Inner Area|The school will only admit students from the published Inner Area|confirmed|ranked by age-standardised score; top 700 deemed selective; 20 music places|
102055|2025|priority_area|all||Inner Area (postcode districts E2-N22)|text|lat_procedures_2025|Inner Area|The school will only admit students from the published Inner Area|confirmed|postcode list, not a radius|
102055|2026|lowest_score_offered|all||||lat_y7_2026|Year 7 2026 page||not_published|only the rank-700 eligibility rule is published|
101676|2026|pan|all||124|places|sto_faq|FAQ|The PAN (published admission number) is 124 plus up to 4 places|confirmed|+ up to 4 Wakeham choristers|
101676|2026|admissions_model|all||score_rank|code|sto_faq|FAQ|Does St. Olave's have a catchment area? No|confirmed|top 450 at stage 1 go to stage 2|
101676|2026|test_applicants|all||1600|applicants (approx., average of 2025 and 2026)|sto_faq|FAQ|an average of around 1600 applicants for the 2025 and 2026 application seasons|confirmed|approximate; registrations for the test, not a count of testers|
101676|2026|testers_stage2|all||450|candidates (cap)|sto_faq|FAQ|the top 450 performing boys will be invited to proceed to our Stage 2 test|confirmed||
136551|2026|pan|all||168|places|nw_policy_2026|1.3|The School's Planned Admission Number (PAN) into Year 7 for September 2026 is 168.|confirmed||
136551|2026|admissions_model|all||score_rank_priority_area|code|nw_policy_2026|3.3|The remaining places will be allocated strictly from the rank order list of the total score|confirmed|9-mile radius first, then outside; no places beyond 9 miles historically|
136551|2026|catchment_km|all||9|miles|nw_policy_2026|3.3.1|within a 9-mile radius of the school|confirmed||
136551|2026|testers_stage1|all||||nw_faq_2026|FAQ||not_published|no candidate counts or required-standard value published|

# ---------------- Sutton SET schools (FOI pending for Wilson's, Sutton Grammar and Wallington County)
|2026|testers_stage1|all||||sutton_set|council page||not_published|council page gives test dates only; boys' candidates (3,282, for 2025) are in the transfer booklet, not used here; girls in the rows below|{SET}
136621|2026|pan|all||186|places|wilsons_criteria|page text|a selective boys' school with an admission number for Year 7 of 186|confirmed||
136621|2026|admissions_model|all||score_rank|code|wilsons_faq|FAQ|our admissions criteria are not based on catchment areas, post codes or distance criteria|confirmed|14 FSM, 9 sport, 9 music places, rest by rank of standardised score|
136621|2026|test_used|all||{SET}|text|wilsons_faq|FAQ|What is the pass mark for the Selective Eligibility Test?|confirmed|plus own second stage|
136787|2026|pan|all||150|places|sgs_policy_2026|admission number|Included in the School's admission number of 150|confirmed||
136787|2026|admissions_model|all||score_rank_priority_area|code|sgs_policy_2026|criterion 4|75 places by rank order of the combined scores in the SET and the School's second stage test where the home addres|confirmed|75 for listed Sutton-area postcodes, rest any postcode, all by score|
136787|2026|priority_area|all||postcodes SM1-7, KT4, KT17, CR0 4, CR4|text|sgs_policy_2026|criterion 3-4|is one of the following postcodes: SM1-7, KT4, KT17, CR0 4--, CR4|confirmed|postcode list|
136787|2026|test_used|all||{SET}|text|sgs_policy_2026|criteria|combined scores in the SET and the School's second stage test|confirmed||
136795|2026|pan|all||210|places|nonsuch_policy_2026|3.3|The Published Admission Number (PAN) for entry to Year 7 is 210.|confirmed||
136795|2026|admissions_model|all||score_rank_mixed_catchment|code|nonsuch_policy_2026|5.2.2-5.2.4|85 places on the basis of the score in the Entrance Test in order of highest score, irrespective of home add|confirmed|85 open by score; up to 35 FSM/PP; up to 125 by score inside a 5.25 km circle|
136795|2026|catchment_km|all||5.25|km|nonsuch_policy_2026|5.2.4|is 5.25 km or less from the front door of Nonsuch|confirmed||
136795|2026|test_used|all||{SET}|text|wilsons_faq|FAQ|What is the pass mark for the Selective Eligibility Test?|confirmed|plus NWSSEE second stage|
136798|2027|admissions_model|all||score_rank|code|wcgs_secondary_lt|blog quoting 2027 determined arrangements|The other 110, nearly three-quarters of the intake, are allocated purely by test score|secondary_source|up to 15 places for Sutton postcodes ranked fifth; primary policy not located|
136798|2027|pan|all||150|places|wcgs_secondary_lt|blog|has no designated area or catchment for its 150 Year 7 places|secondary_source||
136798|2027|test_used|all||{SET}|text|wcgs_secondary_lt|blog|Selective Eligibility Test (SET)|secondary_source||
136789|2026|pan|all||210|places|whsg_policy_2026|3.3|The Published Admission Number (PAN) for entry to Year 7 is 210.|confirmed||
136789|2026|admissions_model|all||score_rank_mixed_catchment|code|whsg_policy_2026|5.2.2-5.2.4|100 places on the basis of the score in the Entrance Test in order of highest score, irrespective of home address.|confirmed|100 open by score; up to 35 FSM/PP; up to 110 by score inside a 6.7 km circle; routes also in the FOI reply of 2026-11-05|
136789|2026|catchment_km|all||6.7|km|whsg_policy_2026|5.2.4|is within a 6.7km radius of the main entrance to the School building|confirmed||
136789|2026|test_used|all||{SET}|text|whsg_policy_2026|4.1|The first stage is the Selective Eligibility Test|confirmed|plus NWSSEE second stage|
# ---------------- Nonsuch and Wallington Girls (FOI answered 2026-11-05 by the Girls' Learning Trust)
# Shared test, so the counts are consortium rows: girls who sat for either school, never per school.
|2023|testers_stage1|girls||2557|candidates|glt_foi_reply|FOI reply 2026-11-05, first table, 'No. of candidates who sat the SET'|2023 2557 1071 210|confirmed|girls only, one pool for both schools (Sutton's transfer booklet gives 2025's figures under each school)|{SET}
|2023|testers_stage2|girls||1071|candidates|glt_foi_reply|FOI reply 2026-11-05, first table, 'No. of candidates who sat the NWSSEE'|2023 2557 1071 210|confirmed|girls only, one pool for both schools|{SET}
|2024|testers_stage1|girls||2704|candidates|glt_foi_reply|FOI reply 2026-11-05, first table, 'No. of candidates who sat the SET'|2024 2704 1149 210|confirmed|girls only, one pool for both schools (Sutton's transfer booklet gives 2025's figures under each school)|{SET}
|2024|testers_stage2|girls||1149|candidates|glt_foi_reply|FOI reply 2026-11-05, first table, 'No. of candidates who sat the NWSSEE'|2024 2704 1149 210|confirmed|girls only, one pool for both schools|{SET}
|2025|testers_stage1|girls||2670|candidates|glt_foi_reply|FOI reply 2026-11-05, first table, 'No. of candidates who sat the SET'|2025 2670 1168 210|confirmed|girls only, one pool for both schools (Sutton's transfer booklet gives 2025's figures under each school)|{SET}
|2025|testers_stage2|girls||1168|candidates|glt_foi_reply|FOI reply 2026-11-05, first table, 'No. of candidates who sat the NWSSEE'|2025 2670 1168 210|confirmed|girls only, one pool for both schools|{SET}
|2026|testers_stage1|girls||2565|candidates|glt_foi_reply|FOI reply 2026-11-05, first table, 'No. of candidates who sat the SET'|2026 2565 1164 210|confirmed|girls only, one pool for both schools (Sutton's transfer booklet gives 2025's figures under each school)|{SET}
|2026|testers_stage2|girls||1164|candidates|glt_foi_reply|FOI reply 2026-11-05, first table, 'No. of candidates who sat the NWSSEE'|2026 2565 1164 210|confirmed|girls only, one pool for both schools|{SET}
136795|2023|lowest_score_offered|pupil_premium|national_offer_day|228|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'PP criterion'|2023 228 322 288 281|confirmed||
136795|2023|lowest_score_offered|open_by_score|national_offer_day|322|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'top 85'|2023 228 322 288 281|confirmed||
136795|2023|lowest_score_offered|catchment|national_offer_day|288|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'catchment criterion'|2023 228 322 288 281|confirmed||
136795|2023|lowest_score_offered|ring_fenced|national_offer_day|281|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'ring fenced criterion'|2023 228 322 288 281|confirmed|cell blacked out for 2024-2026; no such route in the 2026 policy|
136795|2024|lowest_score_offered|pupil_premium|national_offer_day|228|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'PP criterion'|2024 228 321 290|confirmed||
136795|2024|lowest_score_offered|open_by_score|national_offer_day|321|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'top 85'|2024 228 321 290|confirmed||
136795|2024|lowest_score_offered|catchment|national_offer_day|290|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'catchment criterion'|2024 228 321 290|confirmed||
136795|2025|lowest_score_offered|pupil_premium|national_offer_day|221|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'PP criterion'|2025 221 323 300|confirmed||
136795|2025|lowest_score_offered|open_by_score|national_offer_day|323|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'top 85'|2025 221 323 300|confirmed||
136795|2025|lowest_score_offered|catchment|national_offer_day|300|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'catchment criterion'|2025 221 323 300|confirmed||
136795|2026|lowest_score_offered|pupil_premium|national_offer_day|212|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'PP criterion'|2026 212 318 294|confirmed||
136795|2026|lowest_score_offered|open_by_score|national_offer_day|318|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'top 85'|2026 212 318 294|confirmed||
136795|2026|lowest_score_offered|catchment|national_offer_day|294|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Nonsuch table, 'catchment criterion'|2026 212 318 294|confirmed||
136789|2023|lowest_score_offered|pupil_premium|national_offer_day|229|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'PP criterion'|2023 229 309 278|confirmed||
136789|2023|lowest_score_offered|open_by_score|national_offer_day|309|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'top 100'|2023 229 309 278|confirmed||
136789|2023|lowest_score_offered|catchment|national_offer_day|278|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'catchment criterion'|2023 229 309 278|confirmed||
136789|2024|lowest_score_offered|pupil_premium|national_offer_day|228|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'PP criterion'|2024 228 311 283|confirmed||
136789|2024|lowest_score_offered|open_by_score|national_offer_day|311|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'top 100'|2024 228 311 283|confirmed||
136789|2024|lowest_score_offered|catchment|national_offer_day|283|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'catchment criterion'|2024 228 311 283|confirmed||
136789|2025|lowest_score_offered|pupil_premium|national_offer_day|230|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'PP criterion'|2025 230 311 292|confirmed||
136789|2025|lowest_score_offered|open_by_score|national_offer_day|311|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'top 100'|2025 230 311 292|confirmed||
136789|2025|lowest_score_offered|catchment|national_offer_day|292|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'catchment criterion'|2025 230 311 292|confirmed||
136789|2026|lowest_score_offered|pupil_premium|national_offer_day|230|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'PP criterion'|2026 230 315 292|confirmed||
136789|2026|lowest_score_offered|open_by_score|national_offer_day|315|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'top 100'|2026 230 315 292|confirmed||
136789|2026|lowest_score_offered|catchment|national_offer_day|292|Entrance Test total (NWSSEE + half the SET)|glt_foi_reply|FOI reply 2026-11-05, Wallington table, 'catchment criterion'|2026 230 315 292|confirmed||
# ---------------- Barnet LA allocation table (only LA source for QE, HBS, St Michael's): 403 to scripts
136290|2024|lowest_score_offered|all||||barnet_alloc_2024|Barnet allocation table 2024||blocked|HTTP 403 to scripts|
138051|2024|lowest_score_offered|all||||barnet_alloc_2024|Barnet allocation table 2024||blocked|HTTP 403 to scripts|
101361|2024|lowest_score_offered|all||||barnet_alloc_2024|Barnet allocation table 2024||blocked|HTTP 403 to scripts|
# ---------------- FOI pending (requests/SENT.md): testers, offers, lowest score per entry year
136621|2023|testers_stage1|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2023|offers|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2023|lowest_score_offered|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2024|testers_stage1|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2024|offers|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2024|lowest_score_offered|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2025|testers_stage1|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2025|offers|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2025|lowest_score_offered|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2026|testers_stage1|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2026|offers|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136621|2026|lowest_score_offered|all||||mailto:office@wilsonsschool.sutton.sch.uk|FOI sent 2026-10-10 (requests/SENT.md #4)||pending_foi||
136787|2023|testers_stage1|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2023|offers|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2023|lowest_score_offered|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2024|testers_stage1|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2024|offers|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2024|lowest_score_offered|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2025|testers_stage1|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2025|offers|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2025|lowest_score_offered|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2026|testers_stage1|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2026|offers|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136787|2026|lowest_score_offered|all||||mailto:office@suttongrammar.school|FOI sent 2026-10-10 (requests/SENT.md #5)||pending_foi||
136798|2023|testers_stage1|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2023|offers|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2023|lowest_score_offered|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2024|testers_stage1|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2024|offers|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2024|lowest_score_offered|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2025|testers_stage1|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2025|offers|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2025|lowest_score_offered|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2026|testers_stage1|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2026|offers|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136798|2026|lowest_score_offered|all||||mailto:enquiries@wcgschool.co.uk|FOI sent 2026-10-10 (requests/SENT.md #6)||pending_foi||
136789|2023|offers|all||||glt_foi_reply|FOI reply 2026-11-05, first table|Intake per school|not_published|reply gives intake per school (210), not offers; see dfe_offers_total|
136789|2024|offers|all||||glt_foi_reply|FOI reply 2026-11-05, first table|Intake per school|not_published|reply gives intake per school (210), not offers; see dfe_offers_total|
136789|2025|offers|all||||glt_foi_reply|FOI reply 2026-11-05, first table|Intake per school|not_published|reply gives intake per school (210), not offers; see dfe_offers_total|
136789|2026|offers|all||||glt_foi_reply|FOI reply 2026-11-05, first table|Intake per school|not_published|reply gives intake per school (210), not offers; see dfe_offers_total|
136795|2023|offers|all||||glt_foi_reply|FOI reply 2026-11-05, first table|Intake per school|not_published|reply gives intake per school (210), not offers; see dfe_offers_total|
136795|2024|offers|all||||glt_foi_reply|FOI reply 2026-11-05, first table|Intake per school|not_published|reply gives intake per school (210), not offers; see dfe_offers_total|
136795|2025|offers|all||||glt_foi_reply|FOI reply 2026-11-05, first table|Intake per school|not_published|reply gives intake per school (210), not offers; see dfe_offers_total|
136795|2026|offers|all||||glt_foi_reply|FOI reply 2026-11-05, first table|Intake per school|not_published|reply gives intake per school (210), not offers; see dfe_offers_total|
136290|2023|offers|all||224|offers|qe_foi_reply|FOI reply 2026-10-12, 'Offers made will be 192 plus the waiting list position for that year'|2023 entry 224|confirmed|whole admission round, waiting-list offers included|
136290|2024|offers|all||229|offers|qe_foi_reply|FOI reply 2026-10-12, 'Offers made will be 192 plus the waiting list position for that year'|2024 entry 229|confirmed|whole admission round, waiting-list offers included|
136290|2025|offers|all||225|offers|qe_foi_reply|FOI reply 2026-10-12, 'Offers made will be 192 plus the waiting list position for that year'|2025 entry 225|confirmed|whole admission round, waiting-list offers included|
136290|2026|offers|all||||qe_foi_reply|FOI reply 2026-10-12|Information on that year will be made available to the public in the Spring Term|not_published|withheld while the 2026 admission process is live; to be published in the Spring Term|
# ---------------- 2026-11-07 additions: London (Wilson's, Sutton, WCGS, St Olave's, Tiffin, Latymer, St Michael's); found and snippet-checked by discovery agents
# ---------------- Sutton SET (boys): consortium counts, shared by Wilson's, Sutton Grammar and Wallington County
|2025|testers_stage1|boys||3282|candidates|n7_sutton_tss_2026|p.44 Wilson's School entry (same line on p.36 Sutton Grammar)|Number of male candidates at Selective Eligibility Test for September 2025: 3282|confirmed|boys only, one SET pool for the three boys' schools; the Sept 2026 booklet quotes the previous entry year|{SET}
|2024|testers_stage1|boys||3107|candidates|n7_sutton_tss_2025_wb|p.44 Wilson's School entry (same line on p.36 Sutton Grammar)|Number of male candidates at Selective Eligibility Test for September 2024: 3107|confirmed|boys only; WCGS FOI of 24 Apr 2024 (n7_wcgs_foi_stages_wb) also gives 3107|{SET}
|2023|testers_stage1|boys||3098|candidates|n7_sutton_tss_2024_wb|p.44 Wilson's School entry (same line on p.36 Sutton Grammar)|Number of male candidates at Selective Eligibility Test for September 2023: 3098|confirmed|boys only; conflict: WCGS FOI of 24 Apr 2024 says 3113 male students sat Stage 1 for 2023 entry|{SET}
|2025|testers_stage1|all||5925|candidates|n7_wilsons_foi_2125_wb|Wilson's FOI reply 31 Mar 2025, 'total number of candidates who sat stage 1'|2025 - 5925 (boys and girls)|confirmed|boys and girls, all SET schools; conflict: Sutton Grammar FOI of 4 Sep 2025 (n7_sgs_foi_set_wb) says 6670 appeared for Stage 1 SET in 2025e|{SET}
|2024|testers_stage1|all||5811|candidates|n7_wilsons_foi_2125_wb|Wilson's FOI reply 31 Mar 2025, 'total number of candidates who sat stage 1'|2024 - 5811 (boys and girls)|confirmed|boys and girls, all SET schools; conflict: Sutton Grammar FOI of 4 Sep 2025 says 6687 for 2024e|{SET}
|2023|testers_stage1|all||5607|candidates|n7_wilsons_foi_2125_wb|Wilson's FOI reply 31 Mar 2025, 'total number of candidates who sat stage 1'|2023 - 5607 (boys and girls)|confirmed|boys and girls, all SET schools; same figures in Wilson's FOI of 19 Mar 2025 (n7_wilsons_foi_places_wb)|{SET}
|2025|candidates_qualified|boys||1242|candidates|n7_wilsons_foi_2125_wb|Wilson's FOI reply 31 Mar 2025, boys invited to Stage 2|2025 - 1242 boys were invited to stage 2 testing|confirmed|boys who passed the SET and were invited to the shared second stage; booklet prints 1242 (Wilson's) and 1272 (Sutton Grammar) second-stage candidates; Sutton Grammar FOI says 1252 boys appeared|{SET}
|2024|candidates_qualified|boys||1249|candidates|n7_wilsons_foi_2125_wb|Wilson's FOI reply 31 Mar 2025, boys invited to Stage 2|2024 - 1249 boys were invited to stage 2 testing|confirmed|WCGS FOI also 1249 invited; booklet prints 1249 (Wilson's) and 1272 (Sutton Grammar); Sutton Grammar FOI says 1270 boys appeared|{SET}
|2023|candidates_qualified|boys||1177|candidates|n7_wilsons_foi_2125_wb|Wilson's FOI reply 31 Mar 2025, boys invited to Stage 2|2023 - 1177 boys were invited to stage 2 testing|confirmed|conflict: WCGS FOI says 1223 invited for 2023 entry; Sutton booklet prints 1207 second-stage candidates for both Wilson's and Sutton Grammar|{SET}
|2025|candidates_qualified|all||2372|candidates|n7_sgs_foi_set_wb|Sutton Grammar FOI reply 4 Sep 2025, Q2, second column (2025e)|how many children cleared for stage 1 set? 2389 2372|confirmed|children (both sexes) who cleared the SET, as Sutton Grammar reports it|{SET}
|2024|candidates_qualified|all||2389|candidates|n7_sgs_foi_set_wb|Sutton Grammar FOI reply 4 Sep 2025, Q2, first column (2024e)|how many children cleared for stage 1 set? 2389 2372|confirmed|children (both sexes) who cleared the SET, as Sutton Grammar reports it|{SET}

# ---------------- Wilson's School (SET + own second stage, no area)
136621|2025|testers_stage2|all||1242|candidates|n7_sutton_tss_2026|p.44 Wilson's School entry|second stage test for September 2025: 1242 Wilson's is a selective boys' school|confirmed|shared second stage; same as boys invited in Wilson's FOI|
136621|2024|testers_stage2|all||1249|candidates|n7_sutton_tss_2025_wb|p.44 Wilson's School entry|second stage test for September 2024: 1249 Wilson's is a selective boys' school|confirmed|shared second stage; same as boys invited in Wilson's FOI|
136621|2023|testers_stage2|all||1207|candidates|n7_sutton_tss_2024_wb|p.44 Wilson's School entry|second stage test for September 2023: 1207 Wilson's is a selective boys' school|confirmed|conflict: Wilson's FOI says 1177 boys were invited to Stage 2 for 2023 entry (WCGS FOI: 1223)|
136621|2025|qualifying_score|stage1_pass||212|SET standardised score|n7_wilsons_foi_2125_wb|FOI reply 31 Mar 2025, 'minimum score required to pass stage1'|pass stage1 was: 2021 - 213 2022 - 215 2023 - 212 2024 - 212 2025 - 212|confirmed|Wilson's SET pass mark|
136621|2024|qualifying_score|stage1_pass||212|SET standardised score|n7_wilsons_foi_2125_wb|same sentence, 2024|pass stage1 was: 2021 - 213 2022 - 215 2023 - 212 2024 - 212 2025 - 212|confirmed||
136621|2023|qualifying_score|stage1_pass||212|SET standardised score|n7_wilsons_foi_2125_wb|same sentence, 2023|pass stage1 was: 2021 - 213 2022 - 215 2023 - 212 2024 - 212 2025 - 212|confirmed||
136621|2025|qualifying_score|stage2_pass||480|Wilson's combined score (SET and second stage, 1:2:2)|n7_wilsons_foi_2125_wb|FOI reply 31 Mar 2025, 'minimum score required to pass stage 2'|pass stage 2 was: 2021 - 475 2022 - 475 2023 - 475 2024 - 475 2025 - 480|confirmed|pass mark, not the lowest score offered; minimum thresholds in each paper also apply|
136621|2024|qualifying_score|stage2_pass||475|Wilson's combined score (SET and second stage, 1:2:2)|n7_wilsons_foi_2125_wb|same sentence, 2024|pass stage 2 was: 2021 - 475 2022 - 475 2023 - 475 2024 - 475 2025 - 480|confirmed||
136621|2023|qualifying_score|stage2_pass||475|Wilson's combined score (SET and second stage, 1:2:2)|n7_wilsons_foi_2125_wb|same sentence, 2023|pass stage 2 was: 2021 - 475 2022 - 475 2023 - 475 2024 - 475 2025 - 480|confirmed||
136621|2025|places|all|national_offer_day|186|places|n7_wilsons_foi_2125_wb|FOI reply 31 Mar 2025, 'number of offers made on offer day'|in all years we offer places to fill our pupil admission number (186)|confirmed|lowest NOD scores for 2023-2025 are in the attachment to WDTK request last_6_years_of_admission_marks, not archived|
136621|2024|places|all|national_offer_day|186|places|n7_wilsons_foi_2125_wb|same sentence|in all years we offer places to fill our pupil admission number (186)|confirmed||
136621|2023|places|all|national_offer_day|186|places|n7_wilsons_foi_2125_wb|same sentence|in all years we offer places to fill our pupil admission number (186)|confirmed||
136621|2025|places|aptitude_sport_music||18|places|n7_wilsons_foi_places_wb|FOI reply 19 Mar 2025, 2025 entry|2025 entry - 5925 (boys and girls) - 18 sports/music places (9 each) - 168 other places|confirmed|9 sport + 9 music aptitude places; the other 168 include free-school-meal places and academic rank|
136621|2024|places|aptitude_sport_music||18|places|n7_wilsons_foi_places_wb|FOI reply 19 Mar 2025, 2024 entry|2024 entry - 5811 (boys and girls) - 18 sports/music places (9 each) - 168 other places|confirmed||
136621|2023|places|aptitude_sport_music||18|places|n7_wilsons_foi_places_wb|FOI reply 19 Mar 2025, 2023 entry|2023 entry - 5607 (boys and girls) - 18 sports/music places (9 each) - 168 other places|confirmed||

# ---------------- Sutton Grammar School (SET + shared second stage; 75 places for listed postcodes)
136787|2025|testers_stage2|all||1252|candidates|n7_sgs_foi_set_wb|FOI reply 4 Sep 2025, Q3, second column (2025e)|how many children appeared for stage 2? 1270 boys 1252 boys|confirmed|conflict: Sutton booklet (Sept 2026) prints 1272 second-stage candidates for 2025, the same as its 2024 figure|
136787|2024|testers_stage2|all||1270|candidates|n7_sgs_foi_set_wb|FOI reply 4 Sep 2025, Q3, first column (2024e)|how many children appeared for stage 2? 1270 boys 1252 boys|confirmed|Sutton booklet (Sept 2025) prints 1272|
136787|2023|testers_stage2|all||1207|candidates|n7_sutton_tss_2024_wb|p.36 Sutton Grammar School entry|second stage test for September 2023: 1207 Sutton Grammar School is a selective school for boys|confirmed|shared second stage; Wilson's FOI says 1177 boys invited, WCGS FOI 1223|
136787|2025|candidates_qualified|all||921|candidates|n7_sgs_foi_set_wb|FOI reply 4 Sep 2025, Q4, second sentence pair (2025e)|921 boys passed stage 2 for sutton grammar school|confirmed|boys reaching the Sutton Grammar standard|
136787|2024|candidates_qualified|all||905|candidates|n7_sgs_foi_set_wb|FOI reply 4 Sep 2025, Q4, first sentence pair (2024e)|905 boys passed for stage 2 for sutton grammar school|confirmed|boys reaching the Sutton Grammar standard|
136787|2025|offers|all||135|offers|n7_sgs_foi_set_wb|FOI reply 4 Sep 2025, Q4 (2025e)|135 children were offered a place at sutton grammar school|confirmed|offer round not stated; equals the PAN of 135|
136787|2024|offers|all||135|offers|n7_sgs_foi_set_wb|FOI reply 4 Sep 2025, Q4 (2024e)|135 children were offered a place at sutton grammar school|confirmed|offer round not stated; equals the PAN of 135|
136787|2025|pan|all||135|places|n7_sutton_tss_2025_wb|p.36 Sutton Grammar School entry|Published Admissions Number: 135 Number of male candidates at Selective Eligibility Test for September 2024: 3107|confirmed|booklet for Sept 2025 entry; the Sept 2026 booklet and 2026 policy give 150|
136787|2024|pan|all||135|places|n7_sutton_tss_2024_wb|p.36 Sutton Grammar School entry|Published Admissions Number: 135 Number of male candidates at Selective Eligibility Test for September 2023: 3098|confirmed|booklet for Sept 2024 entry|

# ---------------- Wallington County Grammar School (SET + shared second stage; up to 15 places for Sutton postcodes)
136798|2025|lowest_score_offered|outside_priority_area||173.66|WCGS combined score (SET and second stage)|n7_wcgs_foi_2325_wb|FOI reply 26 Nov 2025, first figure for 2025|in 2025 173.66 and 172.32|confirmed|school: we do not store data on when offers are made, so lowest score for entry; first figure = general places, second = Sutton-postcode places; far below 2023-24, change not explained|
136798|2025|lowest_score_offered|inside_priority_area||172.32|WCGS combined score (SET and second stage)|n7_wcgs_foi_2325_wb|FOI reply 26 Nov 2025, second figure for 2025|in 2025 173.66 and 172.32|confirmed|Sutton-postcode places (up to 15); the school says it has no catchment area|
136798|2024|lowest_score_offered|outside_priority_area||187.67|WCGS combined score (SET and second stage)|n7_wcgs_foi_2325_wb|FOI reply 26 Nov 2025, first figure for 2024|in 2024 187.67 and 184.87|confirmed|same values as the 1 March 2024 reply|
136798|2024|lowest_score_offered|inside_priority_area||184.87|WCGS combined score (SET and second stage)|n7_wcgs_foi_2325_wb|FOI reply 26 Nov 2025, second figure for 2024|in 2024 187.67 and 184.87|confirmed||
136798|2023|lowest_score_offered|outside_priority_area||186.35|WCGS combined score (SET and second stage)|n7_wcgs_foi_2325_wb|FOI reply 26 Nov 2025, first figure for 2023|in 2023 186.35 and 183.89|confirmed|conflict: reply of 30 Nov 2023 gives 186.35 as the 1 March 2023 lowest (all places) and 183.89 as the lowest for the whole 2023 entry; reply of 24 Apr 2024 gives 189 on 1 March 2023 excluding PP/LAC|
136798|2023|lowest_score_offered|inside_priority_area||183.89|WCGS combined score (SET and second stage)|n7_wcgs_foi_2325_wb|FOI reply 26 Nov 2025, second figure for 2023|in 2023 186.35 and 183.89|confirmed|see conflict on the 186.35 row|
136798|2024|lowest_score_offered|outside_priority_area|national_offer_day|187.67|WCGS combined score (SET and second stage)|n7_wcgs_foi_2024_wb|FOI reply 19 Mar 2024, Q1|lowest score outside catchment offered on 1st march 2024 187.67|confirmed|the school says it has no catchment, only Sutton-postcode places|
136798|2024|lowest_score_offered|inside_priority_area|national_offer_day|184.87|WCGS combined score (SET and second stage)|n7_wcgs_foi_2024_wb|FOI reply 19 Mar 2024, Q2|lowest score inside catchment offered on 1st march 2024 184.87|confirmed|Sutton-postcode places (up to 15)|
136798|2023|lowest_score_offered|all|national_offer_day|186.35|WCGS combined score (SET and second stage)|n7_wcgs_foi_2023_wb|FOI reply 30 Nov 2023, Q1|on 1st march 2023? 186.35|confirmed|conflict: 24 Apr 2024 reply gives 189 on 1 March 2023 (excluding PP/LAC); 26 Nov 2025 reply labels 186.35 the general-places lowest for entry|
136798|2023|lowest_score_offered|all||183.89|WCGS combined score (SET and second stage)|n7_wcgs_foi_2023_wb|FOI reply 30 Nov 2023, Q2|lowest score offered a seat for the year 2023 entry please? 183.89|confirmed|lowest for the 2023 entry as of Nov 2023, after waiting-list offers; 26 Nov 2025 reply labels it the Sutton-postcode lowest|
136798|2023|lowest_score_offered|all_others|national_offer_day|189|WCGS combined score (SET and second stage)|n7_wcgs_foi_stages_wb|FOI reply 24 Apr 2024, Q8, 2023 entry|2023 entry= 1-mar-23: 189|confirmed|excluding Pupil Premium and looked-after children; conflicts with 186.35 in the 30 Nov 2023 reply|
136798|2024|qualifying_score|stage1_pass||212|SET standardised score|n7_wcgs_foi_stages_wb|FOI reply 24 Apr 2024, Q2|eligibility score to clear stage 1 (for 2024 entry and 2023 entry)? 2024 entry= 212 2023 entry= 212|confirmed||
136798|2023|qualifying_score|stage1_pass||212|SET standardised score|n7_wcgs_foi_stages_wb|FOI reply 24 Apr 2024, Q2|eligibility score to clear stage 1 (for 2024 entry and 2023 entry)? 2024 entry= 212 2023 entry= 212|confirmed||
136798|2024|qualifying_score|stage2_pass||178|WCGS combined score (SET and second stage)|n7_wcgs_foi_stages_wb|FOI reply 24 Apr 2024, Q4|for catchment and out of catchment postcodes (for 2024 entry and 2023 entry)? 2024 entry= 178|confirmed|combined eligibility threshold; for 2023 everyone who sat the second stage was deemed to pass|
136798|2024|candidates_qualified|all||1048|candidates|n7_wcgs_foi_stages_wb|FOI reply 24 Apr 2024, Q5|combined scores (for 2024 entry and 2023 entry)? 2024 entry= 1048 2023 entry= 1175|confirmed|boys eligible to name WCGS on the CAF|
136798|2023|candidates_qualified|all||1175|candidates|n7_wcgs_foi_stages_wb|FOI reply 24 Apr 2024, Q5|combined scores (for 2024 entry and 2023 entry)? 2024 entry= 1048 2023 entry= 1175|confirmed|boys eligible to name WCGS on the CAF|
136798|2024|offers|pupil_premium||6|places|n7_wcgs_foi_stages_wb|FOI reply 24 Apr 2024, Q9|any other non-general categories? 2024 entry= 6 2023 entry= 10|confirmed|seats taken up by Pupil Premium, looked-after or other non-general categories|
136798|2023|offers|pupil_premium||10|places|n7_wcgs_foi_stages_wb|FOI reply 24 Apr 2024, Q9|any other non-general categories? 2024 entry= 6 2023 entry= 10|confirmed|seats taken up by Pupil Premium, looked-after or other non-general categories|

# ---------------- St Olave's (own SET + Stage 2, no area)
101676|2024|qualifying_score|stage1_pass||39|SET raw mark (out of 60)|n7_sto_foi_cutoffs_wb|FOI reply 23 Jul 2024|proceed from the set to the stage 2 test for 2023 and 2024 entry are as follows: 2023: 43/60 2024: 39/60|confirmed|cut-off to reach Stage 2 (top ~450 invited)|
101676|2023|qualifying_score|stage1_pass||43|SET raw mark (out of 60)|n7_sto_foi_cutoffs_wb|FOI reply 23 Jul 2024|proceed from the set to the stage 2 test for 2023 and 2024 entry are as follows: 2023: 43/60 2024: 39/60|confirmed|cut-off to reach Stage 2|
101676|2023|last_rank_offered|all||256|test rank|n7_sto_foi_cutoffs_wb|FOI reply 23 Jul 2024|for 2023 entry, the final ranked position reached was 256|confirmed|final rank reached, after waiting-list offers; 2024 ranks withheld while Bromley used them|
101676|2026|applications|all||473|applications|n7_bromley_sec_2728|p.52 St Olave's entry, '2026 admissions'|2026 admissions selective aided applications received 473 (grammar) places offered 128 including 4 chorister places|confirmed|Bromley-coordinated applications naming the school, not testers; same 473 / 128 printed for 2025|
101676|2026|places|all||128|places|n7_bromley_sec_2728|p.52 St Olave's entry, '2026 admissions'|2026 admissions selective aided applications received 473 (grammar) places offered 128 including 4 chorister places|confirmed|PAN 124 plus 4 Wakeham chorister places|
101676|2025|applications|all||473|applications|n7_bromley_sec_2627_wb|p.50 St Olave's entry, '2025 admissions'|2025 admissions selective aided applications received 473 (grammar) places offered 128 including 4 chorister places|confirmed|identical to the 2026 figures in the next booklet; possibly carried over|
101676|2025|places|all||128|places|n7_bromley_sec_2627_wb|p.50 St Olave's entry, '2025 admissions'|2025 admissions selective aided applications received 473 (grammar) places offered 128 including 4 chorister places|confirmed|PAN 124 plus 4 chorister places|
101676|2023|applications|all||452|applications|n7_bromley_sec_2425_wb|p.61 St Olave's entry, '2023 admissions'|2023 admissions 124 applications received places offered 452 128 - including 4 chorister places|confirmed|Bromley-coordinated applications naming the school, not testers|
101676|2023|places|all||128|places|n7_bromley_sec_2425_wb|p.61 St Olave's entry, '2023 admissions'|2023 admissions 124 applications received places offered 452 128 - including 4 chorister places|confirmed|PAN 124 plus 4 chorister places|

# ---------------- Tiffin Girls' (own two-stage test; Inner + Designated Area): 2023 entry
136615|2023|testers_stage1|all||1445|candidates|n7_tgs_poa_2021_23_wb|'Admissions Information 2021-23', row 'Candidates tested at stage one', col 2023|candidates tested at stage one 1445 1414 1453|confirmed|removed from the school site; FOI reply of 17 Jan 2025 (WDTK school_applicants_stage_one) points to this table|
136615|2023|testers_stage2|all||477|candidates|n7_tgs_poa_2021_23_wb|row 'Candidates tested at stage two', col 2023|candidates tested at stage two 477 460 461|confirmed||
136615|2023|testers_stage1|inner_area||260|candidates|n7_tgs_poa_2021_23_wb|row 'Inner Area candidates stage one', col 2023|inner area candidates stage one 260 245 200|confirmed|Inner Area only (subset of the Designated Area)|
136615|2023|testers_stage1|pupil_premium||60|candidates|n7_tgs_poa_2021_23_wb|row 'Pupil premium candidates stage one', col 2023|pupil premium candidates stage one 60 58 40|confirmed||
136615|2023|pan|all||180|places|n7_tgs_poa_2021_23_wb|row 'Number of places in Year 7 (published admission number)', col 2023|number of places in year 7 (published admission number) 180 180 180|confirmed|all 2021-23 places went to the Designated or Inner Area|

# ---------------- Tiffin School: 2023 entry (column 2023 of the 2025 Patterns of Admissions)
136910|2023|testers_stage1|all||1666|candidates|n7_tiffin_poa_2025|p1, row 'Applicants tested at Stage One', col 2023|applicants tested at stage one 1675 1654 1666|confirmed|same in Patterns of Admissions 2023|
136910|2023|testers_stage2|all||680|candidates|n7_tiffin_poa_2025|p1, row 'Applicants tested at Stage Two', col 2023|applicants tested at stage two 653 666 680|confirmed||
136910|2023|places|all|national_offer_day|186|places|n7_tiffin_poa_2025|p1, row 'Places offered initially', col 2023|places offered initially 186 186 186|confirmed||
136910|2023|lowest_score_offered|all|national_offer_day|104|Tiffin School test score (school's own scale)|n7_tiffin_poa_2025|p1, row 'Initial qualifying score', col 2023|(the lowest score achieved by a student 100 104 104 offered a place on 1st march)|confirmed||
136910|2023|lowest_score_offered|all|end_of_year7|100|Tiffin School test score (school's own scale)|n7_tiffin_poa_2025|p1, row 'Cut off score', col 2023|(the lowest score achieved by a student 98 102 100 offered a place by the end of y7)|confirmed|2023 PDF: in October 2023 the cut off score was 100|
136910|2023|offers|pupil_premium|national_offer_day|5|offers|n7_tiffin_poa_2025|p1, row 'Number of students eligible for Pupil Premium ... offered a place', col 2023|funding who were 11 6 5 offered a place|confirmed|includes offers later declined|

# ---------------- The Latymer School (own test; Inner Area only)
102055|2025|testers_stage1|all||2611|candidates|n7_lat_foi_testers_wb|FOI reply 13 Mar 2025, row (a) 2025, col (b)|(a) 2025 (b) 2611 (c) 700 (d) 368 (e) 53%|confirmed|the 2025 row was filled in by the requester from a prior FOI; the school's reply repeats it|
102055|2024|testers_stage1|all||2540|candidates|n7_lat_foi_testers_wb|FOI reply 13 Mar 2025, row (a) 2024, col (b)|(a) 2024 (b)2540 (c) 700 (d) 357 (e) 51%|confirmed||
102055|2023|testers_stage1|all||3021|candidates|n7_lat_foi_testers_wb|FOI reply 13 Mar 2025, row (a) 2023, col (b)|(a) 2023 (b) 3021 (c) 650 (d) 343 e) 53%|confirmed||
102055|2025|qualifying_score|rank||700|test rank (maths + verbal reasoning)|n7_lat_foi_testers_wb|FOI reply 13 Mar 2025, row (a) 2025, col (c)|(a) 2025 (b) 2611 (c) 700 (d) 368 (e) 53%|confirmed|top N have the English paper marked (Rank 2); below it not selective|
102055|2024|qualifying_score|rank||700|test rank (maths + verbal reasoning)|n7_lat_foi_testers_wb|FOI reply 13 Mar 2025, row (a) 2024, col (c)|(a) 2024 (b)2540 (c) 700 (d) 357 (e) 51%|confirmed||
102055|2023|qualifying_score|rank||650|test rank (maths + verbal reasoning)|n7_lat_foi_testers_wb|FOI reply 13 Mar 2025, row (a) 2023, col (c)|(a) 2023 (b) 3021 (c) 650 (d) 343 e) 53%|confirmed||
102055|2025|candidates_qualified|outside_priority_area||368|candidates|n7_lat_foi_testers_wb|FOI reply 13 Mar 2025, row (a) 2025, col (d)|(a) 2025 (b) 2611 (c) 700 (d) 368 (e) 53%|confirmed|out-of-Inner-Area candidates inside the rank cut-off (53%); they cannot be admitted|
102055|2024|candidates_qualified|outside_priority_area||357|candidates|n7_lat_foi_testers_wb|FOI reply 13 Mar 2025, row (a) 2024, col (d)|(a) 2024 (b)2540 (c) 700 (d) 357 (e) 51%|confirmed|51% of the top 700|
102055|2023|candidates_qualified|outside_priority_area||343|candidates|n7_lat_foi_testers_wb|FOI reply 13 Mar 2025, row (a) 2023, col (d)|(a) 2023 (b) 3021 (c) 650 (d) 343 e) 53%|confirmed|53% of the top 650|
102055|2026|candidates_qualified|outside_priority_area||336|candidates|n7_lat_foi_ooc648_wb|FOI reply 11 Nov 2025|ooc in 648 = 336 we always offer 192 places|confirmed|out-of-area candidates in the top 648 at Rank 2, as the request frames it; 648 not confirmed as the 2026 cut-off|
102055|2026|last_rank_offered|all|national_offer_day|275|test rank|n7_enfield_guide_2027|PDF p.71, 'Breakdown of allocations 2026', Latymer row|the latymer school voluntary aided 192 up to number 275 in the first round of offers|confirmed|rank list not named (probably Rank 3, the Inner Area re-ranking)|
102055|2025|last_rank_offered|all|national_offer_day|293|test rank|n7_enfield_guide_2026|PDF p.71, 'Breakdown of allocations 2025', Latymer row|the latymer school voluntary aided 192 up to number 293 in the first round of offers|confirmed|also in the Sept 2027 guide|
102055|2024|last_rank_offered|all|national_offer_day|306|test rank|n7_enfield_guide_2026|PDF p.70, 'Breakdown of allocations 2024', Latymer row|the latymer school voluntary aided 192 up to number 306 in the first round of offers|confirmed|also in the Sept 2025 guide|
102055|2023|last_rank_offered|all|national_offer_day|308|test rank|n7_enfield_guide_2025|PDF p.70, 'Breakdown of allocations 2023', Latymer row|the latymer school voluntary aided 192 up to number 308 in the first round of offers|confirmed||

# ---------------- St Michael's Catholic Grammar (faith categories, test rank within each)
101361|2023|last_rank_offered|all||162|test rank|n7_stm_foi_rank_wb|FOI reply 20 Nov 2023, Q1|2022: 166 2023: 162 2. lowest rank in the st. michael 11+ entry test|confirmed|lowest test rank admitted (Catholic criterion 3); all places were filled from that criterion; offer round not stated|
# ---------------- 2026-11-07 additions: South-East (CRGS, KEGS, Judd, Bucks schools, Langley); found and snippet-checked by discovery agents
# ---------------- n7 south-east additions: CRGS, KEGS, Judd, Chesham, Dr Challoner's x2, Langley (Reading: nothing new)
# New measure offers_waiting_list: applicants on the waiting list after 1 March who later got a place (KEGS FAQ table).
# New measure appeals_upheld: Year 7 admission appeals upheld (Judd page).
# New category bucks_residents: offers to Buckinghamshire residents (TBGS row 'Buckinghamshire'; the rest of the
#   'Total' row lives outside the county).
# TBGS allocation tables: school names are rotated header text that the extractor does not return. The column order is
#   the same in all eight files: Aylesbury GS, Aylesbury High, Beaconsfield, Burnham, Chesham (5th), Dr Challoner's
#   Grammar (6th), Dr Challoner's High (7th), ... (checked with pdftotext -raw and the page image). Snippets quote the
#   first seven columns. March files use offer_round national_offer_day, except the 2025 file (as at 20 Mar 2025:
#   offer_round blank). Final files (Sept/Oct) use offer_round september, with the date in the note.
# --- Colchester Royal Grammar School (CSSE)
149899|2026|lowest_score_offered|all|national_offer_day|346|CSSE total standardised score|n7_csse_guidance_2027|p1, CRGS row (no priority area)|Colchester Royal 346 Grammar School (Boys)*|confirmed|sheet 'for 2027 entry' gives offers of 1 March 2026 for Sept 2026 entry|
149899|2023|lowest_score_offered|all|national_offer_day|340.7853|CSSE total standardised score|n7_crgs_foi_2023_wb|CRGS FOI reply (Oct 2023)|offered a place for 2023 entry on national offer day: 2023 - 340.7853 (priority category 2)|confirmed|FOI reply; the image-only CSSE sheet prints 340 (rounded)|
149899|2023|lowest_score_offered|all|september|338.2982|CSSE total standardised score|n7_crgs_foi_2023_wb|same FOI reply|offered a place for 2023 entry by the autumn term 2023: 2023 - 338.2982 (priority category 2)|confirmed|lowest score offered by the autumn term, after waiting-list offers|
149899|2023|applications|all||623|applications (all preferences)|n7_essex_dir_2024_25|CRGS entry (school number 881-4036)|Applications received (all preferences) Sept 2023: 623|confirmed|Essex LA count of applications naming the school at any preference|
149899|2024|applications|all||638|applications (all preferences)|n7_essex_dir_2025_26|CRGS entry (school number 881-4036)|Applications received (all preferences) Sept 2024: 638|confirmed|Essex LA count of applications naming the school at any preference|
149899|2025|applications|all||789|applications (all preferences)|n7_essex_dir_2026_27|CRGS entry (school number 881-4036)|Applications received (all preferences) Sept 2025: 789|confirmed|Essex LA count of applications naming the school at any preference|
149899|2026|applications|all||805|applications (all preferences)|n7_essex_dir_2027_28|CRGS entry (school number 881-4036)|Applications received (all preferences) Sept 2026: 805|confirmed|Essex LA count of applications naming the school at any preference|
# --- King Edward VI Grammar School, Chelmsford (CSSE)
136642|2024|lowest_score_offered|inside_priority_area|september|340|CSSE total standardised score (rounded)|n7_kegs_faq_wb_20250804|FAQ on 11+ scores, students starting Sept 2024|For the students starting Year 7 at KEGS in September 2024, the lowest score obtained by an 'in area' applicant, who was neither in receipt of the Pupil Premium payment nor classified as a looked after child, was 340|confirmed|final position for Sept 2024 starters; offer-day value (340.3) is already held from the CSSE sheet|
136642|2024|lowest_score_offered|outside_priority_area|september|376|CSSE total standardised score (rounded)|n7_kegs_faq_wb_20250804|same FAQ answer|For the students starting Year 7 at KEGS in September 2024, the lowest score obtained by an 'out of area' applicant, who was neither in receipt of the Pupil Premium payment nor classified as a looked after child, was 376|confirmed|final position for Sept 2024 starters; offer-day value 376.2|
136642|2023|offers_waiting_list|inside_priority_area||8|offers|kegs_faq|FAQ table on waiting-list places, row 'In Area', column Sept. 2023 (11 columns, Sept. 2016-2026)|In Area 8 4 2 4 10 9 2 8 6 4 0|confirmed||
136642|2023|offers_waiting_list|outside_priority_area||4|offers|kegs_faq|same table, row 'Out of Area', column Sept. 2023|Out of Area 14 10 10 2 8 4 8 4 8 6 5|confirmed||
136642|2024|offers_waiting_list|inside_priority_area||6|offers|kegs_faq|FAQ table on waiting-list places, row 'In Area', column Sept. 2024 (11 columns, Sept. 2016-2026)|In Area 8 4 2 4 10 9 2 8 6 4 0|confirmed||
136642|2024|offers_waiting_list|outside_priority_area||8|offers|kegs_faq|same table, row 'Out of Area', column Sept. 2024|Out of Area 14 10 10 2 8 4 8 4 8 6 5|confirmed||
136642|2025|offers_waiting_list|inside_priority_area||4|offers|kegs_faq|FAQ table on waiting-list places, row 'In Area', column Sept. 2025 (11 columns, Sept. 2016-2026)|In Area 8 4 2 4 10 9 2 8 6 4 0|confirmed||
136642|2025|offers_waiting_list|outside_priority_area||6|offers|kegs_faq|same table, row 'Out of Area', column Sept. 2025|Out of Area 14 10 10 2 8 4 8 4 8 6 5|confirmed||
136642|2026|offers_waiting_list|inside_priority_area||0|offers|kegs_faq|FAQ table on waiting-list places, row 'In Area', column Sept. 2026 (11 columns, Sept. 2016-2026)|In Area 8 4 2 4 10 9 2 8 6 4 0|confirmed||
136642|2026|offers_waiting_list|outside_priority_area||5|offers|kegs_faq|same table, row 'Out of Area', column Sept. 2026|Out of Area 14 10 10 2 8 4 8 4 8 6 5|confirmed||
136642|2023|applications|all||656|applications (all preferences)|n7_essex_dir_2024_25|KEGS entry (school number 881-5411)|Applications received (all preferences) Sept 2023: 656|confirmed|Essex LA count of applications naming the school at any preference|
136642|2024|applications|all||616|applications (all preferences)|n7_essex_dir_2025_26|KEGS entry (school number 881-5411)|Applications received (all preferences) Sept 2024: 616|confirmed|Essex LA count of applications naming the school at any preference|
136642|2025|applications|all||744|applications (all preferences)|n7_essex_dir_2026_27|KEGS entry (school number 881-5411)|Applications received (all preferences) Sept 2025: 744|confirmed|Essex LA count of applications naming the school at any preference|
136642|2026|applications|all||738|applications (all preferences)|n7_essex_dir_2027_28|KEGS entry (school number 881-5411)|Applications received (all preferences) Sept 2026: 738|confirmed|Essex LA count of applications naming the school at any preference|
# --- The Judd School (Kent Test)
118843|2024|places|all|national_offer_day|180|offers|n7_judd_year7_wb_20240508|'Admissions Update' April 2024|On 1 March 2024 180 offers were made|confirmed||
118843|2023|places|all|national_offer_day|180|offers|n7_judd_year7_wb_20240508|'Admissions Update' April 2023|On the 1 March 2023 a total of 180 offers were made|confirmed||
118843|2024|offers|all|april_reallocation|17|offers|n7_judd_year7_wb_20240508|'Admissions Update' April 2024|A total of 17 offers were made in reallocation on the 25th April|confirmed|offers made in the KCC reallocation round|
118843|2023|offers|all|april_reallocation|26|offers|n7_judd_year7_wb_20240508|'Admissions Update' April 2023|a total of 26 offers were made in reallocation on the 25th April|confirmed|offers made in the KCC reallocation round|
118843|2023|lowest_score_offered|inside_priority_area|april_reallocation|376|Kent Test total|judd_history_2026|p1 row 'April Reallocation', Inner, 2023 (11 values, 2016-2026)|357 361 361 373 384 384 384 376 380 367 386|confirmed||
118843|2023|lowest_score_offered|outside_priority_area|april_reallocation|406|Kent Test total|judd_history_2026|p1 same row, Outer, 2023 (10 values: 2016 and 2018-2026; 2017 blank)|383 393 402 402 406 407 406 408 398 403|confirmed||
118843|2024|lowest_score_offered|inside_priority_area|april_reallocation|380|Kent Test total|judd_history_2026|p1 row 'April Reallocation', Inner, 2024 (11 values, 2016-2026)|357 361 361 373 384 384 384 376 380 367 386|confirmed||
118843|2024|lowest_score_offered|outside_priority_area|april_reallocation|408|Kent Test total|judd_history_2026|p1 same row, Outer, 2024 (10 values: 2016 and 2018-2026; 2017 blank)|383 393 402 402 406 407 406 408 398 403|confirmed||
118843|2025|lowest_score_offered|inside_priority_area|april_reallocation|367|Kent Test total|judd_history_2026|p1 row 'April Reallocation', Inner, 2025 (11 values, 2016-2026)|357 361 361 373 384 384 384 376 380 367 386|confirmed||
118843|2025|lowest_score_offered|outside_priority_area|april_reallocation|398|Kent Test total|judd_history_2026|p1 same row, Outer, 2025 (10 values: 2016 and 2018-2026; 2017 blank)|383 393 402 402 406 407 406 408 398 403|confirmed||
118843|2024|applications|all|national_offer_day|817|applications (all preferences, incl. EHCP)|n7_kcc_booklet_2025|p46 table 'Admissions 2024 Offer Day Outcome', row 4622 (Intake, Total Applications, Offers, LA Allocations)|4622 Judd School 180 817 180 0|confirmed|KCC count of applications naming the school; 180 offers, 0 LA allocations|
118843|2025|appeals_upheld|all||7|appeals|judd_year7|'Appeals' paragraph|7 appeals upheld in 2025, 1 appeal upheld in 2024, 7 appeals upheld in 2023|confirmed||
118843|2024|appeals_upheld|all||1|appeals|judd_year7|'Appeals' paragraph|7 appeals upheld in 2025, 1 appeal upheld in 2024, 7 appeals upheld in 2023|confirmed||
118843|2023|appeals_upheld|all||7|appeals|judd_year7|'Appeals' paragraph|7 appeals upheld in 2025, 1 appeal upheld in 2024, 7 appeals upheld in 2023|confirmed||
# --- Buckinghamshire Secondary Transfer Test, whole test (all home LAs; per the file notes, 'Registered for test' counts pupils who sat)
|2023|testers_stage1|all||9783|candidates|n7_tbgs_qual_final_2023|row 'Total', column 'Registered for test' (columns: 121+, qualified after review, total qualified, registered for test, ...)|Total 3593 337 3930 9783 37% 40% 12710|confirmed||{BUCKS}
|2023|candidates_qualified|all||3930|candidates|n7_tbgs_qual_final_2023|row 'Total', column 'Total qualified'|Total 3593 337 3930 9783 37% 40% 12710|confirmed|121+ plus pupils qualified on selection review|{BUCKS}
|2024|testers_stage1|all||9683|candidates|n7_tbgs_qual_final_2024|row 'Total', column 'Registered for test' (columns: 121+, qualified after review, total qualified, registered for test, ...)|Total 3665 295 3960 9683 38% 41% 12776|confirmed||{BUCKS}
|2024|candidates_qualified|all||3960|candidates|n7_tbgs_qual_final_2024|row 'Total', column 'Total qualified'|Total 3665 295 3960 9683 38% 41% 12776|confirmed|121+ plus pupils qualified on selection review|{BUCKS}
|2025|testers_stage1|all||7736|candidates|n7_tbgs_qual_final_2025|row 'Total', column 'Registered for test' (columns: 121+, qualified after review, total qualified, registered for test, ...)|Total 3044 328 3372 7736 39% 44% 9912|confirmed|well below other years, as printed (the file's cohort column also drops, to 9912)|{BUCKS}
|2025|candidates_qualified|all||3372|candidates|n7_tbgs_qual_final_2025|row 'Total', column 'Total qualified'|Total 3044 328 3372 7736 39% 44% 9912|confirmed|121+ plus pupils qualified on selection review|{BUCKS}
|2026|testers_stage1|all||9816|candidates|n7_tbgs_qual_final_2026|row 'Total', column 'Registered for test' (columns: 121+, qualified after review, total qualified, registered for test, ...)|Total 3698 296 3994 9816 38% 41% 12578|confirmed||{BUCKS}
|2026|candidates_qualified|all||3994|candidates|n7_tbgs_qual_final_2026|row 'Total', column 'Total qualified'|Total 3698 296 3994 9816 38% 41% 12578|confirmed|121+ plus pupils qualified on selection review|{BUCKS}
# --- Chesham, Dr Challoner's Grammar, Dr Challoner's High: offers (TBGS allocations by location)
137091|2023|offers|all|national_offer_day|181|offers|n7_tbgs_alloc_mar_2023|row 'Total', column 5 (Chesham)|Total 185 179 180 180 181 182 186|confirmed|allocations as at 27 Feb 2023|
137091|2023|offers|bucks_residents|national_offer_day|135|offers|n7_tbgs_alloc_mar_2023|row 'Buckinghamshire', column 5 (Chesham)|Buckinghamshire 139 153 175 61 135 181 186|confirmed|allocations as at 27 Feb 2023|
137091|2023|offers|all|september|186|offers|n7_tbgs_alloc_final_2023|row 'Total', column 5 (Chesham)|Total 186 184 179 180 186 180 186|confirmed|allocations as at 6 Oct 2023|
137091|2023|offers|bucks_residents|september|133|offers|n7_tbgs_alloc_final_2023|row 'Buckinghamshire', column 5 (Chesham)|Buckinghamshire 139 154 165 59 133 179 186|confirmed|allocations as at 6 Oct 2023|
137091|2024|offers|all|national_offer_day|183|offers|n7_tbgs_alloc_mar_2024|row 'Total', column 5 (Chesham)|Total 186 189 186 181 183 179 186|confirmed|allocations as at 1 Mar 2024|
137091|2024|offers|bucks_residents|national_offer_day|114|offers|n7_tbgs_alloc_mar_2024|row 'Buckinghamshire', column 5 (Chesham)|Buckinghamshire 137 139 179 64 114 179 181|confirmed|allocations as at 1 Mar 2024|
137091|2024|offers|all|september|185|offers|n7_tbgs_alloc_final_2024|row 'Total', column 5 (Chesham)|Total 187 187 179 176 185 179 190|confirmed|allocations as at 16 Sep 2024|
137091|2024|offers|bucks_residents|september|109|offers|n7_tbgs_alloc_final_2024|row 'Buckinghamshire', column 5 (Chesham)|Buckinghamshire 136 138 169 63 109 178 175|confirmed|allocations as at 16 Sep 2024|
137091|2025|offers|all||182|offers|n7_tbgs_alloc_mar_2025|row 'Total', column 5 (Chesham)|Total 187 189 186 180 182 180 189|confirmed|allocations as at 20 Mar 2025 (later than offer day, so offer_round blank)|
137091|2025|offers|bucks_residents||155|offers|n7_tbgs_alloc_mar_2025|row 'Buckinghamshire', column 5 (Chesham)|Buckinghamshire 149 157 186 53 155 180 172|confirmed|allocations as at 20 Mar 2025 (later than offer day, so offer_round blank)|
137091|2025|offers|all|september|186|offers|n7_tbgs_alloc_final_2025|row 'Total', column 5 (Chesham)|Total 186 190 186 179 186 180 190|confirmed|allocations as at 7 Oct 2025|
137091|2025|offers|bucks_residents|september|156|offers|n7_tbgs_alloc_final_2025|row 'Buckinghamshire', column 5 (Chesham)|Buckinghamshire 148 158 180 49 156 178 174|confirmed|allocations as at 7 Oct 2025|
137091|2026|offers|all|national_offer_day|184|offers|n7_tbgs_alloc_mar_2026|row 'Total', column 5 (Chesham)|Total 186 192 186 180 184 186 189|confirmed|allocations as at 2 Mar 2026|
137091|2026|offers|bucks_residents|national_offer_day|137|offers|n7_tbgs_alloc_mar_2026|row 'Buckinghamshire', column 5 (Chesham)|Buckinghamshire 161 153 181 64 137 174 185|confirmed|allocations as at 2 Mar 2026|
137091|2026|offers|all|september|189|offers|n7_tbgs_alloc_final_2026|row 'Total', column 5 (Chesham)|Total 186 192 186 180 189 186 190|confirmed|allocations as at 18 Sep 2026|
137091|2026|offers|bucks_residents|september|135|offers|n7_tbgs_alloc_final_2026|row 'Buckinghamshire', column 5 (Chesham)|Buckinghamshire 161 151 172 66 135 171 184|confirmed|allocations as at 18 Sep 2026|
136419|2023|offers|all|national_offer_day|182|offers|n7_tbgs_alloc_mar_2023|row 'Total', column 6 (Dr Challoner's Grammar)|Total 185 179 180 180 181 182 186|confirmed|allocations as at 27 Feb 2023|
136419|2023|offers|bucks_residents|national_offer_day|181|offers|n7_tbgs_alloc_mar_2023|row 'Buckinghamshire', column 6 (Dr Challoner's Grammar)|Buckinghamshire 139 153 175 61 135 181 186|confirmed|allocations as at 27 Feb 2023|
136419|2023|offers|all|september|180|offers|n7_tbgs_alloc_final_2023|row 'Total', column 6 (Dr Challoner's Grammar)|Total 186 184 179 180 186 180 186|confirmed|allocations as at 6 Oct 2023|
136419|2023|offers|bucks_residents|september|179|offers|n7_tbgs_alloc_final_2023|row 'Buckinghamshire', column 6 (Dr Challoner's Grammar)|Buckinghamshire 139 154 165 59 133 179 186|confirmed|allocations as at 6 Oct 2023|
136419|2024|offers|all|national_offer_day|179|offers|n7_tbgs_alloc_mar_2024|row 'Total', column 6 (Dr Challoner's Grammar)|Total 186 189 186 181 183 179 186|confirmed|allocations as at 1 Mar 2024|
136419|2024|offers|bucks_residents|national_offer_day|179|offers|n7_tbgs_alloc_mar_2024|row 'Buckinghamshire', column 6 (Dr Challoner's Grammar)|Buckinghamshire 137 139 179 64 114 179 181|confirmed|allocations as at 1 Mar 2024|
136419|2024|offers|all|september|179|offers|n7_tbgs_alloc_final_2024|row 'Total', column 6 (Dr Challoner's Grammar)|Total 187 187 179 176 185 179 190|confirmed|allocations as at 16 Sep 2024|
136419|2024|offers|bucks_residents|september|178|offers|n7_tbgs_alloc_final_2024|row 'Buckinghamshire', column 6 (Dr Challoner's Grammar)|Buckinghamshire 136 138 169 63 109 178 175|confirmed|allocations as at 16 Sep 2024|
136419|2025|offers|all||180|offers|n7_tbgs_alloc_mar_2025|row 'Total', column 6 (Dr Challoner's Grammar)|Total 187 189 186 180 182 180 189|confirmed|allocations as at 20 Mar 2025 (later than offer day, so offer_round blank)|
136419|2025|offers|bucks_residents||180|offers|n7_tbgs_alloc_mar_2025|row 'Buckinghamshire', column 6 (Dr Challoner's Grammar)|Buckinghamshire 149 157 186 53 155 180 172|confirmed|allocations as at 20 Mar 2025 (later than offer day, so offer_round blank)|
136419|2025|offers|all|september|180|offers|n7_tbgs_alloc_final_2025|row 'Total', column 6 (Dr Challoner's Grammar)|Total 186 190 186 179 186 180 190|confirmed|allocations as at 7 Oct 2025|
136419|2025|offers|bucks_residents|september|178|offers|n7_tbgs_alloc_final_2025|row 'Buckinghamshire', column 6 (Dr Challoner's Grammar)|Buckinghamshire 148 158 180 49 156 178 174|confirmed|allocations as at 7 Oct 2025|
136419|2026|offers|all|national_offer_day|186|offers|n7_tbgs_alloc_mar_2026|row 'Total', column 6 (Dr Challoner's Grammar)|Total 186 192 186 180 184 186 189|confirmed|allocations as at 2 Mar 2026|
136419|2026|offers|bucks_residents|national_offer_day|174|offers|n7_tbgs_alloc_mar_2026|row 'Buckinghamshire', column 6 (Dr Challoner's Grammar)|Buckinghamshire 161 153 181 64 137 174 185|confirmed|allocations as at 2 Mar 2026|
136419|2026|offers|all|september|186|offers|n7_tbgs_alloc_final_2026|row 'Total', column 6 (Dr Challoner's Grammar)|Total 186 192 186 180 189 186 190|confirmed|allocations as at 18 Sep 2026|
136419|2026|offers|bucks_residents|september|171|offers|n7_tbgs_alloc_final_2026|row 'Buckinghamshire', column 6 (Dr Challoner's Grammar)|Buckinghamshire 161 151 172 66 135 171 184|confirmed|allocations as at 18 Sep 2026|
137219|2023|offers|all|national_offer_day|186|offers|n7_tbgs_alloc_mar_2023|row 'Total', column 7 (Dr Challoner's High)|Total 185 179 180 180 181 182 186|confirmed|allocations as at 27 Feb 2023|
137219|2023|offers|bucks_residents|national_offer_day|186|offers|n7_tbgs_alloc_mar_2023|row 'Buckinghamshire', column 7 (Dr Challoner's High)|Buckinghamshire 139 153 175 61 135 181 186|confirmed|allocations as at 27 Feb 2023|
137219|2023|offers|all|september|186|offers|n7_tbgs_alloc_final_2023|row 'Total', column 7 (Dr Challoner's High)|Total 186 184 179 180 186 180 186|confirmed|allocations as at 6 Oct 2023|
137219|2023|offers|bucks_residents|september|186|offers|n7_tbgs_alloc_final_2023|row 'Buckinghamshire', column 7 (Dr Challoner's High)|Buckinghamshire 139 154 165 59 133 179 186|confirmed|allocations as at 6 Oct 2023|
137219|2024|offers|all|national_offer_day|186|offers|n7_tbgs_alloc_mar_2024|row 'Total', column 7 (Dr Challoner's High)|Total 186 189 186 181 183 179 186|confirmed|allocations as at 1 Mar 2024|
137219|2024|offers|bucks_residents|national_offer_day|181|offers|n7_tbgs_alloc_mar_2024|row 'Buckinghamshire', column 7 (Dr Challoner's High)|Buckinghamshire 137 139 179 64 114 179 181|confirmed|allocations as at 1 Mar 2024|
137219|2024|offers|all|september|190|offers|n7_tbgs_alloc_final_2024|row 'Total', column 7 (Dr Challoner's High)|Total 187 187 179 176 185 179 190|confirmed|allocations as at 16 Sep 2024|
137219|2024|offers|bucks_residents|september|175|offers|n7_tbgs_alloc_final_2024|row 'Buckinghamshire', column 7 (Dr Challoner's High)|Buckinghamshire 136 138 169 63 109 178 175|confirmed|allocations as at 16 Sep 2024|
137219|2025|offers|all||189|offers|n7_tbgs_alloc_mar_2025|row 'Total', column 7 (Dr Challoner's High)|Total 187 189 186 180 182 180 189|confirmed|allocations as at 20 Mar 2025 (later than offer day, so offer_round blank)|
137219|2025|offers|bucks_residents||172|offers|n7_tbgs_alloc_mar_2025|row 'Buckinghamshire', column 7 (Dr Challoner's High)|Buckinghamshire 149 157 186 53 155 180 172|confirmed|allocations as at 20 Mar 2025 (later than offer day, so offer_round blank)|
137219|2025|offers|all|september|190|offers|n7_tbgs_alloc_final_2025|row 'Total', column 7 (Dr Challoner's High)|Total 186 190 186 179 186 180 190|confirmed|allocations as at 7 Oct 2025|
137219|2025|offers|bucks_residents|september|174|offers|n7_tbgs_alloc_final_2025|row 'Buckinghamshire', column 7 (Dr Challoner's High)|Buckinghamshire 148 158 180 49 156 178 174|confirmed|allocations as at 7 Oct 2025|
137219|2026|offers|all|national_offer_day|189|offers|n7_tbgs_alloc_mar_2026|row 'Total', column 7 (Dr Challoner's High)|Total 186 192 186 180 184 186 189|confirmed|allocations as at 2 Mar 2026|
137219|2026|offers|bucks_residents|national_offer_day|185|offers|n7_tbgs_alloc_mar_2026|row 'Buckinghamshire', column 7 (Dr Challoner's High)|Buckinghamshire 161 153 181 64 137 174 185|confirmed|allocations as at 2 Mar 2026|
137219|2026|offers|all|september|190|offers|n7_tbgs_alloc_final_2026|row 'Total', column 7 (Dr Challoner's High)|Total 186 192 186 180 189 186 190|confirmed|allocations as at 18 Sep 2026|
137219|2026|offers|bucks_residents|september|184|offers|n7_tbgs_alloc_final_2026|row 'Buckinghamshire', column 7 (Dr Challoner's High)|Buckinghamshire 161 151 172 66 135 171 184|confirmed|allocations as at 18 Sep 2026|
# --- Bucks April re-allocation: last distance reached under the named rule (Chesham: 'No further offers made' in both years)
136419|2025|last_distance_offered|catchment|april_reallocation|5.347|miles|n7_bucks_realloc_2025|row 'Dr Challoner's Grammar School'|further offers made under rule 6 (catchment) to 5.347 miles|confirmed|re-allocation round, 2 April 2025|
137219|2025|last_distance_offered|distance|april_reallocation|5.418|miles|n7_bucks_realloc_2025|row 'Dr Challoner's High School'|some allocated under rule 9 (distance) to 5.418 miles|confirmed|re-allocation round, 2 April 2025|
136419|2026|last_distance_offered|distance|april_reallocation|10.822|miles|n7_bucks_realloc_2026|row 'Dr Challoner's Grammar School'|further offers made under rule 8 (distance) to 10.822 miles|confirmed|re-allocation round, 1 April 2026|
137219|2026|last_distance_offered|siblings|april_reallocation|6.484|miles|n7_bucks_realloc_2026|row 'Dr Challoner's High School'|some further offers made under rule 6 (siblings) to 6.484 miles|confirmed|re-allocation round, 1 April 2026|
# --- Langley Grammar School and the Slough consortium
136521|2023|applications|all||1099|applications naming the school|n7_lgs_alloc_2023_wb|table row for Langley (PAN, applications, eligible applications)|Langley Grammar Academy 180 1099 745|confirmed|any application naming the school, whatever the score|
136521|2023|applications|eligible_111_plus||745|applications|n7_lgs_alloc_2023_wb|same row|Langley Grammar Academy 180 1099 745|confirmed|applicants scoring 111 or more|
136521|2023|pan|all||180|places|n7_lgs_alloc_2023_wb|same row|Langley Grammar Academy 180 1099 745|confirmed||
136521|2023|lowest_score_offered|priority_area_2|national_offer_day|115|Slough consortium standardised score|n7_lgs_alloc_2023_wb|Langley paragraph|eligible children from priority 2 school admissions area with a rank score down to 115|confirmed|all eligible Priority Area 1 children were admitted (no score cut-off)|
136521|2024|applications|eligible_111_plus||825|applications|lgs_alloc_2024|Langley table row|Academy 180 1211 825|confirmed|applicants scoring 111 or more|
|2023|testers_stage1|all||4150|candidates (approximate)|n7_slough_faq_2023_wb|FAQ on number of candidates, Sept 2023 entry|Approximately 4150 sat the test at a Slough Consortium grammar school|confirmed|approximate; about 350 more sat elsewhere and shared their scores|{SLOUGH}
|2024|testers_stage1|all||4371|candidates (approximate)|n7_slough_faq_2024_wb|FAQ on number of candidates, Sept 2024 entry|Approximately 4371 sat the test at a Slough Consortium grammar school|confirmed|approximate|{SLOUGH}
# ---------------- 2026-11-07 additions: Midlands, North and South West (Pate's, Altrincham Girls/Boys, Blue Coat); found and snippet-checked by discovery agents
# ---------------- Pate's Grammar School (FOI reply excerpts, Wayback copies of WhatDoTheyKnow)
# New measure score_of_150th_rank: standardised score of the child ranked 150th (= PAN) in the test rank order;
# Pate's priority (disadvantaged) places use a threshold of 'within 15% of the 150th ranked score'.
136353|2024|last_rank_offered|all||191|test rank|n7_pates_wdtk_body|request 'Final rank for 2021/22/23 year of entry', reply to Naveen G, 16 Oct 2024 (excerpt on the request list)|The final admission rank for September 2024 was 191 (after the waiting list).|confirmed|after waiting-list offers; reply adds 'The waiting list usually moves 2-4 places each year'; request page itself not archived|
136353|2023|score_of_150th_rank|all||110.40|Gloucestershire test standardised score|n7_pates_wdtk_body|request 'Standardised score for top 150 students', reply to Arindam Ray, 27 Feb 2023 (excerpt)|Minimum standardised score in top 150 – 110.40|confirmed|entry year inferred: reply dated 27 Feb 2023, so the test sat Sept 2022 (2023 entry); year not stated in the excerpt|
136353|2022|lowest_score_offered|all|september|116.39|Gloucestershire test standardised score|n7_pates_wdtk_lowest|reply 13 Oct 2022, item 1|Lowest score for 2022 entry - 116.39|confirmed|'final accepted allocation (so not on results day, but those that came to the school)'|
136353|2021|lowest_score_offered|all|september|112.11|Gloucestershire test standardised score|n7_pates_wdtk_lowest|reply 13 Oct 2022, item 1|Lowest score for 2021 entry - 112.11|confirmed|final accepted allocation, as above|
136353|2026|priority_area_places|all||105|places|n7_pates_infographic_2026|p1 header|Up to: 105 places Min. 45 places|confirmed|up to 105 places (including up to 15 priority places) for Gloucestershire or listed postcodes, at least 45 UK-wide; all from the top 250 ranks|

# ---------------- Altrincham Grammar School for Girls: school FAQ (testers are AGGS's own count, not the whole Trafford test)
# Distances on the FAQ are the school's figures after later offer rounds; Trafford's national-offer-day distances
# (5.47 mi 2025, 6.067 mi 2026) are already held with offer_round national_offer_day.
137289|2026|testers_stage1|all||1470|candidates|n7_aggs_faq_2026|FAQ 'How many students sat the Entrance Examination in September 2025'|1470 students sat the entrance examination in September 2025|confirmed|plus 49 who took the late test in March 2026|
137289|2026|candidates_qualified|all||376|candidates|n7_aggs_faq_2026|FAQ 'How many students achieved the qualifying score in the 2025 Entrance Examination?'|376 students achieved the qualifying score in the entrance examination.|confirmed||
137289|2026|offers|catchment||210|offers|n7_aggs_faq_2026|FAQ 'How many students living in the catchment area were made an offer ... for September 2026?'|210 students in the catchment area were made an offer.|confirmed|round not stated; Trafford outcome page gives 209 total offers on national offer day|
137289|2026|offers|outside_catchment||no_offers|code|n7_aggs_faq_2026|FAQ 'How many students living out of the catchment area were made an offer ... for September 2026?'|No students out of the catchment area were made an offer.|confirmed||
137289|2026|last_distance_offered|catchment||7.346|miles|n7_aggs_faq_2026|FAQ 'To what mileage have you made offers for the last five years?'|2026 entry - 7.346 miles. This was up to and including over-subscription category 4.4.|confirmed|school figure, larger than the offer-day 6.067 miles|
137289|2025|last_distance_offered|catchment||5.529|miles|n7_aggs_faq_2026|same FAQ answer|2025 entry - 5.529 miles. This was up to and including over-subscription category 4.4.|confirmed|offer day 5.47 miles (Trafford)|
137289|2024|last_distance_offered|catchment||5.784|miles|n7_aggs_faq_2026|same FAQ answer|2024 entry - 5.784 miles. This was up to and including over-subscription category 4.4.|confirmed||
137289|2023|last_distance_offered|outside_catchment||11.007|miles|n7_aggs_faq_2026|same FAQ answer|2023 entry - 11.007 miles. This was up to and including over-subscription category 4.7.|confirmed|category 4.7 = outside the 8-mile catchment (2026 policy numbering), so 9 out-of-catchment offers that year|
137289|2025|testers_stage1|all||1482|candidates|n7_aggs_faq_2025_wb|FAQ 'How many students sat the Entrance Examination in September 2024?'|1482 students sat the entrance examination in September 2024|confirmed|plus 37 late testers (March 2025); 1482 is also the figure printed for Sept 2022|
137289|2025|candidates_qualified|all||389|candidates|n7_aggs_faq_2025_wb|FAQ 'How many students achieved the qualifying score in the 2024 Entrance Examination?'|389 students achieved the qualifying score in the entrance examination.|confirmed||
137289|2025|offers|catchment||208|offers|n7_aggs_faq_2025_wb|FAQ '... in the catchment area were made an offer ... for September 2025?'|208 students in the catchment area were made an offer.|confirmed|round not stated|
137289|2025|offers|outside_catchment||no_offers|code|n7_aggs_faq_2025_wb|FAQ '... out of the catchment area were made an offer ... for September 2025?'|No students out of the catchment area were made an offer.|confirmed||
137289|2023|testers_stage1|all||1482|candidates|n7_aggs_faq_2023_wb|FAQ 'How many students sat the Entrance Examination in September 2022?'|1482 students sat the entrance examination (in September 2022)|confirmed|same number as Sept 2024 (2025 entry), printed in two different FAQ versions|
137289|2023|candidates_qualified|all||382|candidates|n7_aggs_faq_2023_wb|FAQ 'How many students achieved the qualifying score in the 2022 Entrance Examination?'|382 students achieved the qualifying score in the entrance examination|confirmed||
137289|2023|offers|catchment||211|offers|n7_aggs_faq_2023_wb|FAQ '... in the catchment area were made an offer ... for September 2023?'|211 students in the catchment area were made an offer|confirmed|round not stated|
137289|2023|offers|outside_catchment||9|offers|n7_aggs_faq_2023_wb|FAQ '... out of the catchment area were made an offer ... for September 2023?'|9 students out of catchment area were made an offer|confirmed||
137289|2026|qualifying_score|all||334|Trafford test total standardised score|n7_aggs_booklet_2026|p3 'Entrance Examination'|candidates who score 334 and above in the exam.|confirmed|looked-after and pupil-premium categories need 324 and above|

# ---------------- Altrincham Grammar School for Boys: FOI replies (Wayback copy of the request page)

# ---------------- The Blue Coat School, Liverpool (URN 137916; two-phase own test)
137916|2025|testers_stage1|all||1055|candidates|n7_bluecoat_faq_2027|FAQ 'How many candidates sat the entrance test ... in entry in September 2025'|A total of 1,055 candidates sat the test at The Blue Coat School.|confirmed|does not say which phase of the two-phase test|
137916|2023|testers_stage1|all||1089|candidates|n7_bluecoat_faq_2025|FAQ 'How many candidates sat the entrance test ... in entry in September 2023'|A total of 1089 candidates sat the test at The Blue Coat School.|confirmed|the 2026-entry FAQ prints the same 1089 for 'entry in September 2024' (row already held); one of the two may be carried forward|
"""

MODEL_NOTES = {
    "136910": "All 2024-2026 places went inside the 10 km priority area.",
    "136642": "12.5-mile (20.1 km) priority area for the first 120 places; consortium testers per place only.",
    "136412": "Own test; 144 places for a 12.5-mile priority area, 36 open; school-level candidates from the anonymised list.",
    "137045": "Ward catchment, priority-score applicants ranked by distance.",
    "137044": "Ward catchment, priority-score applicants ranked by distance.",
    "137046": "Ward catchment, priority-score applicants ranked by distance.",
    "138051": "No catchment to sit the test; looked-after children, pupil premium and those within 3 miles are offered places first, then the rest in rank order (admission FAQs 2026, p.2). No model is recorded because the policy and FAQs are image-only PDFs.",
}

# Hand-set flags, used only where the computed flag is `unassessed`. The reason goes into the note column.
FLAG_OVERRIDES = {
    "138051": ("probable", "Hand-set by the author, 2026-10-20: admission policy 2027-28 read by eye (image-only PDF). Every offer goes to a girl in the top 300 of Round 1; looked-after children, pupil premium and girls within 3 miles (4.8 km) come first, then rank order. Probable, not yes: the share of places the priority groups take is not published."),
}
