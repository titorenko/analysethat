"""Link Cambridge apply centres (2013-2025) to DfE URNs via GIAS postcode + name similarity.

Usage: .venv/Scripts/python -I code/analysis/join_cambridge.py data/derived
Writes cambridge_centre_urn.csv (centre -> urn with method and score) and cambridge_school_cycle.csv
(urn x cycle lower bound / upper bound / estimate per measure, with suppression flags; cam_cells.py).
Gate G-join: every school in top30_independent.csv and top30_grammar.csv is linked, linked centres hold >= 95%
of English-centre acceptances (cycles 2022-2025) in each sector, and a sample of links is printed for review.

Method: normalise postcodes; candidates = GIAS establishments at the same postcode (fallback: same postcode
district). Score = name similarity (difflib ratio on normalised names). Prefer open establishments, then the
highest score. Accept postcode matches with score >= 0.6, district matches with score >= 0.9.
"""
import difflib
import pathlib
import re
import sys

import pandas as pd

derived = pathlib.Path(sys.argv[1])
cam = pd.read_csv(derived / "cambridge_apply_centre.csv", dtype=str)
gias = pd.read_csv(derived / "school_master.csv", dtype=str, low_memory=False)

def norm_name(s):
    """Full-name normalisation: keeps type words (college, high, boys, girls) so sibling schools stay distinct."""
    s = str(s).split(",")[0]                      # Cambridge appends ", Town" to many names
    s = re.sub(r"\(.*?\)", " ", s).lower()        # drop parentheticals such as "(Mixed)"
    s = s.replace("&", " and ").replace("saint ", "st ").replace("st.", "st ")
    s = re.sub(r"[^a-z0-9 ]", " ", s)
    s = re.sub(r"\bthe\b", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def norm_pc(s):
    return re.sub(r"\s+", "", str(s).upper()) if isinstance(s, str) else ""


gias["pc"] = gias.postcode.map(norm_pc)
gias["district"] = gias.pc.str[:-3]
gias["nn"] = gias.name.map(norm_name)
gias["is_open"] = gias.status.str.startswith("Open")
by_pc = {k: v for k, v in gias.groupby("pc")}
by_dist = {k: v for k, v in gias.groupby("district")}

centres = cam.sort_values("cycle").groupby("centre_number").agg(
    centre_name=("centre_name", "last"), postcode=("postcode", "last"), sector=("sector", "last"),
    first_cycle=("cycle", "min"), last_cycle=("cycle", "max")).reset_index()
centres = centres[centres.sector.isin(["Maintained", "Independent"])]


def best(cands, nn):
    if cands is None or cands.empty:
        return None
    sc = cands.nn.map(lambda x: difflib.SequenceMatcher(None, x, nn).ratio())
    c = cands.assign(score=sc).sort_values(["score", "is_open"], ascending=[False, False])
    top = c.iloc[0]
    # among near-ties (e.g. a closed predecessor and its open academy successor), prefer the open one
    ties = c[c.score >= top.score - 0.05]
    pick = ties[ties.is_open].iloc[0] if ties.is_open.any() else top
    return pick


rows = []
for r in centres.itertuples():
    nn, pc = norm_name(r.centre_name), norm_pc(r.postcode)
    pick, method = best(by_pc.get(pc), nn), "postcode"
    if pick is not None and pick.score < 0.6:
        pick = None
    if pick is None and len(pc) > 3:
        pick, method = best(by_dist.get(pc[:-3]), nn), "district"
        if pick is not None and pick.score < 0.9:
            pick = None
    rows.append({"centre_number": r.centre_number, "centre_name": r.centre_name, "postcode": r.postcode,
                 "cam_sector": r.sector, "first_cycle": r.first_cycle, "last_cycle": r.last_cycle,
                 "urn": None if pick is None else pick.urn, "gias_name": None if pick is None else pick["name"],
                 "gias_sector": None if pick is None else pick.sector,
                 "method": None if pick is None else method, "score": None if pick is None else round(pick.score, 3)})
link = pd.DataFrame(rows)
link.to_csv(derived / "cambridge_centre_urn.csv", index=False)

# suppressed cells: lower/upper bounds and calibrated estimates (cam_cells), never summed as zero
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from cam_cells import MEASURES, estimate  # noqa: E402

est = estimate(cam, pd.read_csv(derived / "cambridge_school_type.csv"))
cc = est.merge(link[["centre_number", "urn"]], on="centre_number", how="inner").dropna(subset=["urn"])
flags = [f"{c}_{k}" for c in MEASURES for k in ("floor5", "lt3")]
for f in flags:
    cc[f] = cc[f].astype(str).str.lower().eq("true")
vals = [f"{c}_{k}" for c in MEASURES for k in ("lo", "hi", "est")]
agg = cc.groupby(["urn", "cycle"]).agg(**{v: (v, lambda s: s.sum(min_count=1)) for v in vals},
                                       **{f: (f, "any") for f in flags},
                                       n_centres=("centre_number", "nunique")).reset_index()
agg.to_csv(derived / "cambridge_school_cycle.csv", index=False)

# ---- gate G-join
eng = link[link.postcode.fillna("").str.len() > 0]
print(f"centres (Maintained+Independent) {len(link)}; linked {link.urn.notna().sum()} "
      f"({link.urn.notna().mean():.1%}); by method {link.method.value_counts().to_dict()}")
print("linked share by Cambridge sector:", link.groupby("cam_sector").urn.apply(lambda s: round(s.notna().mean(), 3)).to_dict())
mis = link[link.urn.notna() & ((link.cam_sector == "Independent") != (link.gias_sector == "independent"))]
print(f"sector disagreements (Cambridge Independent vs GIAS independent): {len(mis)}")
print(mis[["centre_name", "cam_sector", "gias_name", "gias_sector", "score"]].head(25).to_string(index=False))
ok = True
for f in ("top30_independent.csv", "top30_grammar.csv"):
    t = pd.read_csv(derived / f, dtype={"urn": str})
    linked = set(link.urn.dropna())
    missing = t[~t.urn.isin(linked)]
    print(f"{f}: {len(t) - len(missing)}/{len(t)} linked")
    if len(missing):
        ok = False
        print(missing[["rank", "urn", "name", "postcode"]].to_string(index=False))
eng_acc = est[est.sector.isin(["Maintained", "Independent"]) & (est.country == "England") & (est.cycle >= 2022)]
eng_acc = eng_acc.assign(linked=eng_acc.centre_number.isin(set(link.dropna(subset=["urn"]).centre_number)))
share = eng_acc.groupby("sector").apply(lambda g: g.loc[g.linked, "acceptances_est"].sum() / g.acceptances_est.sum())
print("linked share of English-centre acceptances, cycles 2022-2025 (estimates):", share.round(3).to_dict())
if (share < 0.95).any():
    ok = False
print("sample of links for hand review:")
print(link.dropna(subset=["urn"]).sample(20, random_state=7)[["centre_name", "postcode", "gias_name", "method", "score"]]
      .to_string(index=False))
print("G-join:", "PASS" if ok else "FAIL")
