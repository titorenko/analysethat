"""P3 step 1: choose the top-30 independent and top-30 grammar schools (PLAN v2 §4.4, decision D4).

Rule: DfE 16-18 'Academic' exam cohort (A level + IB etc.), aps_per_entry pooled over 2023/24 and 2024/25
(weighted by aps_per_entry_student_count), both years present with >= 40 students each.
Excluded: schools whose statutory low age is 14+ (sixth-form-only / 14-19 / 15-20 colleges).
Gate G-pool: Spearman rank correlation of 2023/24 vs 2024/25 APS within each sector's candidate set >= 0.8.

Usage: .venv/Scripts/python -I code/analysis/select_top30.py data/derived
Writes top30_independent.csv, top30_grammar.csv (ranks 1-45, top30 flag) to the same folder.
"""
import pathlib
import sys

import pandas as pd

derived = pathlib.Path(sys.argv[1])
ks5 = pd.read_csv(derived / "ks5_school.csv", dtype={"urn": str})
master = pd.read_csv(derived / "school_master.csv", dtype={"urn": str}, low_memory=False)
astar = pd.read_csv(derived / "ks5_astar_a_school.csv", dtype={"urn": str})
ks4 = pd.read_csv(derived / "ks4_school_2324.csv", dtype={"urn": str})

ac = ks5[(ks5.exam_cohort == "Academic") & ks5.time_period.isin(["2023/24", "2024/25"])].copy()
ac["aps"] = pd.to_numeric(ac.aps_per_entry, errors="coerce")
ac["n"] = pd.to_numeric(ac.aps_per_entry_student_count, errors="coerce")
ac = ac.dropna(subset=["aps", "n"])
wide = ac.pivot_table(index="urn", columns="time_period", values=["aps", "n"])
wide.columns = [f"{a}_{b[:4]}" for a, b in wide.columns]          # aps_2023, aps_2024, n_2023, n_2024
wide = wide.dropna()
wide = wide[(wide.n_2023 >= 40) & (wide.n_2024 >= 40)]
wide["aps_pooled"] = (wide.aps_2023 * wide.n_2023 + wide.aps_2024 * wide.n_2024) / (wide.n_2023 + wide.n_2024)
wide = wide.reset_index()

m = master[["urn", "name", "sector", "la_name", "london", "gender", "boarders", "statutory_low_age",
            "statutory_high_age", "pupils", "postcode"]]
wide = wide.merge(m, on="urn", how="left")
wide["low_age"] = pd.to_numeric(wide.statutory_low_age, errors="coerce")
excluded = wide[wide.low_age >= 14]
wide = wide[~(wide.low_age >= 14)]
# International / tutorial colleges (PLAN §4.4): independents whose 2024/25 A level VA coverage is below 0.5, i.e.
# most A level entries have no English KS4 baseline. Catches Abbey College Cambridge, DLD College and Concord
# College; Concord confirmed by ISI 2021 §1.1/1.8 ("an international co-educational day and boarding school",
# "The majority of boarders come from overseas"; data/raw/school_docs/2026-10-10/concord_isi_2021.pdf).
cov = ks5[(ks5.exam_cohort == "A level") & (ks5.time_period == "2024/25")].set_index("urn").va_coverage
intl = wide[(wide.sector == "independent") & wide.urn.map(cov).lt(0.5)]
wide = wide[~wide.urn.isin(intl.urn)]
wide.to_csv(derived / "ks5_eligible_pooled.csv", index=False)       # whole eligible universe, for P3 distributions

# 2024/25 extras: value added, its coverage and %AAB from the A level cohort row (coverage and AAB exist only
# there; same cohort as P2 and G4), %A*/A, KS4 sex mix
va = ks5[(ks5.exam_cohort == "A level") & (ks5.time_period == "2024/25")][
    ["urn", "value_added", "value_added_lower_ci", "value_added_upper_ci", "va_coverage", "aab_percent"]]
a = astar[astar.columns[astar.columns.isin(["urn", "year", "time_period", "qualification", "pct_astar_a"])]]
ycol = "time_period" if "time_period" in a.columns else "year"
a = a[(a[ycol].astype(str).str.contains("2024")) & (a.qualification.str.contains("A level", case=False))]
a = a[["urn", "pct_astar_a"]].drop_duplicates("urn")
sexcols = ["boys_count", "girls_count", "progress8", "progress8_lower_ci", "progress8_upper_ci", "pa_high_pct_of_known"]
k4 = ks4[["urn"] + sexcols]

out = {}
lines = []
for sector, label in (("independent", "independent"), ("selective", "grammar")):
    s = wide[wide.sector == sector].copy()
    rho = s[["aps_2023", "aps_2024"]].corr(method="spearman").iloc[0, 1]
    top = s.sort_values("aps_pooled", ascending=False).head(45).copy()
    rho_top = top[["aps_2023", "aps_2024"]].corr(method="spearman").iloc[0, 1]
    top["rank"] = range(1, len(top) + 1)
    top["top30"] = top["rank"] <= 30
    top["rank_2023"] = top.aps_2023.rank(ascending=False).astype(int)
    top["rank_2024"] = top.aps_2024.rank(ascending=False).astype(int)
    top = top.merge(va, on="urn", how="left").merge(a, on="urn", how="left").merge(k4, on="urn", how="left")
    cols = ["rank", "top30", "urn", "name", "la_name", "london", "gender", "boarders", "statutory_low_age",
            "statutory_high_age", "pupils", "postcode", "aps_pooled", "aps_2023", "aps_2024", "n_2023", "n_2024",
            "rank_2023", "rank_2024", "pct_astar_a", "aab_percent", "value_added", "value_added_lower_ci",
            "value_added_upper_ci", "va_coverage"] + sexcols
    top[cols].to_csv(derived / f"top30_{label}.csv", index=False)
    out[label] = top
    ok = rho >= 0.8
    lines.append(f"- {'PASS' if ok else 'FAIL'} G-pool {label}: Spearman 2023/24 vs 2024/25 APS, all {len(s)} "
                 f"eligible schools rho={rho:.3f}; within the top 45 rho={rho_top:.3f}")
    movers = top[(top.rank_2023 - top.rank_2024).abs() >= 10]
    for _, r in movers.iterrows():
        lines.append(f"  mover: {r['name']} rank {r.rank_2023}->{r.rank_2024} within top-45 set")

lines.append("- info excluded (international/tutorial college, VA coverage < 0.5): " + "; ".join(intl.name))
lines.append(f"- info excluded (statutory low age >= 14): " +
             "; ".join(f"{r['name']} ({int(r.low_age)}-{r.statutory_high_age}, {r.sector})" for _, r in excluded.iterrows()
                       if r.sector in ("independent", "selective")))
print("\n".join(lines))
print("G-pool:", "PASS" if all(l.startswith("- PASS") for l in lines if "G-pool" in l) else "FAIL")
for label, t in out.items():
    print(f"\nTop 30 {label}:")
    print(t[t.top30][["rank", "name", "aps_pooled", "aps_2023", "aps_2024", "value_added", "pct_astar_a"]]
          .to_string(index=False))
