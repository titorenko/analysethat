"""Shared helpers for Cambridge apply-centre rows: suppressed-cell bounds and estimates, and country from postcode.

Suppression (data/derived/cambridge_apply_centre.md):
- lt3 (2013-2023): empty cell printed '<3'. Applications 1-2; offers and acceptances 0-2.
- floor5 (2024-2025): printed 5 means 1-5.
Estimate for a suppressed cell = calibrated mean per suppressed cell for that cycle x sector x measure:
(school-type table total, Home + Other blocks, minus the sum of exact cells) / number of suppressed cells,
clipped to the cell's bounds. Same calibration as gate G2. 'Other and Overseas' has no usable total
(applicants without a centre are in the table only), and the 2013 school-type table has no offers column,
so those cells get the bounds' midpoint.
"""
import re

import pandas as pd

MEASURES = ("applications", "offers", "acceptances")
SCOTLAND = {"AB", "DD", "DG", "EH", "FK", "G", "HS", "IV", "KA", "KW", "KY", "ML", "PA", "PH", "TD", "ZE"}
WALES = {"CF", "LD", "LL", "NP", "SA"}


def country(pc):
    """England / Wales / Scotland / NI / Crown / unknown from a UK postcode (area + the border districts)."""
    pc = re.sub(r"\s+", "", str(pc).upper()) if isinstance(pc, str) else ""
    m = re.match(r"^([A-Z]{1,2})(\d{1,2})", pc)
    if not m or len(pc) < 5:
        return "unknown"
    area, district = m.group(1), int(m.group(2))
    if area == "BT":
        return "NI"
    if area in ("GY", "JE", "IM"):
        return "Crown"
    if area in WALES or (area == "SY" and district >= 15) or (area == "CH" and 5 <= district <= 8):
        return "Wales"
    if area in SCOTLAND and not (area == "TD" and district == 15):
        return "Scotland"
    return "England"


def estimate(ac, school_type):
    """Add <m>_lo, <m>_hi, <m>_est to apply-centre rows (ac: cambridge_apply_centre.csv read as str)."""
    ac = ac.copy()
    ac["cycle"] = ac.cycle.astype(int)
    st = school_type[school_type.block.isin(["home", "other"]) & (school_type.level == "sector")]
    tot = st.groupby(["cycle", "school_type"])[list(MEASURES)].sum(min_count=1)
    for m in MEASURES:
        v = pd.to_numeric(ac[m], errors="coerce")
        lt3 = ac[f"{m}_lt3"].astype(str).str.lower().eq("true")
        f5 = ac[f"{m}_floor5"].astype(str).str.lower().eq("true")
        sup = lt3 | f5
        lo = v.where(~sup, 1.0 if m == "applications" else 0.0)
        lo = lo.where(~f5, 1.0)
        hi = v.where(~sup, 2.0).where(~f5, 5.0)
        est = v.where(~sup)
        for (cyc, sec), idx in ac[sup].groupby(["cycle", "sector"]).groups.items():
            lo_i, hi_i = lo.loc[idx], hi.loc[idx]
            mean = (lo_i + hi_i) / 2
            if sec != "Other and Overseas" and (cyc, sec) in tot.index and pd.notna(tot.loc[(cyc, sec), m]):
                exact = v[(ac.cycle == cyc) & (ac.sector == sec) & ~sup].sum()
                mean = pd.Series((tot.loc[(cyc, sec), m] - exact) / len(idx), index=idx)
            est.loc[idx] = mean.clip(lo_i, hi_i)
        ac[f"{m}_lo"], ac[f"{m}_hi"], ac[f"{m}_est"] = lo, hi, est
    ac["country"] = ac.postcode.map(country)
    return ac
