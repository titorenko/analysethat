"""PLAN v2 §4.2.2-4.2.3: the adjusted comparisons possible in public data for today's pupils.

Usage: .venv/Scripts/python -I code/analysis/p4_adjusted_public.py data/derived results
Writes results/p4_progress8_by_sector.csv and results/p4_ons_ks4_bands.csv.

- Progress 8, 2023/24 (KS2-adjusted, so ADJ-PRE for 11-16 attainment): pupil-weighted mean and school spread by
  sector. Partially selective schools are their own sector. Independents mostly have no P8 (no KS2 baseline, and
  IGCSEs do not count), so they are reported as coverage only.
- ONS (2022) Figure 5: mean PAYE earnings at 30 within KS4 attainment quintiles, independent vs state non-FSM vs FSM
  (ADJ-MED: conditions on GCSE results, which are themselves partly a school outcome).
"""
import pathlib
import sys

import pandas as pd

D, R = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
k4 = pd.read_csv(D / "ks4_school_2324.csv", dtype={"urn": str})
m = pd.read_csv(D / "school_master.csv", dtype={"urn": str}, low_memory=False)[["urn", "sector"]]
ps = pd.read_csv(D / "partially_selective.csv", dtype={"urn": str})
m.loc[m.urn.isin(ps[ps.classification == "partially_selective"].urn), "sector"] = "partially_selective"
k4 = k4.merge(m, on="urn", how="left")
for c in ("progress8", "progress8_pupils", "attainment8", "pupils", "pa_high_pct_of_known"):
    k4[c] = pd.to_numeric(k4[c], errors="coerce")
rows = []
for sec, g in k4.groupby("sector"):
    v = g.dropna(subset=["progress8", "progress8_pupils"])
    rows.append({"sector": sec, "schools": g.urn.nunique(), "schools_with_p8": v.urn.nunique(),
                 "p8_pupil_weighted": (v.progress8 * v.progress8_pupils).sum() / v.progress8_pupils.sum()
                 if len(v) else None,
                 "p8_p10": v.progress8.quantile(0.1) if len(v) else None,
                 "p8_p50": v.progress8.median() if len(v) else None,
                 "p8_p90": v.progress8.quantile(0.9) if len(v) else None,
                 "attainment8_pupil_weighted": (g.dropna(subset=["attainment8", "pupils"]).pipe(
                     lambda x: (x.attainment8 * x.pupils).sum() / x.pupils.sum())),
                 "pa_high_pct_median": g.pa_high_pct_of_known.median()})
p8 = pd.DataFrame(rows)
p8.to_csv(R / "p4_progress8_by_sector.csv", index=False)

ons = pd.read_csv(D / "ons_fsm_age_ks4.csv")
o = ons[ons.age == 30].pivot_table(index="ks4_quintile", columns="group", values="mean_earnings_gbp_apr2019")
o["ratio_independent_to_non_fsm"] = o.independent / o.state_non_fsm
o["ratio_non_fsm_to_fsm"] = o.state_non_fsm / o.state_fsm
o.reset_index().to_csv(R / "p4_ons_ks4_bands.csv", index=False)

pd.set_option("display.width", 200)
print(p8.round(2).to_string(index=False))
print("\nONS mean PAYE earnings at 30 within KS4 quintile (April 2019 prices):")
print(o.round(2).to_string())
