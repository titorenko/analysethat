"""Bottom 20 private schools open to boys and to girls, and bottom 30 grammar schools (user request, 2026-10-10).

Same universe and ranking as select_top30.py / select_top20_sex.py: ks5_eligible_pooled.csv (Academic cohort, pooled
APS 2023/24-2024/25, >= 40 students each year, no sixth-form-only or international colleges), lowest points first.
Open to boys: DfE sex policy Boys or Mixed; open to girls: Girls or Mixed. At the bottom of the private ranking
every school is Mixed in both DfE and GIAS records, so the two bottom-20 lists coincide; the girls' entry ages of
these schools were not checked one by one (the top-20 check, coed_entry.csv, found sixth-form-only girls' entry only
at former boys' schools at the top of the ranking). Schools that GIAS records as closed are left out (a family can no
longer choose them); they are written to bottom_closed_excluded.csv.

Usage: .venv/Scripts/python -I code/analysis/select_bottom.py data/derived
Writes bottom20_private.csv (rank 1 = lowest, open_to_boys / open_to_girls flags) and bottom30_grammar.csv.
"""
import pathlib
import sys

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import latest_raw  # noqa: E402

D = pathlib.Path(sys.argv[1])
info = pd.read_csv(latest_raw("dfe_ks5", "ks5_institution_info_v*.csv"), dtype=str)
info = info[["school_urn", "sex_policy", "age_range"]].drop_duplicates("school_urn").rename(columns={"school_urn": "urn"})
uni = pd.read_csv(D / "ks5_eligible_pooled.csv", dtype={"urn": str})
gias = pd.read_csv(latest_raw("gias", "edubasealldata*.csv"), dtype=str, encoding="cp1252",
                   usecols=["URN", "EstablishmentStatus (name)", "CloseDate"])
closed = gias[gias["EstablishmentStatus (name)"] == "Closed"].rename(columns={"URN": "urn", "CloseDate": "close_date"})
cols = ["rank", "urn", "name", "sex_policy", "gender", "age_range", "la_name", "aps_pooled", "aps_2023", "aps_2024",
        "n_2023", "n_2024"]

ind = uni[uni.sector == "independent"].merge(info, on="urn", how="left").sort_values("aps_pooled")
gra = uni[uni.sector == "selective"].merge(info, on="urn", how="left").sort_values("aps_pooled")
# closed schools that would otherwise fall in the bottom lists
cut = pd.concat([ind[ind.sex_policy.isin(["Boys", "Mixed"])].head(20), ind[ind.sex_policy.isin(["Girls", "Mixed"])].head(20),
                 gra.head(30)]).drop_duplicates("urn")
cut[cut.urn.isin(closed.urn)].merge(closed[["urn", "close_date"]], on="urn")[["urn", "name", "sector", "close_date"]].to_csv(
    D / "bottom_closed_excluded.csv", index=False)
ind, gra = ind[~ind.urn.isin(closed.urn)], gra[~gra.urn.isin(closed.urn)]
boys = ind[ind.sex_policy.isin(["Boys", "Mixed"])].head(20)
girls = ind[ind.sex_policy.isin(["Girls", "Mixed"])].head(20)
both = pd.concat([boys, girls]).drop_duplicates("urn").sort_values("aps_pooled").copy()
both["open_to_boys"] = both.urn.isin(boys.urn)
both["open_to_girls"] = both.urn.isin(girls.urn)
both["rank"] = range(1, len(both) + 1)
assert (both.gender == "Mixed").all() and (both.sex_policy == "Mixed").all()
both[cols + ["open_to_boys", "open_to_girls"]].to_csv(D / "bottom20_private.csv", index=False)
same = set(boys.urn) == set(girls.urn)
print(f"bottom 20 open to boys and to girls identical: {same}; {len(both)} schools; all Mixed: "
      f"{(both.sex_policy == 'Mixed').all()}")

gra = gra.head(30).copy()
gra["rank"] = range(1, len(gra) + 1)
gra[cols].to_csv(D / "bottom30_grammar.csv", index=False)
print(gra[["rank", "name", "aps_pooled"]].round(1).to_string(index=False))
