"""P4: premium schedules for P5/P6 (PLAN v2 §4.2.5-4.2.6), from the quote-verified evidence table.

Usage: .venv/Scripts/python -I code/analysis/p4_bridge.py data/derived results
Writes results/p4_premiums.csv (route x school type x sex x scenario x age, log points) and
results/p4_premium_anchors.csv (every anchor value with its evidence row_id).

The cohort bridge can only split the 1970-cohort premium into "through education" and "remaining" (no BCS70 table
separates degree, university type or subject; the industry step comes from the Skills and Employment Survey, which
has no ability control). The split is descriptive: education is itself an outcome of schooling, so the remainder is
not a direct effect. The schedules therefore bracket the premium with three named scenarios rather than adding up
channels.

Private, 11-18 (13-18 identical: Next Steps measures private at 13; 7-18 identical: no evidence on prep schools)
- high ("1970 cohort unchanged"): Next Steps background-adjusted 0.159 at 25 (the only early-career point), BCS70
  ADJ-PRE at 34 (GMMZ: men 0.184, women 0.244) and at 42 (GHV: men 0.297; women 0.192, so the women's upper
  envelope keeps 0.244 from 34); linear between points, flat outside them.
- central ("Next Steps, held flat"): 0.159 at every age (t = 2.83, so SE 0.056; the 95% bounds are kept as
  scenarios central_lo95 and central_hi95). Assumes the 1970 cohort's rise with age is offset by a
  smaller education channel for today's pupils (MCS: private GCSE edge 0.05 of a grade after SES, ~0).
- low ("no education channel"): the graduate-only premium after A levels, degree class, institution and subject
  (Crawford & Vignoles, 2006/07 graduates at 3.5 years): men 0.091, women 0.046, flat. A zero causal effect is not
  ruled out either; the write-up says so.
Private, 16-18 only: low 0; central 0.02 (Henderson: +0.09 HE given GCSE, priced at the IFS gross degree return of
  20% = 0.18 lp); high 0.062 (the whole Next Steps education channel, 0.159 - 0.0975).
Grammar vs non-selective, 11-18: low 0; central 0 (the regression-discontinuity estimates for marginal pupils:
  Clark & Del Bono 2SLS log annual income men -0.066, Pastore & Jones log hourly +0.069 with SE 0.167); high men
  0.086 (Dearden et al. ADJ-PRE hourly, an upper bound given the Manning-Pischke placebo), women 0.074 (Clark & Del
  Bono 2SLS log hourly wage; their log annual income figure, 0.158, also moves hours, which the engine holds fixed).
  All from cohorts whose alternative was usually a secondary modern.

Measures differ: GMMZ and GHV are hourly, Next Steps weekly, Crawford & Vignoles annual. The engine applies each as a
percentage of annual pay (exp(lp) - 1), assuming school type changes neither hours nor employment.
"""
import math
import pathlib
import sys

import pandas as pd

D, R = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
ev = pd.read_csv(D / "evidence_table.csv").set_index("row_id")
AGES = range(22, 68)


def a(row_id, expect, sex=None, estimand=None):
    """Anchor value from the evidence table, asserted against the value this script was written for."""
    r = ev.loc[row_id]
    assert r.status == "verified", (row_id, r.status)
    assert abs(r.estimate - expect) < 1e-9, (row_id, r.estimate, expect)
    if sex:
        assert r.sex == sex, (row_id, r.sex)
    if estimand:
        assert r.estimand == estimand, (row_id, r.estimand)
    anchors.append({"row_id": row_id, "study": r.study, "cohort": r.cohort, "outcome": r.outcome, "age": r.age,
                    "sex": r.sex, "estimand": r.estimand, "estimate_lp": r.estimate})
    return r.estimate


def interp(points):
    """Piecewise-linear in age through (age, value) points, flat outside them."""
    pts = sorted(points)
    out = {}
    for age in AGES:
        if age <= pts[0][0]:
            out[age] = pts[0][1]
        elif age >= pts[-1][0]:
            out[age] = pts[-1][1]
        else:
            (x0, y0), (x1, y1) = next(((p, q) for p, q in zip(pts, pts[1:]) if p[0] <= age <= q[0]))
            out[age] = y0 + (age - x0) / (x1 - x0) * (y1 - y0)
    return out


anchors = []
ns = a("GAHH2020-02", 0.159, "all", "ADJ-PRE")
ns_after_edu = a("GAHH2020-03", 0.0975, "all", "ADJ-MED")
assert "(2.83)" in ev.loc["GAHH2020-02"].quote          # t statistic printed under the coefficient
ns_se = ns / 2.83
gmmz34 = {"men": a("GMMZ2012-22", 0.184, "men", "ADJ-PRE"), "women": a("GMMZ2012-24", 0.244, "women", "ADJ-PRE")}
ghv42 = {"men": a("GHV2017-04", 0.297, "men", "ADJ-PRE"), "women": a("GHV2017-13", 0.192, "women", "ADJ-PRE")}
cv = {"men": a("CV2014-19", 0.091, "men", "ADJ-MED"), "women": a("CV2014-23", 0.046, "women", "ADJ-MED")}
he_first_stage = a("HAGH2020-03", 0.09)
grammar_hi = {"men": a("DFM2002-04", 0.086, "men", "ADJ-PRE"), "women": a("CDB2016-15", 0.0741, "women", "ADJ-PRE")}
a("CDB2016-03", -0.0655, "men", "ADJ-PRE")
a("CDB2016-07", 0.158, "women", "ADJ-PRE")
a("PJ2023-03", 0.0693, "all", "ADJ-PRE")
assert "£148k 20% £215k 20%" in ev.loc["IFS2026-04"].quote    # IFS 2026 Table 5.1: gross earnings return 20%
degree_return_lp = math.log(1.20)

rows = []


def add(route, school, sex, scenario, sched, basis):
    for age, v in sched.items():
        rows.append({"route": route, "school_type": school, "sex": sex, "scenario": scenario, "age": age,
                     "premium_lp": v, "premium_pct": math.exp(v) - 1, "basis": basis})


for sex in ("men", "women"):
    hi42 = ghv42[sex] if sex == "men" else max(ghv42["women"], gmmz34["women"])
    high = interp([(25, ns), (34, gmmz34[sex]), (42, hi42)])
    for route in ("11-18", "13-18", "7-18"):
        add(route, "private", sex, "high", high, "1970 cohort unchanged (Next Steps 25; BCS70 34, 42)")
        add(route, "private", sex, "central", {g: ns for g in AGES}, "Next Steps at 25, flat")
        add(route, "private", sex, "central_lo95", {g: ns - 1.96 * ns_se for g in AGES}, "central, lower 95% bound")
        add(route, "private", sex, "central_hi95", {g: ns + 1.96 * ns_se for g in AGES}, "central, upper 95% bound")
        add(route, "private", sex, "low", {g: cv[sex] for g in AGES}, "graduate-only premium after education")
    add("16-18", "private", sex, "low", {g: 0.0 for g in AGES}, "zero")
    add("16-18", "private", sex, "central", {g: he_first_stage * degree_return_lp for g in AGES},
        "Henderson HE first stage x IFS degree return")
    add("16-18", "private", sex, "high", {g: ns - ns_after_edu for g in AGES}, "Next Steps education channel")
    add("11-18", "grammar", sex, "low", {g: 0.0 for g in AGES}, "zero")
    add("11-18", "grammar", sex, "central", {g: 0.0 for g in AGES}, "RD estimates about zero")
    add("11-18", "grammar", sex, "high", {g: grammar_hi[sex] for g in AGES}, "upper bound (placebo > effect)")

out = pd.DataFrame(rows)
out.to_csv(R / "p4_premiums.csv", index=False)
pd.DataFrame(anchors).drop_duplicates("row_id").to_csv(R / "p4_premium_anchors.csv", index=False)
pd.set_option("display.width", 200)
show = out[out.age.isin([25, 34, 42, 55])]
print(show.assign(pct=(100 * show.premium_pct).round(1)).pivot_table(
    index=["school_type", "route", "sex", "scenario"], columns="age", values="pct").to_string())
