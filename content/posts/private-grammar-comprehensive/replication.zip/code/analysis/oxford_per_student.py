"""Oxford by sixth-form sector: acceptances per 1,000 A-level students (England) and offer rates, from the
apply-centre dashboard (data/derived/oxford_apply_centre*.csv). The Oxford counterpart of p2_national.py §2b.

Usage: .venv/Scripts/python -I code/analysis/oxford_per_student.py data/derived results
Writes results/p2_oxford_per_student_england.csv and results/p2_oxford_sector_rates.csv.

Sector of a centre: Oxford's school type (State / Independent); State centres are split into grammar
(selective_state) and other state through the UCAS centre number -> URN link built for Cambridge
(cambridge_centre_urn.csv, gate G-join) and the DfE sector in school_master.csv ('selective'). Unlinked
State centres count as other state. Country from postcode (cam_cells.country): England only, like WP.

Suppressed cells (<3; applications 1-2, offers and acceptances 0-2) get lower and upper bounds and an
estimate. The averages differ by group: most suppressed State cells are tiny colleges, grammar ones are larger,
so one mean for all would understate grammars (it did: summed 2023-25 grammar estimates fell below the
dashboard's own 3-year total; review by Fable, 2026-11-07). So the 2023-25 total is used centre by centre:
- 2023, 2024, 2025: a centre whose 3-year total is shown has known suppressed mass R = total - shown years,
  shared over its k suppressed cells (each in [max(lo, R-(k-1)hi), min(hi, R-(k-1)lo)]). A centre whose total
  is suppressed has every year suppressed and R in [lo, 2]; its estimate is one per-centre value calibrated
  so that UK State centres sum to Table 4.1 of the annual report for 2023-25, as cam_cells does for Cambridge.
  Table 4.1 counts UK-domiciled applicants, narrower than the dashboard's independent centres (overseas pupils
  at UK schools), so it cannot calibrate Independent; independent centres get the State value, and their
  bounds stay wide (322 independent centres have suppressed 3-year totals).
- 2021, 2022 (no total): each group's mean estimate per suppressed cell in 2023-25; lo/hi use the group's mean
  lower and upper bounds per cell in 2023-25 (an assumption that the mix is stable, not a hard bound). The
  UK State sums are printed next to Table 4.1 as a check of that assumption.
  In 2021 and 2022 this undershoots Table 4.1's UK State acceptances by 5.3% and 2.8%; giving the whole
  shortfall to grammars would raise them to 20.9 and 18.9 per 1,000, still below Cambridge. Column bounds_hard
  marks which rows have hard bounds.
- 2023-25 total rows: a suppressed total gets the sum of the centre's single-year estimates.
Calibration to Table 4.1 is exact for offers and acceptances; for applications the 1-per-cell floor makes UK
State sums 0.3-0.5% higher than the report.

Denominator: WP A-level cohort by sixth-form sector, cycle = age-15 cohort + 3 (2021-2023 only), as for Cambridge.
'independent_uk_dom' rescales the independent numerator by Table 4.1 admitted / dashboard UK independent
acceptances (removes non-UK-domiciled pupils, assuming the same share at English and other UK centres).
"""
import pathlib
import sys

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from cam_cells import country, estimate  # noqa: E402

D = pathlib.Path(sys.argv[1])
R = pathlib.Path(sys.argv[2])
M = ["applications", "offers", "acceptances"]
REPORT = {"applications": "applications", "offers": "offers", "acceptances": "admitted"}
pd.set_option("display.width", 200)

kw = dict(dtype={"cycle": str, "centre_number": str}, keep_default_na=False, na_values=[""])
ox = pd.concat([pd.read_csv(D / "oxford_apply_centre.csv", **kw),
                pd.read_csv(D / "oxford_apply_centre_2023_2025.csv", **kw)], ignore_index=True)
link = pd.read_csv(D / "cambridge_centre_urn.csv", dtype=str)[["centre_number", "urn"]]
master = pd.read_csv(D / "school_master.csv", dtype=str, low_memory=False)[["urn", "sector"]]
ox = ox.merge(link, on="centre_number", how="left").merge(master, on="urn", how="left")
ox["country"] = ox.postcode.map(country)
ox["group"] = ox.school_type.map({"Independent": "independent", "State": "other_state"})
ox.loc[(ox.school_type == "State") & (ox.sector == "selective"), "group"] = "selective_state"
rep = pd.read_csv(D / "oxford_school_type.csv", dtype={"cycle": str})
rep = rep[rep.latest_vintage].set_index(["cycle", "school_type"])

# bounds and estimates per cell
uk = ox.postcode != "Non-UK"
years3 = ox.cycle.isin(["2023", "2024", "2025"])
tot = ox[ox.cycle == "2023-2025"].set_index("centre_number")
for m in M:
    sup = ox[m].isna()
    c_lo = 1.0 if m == "applications" else 0.0
    lo, hi, est = ox[m].where(~sup, c_lo), ox[m].where(~sup, 2.0), ox[m].astype(float)
    # 2023-25 single years: residual of the 3-year total per centre
    k = (years3 & sup).groupby(ox.centre_number).transform("sum")
    shown = ox[m].where(years3, 0).fillna(0).groupby(ox.centre_number).transform("sum")
    t = ox.centre_number.map(tot[m])
    known = years3 & sup & t.notna()
    r = t - shown
    lo[known] = (r - (k - 1) * 2.0).clip(lower=c_lo)[known]
    hi[known] = (r - (k - 1) * c_lo).clip(upper=2.0)[known]
    est[known] = (r / k)[known]
    open_ = years3 & sup & t.isna()                      # total suppressed: centre's 3-year sum R in [c_lo, 2]
    hi[open_] = (2.0 - (k - 1) * c_lo)[open_]
    # calibrate one per-centre R for open centres so UK State 2023-25 matches Table 4.1
    st3 = years3 & uk & (ox.school_type == "State")
    report = sum(rep.loc[(y, "state"), REPORT[m]] for y in ("2023", "2024", "2025"))
    n_open = ox.loc[st3 & open_, "centre_number"].nunique()
    r_open = (report - ox.loc[st3 & ~sup, m].sum() - est[st3 & known].sum()) / n_open
    assert c_lo <= r_open <= 2.0, (m, r_open)
    est[open_] = (r_open / k)[open_].clip(lo[open_], hi[open_])
    ox[f"{m}_lo"], ox[f"{m}_hi"], ox[f"{m}_est"] = lo, hi, est
    # 3-year total rows
    t3 = (ox.cycle == "2023-2025") & sup
    ox.loc[t3, f"{m}_est"] = ox[t3].centre_number.map(est[open_].groupby(ox.centre_number).sum())
    # 2021-22: group means per suppressed cell from 2023-25
    for g, gi in ox[years3 & sup].groupby("group").groups.items():
        means = {x: ox.loc[gi, f"{m}_{x}"].mean() for x in ("lo", "est", "hi")}
        idx = ox.cycle.isin(["2021", "2022"]) & sup & (ox.group == g)
        for x, v in means.items():
            ox.loc[idx, f"{m}_{x}"] = v
        print(f"{m:12s} {g:16s} mean per suppressed cell 2023-25: {means['est']:.2f} "
              f"[{means['lo']:.2f}, {means['hi']:.2f}]")
    e = ox[f"{m}_est"].notna()
    assert (ox.loc[e, f"{m}_lo"] <= ox.loc[e, f"{m}_est"] + 1e-9).all() and (ox.loc[e, f"{m}_est"] <= ox.loc[e, f"{m}_hi"] + 1e-9).all()
for cyc in ("2021", "2022", "2023", "2024", "2025"):
    st = (ox.cycle == cyc) & uk & (ox.school_type == "State")
    print(f"  UK State {cyc}: estimated " + ", ".join(
        f"{m} {ox.loc[st, m + '_est'].sum():.0f} vs report {rep.loc[(cyc, 'state'), REPORT[m]]}" for m in M))

# offer and acceptance rates per applicant by sector, England, all cycles
eng = ox[(ox.country == "England") & ox.group.notna()]
agg = {f"{m}_{k}": (f"{m}_{k}", "sum") for m in M for k in ("lo", "est", "hi")}
agg.update({"centres": ("centre_number", "nunique")})
rates = eng.groupby(["cycle", "group"]).agg(**agg).reset_index()
rates["offer_rate_est"] = 100 * rates.offers_est / rates.applications_est
rates["offer_rate_lo"] = 100 * rates.offers_lo / rates.applications_hi
rates["offer_rate_hi"] = 100 * rates.offers_hi / rates.applications_lo
rates["acceptance_rate_est"] = 100 * rates.acceptances_est / rates.applications_est
rates.to_csv(R / "p2_oxford_sector_rates.csv", index=False)

# per 1,000 A-level students, 2021-2023
wp = pd.read_csv(D / "wp_school_type.csv")
wp = wp[(wp.student_group == "a_level") & (wp.by_age == 19) & (wp.school_type_at_17 != "total")].copy()
wp["cycle"] = (wp.cohort_age15.str[:4].astype(int) + 3).astype(str)
cohort = wp.pivot_table(index="cycle", columns="school_type_at_17", values="cohort_students")
cam = pd.read_csv(R / "p2_cambridge_per_student_england.csv", dtype={"cycle": str}).set_index(["cycle", "sector"])
# Cambridge grammar on the same basis as Oxford (URN-linked DfE-selective centres); p2's figure uses UCAS's
# self-declared 'Grammar School' type minus NI, which comes out 5-6% higher
ac = estimate(pd.read_csv(D / "cambridge_apply_centre.csv", dtype=str), pd.read_csv(D / "cambridge_school_type.csv"))
ac = ac.merge(link, on="centre_number", how="left").merge(master, on="urn", how="left")
ac["group"] = ac.sector_x.map({"Independent": "independent", "Maintained": "other_state"})
ac.loc[(ac.sector_x == "Maintained") & (ac.sector_y == "selective"), "group"] = "selective_state"
ac["cycle"] = ac.cycle.astype(str)
cam_urn = ac[(ac.country == "England") & (ac.group == "selective_state")].groupby("cycle").acceptances_est.sum()

# both universities on the same basis (England centres, grammar by URN), for the write-up's comparison
# Imperial (imperial_apply_centre.csv, not suppressed, cycles 2020-2024): no postcodes, so England = a school or
# college centre whose number has an English postcode in the Oxford or Cambridge tables, or, if neither lists it,
# any school/college type other than Welsh, Scottish or NI schools. Private = 'Independent schools'.
imp = pd.read_csv(D / "imperial_apply_centre.csv", dtype={"centre_number": str})
imp["cycle"] = imp.cycle.astype(str)
SCHOOL = {"Academies", "Colleges", "Free Schools", "Further Education College", "Independent schools",
          "Local authority maintained schools", "UK School"}
imp = imp[imp.centre_type.isin(SCHOOL)].merge(link, on="centre_number", how="left").merge(master, on="urn", how="left")
known = pd.concat([ac[["centre_number", "country"]], ox[["centre_number", "country"]]]).drop_duplicates("centre_number")
imp["country"] = imp.centre_number.map(known.set_index("centre_number").country).fillna("England")
imp["group"] = "other_state"
imp.loc[imp.centre_type == "Independent schools", "group"] = "independent"
imp.loc[(imp.group == "other_state") & (imp.sector == "selective"), "group"] = "selective_state"
for m in M:
    imp[f"{m}_est"] = imp[m].astype(float)

same = []
for uni, d in (("Oxford", eng), ("Cambridge", ac[(ac.country == "England") & ac.group.notna()]),
               ("Imperial", imp[imp.country == "England"])):
    d = d[d.cycle.isin(["2020", "2021", "2022", "2023", "2024", "2025"])]
    a = d.groupby(["cycle", "group"])[[f"{m}_est" for m in M]].sum().reset_index()
    a.insert(0, "university", uni)
    same.append(a)
same = pd.concat(same, ignore_index=True)
same["a_level_students"] = [cohort.at[c, g] if c in cohort.index else None for c, g in zip(same.cycle, same.group)]
same["per_1000"] = 1000 * same.acceptances_est / same.a_level_students
same["acceptances_per_application_pct"] = 100 * same.acceptances_est / same.applications_est
same.to_csv(R / "p2_oxbridge_same_basis.csv", index=False)
print("\nSame basis, England (grammar = DfE-selective URN): places per 1,000 A-level students / places per application, %")
print(same.pivot_table(index=["university", "cycle"], columns="group",
                       values=["per_1000", "acceptances_per_application_pct"]).round(1).to_string())
out = []
for cyc in sorted(set(rates.cycle) & set(cohort.index)):
    r = rates[rates.cycle == cyc].set_index("group")
    ukind = ox[(ox.cycle == cyc) & uk & (ox.school_type == "Independent")].acceptances_est.sum()
    for g in ("independent", "selective_state", "other_state"):
        n = cohort.loc[cyc, g]
        row = {"cycle": cyc, "sector": g, "a_level_students": n, "bounds_hard": cyc not in ("2021", "2022"),
               "acceptances_lo": r.at[g, "acceptances_lo"], "acceptances_est": r.at[g, "acceptances_est"],
               "acceptances_hi": r.at[g, "acceptances_hi"]}
        for k in ("lo", "est", "hi"):
            row[f"per_1000_{k}"] = 1000 * row[f"acceptances_{k}"] / n
        if g == "independent":
            row["per_1000_uk_dom"] = row["per_1000_est"] * rep.loc[(cyc, "independent"), "admitted"] / ukind
        row["cambridge_per_1000_p2"] = cam.loc[(cyc, g), "per_1000_england"]
        row["cambridge_per_1000"] = (1000 * cam_urn[cyc] / n if g == "selective_state"
                                     else row["cambridge_per_1000_p2"])
        out.append(row)
out = pd.DataFrame(out)
out.to_csv(R / "p2_oxford_per_student_england.csv", index=False)

print("\nOxford acceptances per 1,000 A-level students, England (estimate [range]), with Cambridge (grammar by URN):")
for _, x in out.iterrows():
    extra = f"  UK-domiciled approx {x.per_1000_uk_dom:.1f}" if x.sector == "independent" else ""
    print(f"  {x.cycle} {x.sector:16s} {x.per_1000_est:5.1f} [{x.per_1000_lo:5.1f}, {x.per_1000_hi:5.1f}]"
          f"{extra}   Cambridge {x.cambridge_per_1000:5.1f} (p2 {x.cambridge_per_1000_p2:5.1f})")
print("\nOxford offer rate per applicant, England centres, % (estimate [bounds]):")
for _, x in rates.iterrows():
    print(f"  {x.cycle:9s} {x.group:16s} {x.offer_rate_est:5.1f} [{x.offer_rate_lo:5.1f}, {x.offer_rate_hi:5.1f}]"
          f"  apps {x.applications_est:7.0f}  offers {x.offers_est:6.0f}  acceptances {x.acceptances_est:6.0f}"
          f"  ({x.centres} centres)")

