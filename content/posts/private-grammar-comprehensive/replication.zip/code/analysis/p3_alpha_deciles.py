"""A-level "alpha" (16-18 value added, A level cohort 2024/25) by tenths (user request, 2026-10-10).

Table A: value added at each tenth of schools (P10 ... P90), by kind of school.
Table B: schools of each kind sorted into ten equal groups by A-level points per entry (pooled 2023/24-2024/25),
group 1 = the top tenth; for each group the average points, the average value added across schools, and the share
of schools whose value-added range (95%) is above zero.

Universe: p3_universe.csv (the eligible sixth forms of select_top30.py; partially selective schools are their own
sector). Schools without a value-added figure are left out of the value-added columns.

Usage: .venv/Scripts/python -I code/analysis/p3_alpha_deciles.py results
Writes results/p3_alpha_quantiles.csv and results/p3_alpha_by_results_decile.csv.
"""
import pathlib
import sys

import pandas as pd

R = pathlib.Path(sys.argv[1])
u = pd.read_csv(R / "p3_universe.csv")
SECTORS = {"independent": "Private", "selective": "Grammar", "non_selective_other": "Comprehensive",
           "non_selective_highly_selective_area": "Non-selective, grammar areas", "partially_selective": "Partially selective"}

qa = []
for sec, lab in SECTORS.items():
    v = u[u.sector == sec].value_added.dropna()
    row = {"sector": sec, "label": lab, "schools": len(v)}
    row.update({f"p{q}": v.quantile(q / 100) for q in range(10, 100, 10)})
    qa.append(row)
qa = pd.DataFrame(qa)
qa.to_csv(R / "p3_alpha_quantiles.csv", index=False)

rows = []
for sec in ("independent", "selective", "non_selective_other"):
    g = u[(u.sector == sec)].dropna(subset=["aps_pooled"]).copy()
    # rank by points, best first; ten groups as equal in size as possible
    g["decile"] = pd.qcut(g.aps_pooled.rank(ascending=False, method="first"), 10, labels=range(1, 11)).astype(int)
    for d, x in g.groupby("decile"):
        xv = x.dropna(subset=["value_added"])
        rows.append({"sector": sec, "label": SECTORS[sec], "decile": d, "schools": len(x), "schools_with_va": len(xv),
                     "aps_mean": x.aps_pooled.mean(), "aps_min": x.aps_pooled.min(), "aps_max": x.aps_pooled.max(),
                     "va_mean": xv.value_added.mean(),
                     "share_va_ci_above_0": (xv.value_added_lower_ci > 0).mean()})
td = pd.DataFrame(rows)
td.to_csv(R / "p3_alpha_by_results_decile.csv", index=False)

pd.set_option("display.width", 220)
print(qa.round(2).to_string(index=False))
print(td.pivot_table(index="decile", columns="label", values=["aps_mean", "va_mean", "share_va_ci_above_0"]).round(2))
