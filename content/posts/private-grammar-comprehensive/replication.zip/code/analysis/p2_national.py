"""P2: national three-way comparisons (raw, plus the conditioning available in public data).

Usage: .venv/Scripts/python -I code/analysis/p2_national.py data/derived results
Writes results/p2_*.csv and prints the headline numbers used in FINDINGS_P2.md.
"""
import pathlib
import sys

import pandas as pd

D = pathlib.Path(sys.argv[1])
R = pathlib.Path(sys.argv[2])
R.mkdir(parents=True, exist_ok=True)
pd.set_option("display.width", 200)

# 1. Widening participation by sixth-form sector (school at 17), A-level students
wp = pd.read_csv(D / "wp_school_type.csv")
wp = wp[(wp.student_group == "a_level") & (wp.school_type_at_17 != "total")]
series = wp.pivot_table(index=["by_age", "cohort_age15"], columns="school_type_at_17",
                        values=["he_rate", "high_tariff_rate", "cohort_students"])
series.columns = [f"{a}__{b}" for a, b in series.columns]
series = series.reset_index()
for m in ("he_rate", "high_tariff_rate"):
    series[f"{m}__gap_independent_minus_other"] = series[f"{m}__independent"] - series[f"{m}__other_state"]
    series[f"{m}__gap_selective_minus_other"] = series[f"{m}__selective_state"] - series[f"{m}__other_state"]
    series[f"{m}__gap_independent_minus_selective"] = series[f"{m}__independent"] - series[f"{m}__selective_state"]
series.to_csv(R / "p2_wp_series.csv", index=False)
s19 = series[series.by_age == 19].set_index("cohort_age15")
print("WP, A-level students, by 19 (first and latest cohorts):")
print(s19.loc[[s19.index.min(), s19.index.max()],
              [c for c in s19.columns if c.startswith(("he_rate__", "high_tariff_rate__")) and "gap" not in c]].round(1).T)

# 2. Cambridge by school type, and acceptances per 1,000 A-level students of each sixth-form sector
cam = pd.read_csv(D / "cambridge_school_type.csv")
cam = cam[(cam.block == "home") & cam.level.isin(["sector", "maintained_subtype"])]
cam = cam[cam.school_type != "Maintained"]
cam["type"] = cam.school_type.map({"Comprehensive School": "comprehensive", "Grammar School": "grammar",
                                   "Sixth Form College": "sixth_form_college",
                                   "FE and Tertiary Colleges": "fe_tertiary", "Independent": "independent"})
cam = cam.dropna(subset=["type"])
tot = cam.groupby("cycle").acceptances.transform("sum")
cam["share_uk_school_acceptances"] = 100 * cam.acceptances / tot
cam["offer_rate"] = 100 * cam.offers / cam.applications
cam["acceptance_rate"] = 100 * cam.acceptances / cam.applications
cam[["cycle", "type", "applications", "offers", "acceptances", "offer_rate", "acceptance_rate",
     "share_uk_school_acceptances"]].to_csv(R / "p2_cambridge_type.csv", index=False)

# Map WP sixth-form sectors to Cambridge categories: independent ~ Independent; selective_state ~ Grammar;
# other_state ~ Comprehensive + Sixth Form College + FE/Tertiary. Cycle = start year of age-15 cohort + 3.
wp19 = wp[wp.by_age == 19].copy()
wp19["cycle"] = wp19.cohort_age15.str[:4].astype(int) + 3
cohort = wp19.pivot_table(index="cycle", columns="school_type_at_17", values="cohort_students")
cam_sect = cam.assign(sector=cam.type.map({"independent": "independent", "grammar": "selective_state",
                                           "comprehensive": "other_state", "sixth_form_college": "other_state",
                                           "fe_tertiary": "other_state"}))
acc = cam_sect.groupby(["cycle", "sector"]).agg(applications=("applications", "sum"),
                                                acceptances=("acceptances", "sum")).reset_index()
acc["a_level_students"] = acc.apply(lambda r: cohort.loc[r.cycle, r.sector] if r.cycle in cohort.index else None,
                                    axis=1)
acc["applications_per_1000"] = 1000 * acc.applications / acc.a_level_students
acc["acceptances_per_1000"] = 1000 * acc.acceptances / acc.a_level_students
acc.dropna().to_csv(R / "p2_cambridge_per_student.csv", index=False)
print("\nCambridge per 1,000 A-level students of each sixth-form sector:")
print(acc.dropna().pivot_table(index="cycle", columns="sector",
                               values=["applications_per_1000", "acceptances_per_1000"]).round(2))

# 2b. England-only numerators. The Home block covers UK schools (NI grammars, Scottish and Welsh schools) while
# WP counts English schools only. Country from apply-centre postcodes (suppressed cells calibrated, cam_cells).
# independent: all fee statuses at English centres (WP's independent cohort may include overseas boarders,
# whose applications sit in the Other block); home_only variant = Home independent minus non-English centres.
# grammar: Home grammar minus all NI maintained acceptances
# (NI's Cambridge entrants are assumed all grammar: an upper bound on the correction). other state: Home
# comprehensive + SFC + FE minus Scottish, Welsh and Crown-dependency maintained acceptances.
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from cam_cells import estimate  # noqa: E402

ace = estimate(pd.read_csv(D / "cambridge_apply_centre.csv", dtype=str), pd.read_csv(D / "cambridge_school_type.csv"))
ace = ace[ace.sector.isin(["Maintained", "Independent"])]
geo = ace.groupby(["cycle", "sector", "country"]).acceptances_est.sum().unstack(fill_value=0)
home = acc.set_index(["cycle", "sector"]).acceptances
eng = []
for cyc in sorted(set(acc.cycle) & set(cohort.index)):
    ind, mnt = geo.loc[(cyc, "Independent")], geo.loc[(cyc, "Maintained")]
    ind_non_eng = ind[["NI", "Scotland", "Wales", "Crown"]].sum()
    for sector, num, num_home in (
            ("independent", ind.sum() - ind_non_eng, home[(cyc, "independent")] - ind_non_eng),
            ("selective_state", home[(cyc, "selective_state")] - mnt["NI"], None),
            ("other_state", home[(cyc, "other_state")] - mnt[["Scotland", "Wales", "Crown"]].sum(), None)):
        num_home = num if num_home is None else num_home
        eng.append({"cycle": cyc, "sector": sector, "acceptances_uk_home": home[(cyc, sector)],
                    "acceptances_england": num, "acceptances_england_home_only": num_home,
                    "a_level_students": cohort.loc[cyc, sector],
                    "per_1000_uk_home": 1000 * home[(cyc, sector)] / cohort.loc[cyc, sector],
                    "per_1000_england": 1000 * num / cohort.loc[cyc, sector],
                    "per_1000_england_home_only": 1000 * num_home / cohort.loc[cyc, sector]})
eng = pd.DataFrame(eng)
eng.to_csv(R / "p2_cambridge_per_student_england.csv", index=False)
print("\nCambridge acceptances per 1,000 A-level students, UK Home block vs England-only numerator:")
print(eng.pivot_table(index="cycle", columns="sector",
                      values=["per_1000_uk_home", "per_1000_england", "per_1000_england_home_only"]).round(1))

print("\nCambridge offer rate (offers/applications), % :")
print(cam.pivot_table(index="cycle", columns="type", values="offer_rate").round(1).tail(6))

# 3. Oxford state vs independent, latest vintage
ox = pd.read_csv(D / "oxford_school_type.csv")
ox = ox[ox.latest_vintage.astype(str) == "True"]
ox["offer_rate"] = 100 * ox.offers / ox.applications
ox.to_csv(R / "p2_oxford.csv", index=False)
print("\nOxford offer rate by type, %:")
print(ox.pivot_table(index="cycle", columns="school_type", values="offer_rate").round(1))

# 4. ONS earnings at 30: independent vs state non-FSM vs FSM, ratio by percentile
ons = pd.read_csv(D / "ons_fsm_percentiles.csv")
op = ons.pivot_table(index="percentile", columns="group", values="earnings_gbp")
op["ratio_independent_to_nonfsm"] = op["independent"] / op["state_non_fsm"]
op.reset_index().to_csv(R / "p2_ons_percentiles.csv", index=False)
print("\nONS PAYE earnings at 30, ratio independent / state non-FSM:")
print(op.loc[[10, 25, 50, 75, 90, 95, 99]].round(2))

# 5. A-level results by sector, 2024/25, from school-level rows (student-weighted)
ks5 = pd.read_csv(D / "ks5_school.csv", dtype={"urn": str})
master = pd.read_csv(D / "school_master.csv", dtype={"urn": str}, low_memory=False)[["urn", "sector"]]
ps = pd.read_csv(D / "partially_selective.csv", dtype={"urn": str})        # hand list, gates G-partial / G-class
master.loc[master.urn.isin(ps[ps.classification == "partially_selective"].urn), "sector"] = "partially_selective"
k = ks5[(ks5.time_period == "2024/25")].merge(master, on="urn", how="left")
rows = []
for cohort_name in ("Academic", "A level"):
    kk = k[k.exam_cohort == cohort_name].copy()
    for c in ("aps_per_entry", "aps_per_entry_student_count", "value_added", "va_entries"):
        kk[c] = pd.to_numeric(kk[c], errors="coerce")
    for sec, g in kk.groupby("sector"):
        g1 = g.dropna(subset=["aps_per_entry", "aps_per_entry_student_count"])
        g2 = g.dropna(subset=["value_added", "va_entries"])
        rows.append({"exam_cohort": cohort_name, "sector": sec, "schools": g1.urn.nunique(),
                     "students": g1.aps_per_entry_student_count.sum(),
                     "aps_per_entry": (g1.aps_per_entry * g1.aps_per_entry_student_count).sum()
                     / g1.aps_per_entry_student_count.sum(),
                     "value_added_entry_weighted": (g2.value_added * g2.va_entries).sum() / g2.va_entries.sum()
                     if len(g2) else None,
                     "va_schools": g2.urn.nunique()})
sect = pd.DataFrame(rows)
sect.to_csv(R / "p2_ks5_by_sector.csv", index=False)
print("\nA level / Academic results by sector, 2024/25 (school rows, student-weighted):")
print(sect.round(3).to_string(index=False))

# 6. RR1125 earnings 15 years after GCSE (raw)
rr = pd.read_csv(D / "rr1125_school_type.csv")
print("\nRR1125 Table 6:")
print(rr[rr.table.astype(str) == "6"][["measure", "school_type", "value", "unit"]].to_string(index=False))
