"""Oxford and Cambridge applications and places by English school, 2022-2025, and Imperial's, 2022-2024, with places
as % of sixth-form leavers, for the article's school lookup.

Usage: .venv/Scripts/python -I code/analysis/oxbridge_by_school.py data/derived results
Writes results/p3_oxbridge_by_school.csv: one row per English school or college that applied (Oxford type
State/Independent or Cambridge sector Maintained/Independent; the other university's rows are kept
whatever it calls the centre). Four-year totals 2022-2025 as [lo, hi]:
- Oxford: the 2022 row plus the 2023-25 total row (suppressed <3: applications 1-2, places 0-2).
- Cambridge: cam_cells bounds per cycle (<3 in 2022-2023; from 2024 a printed 5 means 1-5).
- Imperial: 2022-2024 (its file ends at cycle 2024), exact counts (nothing suppressed; all nationalities), joined
  by centre number to the schools above (Imperial gives no postcode, so a centre that applied only to Imperial is
  not in the table). imp_places = acceptances.
- All three (all3_*): Oxford + Cambridge + Imperial, 2022-2024 (the years all three cover): Oxford's single-year rows
  (suppressed <3 as above), Cambridge's cam_cells bounds for those cycles, and Imperial's exact counts, added.
All three universities share UCAS centre numbers. Centres linked to the same URN (cambridge_centre_urn.csv) are merged.
Kind: Private (independent), Grammar (State/Maintained centre linked to a DfE-selective URN, as in
oxford_per_student.py), State (other).
Leavers: DfE end-of-16-18 students with academic qualifications ('Academic' cohort, ks5_school.csv), 2021/22-
2024/25 (cycle Y = applications in autumn Y-1 = leavers in summer Y), the same denominator as the article's Cam/100
column (p3_profiles.py). When a school changed URN (academy conversion, new trust), earlier years are read under
the predecessor: a closed URN at the same postcode with a similar name (difflib ratio >= 0.8). Per year the largest count
among the school's URNs is used. pct columns need at least two years of leavers; with fewer than all
(leavers_scaled, imp_leavers_scaled) the average year is taken as the period's figure. Imperial's % uses the
leavers of its own three years.
website: the school's site from GIAS (SchoolWebsite), https:// added where missing; blank if absent or malformed.
"""
import difflib
import re
import pathlib
import sys

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from cam_cells import country, estimate  # noqa: E402
sys.path.insert(1, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from build_school_master import read_gias  # noqa: E402

D, R = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
YEARS = ["2022", "2023", "2024", "2025"]
PERIODS = ["2021/22", "2022/23", "2023/24", "2024/25"]
IMP_YEARS, IMP_PERIODS = YEARS[:3], PERIODS[:3]
link = pd.read_csv(D / "cambridge_centre_urn.csv", dtype=str)[["centre_number", "urn"]]
master = pd.read_csv(D / "school_master.csv", dtype=str, low_memory=False)
selective = set(master[master.sector == "selective"].urn)

kw = dict(dtype={"cycle": str, "centre_number": str}, keep_default_na=False, na_values=[""])
ox = pd.concat([pd.read_csv(D / "oxford_apply_centre.csv", **kw),
                pd.read_csv(D / "oxford_apply_centre_2023_2025.csv", **kw)], ignore_index=True)
ox = ox[ox.cycle.isin(["2022", "2023-2025"]) & (ox.postcode.map(country) == "England")].sort_values("cycle").copy()
for m, c_lo in (("applications", 1), ("acceptances", 0)):
    ox[f"{m}_lo"], ox[f"{m}_hi"] = ox[m].fillna(c_lo), ox[m].fillna(2)
oxs = ox.groupby("centre_number").agg(
    ox_name=("centre_name", "last"), ox_type=("school_type", "last"), ox_postcode=("postcode", "last"),
    ox_apps_lo=("applications_lo", "sum"), ox_apps_hi=("applications_hi", "sum"),
    ox_places_lo=("acceptances_lo", "sum"), ox_places_hi=("acceptances_hi", "sum"))

# single Oxford years 2022-2024, for the three-university total
ox3 = pd.read_csv(D / "oxford_apply_centre.csv", **kw)
ox3 = ox3[ox3.cycle.isin(IMP_YEARS)].copy()
for m, c_lo in (("applications", 1), ("acceptances", 0)):
    ox3[f"{m}_lo"], ox3[f"{m}_hi"] = ox3[m].fillna(c_lo), ox3[m].fillna(2)
ox3s = ox3.groupby("centre_number").agg(ox3_apps_lo=("applications_lo", "sum"), ox3_apps_hi=("applications_hi", "sum"),
                                         ox3_places_lo=("acceptances_lo", "sum"), ox3_places_hi=("acceptances_hi", "sum"))

cam = estimate(pd.read_csv(D / "cambridge_apply_centre.csv", dtype=str), pd.read_csv(D / "cambridge_school_type.csv"))
cam = cam[cam.cycle.astype(str).isin(YEARS) & (cam.country == "England")].sort_values("cycle")
cam3s = cam[cam.cycle.astype(str).isin(IMP_YEARS)].groupby("centre_number").agg(
    cam3_apps_lo=("applications_lo", "sum"), cam3_apps_hi=("applications_hi", "sum"),
    cam3_places_lo=("acceptances_lo", "sum"), cam3_places_hi=("acceptances_hi", "sum"))
cams = cam.groupby("centre_number").agg(
    cam_name=("centre_name", "last"), cam_sector=("sector", "last"), cam_postcode=("postcode", "last"),
    cam_apps_lo=("applications_lo", "sum"), cam_apps_hi=("applications_hi", "sum"),
    cam_places_lo=("acceptances_lo", "sum"), cam_places_hi=("acceptances_hi", "sum"))

imp = pd.read_csv(D / "imperial_apply_centre.csv", dtype={"cycle": str, "centre_number": str})
imps = imp[imp.cycle.isin(IMP_YEARS)].groupby("centre_number").agg(imp_apps=("applications", "sum"),
                                                                    imp_places=("acceptances", "sum"))

t = oxs.join(cams, how="outer").join(imps, how="left").join(ox3s, how="left").join(cam3s, how="left").reset_index().merge(link, on="centre_number", how="left")
t["name"] = t.cam_name.fillna(t.ox_name)                  # Cambridge prints full names; Oxford truncates long ones
t["postcode"] = t.cam_postcode.fillna(t.ox_postcode)
# a school if either university types it as one (the other may call it "Other"); keep both universities' counts
ox_school = t.ox_type.isin(["State", "Independent"])
t = t[ox_school | t.cam_sector.isin(["Maintained", "Independent"])].copy()
ox_school = t.ox_type.isin(["State", "Independent"])
t["private"] = t.ox_type.eq("Independent") | (~ox_school & t.cam_sector.eq("Independent"))
COUNTS = [f"{u}_{m}_{k}" for u in ("ox", "cam", "ox3", "cam3") for m in ("apps", "places") for k in ("lo", "hi")] + [
    "imp_apps", "imp_places"]
t[COUNTS] = t[COUNTS].fillna(0).astype(int)

# merge centres of the same school (same URN); name and postcode from the centre with most applications
t["key"] = t.urn.fillna("c" + t.centre_number)
t["apps"] = t.ox_apps_lo + t.cam_apps_lo
t = t.sort_values("apps", ascending=False)
s = t.groupby("key", sort=False).agg(
    centre_numbers=("centre_number", lambda x: " ".join(sorted(x))), urn=("urn", "first"), name=("name", "first"),
    postcode=("postcode", "first"), private=("private", "first"), **{c: (c, "sum") for c in COUNTS}).reset_index()
s["kind"] = "State"
s.loc[s.private, "kind"] = "Private"
s.loc[~s.private & s.urn.isin(selective), "kind"] = "Grammar"

# leavers, with predecessor URNs at the same postcode
ks5 = pd.read_csv(D / "ks5_school.csv", dtype={"urn": str})
ks5 = ks5[(ks5.exam_cohort == "Academic") & ks5.time_period.isin(PERIODS)].copy()
ks5["n"] = pd.to_numeric(ks5.end1618_student_count, errors="coerce")
lv = ks5.dropna(subset=["n"]).pivot_table(index="urn", columns="time_period", values="n", aggfunc="max")
mi = master.set_index("urn")
by_pc = master.groupby("postcode").urn.apply(list).to_dict()


def family(urn):
    if pd.isna(urn) or urn not in mi.index:
        return []
    name = str(mi.at[urn, "name"]).lower()
    return [u for u in by_pc.get(mi.at[urn, "postcode"], [urn])
            if u == urn or (not str(mi.at[u, "status"]).startswith("Open")          # a sibling school is not a predecessor
                            and difflib.SequenceMatcher(None, name, str(mi.at[u, "name"]).lower()).ratio() >= 0.8)]


fam = s.urn.map(family)
per = pd.DataFrame([lv.reindex(f).max() if f else pd.Series(dtype=float) for f in fam], index=s.index)
per = per.reindex(columns=PERIODS)
s["leavers_years"] = per.notna().sum(axis=1)
s["leavers"] = per.sum(axis=1, min_count=1)
s["predecessor_urns"] = [" ".join(u for u in f if u != urn) for f, urn in zip(fam, s.urn)]
ok = s.leavers_years >= 2
s["leavers_scaled"] = ok & (s.leavers_years < 4)          # 2-3 years found: average year x 4
den = s.leavers * 4 / s.leavers_years
for u in ("ox", "cam"):
    for k in ("lo", "hi"):
        s[f"{u}_places_pct_{k}"] = (100 * s[f"{u}_places_{k}"] / den).where(ok)
imp_years = per[IMP_PERIODS].notna().sum(axis=1)
imp_ok = imp_years >= 2
s["imp_leavers_scaled"] = imp_ok & (imp_years < 3)
imp_den = per[IMP_PERIODS].sum(axis=1, min_count=1) * 3 / imp_years
s["imp_places_pct"] = (100 * s.imp_places / imp_den).where(imp_ok)
for m in ("apps", "places"):
    for k in ("lo", "hi"):
        s[f"all3_{m}_{k}"] = s[f"ox3_{m}_{k}"] + s[f"cam3_{m}_{k}"] + s[f"imp_{m}"]
for k in ("lo", "hi"):
    s[f"all3_places_pct_{k}"] = (100 * s[f"all3_places_{k}"] / imp_den).where(imp_ok)
s = s.drop(columns=["key", "private"]).sort_values("name")
web = read_gias()[0].set_index("URN").SchoolWebsite.str.strip()


def site(urn):
    w = web.get(str(int(float(urn))), "") if pd.notna(urn) and str(urn) else ""
    w = w if re.match(r"(?i)https?://", w) else "https://" + w
    return w if re.fullmatch(r"(?i)https?://[a-z0-9.-]+[.][a-z]{2,}(?::\d+)?(?:/\S*)?", w) else ""


s["website"] = s.urn.map(site)
s.to_csv(R / "p3_oxbridge_by_school.csv", index=False)

places = s.ox_places_lo + s.cam_places_lo
print(f"{len(s)} English schools/colleges ({len(t)} centres); by kind {s.kind.value_counts().to_dict()}")
print(f"  with a % of leavers: {ok.sum()} schools ({int(s.leavers_scaled.sum())} scaled from 2-3 years), holding "
      f"{places[ok].sum() / places.sum():.1%} of places shown; "
      f"{(s.predecessor_urns != '').sum()} use a predecessor URN")
for kind in ("Private", "Grammar", "State"):
    k = s[(s.kind == kind).to_numpy() & (s.leavers_years == 4).to_numpy()]
    print(f"  {kind}: Oxford places {100 * k.ox_places_lo.sum() / k.leavers.sum():.2f}-"
          f"{100 * k.ox_places_hi.sum() / k.leavers.sum():.2f}% of leavers, Cambridge "
          f"{100 * k.cam_places_lo.sum() / k.leavers.sum():.2f}-{100 * k.cam_places_hi.sum() / k.leavers.sum():.2f}%")
