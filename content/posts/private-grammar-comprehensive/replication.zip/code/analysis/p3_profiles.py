"""P3: top-30 profiles, sector distributions and the comprehensive overlay (PLAN v2 §4.3.3, §4.4, decision D4).

Usage: .venv/Scripts/python -I code/analysis/p3_profiles.py data/derived results
Inputs: top30_*.csv and ks5_eligible_pooled.csv (select_top30.py), ks5_school.csv, cambridge_school_cycle.csv
(join_cambridge.py), grammar_intake.csv, grammar_super_selective.csv, partially_selective.csv.
Writes results/p3_top30_independent.csv, p3_top30_grammar.csv, p3_sector_distributions.csv,
p3_universe.csv (one row per eligible school, the overlay data).

Definitions
- Universe: select_top30's eligible set (Academic cohort, >= 40 students in 2023/24 and 2024/25, statutory low
  age < 14). Sector from school_master, with partially selective schools (hand list, classification
  'partially_selective') moved to their own sector, kept out of both the grammar list and the comparator.
- Value added, its CI, coverage and %AAB: A level cohort, 2024/25. Coverage < 0.7 is flagged (IGCSE baselines).
- Cambridge per 100 leavers: acceptances (and offers, applications) in cycles 2022-2025 over Academic-cohort
  end-of-16-18 students in 2021/22-2024/25 (cycle Y = applications in autumn Y-1 = leavers in summer Y).
  Suppressed cells enter as calibrated estimates with lower and upper bounds (cam_cells.py).
- Comparator ('comprehensive'): non_selective_other, i.e. non-selective schools outside highly selective areas.
"""
import pathlib
import sys

import pandas as pd

D = pathlib.Path(sys.argv[1])
R = pathlib.Path(sys.argv[2])
R.mkdir(parents=True, exist_ok=True)
CYCLES = range(2022, 2026)
PERIODS = ["2021/22", "2022/23", "2023/24", "2024/25"]

uni = pd.read_csv(D / "ks5_eligible_pooled.csv", dtype={"urn": str})
ps_path = D / "partially_selective.csv"
if ps_path.exists():
    ps = pd.read_csv(ps_path, dtype={"urn": str})
    ps_urns = set(ps[ps.classification == "partially_selective"].urn)
    uni.loc[uni.urn.isin(ps_urns), "sector"] = "partially_selective"
else:
    print("WARNING: partially_selective.csv missing; comparator still contains partially selective schools")

ks5 = pd.read_csv(D / "ks5_school.csv", dtype={"urn": str})
al = ks5[(ks5.exam_cohort == "A level") & (ks5.time_period == "2024/25")][
    ["urn", "value_added", "value_added_lower_ci", "value_added_upper_ci", "va_coverage", "aab_percent"]]
for c in al.columns[1:]:
    al[c] = pd.to_numeric(al[c], errors="coerce")
astar = pd.read_csv(D / "ks5_astar_a_school.csv", dtype={"urn": str})
astar = astar[(astar.time_period.astype(str) == "2024/25") & astar.qualification.str.contains("A level", case=False)]
astar = astar[["urn", "pct_astar_a"]].drop_duplicates("urn")

# Pair each cycle with its leavers year under the same URN, so a URN change (academy conversion) never leaves
# four cycles of Cambridge counts over two years of leavers. A cycle with leavers but no apply-centre row = 0.
leavers = ks5[(ks5.exam_cohort == "Academic") & ks5.time_period.isin(PERIODS)].copy()
leavers["n"] = pd.to_numeric(leavers.end1618_student_count, errors="coerce")
leavers = leavers.dropna(subset=["n"])
leavers["cycle"] = leavers.time_period.str[:4].astype(int) + 1
cam = pd.read_csv(D / "cambridge_school_cycle.csv", dtype={"urn": str})
cam = cam[cam.cycle.isin(CYCLES)]
vals = [f"{m}_{k}" for m in ("applications", "offers", "acceptances") for k in ("lo", "est", "hi")]
paired = leavers[["urn", "cycle", "n"]].merge(cam[["urn", "cycle"] + vals], on=["urn", "cycle"], how="left")
paired[vals] = paired[vals].fillna(0)
paired = paired.groupby("urn").agg(leavers_4y=("n", "sum"), periods=("n", "count"),
                                   **{v: (v, "sum") for v in vals}).reset_index()

u = (uni.merge(al, on="urn", how="left").merge(astar, on="urn", how="left")
        .merge(paired, on="urn", how="left"))
for m in ("applications", "offers", "acceptances"):
    for k in ("lo", "est", "hi"):
        u[f"cam_{m}_per100_{k}"] = 100 * u[f"{m}_{k}"] / u.leavers_4y
u["va_low_coverage"] = u.va_coverage < 0.7

# comprehensive overlay: percentile of each school within the comparator distribution
comp = u[u.sector == "non_selective_other"]
METRICS = {"aps_pooled": "APS per entry (pooled)", "value_added": "VA 2024/25", "pct_astar_a": "% A*/A",
           "cam_acceptances_per100_est": "Cambridge acceptances per 100 leavers"}
for col in METRICS:
    ref = comp[col].dropna().sort_values().to_numpy()
    u[f"{col}_comp_pctile"] = u[col].map(lambda x: None if pd.isna(x) else 100 * (ref < x).mean() + 50 * (ref == x).mean())
u.to_csv(R / "p3_universe.csv", index=False)

# sector distributions
rows = []
for sec, g in u.groupby("sector"):
    for col, label in METRICS.items():
        s = g[col].dropna()
        if s.empty:
            continue
        r = {"sector": sec, "metric": col, "label": label, "schools": len(s), "mean": s.mean()}
        r.update({f"p{q}": s.quantile(q / 100) for q in (10, 25, 50, 75, 90, 99)})
        if col == "value_added":
            gv = g.dropna(subset=["value_added"])
            r["share_ci_above_0"] = (gv.value_added_lower_ci > 0).mean()
            r["share_ci_below_0"] = (gv.value_added_upper_ci < 0).mean()
            hi = gv[~gv.va_low_coverage.fillna(True)]
            r["schools_cov70"], r["mean_cov70"] = len(hi), hi.value_added.mean()
        rows.append(r)
dist = pd.DataFrame(rows)
dist.to_csv(R / "p3_sector_distributions.csv", index=False)

# top-30 profiles
intake = pd.read_csv(D / "grammar_intake.csv", dtype={"urn": str})
ss = pd.read_csv(D / "grammar_super_selective.csv", dtype={"urn": str})


def latest(measure, category="all"):
    x = intake[(intake.measure == measure) & (intake.category == category) & intake.value.notna()]
    x = x.sort_values("entry_year", kind="stable").groupby("urn").tail(1)
    return x[["urn", "entry_year", "value", "status"]].rename(
        columns={"entry_year": f"{measure}_year", "value": measure, "status": f"{measure}_status"})


def fees_summary():
    """Annual VAT-inclusive list fees per school (independent_fees.csv, G-fees): mean of the confirmed rows for each
    year x stage x day/boarding (several rows where a school prices year groups separately); the sixth-form day fee
    falls back to the 16+ entrant fee (Westminster)."""
    f = pd.read_csv(D / "independent_fees.csv", dtype={"urn": str})
    f = f[f.status == "confirmed"]
    out = {}
    for col, year, stages, kind in (("fee_senior_day_2627", "2026/27", ["senior"], "day"),
                                    ("fee_senior_day_2526", "2025/26", ["senior"], "day"),
                                    ("fee_sixth_day_2627", "2026/27", ["sixth_form", "sixth_form_new_entrant"], "day"),
                                    ("fee_senior_boarding_2627", "2026/27", ["senior"], "boarding")):
        for stage in stages:
            x = f[(f.fee_year == year) & (f.stage == stage) & (f.day_or_boarding == kind)]
            for urn, v in x.groupby("urn").annual_incl_vat.mean().items():
                out.setdefault(urn, {}).setdefault(col, v)
            if col == "fee_senior_day_2627":  # False where the fee sheet does not say whether VAT is included
                for urn, ok in x.groupby("urn").incl_vat.apply(lambda s: s.eq(True).all()).items():
                    out[urn].setdefault("fee_senior_day_2627_vat_stated", ok)
    return pd.DataFrame.from_dict(out, orient="index").rename_axis("urn").reset_index()


bursaries = pd.read_csv(D / "independent_bursaries.csv", dtype={"urn": str})[
    ["urn", "fy_end", "remission_share", "means_tested_share", "means_tested_pupils", "full_remission_pupils",
     "charity_scope"]]

PROFILE = ["rank", "urn", "name", "la_name", "london", "gender", "boarders", "pupils", "sector", "aps_pooled",
           "pct_astar_a", "aab_percent", "value_added", "value_added_lower_ci", "value_added_upper_ci",
           "va_coverage", "va_low_coverage", "leavers_4y", "cam_applications_per100_est",
           "cam_offers_per100_est", "cam_acceptances_per100_lo", "cam_acceptances_per100_est",
           "cam_acceptances_per100_hi"] + [f"{c}_comp_pctile" for c in METRICS]
for label, sector in (("independent", "independent"), ("grammar", "selective")):
    t = pd.read_csv(D / f"top30_{label}.csv", dtype={"urn": str})
    t = t[t.top30][["rank", "urn", "progress8", "progress8_lower_ci", "progress8_upper_ci",
                    "pa_high_pct_of_known", "boys_count", "girls_count"]]
    p = t.merge(u, on="urn", how="left")
    assert p.sector.eq(sector).all(), p[~p.sector.eq(sector)][["name", "sector"]]
    p = p[PROFILE + ["progress8", "progress8_lower_ci", "progress8_upper_ci", "pa_high_pct_of_known",
                     "boys_count", "girls_count"]]
    if label == "independent":
        p = p.merge(fees_summary(), on="urn", how="left").merge(bursaries, on="urn", how="left")
        p["fee_senior_day_2627_net_of_remissions_avg"] = p.fee_senior_day_2627 * (1 - p.remission_share)
    if label == "grammar":
        for m in ("admissions_model", "dfe_preferences_per_offer", "testers_per_place", "lowest_score_offered",
                  "last_distance_offered", "test_used"):
            p = p.merge(latest(m), on="urn", how="left")
        p = p.merge(ss[["urn", "flag", "testers_per_place_basis"]].rename(columns={"flag": "super_selective"}),
                    on="urn", how="left")
    p.to_csv(R / f"p3_top30_{label}.csv", index=False)

# Top 20 private schools open to boys and open to girls (select_top20_sex.py), with fees and remissions
for label in ("boys", "girls"):
    t = pd.read_csv(D / f"top20_{label}.csv", dtype={"urn": str})
    t = t[t.top20][["rank", "urn", "sex_policy"]]
    p = t.merge(u, on="urn", how="left")
    assert p.sector.eq("independent").all(), p[~p.sector.eq("independent")][["name", "sector"]]
    p = p[PROFILE + ["sex_policy"]].merge(fees_summary(), on="urn", how="left").merge(bursaries, on="urn", how="left")
    p.to_csv(R / f"p3_top20_{label}.csv", index=False)

# Bottom 20 private (open to boys and/or girls) and bottom 30 grammar schools (select_bottom.py)
k4 = pd.read_csv(D / "ks4_school_2324.csv", dtype={"urn": str})[
    ["urn", "progress8", "progress8_lower_ci", "progress8_upper_ci", "pa_high_pct_of_known"]]
t = pd.read_csv(D / "bottom20_private.csv", dtype={"urn": str})[["rank", "urn", "sex_policy", "age_range",
                                                                 "open_to_boys", "open_to_girls"]]
p = t.merge(u, on="urn", how="left")
assert p.sector.eq("independent").all()
p = p[PROFILE + ["sex_policy", "age_range", "open_to_boys", "open_to_girls"]]
p = p.merge(fees_summary(), on="urn", how="left").merge(bursaries, on="urn", how="left")
p.to_csv(R / "p3_bottom20_private.csv", index=False)
t = pd.read_csv(D / "bottom30_grammar.csv", dtype={"urn": str})[["rank", "urn"]]
p = t.merge(u, on="urn", how="left")
assert p.sector.eq("selective").all()
p = p[PROFILE].merge(k4, on="urn", how="left")
for m in ("admissions_model", "dfe_preferences_per_offer", "testers_per_place", "lowest_score_offered",
          "last_distance_offered", "test_used"):
    p = p.merge(latest(m), on="urn", how="left")
p = p.merge(ss[["urn", "flag", "testers_per_place_basis"]].rename(columns={"flag": "super_selective"}), on="urn",
            how="left")
for c in ("progress8", "progress8_lower_ci", "progress8_upper_ci", "pa_high_pct_of_known"):
    p[c] = pd.to_numeric(p[c], errors="coerce")
p.to_csv(R / "p3_bottom30_grammar.csv", index=False)

pd.set_option("display.width", 250)
print(dist[dist.metric.isin(["value_added", "cam_acceptances_per100_est"])].round(3).to_string(index=False))
for label in ("independent", "grammar"):
    p = pd.read_csv(R / f"p3_top30_{label}.csv")
    print(f"\nTop 30 {label}: median comprehensive percentile",
          {c: round(p[f"{c}_comp_pctile"].median(), 1) for c in METRICS})
    print(p[["rank", "name", "aps_pooled", "value_added", "va_coverage", "cam_acceptances_per100_est",
             "cam_acceptances_per100_lo", "cam_acceptances_per100_hi"]].round(2).head(10).to_string(index=False))
