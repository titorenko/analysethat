"""Top 20 private schools open to boys and top 20 open to girls (user request, 2026-10-10).

Same universe and ranking as select_top30.py (ks5_eligible_pooled.csv: Academic cohort, pooled APS 2023/24-2024/25,
>= 40 students each year, no sixth-form-only or international colleges). A school is open to boys if DfE's sex
policy (16-18 institution information) is Boys or Mixed, and open to girls if Girls or Mixed; but a Mixed school
goes on the girls' list only if a girl entering at 11+ or 13+ in September 2027 reaches the school (coed_entry.csv, checked against each
school's admissions page), since the cost-benefit calculation is for entry at 11. Mixed schools can be on both lists.

Usage: .venv/Scripts/python -I code/analysis/select_top20_sex.py data/derived
Writes top20_boys.csv and top20_girls.csv (ranks 1-25, top20 flag).
"""
import pathlib
import sys

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import latest_raw  # noqa: E402

D = pathlib.Path(sys.argv[1])
info = pd.read_csv(latest_raw("dfe_ks5", "ks5_institution_info_v*.csv"), dtype=str)
info = info[["school_urn", "sex_policy"]].drop_duplicates("school_urn").rename(columns={"school_urn": "urn"})
uni = pd.read_csv(D / "ks5_eligible_pooled.csv", dtype={"urn": str})
x = uni[uni.sector == "independent"].merge(info, on="urn", how="left").sort_values("aps_pooled", ascending=False)
assert x.sex_policy.isin(["Boys", "Girls", "Mixed"]).all(), x[~x.sex_policy.isin(["Boys", "Girls", "Mixed"])]
co = pd.read_csv(D / "coed_entry.csv", dtype={"urn": str}).set_index("urn")

boys = x[x.sex_policy.isin(["Boys", "Mixed"])].copy()
girls = x[x.sex_policy.isin(["Girls", "Mixed"])].copy()
# walk down the ranking: every Mixed school met before the 25th eligible school must have a checked coed_entry row
girls["girls_at_11_13"] = None
eligible = 0
for i, r in girls.iterrows():
    if eligible >= 25:
        break
    if r.sex_policy == "Girls":
        girls.at[i, "girls_at_11_13"] = "yes"
    else:
        assert r.urn in co.index, f"mixed school {r['name']} ({r.urn}) is within the girls' top 25 but unchecked"
        girls.at[i, "girls_at_11_13"] = co.at[r.urn, "girls_at_11_or_13_for_2027_entry"]
    eligible += girls.at[i, "girls_at_11_13"] == "yes"
dropped = girls[girls.girls_at_11_13 != "yes"]
girls = girls[girls.girls_at_11_13 == "yes"]
for label, t in (("boys", boys), ("girls", girls)):
    t = t.head(25).copy()
    t["rank"] = range(1, len(t) + 1)
    t["top20"] = t["rank"] <= 20
    t[["rank", "top20", "urn", "name", "sex_policy", "gender", "la_name", "aps_pooled", "aps_2023", "aps_2024",
       "n_2023", "n_2024"]].to_csv(D / f"top20_{label}.csv", index=False)
    print(f"\nTop 20 open to {label}:")
    print(t[t.top20][["rank", "name", "sex_policy", "aps_pooled"]].round(1).to_string(index=False))
print("\nMixed schools kept off the girls' list (no girls' entry at 11 or 13):",
      "; ".join(f"{r.name} ({r.girls_at_11_13})" for r in dropped.itertuples() if r.aps_pooled >= girls.aps_pooled.iloc[19]))
