"""Build replication.zip for the write-up: code, derived tables, results, manifests (URL, date, hash of every raw
file), the article template and a README. Raw downloads are not redistributed (re-fetch them with code/harvest);
ISC census tables are left out (ISC copyright); FOI recipient addresses in grammar_intake.csv are replaced.

Usage: .venv/Scripts/python -I code/package_replication.py <out zip>
"""
import io
import pathlib
import sys
import zipfile

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = pathlib.Path(sys.argv[1])
README = """# Replication files: private, grammar and comprehensive schools

Contents
- code/harvest   downloads every source (logged to data/manifest with URL, date, HTTP status, bytes, sha256)
- code/derive    builds the tidy tables in data/derived (each has a .md describing columns and caveats)
- code/checks    gates: each derived table against the published figure it reproduces (results in the article)
- code/analysis  P2-P4: national comparisons, top-30 selection, Cambridge linkage, profiles, premium scenarios
- code/engine    lifetime earnings and cost-benefit engine (lifetime.py), run_p5.py, run_p6.py
- code/figures   figures and the article (article_values.py computes every number in it)
- results        outputs and FINDINGS_*.md notes
- writeup        article template

Run order (Python 3.13, pip install -r requirements.txt; always run with python -I)
1. code/harvest/*.py      (raw files are not included; manifests give URLs and sha256 to check them)
2. code/derive/*.py       then code/checks/*.py
3. code/analysis/select_top30.py data/derived; join_cambridge.py data/derived; p2_national.py data/derived results;
   p3_profiles.py data/derived results; p4_adjusted_public.py data/derived results; p4_bridge.py data/derived results
4. code/engine/run_p5.py results; code/engine/run_p6.py data/derived results
5. code/figures/make_figures.py <dir>; code/figures/build_article.py <dir>; code/checks/g_article.py writeup/article.md.tmpl

Not included: raw downloads; ISC census tables (isc_*.csv, ISC copyright: see ISC Census and Annual Report 2026);
FOI correspondence. Sources are public; DfE, ONS, GIAS, OBR and HMRC data are under the Open Government Licence.
Cohort microdata (NCDS, BCS70, MCS, Next Steps) were not used.
"""


def keep(p):
    rel = p.relative_to(ROOT).as_posix()
    if "__pycache__" in rel or p.is_dir():
        return False
    if rel.startswith("data/derived/") and p.name.startswith("isc_"):
        return False
    return rel.startswith(("code/", "results/", "writeup/", "data/manifest/", "data/derived/")) or rel == "requirements.txt"


files = sorted(p for p in ROOT.rglob("*") if keep(p))
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("README.md", README)
    for p in files:
        rel = p.relative_to(ROOT).as_posix()
        if rel == "data/derived/grammar_intake.csv":
            d = pd.read_csv(p, dtype=str, keep_default_na=False)
            d.loc[d.source_url.str.startswith("mailto:"), "source_url"] = "FOI request (pending)"
            buf = io.StringIO()
            d.to_csv(buf, index=False)
            z.writestr(rel, buf.getvalue())
        else:
            z.write(p, rel)
with zipfile.ZipFile(OUT) as z:
    names = z.namelist()
    assert not any("requests/" in n or "secrets" in n or n.endswith(".pdf") for n in names)
    assert not any("mailto:" in z.read(n).decode("utf-8", "ignore") for n in names if n.endswith(".csv"))
print(f"wrote {OUT}: {len(names)} files, {OUT.stat().st_size / 1e6:.1f} MB")
