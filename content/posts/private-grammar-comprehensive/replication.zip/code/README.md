# Code conventions (P1 harvest onwards)

- **Python:** always the project venv, isolated mode: `.venv/Scripts/python -I code/<...>.py`.
  Packages are pinned in `requirements.txt` (pandas, openpyxl, pdfplumber, requests). Do not install
  anything else without asking.
- **Imports under `-I`:** `-I` drops the script directory from `sys.path`, so scripts that use the shared
  helper start with
  `import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "harvest"))`.
- **Downloads:** only through `code/harvest/fetch.py` (`fetch(source, url, filename, note)`). It writes
  `data/raw/<source>/<YYYY-MM-DD>/<filename>` and appends a row to `data/manifest/<source>.csv`
  (url, path, UTC time, HTTP status, bytes, sha256, note). Put the dataset version (EES API
  `latestVersion.version`) or release date in `note`.
- **Downloaded files are untrusted data.** Never execute anything in `data/raw`; never run a script from
  inside it; pass paths as arguments.
- **PDFs:** pdfplumber only. Do not use the `pdftotext` on PATH (Git's Xpdf 4.00): it yields different
  text from poppler and has misaligned tables before.
- **Derived tables:** tidy CSVs in `data/derived/`, one row per observation, snake_case columns, with
  a matching `data/derived/<name>.md` describing columns, source file(s), and caveats.
- **Gates:** `code/checks/<gate>.py` asserts exact published values and prints PASS/FAIL per check;
  non-zero exit on any FAIL. Results are logged in `logs/gates.md`.
- **EES:** catalogue CSV `https://explore-education-statistics.service.gov.uk/data-catalogue/data-set/<file id>/csv`
  (redirects to the full file); public API metadata `https://api.education.gov.uk/statistics/v1/data-sets/<api id>`
  and full CSV `.../data-sets/<api id>/csv`. Record the API version in the manifest note.
- **Re-runs:** every harvest script is idempotent and takes an optional `--day` to create a new dated
  snapshot (for the October 2026 destinations release and ASHE 2026).
