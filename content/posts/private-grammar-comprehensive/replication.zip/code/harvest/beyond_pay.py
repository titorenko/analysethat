"""Fetch the sources for the article's "beyond pay" section (PhDs, elite positions, top scholars, wellbeing).

Usage: .venv/Scripts/python -I code/harvest/beyond_pay.py [--day YYYY-MM-DD]
"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import fetch  # noqa: E402

SOURCES = [
    ("https://ifs.org.uk/sites/default/files/output_url_files/Family-background-and-access-to-postgraduate-degrees__.pdf",
     "ifs_pg_access.pdf", "Britton & van der Erve, IFS Briefing Note 'Family background and access to postgraduate "
     "degrees' (NPD-HESA, 2002 GCSE cohort)"),
    ("https://www.suttontrust.com/wp-content/uploads/2025/09/Elitist-Britain-2025.pdf",
     "elitist_britain_2025.pdf", "Sutton Trust, Elitist Britain 2025 (18 Sep 2025)"),
    ("https://dera.ioe.ac.uk/id/eprint/30358/1/ScientistScholars-1.pdf",
     "sutton_trust_2009_scientists_scholars.pdf", "Sutton Trust (2009), The educational backgrounds of leading "
     "scientists and scholars (Royal Society and British Academy fellows), DERA 30358"),
    ("https://discovery.ucl.ac.uk/id/eprint/10146841/3/Henderson_Does%20attending%20an%20English%20private%20school"
     "%20benefit%20mental%20health%20and%20life%20satisfaction_%20From%20adolescence%20to%20adulthood_AOP.pdf",
     "henderson2022_cje.pdf", "Henderson, Anders, Green & Henseke (2022) Cambridge J Educ, doi 10.1080/0305764X.2022."
     "2040951, published version (AOP), UCL Discovery 10146841"),
]

if __name__ == "__main__":
    day = sys.argv[sys.argv.index("--day") + 1] if "--day" in sys.argv else None
    for url, name, note in SOURCES:
        print(fetch("literature", url, name, note, day=day))
