"""Harvest Cambridge admissions statistics + apply-centre PDFs, and Oxford admissions reports.

Cambridge: the index page is fetched first and every PDF linked from it whose name matches the annual
statistics or apply-centre pattern is downloaded (one per cycle). Oxford: the current report from ox.ac.uk
(via curl_fetch, see its docstring) and earlier editions from fixed Wayback Machine captures (via fetch).

    .venv/Scripts/python -I code/harvest/cambridge_oxford.py [--day YYYY-MM-DD]
"""
import argparse
import pathlib
import re
import subprocess
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import UA, _log, fetch, snapshot_dir  # noqa: E402


GIT_CURL = r"C:\Program Files\Git\mingw64\bin\curl.exe"


def curl_fetch(source, url, filename, note, day=None):
    """Same layout and manifest row as fetch(), but downloaded with curl: ox.ac.uk's Cloudflare
    challenges Python's TLS client (requests and urllib both get 403 'cf-mitigated: challenge'),
    while Git's curl with the same User-Agent gets 200 (Windows' System32 curl.exe is also challenged)."""
    dest = snapshot_dir(source, day) / filename
    if dest.exists() and dest.stat().st_size > 0:
        return dest
    part = dest.with_name(dest.name + ".part")
    r = subprocess.run([GIT_CURL, "-sSL", "-A", UA, "-o", str(part), "-w", "%{http_code}", url],
                       capture_output=True, text=True, timeout=300)
    status = int(r.stdout.strip() or 0)
    if status != 200 or not part.exists() or part.stat().st_size == 0:
        part.unlink(missing_ok=True)
        raise RuntimeError(f"curl fetch failed ({status} {r.stderr.strip()}): {url}")
    part.replace(dest)
    _log(source, url, dest, status, dest.read_bytes(),
         note + " [downloaded with curl: Python TLS is Cloudflare-challenged (403) on ox.ac.uk]")
    return dest


CAM_BASE = "https://www.undergraduate.study.cam.ac.uk"
CAM_INDEX = CAM_BASE + "/apply/before/application-statistics"
STATS_RE = re.compile(r'href="(/sites/default/files/[^"]*?(?:ug|undergrad)_admissions_statistics_(\d{4})_cycle[^"]*\.pdf)"')
CENTRE_RE = re.compile(r'href="(/sites/default/files/[^"]*?undergraduate_admissions_by_apply_centre_(\d{4})_cycle[^"]*\.pdf)"')

# Oxford Undergraduate Admissions Reports (filename -> (url, note)).
OXFORD = {
    "oxford_ug_statistics_index.html": (
        "https://www.ox.ac.uk/about/the-university/facts-and-figures/admissions-statistics/undergraduate",
        "Oxford undergraduate admissions statistics index page"),
    "oxford_ug_admissions_report_2026.pdf": (
        "https://assets-oxweb.admin.ox.ac.uk/2026-07/Undergraduate%20Admissions%20Report%202026_0.pdf",
        "Oxford Undergraduate Admissions Report 2026 (UCAS cycles 2021-2025), published Jul 2026"),
}
# Earlier Oxford reports were removed from ox.ac.uk (the old /sites/files/oxford/ URLs now redirect to the
# home page); the Wayback Machine holds them. year -> (capture timestamp, original URL), from the CDX index.
OXFORD_WAYBACK = {
    2018: ("20190225130039", "https://www.ox.ac.uk/sites/files/oxford/Annual%20Admissions%20Statistical%20Report%202018.pdf"),
    2020: ("20200624145649", "https://www.ox.ac.uk/sites/files/oxford/Annual%20Admissions%20Statistical%20Report%202020.pdf"),
    2021: ("20210531140507", "https://www.ox.ac.uk/sites/files/oxford/AnnualAdmissionsStatisticalReport2021.pdf"),
    2022: ("20220507090629", "https://www.ox.ac.uk/sites/files/oxford/AnnualAdmissionsStatisticalReport2022.pdf"),
    2023: ("20230626030232", "https://www.ox.ac.uk/sites/files/oxford/AnnualAdmissionsStatisticalReport2023b.pdf"),
    2024: ("20240611134050", "https://www.ox.ac.uk/sites/files/oxford/AnnualAdmissionsStatisticalReport2024.pdf"),
    2025: ("20250626201315", "https://www.ox.ac.uk/sites/files/oxford/AnnualAdmissionsStatisticalReport2025.pdf"),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--day", default=None)
    day = ap.parse_args().day

    idx = fetch("cambridge_stats", CAM_INDEX, "application-statistics_index.html",
                "index page of Cambridge application statistics", day=day)
    html = idx.read_text(encoding="utf-8", errors="replace")
    stats = {int(y): u for u, y in STATS_RE.findall(html)}
    centres = {int(y): u for u, y in CENTRE_RE.findall(html)}
    print(f"index: {len(stats)} statistics PDFs {sorted(stats)}; {len(centres)} apply-centre PDFs {sorted(centres)}")

    for y, u in sorted(stats.items()):
        p = fetch("cambridge_stats", CAM_BASE + u, f"ug_admissions_statistics_{y}_cycle.pdf",
                  f"Cambridge Undergraduate Admissions Statistics, {y} cycle (linked from index)", day=day)
        print(y, p.stat().st_size, p.name)
    for y, u in sorted(centres.items()):
        p = fetch("cambridge_apply_centre", CAM_BASE + u, f"undergraduate_admissions_by_apply_centre_{y}_cycle.pdf",
                  f"Cambridge Applications, Offers and Acceptances by UCAS Apply Centre, {y} cycle (linked from index)",
                  day=day)
        print(y, p.stat().st_size, p.name)
    for fn, (u, note) in OXFORD.items():
        p = curl_fetch("oxford", u, fn, note, day=day)
        print(p.stat().st_size, p.name)
    for y, (ts, orig) in sorted(OXFORD_WAYBACK.items()):
        p = fetch("oxford", f"https://web.archive.org/web/{ts}id_/{orig}", f"oxford_admissions_report_{y}.pdf",
                  f"Oxford Annual Admissions Statistical Report {y}; Wayback capture {ts} of {orig}", day=day)
        print(p.stat().st_size, p.name)


if __name__ == "__main__":
    main()
