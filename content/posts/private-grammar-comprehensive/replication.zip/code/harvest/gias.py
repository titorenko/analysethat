"""Harvest the GIAS (Get Information About Schools) full establishment extract.

Usage: .venv/Scripts/python -I code/harvest/gias.py [--day YYYY-MM-DD]

The daily file name carries the date: edubasealldata<YYYYMMDD>.csv. --day selects both the file date and
the snapshot folder (default today).
"""
import argparse
import datetime as dt
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import fetch  # noqa: E402

URL = "https://ea-edubase-api-prod.azurewebsites.net/edubase/downloads/public/edubasealldata{ymd}.csv"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--day", default=dt.date.today().isoformat())
    a = ap.parse_args()
    ymd = a.day.replace("-", "")
    path = fetch("gias", URL.format(ymd=ymd), f"edubasealldata{ymd}.csv",
                 note=f"GIAS all establishments extract dated {a.day}", day=a.day, timeout=600)
    print(path, f"{path.stat().st_size:,d}")


if __name__ == "__main__":
    main()
