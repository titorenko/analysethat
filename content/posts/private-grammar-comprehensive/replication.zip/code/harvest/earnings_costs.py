"""Harvest raw files for the earnings, tax and cost slice (sources ons_fsm, rr1125, ashe, ons_adhoc3105,
boe, isc, ifs, hmt, obr, school_funding).

Run:  .venv/Scripts/python -I code/harvest/earnings_costs.py [--day YYYY-MM-DD] [--only SOURCE ...]

Landing pages are saved too (they are the evidence for which file links existed on the day); the data
files are then discovered from them where the file name is not fixed. Idempotent: fetch() skips files
already present in the day's snapshot.
"""
import argparse
import pathlib
import re
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "harvest"))
from fetch import fetch  # noqa: E402

ONS = "https://www.ons.gov.uk"
GOV = "https://www.gov.uk"


def hrefs(path: pathlib.Path, pattern: str) -> list[str]:
    """Unique href values in a saved HTML page matching a regex, in page order."""
    text = path.read_text(encoding="utf-8", errors="replace")
    out = []
    for h in re.findall(r'href="([^"]+)"', text):
        if re.search(pattern, h) and h not in out:
            out.append(h)
    return out


def ons_fsm(day):
    page = fetch("ons_fsm", f"{ONS}/peoplepopulationandcommunity/educationandchildcare/articles/"
                 "whyfreeschoolmealrecipientsearnlessthantheirpeers/2022-08-04",
                 "article_2022-08-04.html", "ONS article, released 4 Aug 2022 (figure links)", day)
    figs = hrefs(page, r"dvc2083/Fig_\d_[^/]+/datadownload\.xlsx$")
    assert len(figs) == 7, figs
    for url in figs:
        name = url.split("/")[-2]                      # e.g. Fig_1_Earnings_percentiles
        fetch("ons_fsm", url, f"{name}.xlsx", "ONS FSM earnings article 4 Aug 2022, figure data download", day)


def rr1125(day):
    fetch("rr1125", "https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/"
          "file/1122775/Research_report_-_Post_16_education_and_labour_market_activities_pathways_and_outcomes_LEO.pdf",
          "RR1125_post16_pathways_LEO.pdf", "DfE RR1125 (Anderson & Nelson), report dated May 2021, file Dec 2022", day)


def ashe(day):
    page = fetch("ashe", f"{ONS}/employmentandlabourmarket/peopleinwork/earningsandworkinghours/datasets/"
                 "agegroupashetable6", "agegroupashetable6_dataset_page.html",
                 "ASHE Table 6 dataset page (editions list; release date / next release)", day)
    zips = hrefs(page, r"agegroupashetable6/\d{4}[a-z]*/[^/]+\.zip$")
    # 2025 provisional is always kept (the G1-ASHE gate is pinned to it); 2026 provisional is added when it appears
    for edition, note in (("2025provisional", "released 23 Oct 2025"), ("2026provisional", "new edition")):
        hit = [z for z in zips if f"/{edition}/" in z]
        if hit:
            fetch("ashe", ONS + hit[0], hit[0].split("/")[-1], f"ASHE Table 6, {edition}, {note}", day)
        print(f"ashe: {edition} {'on' if hit else 'NOT on'} the dataset page")


def ons_adhoc3105(day):
    page = fetch("ons_adhoc3105", f"{ONS}/employmentandlabourmarket/peopleinwork/earningsandworkinghours/adhocs/"
                 "3105annualsurveyofhoursandearningsashegrossannualearningsforthe90to99percentilesofemployeejobs"
                 "bysectorintheukandregions2024and2025", "adhoc3105_page.html",
                 "ONS ad hoc 3105 page, released 4 Nov 2025", day)
    zips = hrefs(page, r"\.zip$")
    assert len(zips) == 2, zips
    for z in zips:
        fetch("ons_adhoc3105", ONS + z, z.split("/")[-1], "ONS ad hoc 3105 (ASHE P90-P99 gross annual), released 4 Nov 2025", day)


def boe(day):
    fetch("boe", "https://www.bankofengland.co.uk/-/media/boe/files/statistics/yield-curves/latest-yield-curve-data.zip",
          "latest-yield-curve-data.zip", "BoE yield curves, latest (current month daily) zip", day)


def isc(day):
    fetch("isc", "https://www.isc.co.uk/media/5rmduu0j/2026-06-isc-census-2026.pdf", "isc_census_2026.pdf",
          "ISC Census and Annual Report 2026 (census Jan 2026, published Jun 2026)", day)
    fetch("isc", "https://www.isc.co.uk/media/0u0llqvv/_isc_census_2025_29may25.pdf", "isc_census_2025.pdf",
          "ISC Census and Annual Report 2025 (census Jan 2025, published 29 May 2025)", day)


def ifs(day):
    fetch("ifs", "https://ifs.org.uk/sites/default/files/2026-06/IFS%20Report%20-%20New%20estimates%20of%20the%20"
          "impact%20of%20undergraduate%20degrees%20on%20lifetime%20earnings.pdf",
          "ifs_2026_degrees_lifetime_earnings.pdf",
          "IFS report for DfE, Britton, Ogden, Ornadel & Waltmann, June 2026", day)


def hmt(day):
    fetch("hmt", "https://assets.publishing.service.gov.uk/media/698f30a4492ea446ea7f43d3/"
          "Green_Book_supplementary_guidance_-_discounting.pdf", "green_book_discounting_2026-02.pdf",
          "HMT Green Book supplementary guidance: discounting, Feb 2026", day)
    fetch("hmt", "https://assets.publishing.service.gov.uk/media/6a43915e7ac6fd9c6a94abbe/"
          "Findings_and_Recommendations_-_Green_Book_Discount_Rate_Review.pdf", "green_book_discount_rate_review_2026-06.pdf",
          "Groom & Freeman, Green Book Discount Rate Review: findings and recommendations, June 2026", day)
    fetch("hmt", f"{GOV}/guidance/rates-and-thresholds-for-employers-2026-to-2027",
          "rates_and_thresholds_for_employers_2026-27.html", "gov.uk rates and thresholds for employers 2026 to 2027", day)
    fetch("hmt", f"{GOV}/income-tax-rates/income-over-100000", "income_over_100000.html",
          "gov.uk personal allowance taper page", day)
    fetch("hmt", f"{GOV}/government/news/student-loans-interest-rates-and-repayment-threshold-announcement--7",
          "slc_interest_announcement_2026-08.html", "SLC interest rates and thresholds announcement, 10 Aug 2026", day)


def obr(day):
    fetch("obr", "https://obr.uk/frs/fiscal-risks-and-sustainability-july-2026/", "frs_july_2026.html",
          "OBR Fiscal risks and sustainability, 7 Jul 2026 (Table 2.1 in page HTML)", day)


def school_funding(day):
    fetch("school_funding", "https://ifs.org.uk/sites/default/files/2026-01/"
          "IFS-annual-report-on-education-spending-in-England-2025%E2%80%9326.pdf",
          "ifs_annual_report_education_spending_2025-26.pdf",
          "IFS annual report on education spending in England 2025-26 (Jan 2026); IFS HTML pages return 403", day)
    fetch("school_funding", "https://explore-education-statistics.service.gov.uk/data-catalogue/data-set/"
          "ce1e4917-b2ea-45bc-9a89-e4608c7c67d3/csv", "dfe_revenue_funding_5to16_2010-11_to_2026-27.csv",
          "DfE School funding statistics FY2025-26 release: revenue funding to state-funded schools, pupils aged 5-16, "
          "cash and real, 2010-11 to 2026-27 (EES data set ce1e4917)", day)
    page = fetch("school_funding", f"{GOV}/government/publications/national-funding-formula-tables-for-schools-and-high-needs-2025-to-2026",
                 "nff_tables_2025-26_page.html", "gov.uk NFF tables for schools and high needs 2025 to 2026 (landing page)", day)
    ods = hrefs(page, r"NFF_LA_summary_tables\.ods$")
    fetch("school_funding", ods[0], "NFF_LA_summary_tables_2025-26.ods",
          "DfE NFF tables for schools and high needs 2025 to 2026: LA summary tables (published Dec 2024)", day)


SOURCES = {f.__name__: f for f in (ons_fsm, rr1125, ashe, ons_adhoc3105, boe, isc, ifs, hmt, obr, school_funding)}

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--day", help="snapshot date folder (default today)")
    ap.add_argument("--only", nargs="*", choices=sorted(SOURCES), help="subset of sources")
    a = ap.parse_args()
    failed = []
    for name in a.only or SOURCES:
        try:
            SOURCES[name](a.day)
            print(f"{name}: ok")
        except Exception as e:                       # report and carry on; blocked sites are noted by hand
            failed.append(name)
            print(f"{name}: FAILED {e}")
    sys.exit(1 if failed else 0)
