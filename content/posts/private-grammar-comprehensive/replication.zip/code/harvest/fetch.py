"""Shared downloader: every raw file in data/raw is fetched through here and logged to data/manifest.

Usage from another script:
    from fetch import fetch
    path = fetch(source="dfe_wp", url=..., filename="school_type.csv", note="WP School Type, 2024/25 release")

Each source has its own folder data/raw/<source>/<snapshot date>/ and manifest data/manifest/<source>.csv.
Re-running on another day creates a new dated snapshot; re-running on the same day skips files already present.
"""
import csv
import datetime as dt
import hashlib
import pathlib
import time

import requests

ROOT = pathlib.Path(__file__).resolve().parents[2]          # .../schools
RAW = ROOT / "data" / "raw"
MANIFEST = ROOT / "data" / "manifest"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36"
FIELDS = ["source", "url", "local_path", "retrieved_utc", "http_status", "bytes", "sha256", "note"]


def snapshot_dir(source: str, day: str | None = None) -> pathlib.Path:
    d = RAW / source / (day or dt.date.today().isoformat())
    d.mkdir(parents=True, exist_ok=True)
    return d


def fetch(source: str, url: str, filename: str, note: str = "", day: str | None = None,
          retries: int = 3, timeout: int = 120) -> pathlib.Path:
    dest = snapshot_dir(source, day) / filename
    if dest.exists() and dest.stat().st_size > 0:
        return dest
    last = None
    for attempt in range(retries):
        try:
            r = requests.get(url, headers={"User-Agent": UA}, timeout=timeout)
            last = r.status_code
            if r.status_code == 200 and r.content:
                dest.write_bytes(r.content)
                _log(source, url, dest, r.status_code, r.content, note)
                return dest
        except requests.RequestException as e:   # network hiccup: retry
            last = repr(e)
        time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"fetch failed ({last}): {url}")


def _log(source, url, dest, status, content, note):
    MANIFEST.mkdir(parents=True, exist_ok=True)
    mf = MANIFEST / f"{source}.csv"
    new = not mf.exists()
    with mf.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        if new:
            w.writeheader()
        w.writerow({
            "source": source, "url": url, "local_path": str(dest.relative_to(ROOT)).replace("\\", "/"),
            "retrieved_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
            "http_status": status, "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest(),
            "note": note,
        })
