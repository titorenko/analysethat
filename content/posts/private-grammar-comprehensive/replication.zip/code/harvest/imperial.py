"""Harvest Imperial College London's 'Application figures by School 2020-24' workbook (publication scheme).

The file is linked from Imperial's frequently requested information page (freedom of information); it answers
FOI requests IMPFOI-25-237, -276 and -311. One sheet per entry year 2020-21 ... 2024-25, one row per UCAS apply
centre with applications, offers, rejections and acceptances, nothing suppressed. The URL's 'pulication' typo is
Imperial's own.

    .venv/Scripts/python -I code/harvest/imperial.py [--day YYYY-MM-DD]
"""
import argparse
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import fetch  # noqa: E402

URL = ("https://www.imperial.ac.uk/media/imperial-college/administration-and-support-services/legal-services-office/"
       "public/freedom-of-information/pulication-scheme-docs/Application-figures-by-School-2020-2024.xlsx")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--day")
    a = ap.parse_args()
    print(fetch(source="imperial_apply_centre", url=URL, filename="Application-figures-by-School-2020-2024.xlsx",
                note="Imperial College London publication scheme: UG application figures by UCAS apply centre, "
                     "entry 2020-21 to 2024-25 (FOI IMPFOI-25-237/276/311)", day=a.day))
