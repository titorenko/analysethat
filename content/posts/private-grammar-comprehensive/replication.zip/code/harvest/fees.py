"""Harvest fee pages and charity accounts for the 45 independents in data/derived/top30_independent.csv, plus the
2026/27 live fee pages (and linked fee PDFs) of the 20 schools in data/derived/bottom20_private.csv.

Sources written (all through fetch.py):
  fees_cdx            Wayback CDX listings of fee-like URLs per school domain (discovery evidence)
  fees                live fee pages (2026/27) as <urn>_2026.<ext>; Wayback captures (2025/26) as <urn>_2025.<ext>
                      (a stem ending in _pdf is saved as .pdf whatever the URL looks like)
  charity_commission  Charity Commission register extract (publicextract.charity.zip)
  charity_accounts    OpenCharities charity JSON and accounts-as-text HTML, <charity number>_<fy end>_accounts.html

Run:  .venv/Scripts/python -I code/harvest/fees.py [--day YYYY-MM-DD] [--only cdx live wayback charity accounts]

Politeness: one request per second per site at most (PAUSE between calls; fetch() itself does not throttle).
Pages that cannot be fetched by script are reported, not retried by other means; the builder records them
as `blocked`. Idempotent: fetch() skips files already present in the day's snapshot.
"""
import argparse
import json
import pathlib
import sys
import time
import urllib.parse

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "harvest"))
from fetch import fetch, snapshot_dir  # noqa: E402

PAUSE = 1.5
WB_PAUSE = 6      # archive.org refuses connections for a while after bursts (seen at ~1.5 s spacing)
CDX = "http://web.archive.org/cdx/search/cdx"

# urn -> school web domain (GIAS SchoolWebsite; GIAS is blank for St Paul's, Habs Boys and Trinity)
DOMAINS = {
    "100366": "spgs.org", "102942": "stpaulsschool.org.uk", "101162": "westminster.org.uk",
    "102257": "nlcs.org.uk", "114614": "brightoncollege.org.uk", "102684": "kcs.org.uk",
    "125342": "guildfordhigh.co.uk", "100369": "godolphinandlatymer.com", "100001": "clsg.org.uk",
    "102692": "wimbledonhigh.gdst.net", "123623": "concordcollegeuk.com", "123311": "mcsoxford.org",
    "110923": "perse.co.uk", "100370": "latymer-upper.org", "103585": "kehs.org.uk",
    "102163": "highgateschool.org.uk", "110547": "wycombeabbey.com", "100864": "alleyns.org.uk",
    "100076": "shhs.gdst.net", "102932": "lehs.org.uk", "100003": "cityoflondonschool.org.uk",
    "117648": "habselstree.org.uk", "101072": "putneyhigh.gdst.net", "105595": "wgs.org",
    "117649": "habselstree.org.uk", "110158": "etoncollege.com", "100863": "jags.org.uk",
    "125424": "rgsg.co.uk", "102619": "kgs.org.uk", "102875": "bancrofts.org",
    "118959": "tonbridge-school.co.uk", "102946": "hamptonschool.org.uk", "101842": "trinity-school.org",
    "116532": "winchestercollege.org", "125422": "reigategrammar.org", "118952": "sevenoaksschool.org",
    "110120": "st-marys-ascot.co.uk", "105591": "mgs.org", "117617": "stahs.org.uk",
    "117616": "mtsn.org.uk", "100065": "ucs.org.uk", "123312": "abingdon.org.uk",
    "122915": "nottinghamhigh.co.uk", "101161": "fhs-sw1.org.uk", "116534": "stswithuns.com",
    "101071": "emanuel.org.uk",   # added to the list on 2026-10-10 16:46 (Concord College dropped)
}

# Pages to save. key = file stem (<urn>_<year>[_<part>]); value = URL. Live = school site (2026/27);
# Wayback = web.archive.org/web/<timestamp>id_/<original> (2025/26, capture Sept 2025 - July 2026).
WB = "https://web.archive.org/web/"
LIVE = {
    "101162_2026": "https://www.westminster.org.uk/admissions/westminster-school-fees/",
    "123312_2026": "https://www.abingdon.org.uk/admissions/fees-and-insurance/",
    "100864_2026": "https://www.alleyns.org.uk/admissions/school-fees",
    "102875_2026": "https://www.bancrofts.org/admissions/school-fees/",
    "114614_2026": "https://www.brightoncollege.org.uk/parents/fees",
    "100003_2026": "https://www.cityoflondonschool.org.uk/admissions/fees/",
    "100001_2026": "https://clsg.org.uk/admissions/fees/",
    "123623_2026": "https://concordcollegeuk.com/admissions/boarding-fees/",
    "123623_2026_day": "https://concordcollegeuk.com/admissions/day-fees/",
    "110158_2026": "https://www.etoncollege.com/admissions/fees/",
    "101161_2026": "https://www.fhs-sw1.org.uk/admissions/fees/",
    "100369_2026": "https://www.godolphinandlatymer.com/admissions/fees/",
    "125342_2026": "https://www.guildfordhigh.co.uk/admissions/fees/",
    "117648_2026": "https://www.habselstree.org.uk/boys/admissions/fees/",
    "117649_2026": "https://www.habselstree.org.uk/girls/admissions/fees/",
    "102946_2026": "https://hamptonschool.org.uk/admissions/fees/",
    "102163_2026": "https://www.highgateschool.org.uk/admissions/school-fees/",
    "100863_2026": "https://www.jags.org.uk/admissions/fees/",
    "102684_2026": "https://www.kcs.org.uk/admissions/fees",
    "103585_2026": "https://kehs.org.uk/admissions/fees/",
    "102619_2026": "https://www.kgs.org.uk/admissions/fees/",
    "100370_2026": "https://www.latymer-upper.org/admissions/fees/",
    "102932_2026": "https://www.lehs.org.uk/admissions/fees/",
    "123311_2026": "https://www.mcsoxford.org/admissions/fees/",
    "105591_2026": "https://www.mgs.org/admissions/fees-and-assistance",
    "117616_2026": "https://www.mtsn.org.uk/admissions/fees/",
    "122915_2026": "https://www.nottinghamhigh.co.uk/admissions/school-fees",
    "110923_2026": "https://www.perse.co.uk/admissions/upper/fees/",
    "101072_2026": "https://www.putneyhigh.gdst.net/admissions/fees/",
    "125422_2026": "https://www.reigategrammar.org/admissions/fees/school-fees",
    "125424_2026": "https://www.rgsg.co.uk/admissions/fees/",
    "118952_2026": "https://www.sevenoaksschool.org/admissions/fees/overview/",
    "100366_2026": "https://spgs.org/admissions/fees-and-scholarships/",
    "117617_2026": "https://www.stahs.org.uk/admissions/fees/",
    "102942_2026": "https://www.stpaulsschool.org.uk/admissions/fees/",
    "116534_2026": "https://www.stswithuns.com/fees",
    "116534_2026_senior": "https://www.stswithuns.com/senior-fees",
    "118959_2026": "https://www.tonbridge-school.co.uk/admissions/fees-charges/",
    "101842_2026": "https://www.trinity-school.org/admissions/fees-bursaries-scholarships/",
    "100065_2026": "https://www.ucs.org.uk/admissions/fees/",
    "105595_2026": "https://www.wgs.org/admissions/fees/",
    "102692_2026": "https://www.wimbledonhigh.gdst.net/admissions/fees/",
    "116532_2026": "https://www.winchestercollege.org/fees/",
    "102257_2026": "https://www.nlcs.org.uk/admissions/fees/",
    "100076_2026": "https://www.shhs.gdst.net/admissions/fees/",
    "110547_2026": "https://www.wycombeabbey.com/admissions/",
    "110120_2026": "https://www.st-marys-ascot.co.uk/admissions/",
    "114614_2026_pdf": "https://www.brightoncollege.org.uk/file/45/1718872598/"
                       "brighton-college-uk-boarding-and-day-fees-structure-2026-27.pdf",
    "102684_2026_json": "https://www.kcs.org.uk/?method=url&path=/admissions/fees",
    "117617_2026_pdf": "https://www.stahs.org.uk/wp-content/uploads/2026/04/Schedule-of-Fees-2026-27.pdf",
    "101071_2026": "https://www.emanuel.org.uk/admissions/fees/",
    "101071_2026_table": "https://www.emanuel.org.uk/wp-content/uploads/Screenshot-2026-04-21-160111-1.png",
    # --- bottom 20 private schools (data/derived/bottom20_private.csv), 2026/27 only, added 2026-10-10
    "146999_2026": "https://camphilleducation.co.uk/",
    "133444_2026": "https://www.ealingindependentcollege.com/admissions/fees-and-scholarships/",
    "100544_2026": "https://www.davidgamecollege.com/admissions/fees",
    "119835_2026": "https://www.kirkhamgrammar.co.uk/admissions/fees-and-charges",
    "122149_2026": "https://bosworthschool.co.uk/admission-process/fees/",
    "123600_2026": "https://www.ellesmere.com/admissions/fees",
    "113912_2026": "https://www.clayesmore.com/admissions/senior/fees",
    "113912_2026_sixth": "https://www.clayesmore.com/admissions/sixth/fees",
    "126522_2026": "https://www.warminsterschool.org.uk/admissions/school-fees/",
    "114336_2026": "https://www.barnardcastleschool.org.uk/admissions/fees/",
    "101685_2026": "https://www.farringtons.org.uk/admissions/fees-bursaries-scholarships/",
    "110159_2026": "https://www.lvs.ascot.sch.uk/admissions/admissions-fees/",
    "121730_2026": "https://scarboroughcollege.co.uk/school-fees/",
    "118947_2026": "https://www.slcuk.com/admissions/school-fees/",
    "124883_2026": "https://www.stjos.co.uk/admissions/fees/",
    "123282_2026": "https://www.oratory.co.uk/information/fees",
    "123613_2026": "https://www.oswestryschool.com/admissions/fees",
    "115788_2026": "https://www.wycliffe.co.uk/admissions/fees/",
    "118948_2026": "https://kings-rochester.co.uk/admissions/fees/",
    "111484_2026": "https://www.abbeygatecollege.co.uk/admissions/fees/",
    "110153_2026": "https://www.clairescourt.com/admissions/fees/",
    "109362_2026": "https://www.sidcot.org.uk/admissions/fees",   # replaces St Lawrence (closed), added 2026-10-10
    # fee PDFs linked from the pages above (hrefs taken from the saved pages)
    "100544_2026_pdf": "https://davidgame.reactfiles.co.uk/uploads/document/Home-EEA-Fees-2026-27-V2.pdf?t=1774546820",
    "100544_2026_boarding_pdf": "https://davidgame.reactfiles.co.uk/uploads/document/Boarding-Fees-Only-2026-27.pdf"
                                "?t=1773657156",
    "122149_2026_pdf": "https://bosworthschool.co.uk/wp-content/uploads/2025/10/Domestic-Fees-2026_2027.pdf",
    "123600_2026_pdf": "https://www.ellesmere.com/fs/resource-manager/view/52ac5867-ee1b-4c0e-8737-460b539fce3d",
    "114336_2026_pdf": "https://www.barnardcastleschool.org.uk/wp-content/uploads/2026/08/Fees-2026.27-for-website.pdf",
    "121730_2026_pdf": "https://scarboroughcollege.co.uk/wp-content/uploads/2026/04/Scarborough-College-2026-27-Fees.pdf",
    "124883_2026_pdf": "https://stjosephscollege.sds-chapterandverse.co.uk/cat/admissions%20%20attendance/"
                       "PoliciesAndProcedures/DownloadFile?recordID=26",
    "123613_2026_pdf": "https://www.oswestryschool.com/userfiles/oswestrysmvc/documents/260605%202026-27%20fees.pdf",
    "109362_2026_pdf": "https://www.sidcot.org.uk/sites/default/files/2026-07/"
                       "Updated%20Sidcot%20School%20Fees%2020262027%20%281%29.pdf",
}
WAYBACK = {
    "101162_2025": WB + "20251017204612id_/https://www.westminster.org.uk/admissions/fees/",
    "123312_2025": WB + "20251109074640id_/https://www.abingdon.org.uk/admissions/fees-and-insurance/",
    "100864_2025": WB + "20251212122637id_/https://www.alleyns.org.uk/admissions/school-fees",
    "102875_2025": WB + "20251014012530id_/https://www.bancrofts.org/admissions/school-fees/",
    "102875_2025_pdf": WB + "20251201152019id_/https://www.bancrofts.org/wp-content/uploads/2025/11/"
                            "Schedule-of-Fees-2025-2026.pdf",
    "114614_2025": WB + "20250916110834id_/https://www.brightoncollege.org.uk/parents/fees",
    "114614_2025_pdf": WB + "20251209035701id_/https://www.brightoncollege.org.uk/assets/files/uploads/"
                            "brighton-college-uk-boarding-and-day-fees-structure-2025-26.pdf",
    "123623_2025": WB + "20251006135622id_/https://concordcollegeuk.com/admissions/boarding-fees/",
    "123623_2025_day": WB + "20251006135605id_/https://concordcollegeuk.com/admissions/day-fees/",
    "110158_2025": WB + "20250907105636id_/https://www.etoncollege.com/admissions/fees/",
    "101161_2025": WB + "20260211065747id_/https://www.fhs-sw1.org.uk/admissions/fees/",
    "100369_2025": WB + "20251009182410id_/https://www.godolphinandlatymer.com/admissions/fees/",
    "117648_2025": WB + "20260114140433id_/https://www.habselstree.org.uk/boys/admissions/fees/",
    "117649_2025": WB + "20250901183620id_/https://www.habselstree.org.uk/girls/admissions/fees/",
    "102946_2025": WB + "20260316100804id_/https://hamptonschool.org.uk/admissions/fees/",
    "102163_2025": WB + "20250906202316id_/https://www.highgateschool.org.uk/admissions/school-fees/",
    "100863_2025": WB + "20260118104208id_/https://www.jags.org.uk/admissions/fees/",
    "102684_2025": WB + "20250923051118id_/https://www.kcs.org.uk/content/fees-finance",
    "103585_2025": WB + "20251013054018id_/https://kehs.org.uk/admissions/fees/",
    "103585_2025_pdf": WB + "20251028092750id_/https://kehs.org.uk/wp-content/uploads/2025/08/"
                            "Fees-and-Charges-KEHS-2025-26.pdf",
    "102619_2025": WB + "20260507094046id_/https://www.kgs.org.uk/admissions/fees/",
    "100370_2025": WB + "20260720201908id_/https://www.latymer-upper.org/admissions/fees/",
    "102932_2025": WB + "20251014043148id_/https://www.lehs.org.uk/admissions/fees",
    "123311_2025": WB + "20260415133036id_/https://www.mcsoxford.org/admissions/fees/",
    "105591_2025": WB + "20250913142211id_/https://www.mgs.org/admissions/fees-and-assistance",
    "117616_2025": WB + "20250912200017id_/https://www.mtsn.org.uk/admissions/fees/",
    "122915_2025": WB + "20251010081824id_/https://www.nottinghamhigh.co.uk/admissions/school-fees",
    "110923_2025": WB + "20260214152756id_/https://www.perse.co.uk/admissions/upper/fees/",
    "101072_2025": WB + "20251018174202id_/https://www.putneyhigh.gdst.net/admissions/fees/",
    "125422_2025": WB + "20251107192925id_/https://www.reigategrammar.org/admissions/fees/school-fees",
    "125424_2025": WB + "20251107030821id_/https://www.rgsg.co.uk/admissions/fees/",
    "118952_2025": WB + "20251116215508id_/https://www.sevenoaksschool.org/admissions/fees/overview/",
    "100366_2025": WB + "20251208073325id_/https://spgs.org/admissions/fees-and-scholarships/",
    "117617_2025": WB + "20260122230033id_/https://www.stahs.org.uk/admissions/fees/",
    "102942_2025": WB + "20251009140052id_/https://www.stpaulsschool.org.uk/admissions/fees/",
    "116534_2025": WB + "20251013220907id_/https://www.stswithuns.com/fees",
    "116534_2025_senior": WB + "20251013215054id_/https://www.stswithuns.com/senior-fees",
    "118959_2025": WB + "20251105033349id_/https://www.tonbridge-school.co.uk/admissions/fees-charges/",
    "101842_2025": WB + "20251016101038id_/https://www.trinity-school.org/admissions/fees-bursaries-scholarships/",
    "100065_2025": WB + "20260315052752id_/https://www.ucs.org.uk/admissions/fees/",
    "105595_2025": WB + "20251114045713id_/https://www.wgs.org/admissions/fees/",
    "102692_2025": WB + "20251028224902id_/https://www.wimbledonhigh.gdst.net/admissions/fees/",
    "116532_2025": WB + "20250913104023id_/https://www.winchestercollege.org/fees/",
    "102257_2025": WB + "20251018102312id_/https://www.nlcs.org.uk/admissions/fees/",
    "100076_2025": WB + "20251016120514id_/https://www.shhs.gdst.net/admissions/fees/",
    "110547_2025": WB + "20251118014309id_/https://www.wycombeabbey.com/admissions/",
    "110120_2025": WB + "20251018110611id_/https://www.st-marys-ascot.co.uk/admissions/",
}


# exact-URL CDX listings where the fee page URL has no "fee" in it (fees sit on the admissions page)
# and checks behind no_snapshot statuses (value = extra CDX parameters: matchType, filter)
CDX_URLS = {"wycombeabbey.com_admissions.json": ("wycombeabbey.com/admissions/", {}),
            "st-marys-ascot.co.uk_admissions.json": ("st-marys-ascot.co.uk/admissions/", {}),
            "stahs_schedule_2025-26_pdf.json": ("stahs.org.uk/wp-content/uploads/2025/06/Schedule-of-Fees-2025-26-1.pdf", {}),
            "kcs.org.uk_content_api.json": ("kcs.org.uk/", {"matchType": "prefix", "filter": "original:.*method=url.*"}),
            "fhs-sw1.org.uk_admin-ajax.json": ("fhs-sw1.org.uk/wp-admin/admin-ajax.php", {"matchType": "prefix"}),
            "fhs-sw1.org.uk_info_book_2025-26.json":
                ("fhs-sw1.org.uk/wp-content/uploads/FHS-Sloane-Square-Information-Book-2025-26.pdf", {})}


# Schools whose only in-window captures show 2026/27 fees, so no 2025/26 page is saved (recorded as no_snapshot):
# CLS and CLSG (captures 2026-07-16/20 only; the CLS 2025-11-05 capture is HTTP 202, a bot-challenge page),
# Guildford High (2026-07-20 only), Latymer Upper (2026-07-20 only), Emanuel (2026-07-16/20 only; the 07-16 capture
# was fetched, showed 2026/27 fees, and was deleted).
# Captures replaced because the first in-window one was a bot-challenge page ("One moment, please...") or a
# Common Crawl record stored brotli-encoded (undecodable without the brotli package): SPGS, JAGS, NLCS, Perse,
# STAHS, Habs Boys, Concord (day), Wycombe Abbey.


# Admissions pages, fetched only where the saved fee page gives no evidence of the senior entry points
ADMISSIONS = {
    "114614": "https://www.brightoncollege.org.uk/admissions/",
    "125342": "https://www.guildfordhigh.co.uk/admissions/admissions-process/",
    "117648": "https://www.habselstree.org.uk/boys/admissions/admissions-process/",
    "117649": "https://www.habselstree.org.uk/girls/admissions/admissions-process/",
    "102946": "https://hamptonschool.org.uk/admissions/admissions-process/",
    "125422": "https://www.reigategrammar.org/admissions/admissions-process",
    "122915": "https://www.nottinghamhigh.co.uk/admissions/admissions-process-1",
    "125424": "https://www.rgsg.co.uk/admissions/senior-ages-11-18/",
    "102692": "https://www.wimbledonhigh.gdst.net/admissions/joining-wimbledon-high/",
    "101072": "https://www.putneyhigh.gdst.net/admissions/joining-putney-high/",
    "100863": "https://www.jags.org.uk/admissions/joining-jags/",
    "110923": "https://www.perse.co.uk/admissions/upper/joining/",
}


def admissions(day):
    failures = []
    for urn, url in ADMISSIONS.items():
        _get("fees", url, f"{urn}_admissions.html", "live admissions page (entry points)", day, failures)
    return failures


def cdx(day):
    """One CDX listing per domain: fee-like URLs captured 2025-08 .. 2026-10 (for choosing live and 2025/26 pages)."""
    for domain in sorted(set(DOMAINS.values())):
        q = {"url": domain, "matchType": "domain", "from": "20250801", "to": "20261010", "output": "json",
             "filter": "original:.*([Ff]ees|[Ff]ee[-_]|FEES).*", "collapse": "digest"}
        url = CDX + "?" + urllib.parse.urlencode(q)
        try:
            fetch("fees_cdx", url, f"{domain}.json", "Wayback CDX: fee-like URLs, 2025-08-01..2026-10-10", day)
        except RuntimeError as e:
            print("CDX FAIL", domain, e)
        time.sleep(WB_PAUSE)
    for name, (target, extra) in CDX_URLS.items():
        q = {"url": target, "from": "20250801", "to": "20261010", "output": "json", "collapse": "digest", **extra}
        try:
            fetch("fees_cdx", CDX + "?" + urllib.parse.urlencode(q), name,
                  f"Wayback CDX: {extra.get('matchType', 'exact')} URL, 2025-08-01..2026-10-10", day)
        except RuntimeError as e:
            print("CDX FAIL", target, e)
        time.sleep(WB_PAUSE)


def _get(source, url, filename, note, day, failures, pause=PAUSE):
    try:
        p = fetch(source, url, filename, note, day)
        print("ok  ", filename, p.stat().st_size)
    except RuntimeError as e:
        failures.append((filename, url, str(e)))
        print("FAIL", filename, e)
    time.sleep(pause)


def live(day):
    failures = []
    for stem, url in LIVE.items():
        ext = ".pdf" if stem.endswith("_pdf") else \
            next((e for e in (".pdf", ".png") if url.lower().split("?")[0].endswith(e)), ".html")
        _get("fees", url, stem + ext, "live school fee page, 2026/27", day, failures)
    return failures


def wayback(day):
    failures = []
    for stem, url in WAYBACK.items():
        ext = ".pdf" if url.lower().split("?")[0].endswith(".pdf") else ".html"
        ts = url.split("/web/")[1].split("id_")[0]
        _get("fees", url, stem + ext, f"Wayback capture {ts} of school fee page, 2025/26", day, failures,
             WB_PAUSE)
    return failures


# charity number -> URNs it runs (matched in the register extract by postcode, web domain and name; see
# data/notes/fees_bursaries.md). City of London School and CLSG are run by the City of London Corporation and
# are not charities; 1020824 is CLS's separate bursary trust (fetched for its bursary spend only).
CHARITIES = {
    "1119613": ["100366"], "1119619": ["102942"], "312728": ["101162"], "1115843": ["102257"],
    "307061": ["114614"], "310024": ["102684"], "1016538": ["125342"], "312699": ["100369"],
    "306983": ["102692", "100076", "101072"], "326279": ["123623"], "295785": ["123311"],
    "1120654": ["110923"], "312714": ["100370"], "529051": ["103585"], "312765": ["102163"],
    "310638": ["110547"], "1161864": ["100864"], "1130254": ["102932"], "1020824": ["100003"],
    "313996": ["117648", "117649"], "1158226": ["105595"], "1139086": ["110158"], "1124853": ["100863"],
    "1177353": ["125424"], "1078461": ["102619"], "1068532": ["102875"], "1097977": ["118959"],
    "1120005": ["102946"], "312612": ["101842"], "1139000": ["116532"], "1081898": ["125422"],
    "1101358": ["118952"], "290286": ["110120"], "529909": ["105591"], "311065": ["117617"],
    "1063740": ["117616"], "312748": ["100065"], "1071298": ["123312"], "1104251": ["122915"],
    "312745": ["101161"], "307335": ["116534"], "1181012": ["101071"],
}
OC = "https://opencharities.uk"


def accounts(day):
    """OpenCharities JSON per charity, then the latest accounts PDF (CC filing mirror) and its text (.md)."""
    failures = []
    for num in CHARITIES:
        try:
            js = fetch("charity_accounts", f"{OC}/ew/{num}.json", f"{num}.json", "OpenCharities charity JSON", day)
        except RuntimeError as e:
            failures.append((f"{num}.json", num, str(e)))
            continue
        time.sleep(PAUSE)
        years = [y for y in json.loads(js.read_text(encoding="utf-8"))["financial_years"] if y.get("accounts_url")]
        if not years:
            failures.append((num, "no accounts_url", ""))
            continue
        y = max(years, key=lambda y: y["end"])
        _get("charity_accounts", y["accounts_url"], f"{num}_{y['end']}_accounts.pdf",
             f"accounts FY to {y['end']} (OpenCharities mirror of the CC filing)", day, failures)
        _get("charity_accounts", OC + y["accounts_md_url"], f"{num}_{y['end']}_accounts.md",
             f"accounts FY to {y['end']} as text (OpenCharities)", day, failures)
    return failures


def charity(day):
    fetch("charity_commission",
          "https://ccewuksprdoneregsadata1.blob.core.windows.net/data/txt/publicextract.charity.zip",
          "publicextract.charity.zip", "Charity Commission register full extract (charity table, txt)", day)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--day")
    ap.add_argument("--only", nargs="*", default=["cdx", "live", "wayback", "charity", "accounts", "admissions"])
    a = ap.parse_args()
    fails = []
    if "charity" in a.only:
        charity(a.day)
    if "cdx" in a.only:
        cdx(a.day)
    if "live" in a.only:
        fails += live(a.day)
    if "wayback" in a.only:
        fails += wayback(a.day)
    if "accounts" in a.only:
        fails += accounts(a.day)
    if "admissions" in a.only:
        fails += admissions(a.day)
    for f in fails:
        print("FAILED:", *f)


if __name__ == "__main__":
    main()
