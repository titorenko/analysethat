"""Harvest DfE Explore Education Statistics (EES) files: 16-18 results, KS4, Widening Participation,
destination measures.

Usage: .venv/Scripts/python -I code/harvest/dfe_ees.py [--day YYYY-MM-DD] [--source dfe_ks5 ...]

Two kinds of data set:
- "api": EES public API data set. Saves the data-set JSON (carries latestVersion.version), the /meta JSON
  (filters and indicators) and the full CSV as <stem>_v<version>.csv.
- "cat": data-catalogue file with no API version. Saves the content-API JSON (release, lastUpdated) and the
  full CSV as <stem>.csv.
Each fetch is logged in data/manifest/<source>.csv; the note carries the version or release date.

The 1 GB (16-18) and 538 MB (KS4) destination "api" files are NOT fetched: the institution-level and
national-level catalogue files carry the same school and national rows.
"""
import argparse
import json
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import fetch  # noqa: E402

API = "https://api.education.gov.uk/statistics/v1/data-sets/{id}"
CAT_META = "https://content.explore-education-statistics.service.gov.uk/api/data-set-files/{id}"
CAT_CSV = "https://explore-education-statistics.service.gov.uk/data-catalogue/data-set/{id}/csv"

# (source, kind, id, stem)
DATASETS = [
    # Widening participation in HE, 2024/25 release
    ("dfe_wp", "cat", "93f0e5c3-6cf9-4344-a88b-6c64c3c01143", "wp_school_type"),
    ("dfe_wp", "cat", "9394a8fb-f865-4f7b-8e02-6403c215873b", "wp_school_type_gap"),
    # A level and other 16 to 18 results, 2024/25
    ("dfe_ks5", "api", "019c2960-34d9-71c0-976c-3540602f2669", "ks5_institution_info"),
    ("dfe_ks5", "api", "019d9132-c369-7165-8288-207ef5e5e616", "ks5_nat_attainment_inst_sex"),
    ("dfe_ks5", "api", "019d9131-e08b-7776-b230-ccacc6d75c5c", "ks5_nat_va_inst_sex"),
    ("dfe_ks5", "api", "019d9137-6b57-75c3-8b08-457f83fc2dea", "ks5_nat_prior_attainment_inst_sex"),
    ("dfe_ks5", "api", "019c2960-81e3-70c2-8d65-72c3718ae4fd", "ks5_performance"),
    ("dfe_ks5", "api", "019c2960-abc0-700e-91ed-bb9823c0feed", "ks5_subject_va"),
    ("dfe_ks5", "api", "019c2960-df54-772f-8ad4-a2bc3d3b134f", "ks5_subject_grades"),
    # Key stage 4 performance, 2024/25 (school file covers 2022/23-2024/25)
    ("dfe_ks4", "cat", "467bf0c7-a003-44fe-8aa6-b51c49812c7d", "ks4_school_info"),
    ("dfe_ks4", "api", "18e39901-7fe3-8372-8b2b-33f7ae1e1d12", "ks4_nat_by_school_type"),
    ("dfe_ks4", "api", "19e39901-a96c-be76-b9c2-6af54ae076d2", "ks4_performance"),
    # Destination measures, 2023/24 releases
    ("dfe_dest", "cat", "771e2b11-ef92-4885-acb9-f4ae2881ca41", "dest_ks4_nat"),
    ("dfe_dest", "cat", "87c46b03-2361-43d3-baad-1b11f12af604", "progression_nat"),
    ("dfe_dest", "cat", "c3518f1e-7e51-48d9-ac47-1f1ab8767987", "progression_inst"),
    ("dfe_dest", "cat", "28cc87b6-ddbf-4bd3-8c62-fca3075dfbaf", "dest_1618_nat"),
    ("dfe_dest", "cat", "7be58881-d49f-4e3b-b2b6-0877a1a0fe6e", "dest_ks4_inst"),
    ("dfe_dest", "cat", "bbee3278-589b-436f-a031-adeb0368e49f", "dest_1618_inst"),
]


def harvest_api(source, ds_id, stem, day):
    url = API.format(id=ds_id)
    meta_path = fetch(source, url, f"{stem}_dataset.json", note=f"EES API data set {ds_id}", day=day)
    info = json.loads(meta_path.read_text(encoding="utf-8"))
    lv = info["latestVersion"]
    ver = lv["version"]
    fetch(source, url + "/meta", f"{stem}_meta.json", note=f"EES API meta {ds_id} v{ver}", day=day)
    note = (f"EES API {ds_id} '{info['title']}' v{ver} published {lv['published'][:10]}; "
            f"{lv['timePeriods']['start']}-{lv['timePeriods']['end']}; {lv['totalResults']} rows")
    return fetch(source, url + "/csv", f"{stem}_v{ver}.csv", note=note, day=day, timeout=600)


def harvest_cat(source, file_id, stem, day):
    meta_path = fetch(source, CAT_META.format(id=file_id), f"{stem}_catalogue.json",
                      note=f"EES catalogue file {file_id}", day=day)
    info = json.loads(meta_path.read_text(encoding="utf-8"))
    rel = info["release"]
    f = info["file"]
    note = (f"EES catalogue {file_id} '{info['title']}' ({f['name']}, {f['size']}); "
            f"{rel['publication']['title']} release '{rel['title']}' published {rel['published'][:10]}, "
            f"last updated {rel['lastUpdated'][:10]}")
    return fetch(source, CAT_CSV.format(id=file_id), f"{stem}.csv", note=note, day=day, timeout=600)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--day", help="snapshot folder date (YYYY-MM-DD); default today")
    ap.add_argument("--source", nargs="*", help="only these sources (e.g. dfe_ks5 dfe_wp)")
    a = ap.parse_args()
    for source, kind, ds_id, stem in DATASETS:
        if a.source and source not in a.source:
            continue
        path = (harvest_api if kind == "api" else harvest_cat)(source, ds_id, stem, a.day)
        print(f"{source:9s} {path.name:55s} {path.stat().st_size:>12,d}")


if __name__ == "__main__":
    main()
