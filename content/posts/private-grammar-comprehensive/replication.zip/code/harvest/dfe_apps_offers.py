"""Harvest DfE "Primary and secondary school applications and offers" 2026/27 (EES, published 18 Jun 2026).

Usage: .venv/Scripts/python -I code/harvest/dfe_apps_offers.py [--day YYYY-MM-DD]

The school-level file is a release *supporting file*, not a data-catalogue data set, so the whole release
ZIP (data + supporting files) is fetched; build_school_preferences.py reads the school-level CSV from it.
"""
import argparse
import json
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import fetch  # noqa: E402

RELEASE_ID = "0bf4f9cf-721d-44e3-8473-266c87e17e00"
FILES_LIST = ("https://content.explore-education-statistics.service.gov.uk/api/data-set-files"
              f"?releaseId={RELEASE_ID}&pageSize=40")
ZIP = f"https://content.explore-education-statistics.service.gov.uk/api/releases/{RELEASE_ID}/files"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--day")
    a = ap.parse_args()
    lst = fetch("dfe_apps_offers", FILES_LIST, "release_data_set_files.json",
                note=f"EES data-set files of release {RELEASE_ID} (Applications and offers 2026/27)", day=a.day)
    titles = [r["title"] for r in json.loads(lst.read_text(encoding="utf-8"))["results"]]
    path = fetch("dfe_apps_offers", ZIP, "apps_offers_2026-27_all_files.zip",
                 note=(f"EES release {RELEASE_ID} 'Primary and secondary school applications and offers' "
                       f"2026/27, published 2026-06-18, last updated 2026-06-29; full ZIP; data sets: "
                       + "; ".join(titles)), day=a.day, timeout=600)
    print(path, f"{path.stat().st_size:,d}")


if __name__ == "__main__":
    main()
