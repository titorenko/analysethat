"""Harvest grammar-school Year 7 admission data (test scores, cut-offs, testers, places) for the 45 grammars
in data/derived/top30_grammar.csv.

Usage: .venv/Scripts/python -I code/harvest/grammar_intake.py [--day YYYY-MM-DD] [--only ID ...]

Every file goes through fetch() (source "grammar_intake"). This wrapper adds what fetch() lacks:
- politeness: at least 1.1 s between two requests to the same host;
- failures are not fatal: url, error and time are appended to data/manifest/grammar_intake_blocked.csv
  (a site that refuses scripts is recorded as `blocked`, never guessed).
SOURCES rows: (id, url, filename, note). The id is what build_grammar_intake.py cites.
"""
import argparse
import csv
import datetime as dt
import sys
import time
import pathlib
from urllib.parse import urlparse

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import fetch, snapshot_dir, MANIFEST  # noqa: E402

SOURCE = "grammar_intake"
BLOCKED = MANIFEST / f"{SOURCE}_blocked.csv"
_last_hit: dict[str, float] = {}

SOURCES = [
    # --- Tiffin School (Kingston) ---
    ("tiffin_poa_2026", "https://www.tiffinschool.co.uk/wp-content/uploads/2026/04/Patterns-of-Admissions-for-website-2026.pdf",
     "tiffin_patterns_of_admissions_2026.pdf", "Tiffin School Patterns of Admissions 2026 (uploaded 2026-04)"),
    # --- CSSE (Essex / Southend) ---
    ("csse_foi", "https://csse.org.uk/freedom-of-information/", "csse_foi_page.html",
     "CSSE Freedom of Information / publication scheme page"),
    ("csse_guidance_2026", "https://csse.org.uk/storage/2025/10/FOR-PUBLICATION-HISTORICAL-GUIDANCE-SHEET-FOR-2026-ENTRY.pdf",
     "csse_historical_guidance_sheet_for_2026_entry.pdf",
     "CSSE historical guidance sheet published for 2026 entry (lowest scores offered, Sept 2025 entry)"),
    ("csse_guidance_2025", "https://csse.org.uk/storage/2024/10/CSSE-Historical-Guidance-sheet-2025-Entry.pdf",
     "csse_historical_guidance_sheet_for_2025_entry.pdf",
     "CSSE historical guidance sheet published for 2025 entry (lowest scores offered, Sept 2024 entry)"),
    ("csse_guidance_2019_2024", "https://csse.org.uk/storage/2025/10/Historical-Guidance-Sheets-2019-Entry-to-2024-Entry-1.pdf",
     "csse_historical_guidance_sheets_2019_to_2024_entry.pdf", "CSSE historical guidance sheets 2019-2024 entry"),
    ("csse_std_report_2026", "https://csse.org.uk/storage/2025/10/2026-Entry-Standardisation-Report-1.pdf",
     "csse_standardisation_report_2026_entry.pdf", "CSSE standardisation report, 2026 entry"),
    ("csse_std_report_2025", "https://csse.org.uk/storage/2024/10/2025-Entry-Standardisation-Report.pdf",
     "csse_standardisation_report_2025_entry.pdf", "CSSE standardisation report, 2025 entry"),
    ("csse_std_scores_2026", "https://csse.org.uk/storage/2026/04/Standardised-scores-for-2026-Entry.csv",
     "csse_standardised_scores_2026_entry.csv", "CSSE all-candidate standardised scores, 2026 entry (posted 2026-04)"),
    ("csse_raw_scores_2026", "https://csse.org.uk/storage/2026/04/Raw-scores-for-2026-Entry.csv",
     "csse_raw_scores_2026_entry.csv", "CSSE all-candidate raw scores, 2026 entry (posted 2026-04)"),
    ("csse_std_scores_2025", "https://csse.org.uk/storage/2025/04/Standardised-scores-2025-Entry-1.csv",
     "csse_standardised_scores_2025_entry.csv", "CSSE all-candidate standardised scores, 2025 entry (posted 2025-04)"),
    ("csse_raw_scores_2025", "https://csse.org.uk/storage/2025/04/Raw-scores-for-2025-Entry.csv",
     "csse_raw_scores_2025_entry.csv", "CSSE all-candidate raw scores, 2025 entry (posted 2025-04)"),
    ("csse_std_scores_2019_2024", "https://csse.org.uk/storage/2025/10/Standardised-Scores-from-2019-Entry-to-2024-Entry-for-publication-1.xlsx",
     "csse_standardised_scores_2019_to_2024_entry.xlsx", "CSSE all-candidate standardised scores, 2019-2024 entry"),
    ("csse_raw_scores_2019_2024", "https://csse.org.uk/storage/2025/10/Raw-Scores-from-2019-Entry-to-2024-Entry-for-publication.xlsx",
     "csse_raw_scores_2019_to_2024_entry.xlsx", "CSSE all-candidate raw scores, 2019-2024 entry"),
    ("csse_candidates", "https://csse.org.uk/storage/2025/04/Total-Number-of-CSSE-11-Examination-Candidates-2010-2025-Entry.pdf",
     "csse_total_candidates_2010_2025_entry.pdf", "CSSE total number of 11+ candidates, 2010-2025 entry"),
    # --- CSSE schools' own / Essex CC documents ---
    ("kegs_priority_area", "https://www.kegs.org.uk/admissions/priority-admissions-area/", "kegs_priority_admissions_area.html",
     "KEGS Chelmsford 'Priority admissions area' page"),
    ("kegs_faq", "https://www.kegs.org.uk/admissions/frequently-asked-questions/", "kegs_admissions_faq.html",
     "KEGS Chelmsford admissions FAQ page"),
    ("kegs_policy_2026", "https://www.essex.gov.uk/sites/default/files/2025-08/2025%20King%20Edward%20VI%20Grammar%20School%20%285411%29_0.pdf",
     "kegs_admissions_policy_2026_entry_essexcc.pdf", "KEGS admissions policy (Essex CC copy, uploaded 2025-08)"),
    ("kegs_scores_2026", "https://www.kegs.org.uk/wp-content/uploads/2026/09/11-scores-for-KEGS-website-successful-applicants-2026.pdf",
     "kegs_successful_applicant_scores_2026.pdf", "KEGS list of 11+ scores of students starting Sept 2026"),
    ("kegs_scores_2025", "https://www.kegs.org.uk/wp-content/uploads/2025/09/11-scores-for-KEGS-website-successful-applicants-2025.pdf",
     "kegs_successful_applicant_scores_2025.pdf", "KEGS list of 11+ scores of students starting Sept 2025"),
    ("kegs_scores_2024", "https://www.kegs.org.uk/wp-content/uploads/2025/02/11-scores-for-kegs-website-successful-applicants-2024.pdf",
     "kegs_successful_applicant_scores_2024.pdf", "KEGS list of 11+ scores of students starting Sept 2024"),
    ("kegs_scores_2023", "https://www.kegs.org.uk/wp-content/uploads/2025/02/11-scores-for-kegs-website-successful-applicants-2023.pdf",
     "kegs_successful_applicant_scores_2023.pdf", "KEGS list of 11+ scores of students starting Sept 2023"),
    ("crgs_policy_2025", "https://www.essex.gov.uk/sites/default/files/2024-09/Colchester%20Royal%20Grammar%20School%20%284036%29.pdf",
     "crgs_admissions_arrangements_essexcc_2024-09.pdf", "CRGS admission arrangements (Essex CC copy, uploaded 2024-09)"),
    ("cchs_foi", "https://www.cchs.co.uk/admissions/foi-requests/", "cchs_foi_requests.html",
     "Chelmsford County High School for Girls admissions FOI page (lowest scores offered by year)"),
    ("cchs_scores_2026", "https://www.cchs.co.uk/wp-content/uploads/2026/03/2026-Anonymised-Scores.pdf",
     "cchs_2026_anonymised_scores.pdf", "CCHS 2026 anonymised scores (uploaded 2026-03)"),
    ("cchs_results_2025", "https://www.cchs.co.uk/wp-content/uploads/2025/03/Anonymised-Results.pdf",
     "cchs_2025_anonymised_results.pdf", "CCHS 2025 Year 7 anonymised results (uploaded 2025-03)"),
    ("cchs_policy_2027", "https://www.cchs.co.uk/wp-content/uploads/2026/02/Admissions-Policy-for-Entry-in-2027-Approved-11-Feb-26.pdf",
     "cchs_admissions_policy_2027_entry.pdf", "CCHS admissions policy for 2027 entry (approved 11 Feb 2026)"),
    ("cchs_policy_2026", "https://www.cchs.co.uk/wp-content/uploads/2025/03/Admissions-Policy-for-Entry-in-2026-Approved-Date-Revised-7-Feb-25.pdf",
     "cchs_admissions_policy_2026_entry.pdf", "CCHS admissions policy for 2026 entry (revised 7 Feb 2025)"),
    ("cchs_guide_2026", "https://www.cchs.co.uk/wp-content/uploads/2025/03/Information-Guide-for-2026-Entry.pdf",
     "cchs_information_guide_2026_entry.pdf", "CCHS information guide for 2026 entry"),
    ("whsb_doc_a", "https://www.whsb.essex.sch.uk/_site/data/files/7BF7023B100A47E18B918F009CFDDB86.pdf",
     "whsb_doc_7BF7023B.pdf", "Westcliff High School for Boys document (admission arrangements, per search)"),
    ("whsb_doc_b", "https://whsb.essex.sch.uk/_site/data/files/documents/key-information/school-policies/6EB5D9A9CAB3640789A87935E9BBF69E.pdf",
     "whsb_doc_6EB5D9A9.pdf", "Westcliff High School for Boys school-policies document (admission arrangements, per search)"),
    # --- King Edward VI Foundation, Birmingham ---
    ("kef_results", "https://kingedwardvifoundation.co.uk/results-and-offers/", "kef_results_and_offers.html",
     "KEVI Foundation Birmingham 'Results and offers' page"),
    ("kef_grammar_schools", "https://kingedwardvifoundation.co.uk/grammar-schools/", "kef_grammar_schools.html",
     "KEVI Foundation 'Grammar Schools' admissions page"),
    ("kef_the_test", "https://kingedwardvifoundation.co.uk/the-test/", "kef_the_test.html",
     "KEVI Foundation 'Entrance test information' page"),
    ("kef_chb_policy_2027", "https://kingedwardvifoundation.co.uk/wp-content/uploads/2023/06/King-Edward-VI-Camp-Hill-School-for-Boys-2027-admissions-policy.pdf",
     "kef_camp_hill_boys_admissions_policy_2027.pdf", "KE VI Camp Hill School for Boys admissions policy 2027"),
    ("kef_chg_policy_2027", "https://kingedwardvifoundation.co.uk/wp-content/uploads/2023/06/King-Edward-VI-Camp-Hill-School-for-Girls-2027-admissions-policy.pdf",
     "kef_camp_hill_girls_admissions_policy_2027.pdf", "KE VI Camp Hill School for Girls admissions policy 2027"),
    ("kef_fws_policy_2027", "https://kingedwardvifoundation.co.uk/wp-content/uploads/2023/09/King-Edward-VI-Five-Ways-School-2027-admissions-policy.pdf",
     "kef_five_ways_admissions_policy_2027.pdf", "KE VI Five Ways School admissions policy 2027"),
    ("bv_policy_2027_proposed", "https://www.birmingham.gov.uk/download/downloads/id/31042/bishop_veseys_grammar_school_-_proposed_admissions_arrangements.pdf",
     "bishop_veseys_proposed_admissions_arrangements_2027_bcc.pdf", "Bishop Vesey's Grammar School proposed admissions arrangements (Birmingham CC download id 31042)"),
    ('kendrick_results_2026', 'https://www.kendrick.reading.sch.uk/_site/data/files/users/admissions/2026/0380340C3D620D49E62FB160A101B893.pdf',
     'kendrick_results_faq_2026_entry.pdf', 'Kendrick School results FAQ, 2026 entry'),
    ('kendrick_results_2025', 'https://kendrick.reading.sch.uk/_site/data/files/users/admissions/2025/results/7695474F75961DA09FB71966322B078D.pdf',
     'kendrick_results_faq_2025_entry.pdf', 'Kendrick School results FAQ, 2025 entry'),
    ('kendrick_results_2024', 'https://www.kendrick.reading.sch.uk/_site/data/files/users/admissions/2024/41AF1B10671550B267DCE499F5847377.pdf',
     'kendrick_results_faq_2024_entry.pdf', 'Kendrick School results FAQ, 2024 entry'),
    ('kendrick_results_2023', 'https://www.kendrick.reading.sch.uk/_site/data/files/users/admissions/2023/FA35B51573D16AE5D0735BFDA6FFE76B.pdf',
     'kendrick_results_faq_2023_entry.pdf', 'Kendrick School results FAQ, 2023 entry'),
    ('kendrick_policy_2026', 'https://www.kendrick.reading.sch.uk/_site/data/files/users/admissions/2026/E4EF5E788BB18F2694C6B7062D799169.pdf',
     'kendrick_admissions_policy_2026.pdf', 'Kendrick School admissions policy 2026 (per school site link)'),
    ('rs_foi_index', 'https://www.reading-school.co.uk/admissions/year-7-entry/foi-requests',
     'reading_school_foi_requests.html', 'Reading School Year 7 FOI requests page'),
    ('rs_annual_release_2026', 'https://www.reading-school.co.uk/attachments/download.asp?file=1574&type=pdf',
     'reading_school_annual_data_release_summer_2026.pdf', 'Reading School Annual Data Release Summer 2026 (file=1574)'),
    ('rs_results_faq_2026', 'https://www.reading-school.co.uk/attachments/download.asp?file=1322&type=pdf',
     'reading_school_year7_results_faqs_2026_entry.pdf', 'Reading School Year 7 results FAQs, 2026 entry (file=1322)'),
    ('rs_scores_2025', 'https://www.reading-school.co.uk/attachments/download.asp?file=1069&type=pdf',
     'reading_school_anonymised_results_2025.pdf', 'Reading School anonymised results 2025 (file=1069)'),
    ('rs_scores_summer_2026', 'https://www.reading-school.co.uk/attachments/download.asp?file=1575&type=pdf',
     'reading_school_anonymised_score_release_summer_2026.pdf', 'Reading School anonymised score release Summer 2026 (file=1575)'),
    ('rs_policy_2026_day', 'https://www.reading-school.co.uk/attachments/download.asp?file=1445&type=pdf',
     'reading_school_admissions_policy_2026_day.pdf', 'Reading School admissions policy 2026 entry, day (file=1445)'),
    ('rs_faq', 'https://www.reading-school.co.uk/admissions/year-7-entry',
     'reading_school_year7_entry.html', 'Reading School Year 7 entry page'),
    ('tgs_y7', 'https://www.tiffingirls.org/admissions/year-7/',
     'tiffin_girls_admissions_year7.html', "Tiffin Girls' School Year 7 admissions page"),
    ('tgs_poa_2024_26', 'https://fra1.digitaloceanspaces.com/tiffingirls.org/wp-content/uploads/2026/09/02143656/Patterns-of-Admission-2024-26.pdf',
     'tiffin_girls_patterns_of_admission_2024_26.pdf', "Tiffin Girls' School Patterns of Admission 2024-26 (uploaded 2026-09)"),
    ('tgs_policy_2027', 'https://fra1.digitaloceanspaces.com/tiffingirls.org/wp-content/uploads/2026/03/11120006/Determined-Admissions-Arrangements-for-entry-September-2027.pdf',
     'tiffin_girls_admissions_arrangements_2027.pdf', "Tiffin Girls' determined admission arrangements, Sept 2027"),
    ('hbs_admissions', 'https://www.hbschool.org.uk/admissions/',
     'hbs_admissions.html', 'Henrietta Barnett School admissions page'),
    ('hbs_policy_2027', 'https://henrietta-barnett.ams3.digitaloceanspaces.com/wp-content/uploads/2026/07/10095733/Admissions-Policy-2027-2028.pdf',
     'hbs_admissions_policy_2027_28.pdf', 'Henrietta Barnett admissions policy 2027-28'),
    ('hbs_faq_2026', 'https://henrietta-barnett.ams3.digitaloceanspaces.com/wp-content/uploads/2026/01/29122129/Admission-FAQs-2026.pdf',
     'hbs_admission_faqs_2026.pdf', 'Henrietta Barnett admission FAQs 2026 (image-only PDF)'),
    ('hbs_fois', 'https://www.hbschool.org.uk/admissions/policies-and-documents/fois/',
     'hbs_fois.html', 'Henrietta Barnett FOI page'),
    ('hbs_secondary_lt', 'https://www.leadingtuition.co.uk/blog/henrietta-barnett-waiting-list-how-far-it-moves',
     'secondary_leadingtuition_hbs_waiting_list.html', 'SECONDARY: Leading Tuition blog on HBS waiting list'),
    ('qe_faq', 'https://www.qebarnet.co.uk/admissions-information/secondary-transfer-entrance-test-faqs/',
     'qe_entrance_test_faqs.html', 'QE Barnet secondary transfer entrance test FAQs'),
    ('qe_admissions', 'https://www.qebarnet.co.uk/admissions-information/admissions/',
     'qe_admissions.html', 'QE Barnet admissions page'),
    ('qe_secondary_lt', 'https://www.leadingtuition.co.uk/blog/qe-boys-11-plus-score-what-you-need',
     'secondary_leadingtuition_qe_scores.html', 'SECONDARY: Leading Tuition blog on QE Boys scores'),
    ('stm_policy_2026', 'https://st-michaels.barnet.sch.uk/assets/Documents/Attachments/St-Michaels-Admissions-Policy-for-2026-27-v3.pdf',
     'st_michaels_admissions_policy_2026_27.pdf', "St Michael's Catholic Grammar admissions policy 2026-27"),
    ('lat_procedures_2025', 'https://www.latymer.co.uk/_site/data/files/documents/5-admissions/55649FB1C6EFE5C2543770A95B82B326.pdf',
     'latymer_admission_procedures_2025.pdf', 'Latymer School admission procedures, Sept 2025 entry'),
    ('lat_y7_2026', 'https://www.latymer.co.uk/north-london-grammar-school-admissions/year-7/2026',
     'latymer_year7_2026.html', 'Latymer School Year 7 2026 admissions page'),
    ('lat_policy_2026', 'https://www.latymer.co.uk/_site/data/files/documents/5-admissions/6D8E6BA83DF416D1FEE24DB0C394B059.pdf',
     'latymer_admissions_policy_linked_2026.pdf', 'Latymer School admissions policy (linked from 2026 page)'),
    ('sto_faq', 'https://www.saintolaves.net/113/faq-1',
     'st_olaves_faq.html', "St Olave's admissions FAQ"),
    ('nw_faq_2026', 'https://www.newsteadwood.co.uk/Portals/0/adam/Content/i2Q6b2NBl0Wx8900sgOY3g/Link/FAQs%20-%20YEAR%207%20ADMISSIONS%202026-1.pdf',
     'newstead_wood_faqs_year7_2026.pdf', 'Newstead Wood FAQs Year 7 admissions 2026'),
    ('nw_y7', 'https://www.newsteadwood.co.uk/admissions/year-7-admissions',
     'newstead_wood_year7_admissions.html', 'Newstead Wood Year 7 admissions page'),
    ('sutton_set', 'https://www.sutton.gov.uk/w/selection-tests-aptitude-assessments-and-supplementary-forms',
     'sutton_selection_tests.html', 'Sutton Council selection tests page'),
    ('nonsuch_policy_2026', 'https://www.nonsuchschool.org/_site/data/files/about_us/policies/65F663938879174BA10D419FFB230236.pdf',
     'nonsuch_admissions_policy_2026.pdf', 'Nonsuch High School for Girls admissions policy (2026)'),
    ('wilsons_criteria', 'https://wilsons.school/admissions-criteria/',
     'wilsons_admissions_criteria.html', "Wilson's School admissions criteria"),
    ('wilsons_faq', 'https://wilsons.school/admissions-faqs',
     'wilsons_admissions_faqs.html', "Wilson's School admissions FAQs"),
    ('sgs_admissions', 'https://www.suttongrammar.sutton.sch.uk/admissions/',
     'sutton_grammar_admissions.html', 'Sutton Grammar School admissions page'),
    ('sgs_policy_2026', 'https://www.suttongrammar.sutton.sch.uk/wp-content/uploads/2025/12/Sutton-Grammar-School-Admissions-Policy-Year-7-entry-2026-determined.pdf',
     'sutton_grammar_admissions_policy_2026.pdf', 'Sutton Grammar School admissions policy Year 7 entry 2026 (determined)'),
    ('barnet_alloc_2024', 'https://admin.barnet.gov.uk/sites/default/files/allocation_table_2024_final-corrected_taa_2.pdf',
     'barnet_allocation_table_2024.pdf', 'Barnet allocation table 2024'),
    ('tgs_guidance_2026', 'https://www.tgs.kent.sch.uk/_site/data/files/admissions/70C9D41C5C97EE0F737BFBF528B1FBB5.pdf',
     'tonbridge_grammar_guidance_for_parents_2026_entry.pdf', 'Tonbridge Grammar School guidance for parents, Y7 entry 2026'),
    ('tgs_guidance_2027', 'https://www.tgs.kent.sch.uk/_site/data/files/admissions/entry-2027/0F76F5268B1C8627A77D34ACA1E7FA72.pdf',
     'tonbridge_grammar_guidance_for_parents_2027_entry.pdf', 'Tonbridge Grammar School guidance for parents, Y7 entry 2027'),
    ('judd_history_2026', 'https://www.judd.online/attachments/download.asp?file=1991&type=pdf',
     'judd_historical_11plus_information_2026.pdf', 'Judd School Historical 11+ Information 2026 (previous cut-off scores)'),
    ('judd_year7', 'https://www.judd.online/page/?title=At+Year+7&pid=50',
     'judd_at_year7.html', "Judd School 'At Year 7' admissions page (March 2026 update)"),
    ('judd_areas', 'https://www.judd.online/page/?title=Inner+and+Outer+Area&pid=167',
     'judd_inner_outer_area.html', "Judd School 'Inner and Outer Area' page"),
    ('skinners_policy_2027', 'https://skinnersschool.reactfiles.co.uk/uploads/document/Admissions-Arrangements-2027-Final-for-Website-.pdf',
     'skinners_admissions_arrangements_2027.pdf', "Skinners' School determined admissions arrangements from Sept 2027"),
    ('skinners_policy_2026', 'https://skinnersschool.reactfiles.co.uk/uploads/document/Admissions-Arrangements-2026-Final-Website-Copy.pdf',
     'skinners_admissions_arrangements_2026.pdf', "Skinners' School admissions arrangements 2026"),
    ('skinners_questions', 'https://www.skinners-school.co.uk/40/questions-about-admissions',
     'skinners_questions_about_admissions.html', "Skinners' School 'Questions about admissions' page"),
    ('skinners_kent_info_oct2025', 'https://www.skinners-school.co.uk/38/kent-test-information-16th-october-2025',
     'skinners_kent_test_information_16oct2025.html', "Skinners' 'Kent test information 16th October 2025' page (reported removed)"),
    ('lgs_alloc_2025', 'https://www.lgs.slough.sch.uk/attachments/download.asp?file=338&type=pdf',
     'slough_consortium_information_on_2025_allocations.pdf', "Slough Consortium 'Information on 2025 Allocations' (3 March 2025)"),
    ('lgs_alloc_2026', 'https://www.lgs.slough.sch.uk/attachments/download.asp?file=425&type=pdf',
     'slough_consortium_information_on_2026_allocations.pdf', "Slough Consortium 'Information on 2026 Allocations' (2 March 2026)"),
    ('lgs_alloc_2024', 'https://www.lgs.slough.sch.uk/attachments/download.asp?file=305&type=pdf',
     'slough_consortium_2024_statistics_summary.pdf', "Slough Consortium '11+ for 2024 entry - 2024 statistics summary - FINAL'"),
    ('lgs_policy_2027', 'https://www.lgs.slough.sch.uk/attachments/download.asp?file=381&type=pdf',
     'langley_admissions_arrangements_2027.pdf', 'Langley Grammar School admissions arrangements 2027 entry'),
    ('lgs_policy_2026', 'https://www.lgs.slough.sch.uk/attachments/download.asp?file=333&type=pdf',
     'langley_admissions_arrangements_2026.pdf', 'Langley Grammar School admissions arrangements 2026 entry'),
    ('lgs_page_2026', 'https://www.lgs.slough.sch.uk/page/?title=Admission+to+Year+7+%2D+September+2026&pid=190',
     'langley_admission_year7_sept2026.html', "Langley 'Admission to Year 7 - September 2026' page"),
    ('lgs_scores_2025test', 'https://www.lgs.slough.sch.uk/attachments/download.asp?file=340&type=pdf',
     'slough_consortium_standardised_scores_test_20sep2025.pdf', 'Slough Consortium 11+ 20 Sept 2025 anonymised standardised scores'),
    ('lgs_scores_2024test', 'https://www.lgs.slough.sch.uk/attachments/download.asp?file=307&type=pdf',
     'slough_consortium_standardised_scores_test_sep2024.pdf', 'Slough Consortium 11+ Sept 2024 anonymised standardised scores'),
    ('bucks_alloc_stats', 'https://www.buckinghamshire.gov.uk/schools-libraries-and-parks/school-admissions-and-appeals/guides-and-policies/school-place-allocation-statistics/',
     'bucks_school_place_allocation_statistics.html', 'Buckinghamshire Council school place allocation statistics page'),
    ('bucks_alloc_2026', 'https://media.buckinghamshire.gov.uk/documents/Allocation_Profile_2026_-_FINAL_V2.xlsx',
     'bucks_allocation_profile_2026_final_v2.xlsx', 'Bucks allocation profile 2026 (2 March offers)'),
    ('bucks_alloc_2025', 'https://www.buckinghamshire.gov.uk/documents/36157/Allocation_Profile_2025_-_FINAL.xlsx',
     'bucks_allocation_profile_2025_final.xlsx', 'Bucks allocation profile 2025 (3 March offers)'),
    ('bucks_alloc_2024', 'https://www.buckinghamshire.gov.uk/documents/33847/Allocation_Profile_2024_-_FINAL_rrgfYhf.xlsx',
     'bucks_allocation_profile_2024_final.xlsx', 'Bucks allocation profile 2024 (1 March offers)'),
    ('bucks_alloc_2023', 'https://www.buckinghamshire.gov.uk/documents/33846/ALLOCATION_PROFILE_2023__5ua2yRL.xlsx',
     'bucks_allocation_profile_2023.xlsx', 'Bucks allocation profile 2023 (1 March offers)'),
    ('bucks_11plus', 'https://www.buckinghamshire.gov.uk/schools-libraries-and-parks/school-admissions-and-appeals/grammar-schools-and-transfer-testing-11/',
     'bucks_grammar_schools_transfer_testing.html', "Bucks 'Grammar schools and Secondary Transfer Testing (11+)' page"),
    ('bucks_stt_results', 'https://www.buckinghamshire.gov.uk/schools-libraries-and-parks/school-admissions-and-appeals/grammar-schools-and-transfer-testing-11/secondary-transfer-test-results/',
     'bucks_secondary_transfer_test_results.html', "Bucks 'Secondary Transfer Test results' page"),
    ('swbgs_policy_2027', 'https://www.swbgs.com/_site/data/files/policies/D4A20351A46588F6D98ADC8E4E33F723.pdf',
     'borlase_admissions_policy_2027.pdf', "Sir William Borlase's Grammar School admissions policy 2027"),
    ('rls_adjudicator_2027', 'https://assets.publishing.service.gov.uk/media/6a32b0a800ff27f06e3ef992/ADA4597_Royal_Latin_School_Buckinghamshire_15_June_2026.pdf',
     'royal_latin_adjudicator_ADA4597_2026-06-15.pdf', 'Schools Adjudicator determination ADA4597 Royal Latin School (15 June 2026)'),
    ('warks_leaflet_2023', 'https://api.warwickshire.gov.uk/documents/WCCC-1990003847-3524',
     'warks_offer_day_leaflet_2023_entry.pdf', 'Warwickshire grammar offer-day leaflet, 2023 entry'),
    ('warks_leaflet_2024', 'https://api.warwickshire.gov.uk/documents/WCCC-1990003847-3787',
     'warks_offer_day_leaflet_2024_entry.pdf', 'Warwickshire grammar offer-day leaflet, 2024 entry'),
    ('warks_leaflet_2025', 'https://api.warwickshire.gov.uk/documents/WCCC-1990003847-3910',
     'warks_offer_day_leaflet_2025_entry.pdf', 'Warwickshire grammar offer-day leaflet, 2025 entry'),
    ('warks_leaflet_2026', 'https://api.warwickshire.gov.uk/documents/WCCC-1990003847-4160',
     'warks_offer_day_leaflet_2026_entry.pdf', 'Warwickshire grammar offer-day leaflet, 2026 entry'),
    ('warks_ranking_2024', 'https://api.warwickshire.gov.uk/documents/WCCC-1980322935-2492',
     'warks_11plus_score_rankings_2024_entry.xlsx', 'Warwickshire 11+ score rankings, 2024 entry (on-time candidates)'),
    ('warks_ranking_2025', 'https://api.warwickshire.gov.uk/documents/WCCC-1990003847-3879',
     'warks_11plus_score_rankings_2025_entry.xlsx', 'Warwickshire 11+ score rankings, 2025 entry'),
    ('warks_ranking_2026', 'https://api.warwickshire.gov.uk/documents/WCCC-1990003847-4108',
     'warks_11plus_score_rankings_2026_entry.xlsx', 'Warwickshire 11+ score rankings, 2026 entry'),
    ('warks_ranking_2023', 'https://api.warwickshire.gov.uk/documents/WCCC-1990003847-2937',
     'warks_11plus_score_rankings_2023_entry.xlsx', 'Warwickshire 11+ score rankings, 2023 entry'),
    ('warks_minutes_2025', 'https://api.warwickshire.gov.uk/documents/WCCC-1990003847-4074',
     'warks_committee_of_reference_south_2025_entry.pdf', 'Warwickshire Committee of Reference (South) minutes, 2025 entry'),
    ('warks_minutes_2026', 'https://api.warwickshire.gov.uk/documents/WCCC-1990003847-4240',
     'warks_committee_of_reference_south_2026_entry.pdf', 'Warwickshire Committee of Reference (South) minutes, 2026 entry'),
    ('kes_policy_2026', 'https://kes.net/files/cms/3451_M%20-%20Admissions%20Policy%202026.pdf',
     'kes_stratford_admissions_policy_2026.pdf', 'King Edward VI School Stratford admissions policy 2026 (determined 12/12/24)'),
    ('agsb_booklet_2025', 'https://www.agsb.co.uk/_site/data/files/admissions/entrance-exam/EF38086DA211A65D9BAEE22F1F6C2278.pdf',
     'agsb_year7_admission_sept2025.pdf', "Altrincham Grammar School for Boys 'Year 7 admission September 2025'"),
    ('aggs_booklet_2024', 'https://aggs.bright-futures.co.uk/wp-content/uploads/2023/05/Information-Booklet-Admissions-2024-2.pdf',
     'aggs_information_booklet_admissions_2024.pdf', 'Altrincham Grammar School for Girls information booklet, admissions 2024'),
    ('sale_2026', 'https://www.salegrammar.co.uk/6733/september-2026-entry',
     'sale_grammar_september_2026_entry.html', "Sale Grammar School 'September 2026 entry' page"),
    ('sale_policy_2026', 'https://0e58658be539ee7325a0-220f04f871df648cf4a4d93a111e3366.ssl.cf3.rackcdn.com/sale/uploads/document/Admissions-Policy-2026-1.pdf',
     'sale_grammar_admissions_policy_2026.pdf', 'Sale Grammar School admissions policy 2026'),
    ('loreto_policy_2026', 'https://loretogrammar.co.uk/docs/Admissions/Admissions-Policy-2026-Entry-1.pdf',
     'loreto_admissions_policy_2026.pdf', 'Loreto Grammar School admissions policy 2026 entry'),
    ('trafford_outcomes_2025', 'https://www.trafford.gov.uk/schools-and-learning/starting-school-and-admissions/secondary-admission-outcomes-2025',
     'trafford_secondary_admission_outcomes_2025.html', 'Trafford Council secondary admission outcomes 2025'),
    ('trafford_outcomes_2026', 'https://www.trafford.gov.uk/schools-and-learning/starting-school-and-admissions/secondary-admission-outcomes-2026',
     'trafford_secondary_admission_outcomes_2026.html', 'Trafford Council secondary admission outcomes 2026'),
    ('bowdon_secondary_2024', 'https://bowdoncs.org.uk/page/?pid=100&title=Which+secondary+schools+can+I+choose+from%3F',
     'secondary_bowdon_church_school_trafford_outcomes.html', 'SECONDARY: Bowdon Church School page reproducing Trafford 2024 outcomes'),
    ('glos_alloc_2023', 'https://www.gloucestershire.gov.uk/media/twhi0kxy/secondary-allocation-day-statistics-2023.pdf',
     'glos_secondary_allocation_day_statistics_2023.pdf', 'Gloucestershire secondary allocation day statistics 2023'),
    ('glos_alloc_2024', 'https://www.gloucestershire.gov.uk/media/qgccbea1/secondary-allocation-day-statistics-2024.pdf',
     'glos_secondary_allocation_day_statistics_2024.pdf', 'Gloucestershire secondary allocation day statistics 2024'),
    ('glos_alloc_2025', 'https://www.gloucestershire.gov.uk/media/v1jdwr0r/secondary-allocation-day-statistics-2025.pdf',
     'glos_secondary_allocation_day_statistics_2025.pdf', 'Gloucestershire secondary allocation day statistics 2025'),
    ('glos_alloc_2026', 'https://www.gloucestershire.gov.uk/media/axxjyzy5/secondary-allocation-day-2026.pdf',
     'glos_secondary_allocation_day_2026.pdf', 'Gloucestershire secondary allocation day 2026'),
    ('glos_summary_2026', 'https://www.gloucestershire.gov.uk/media/exopgjs5/secondary-school-2026-intake-allocation-summary.pdf',
     'glos_secondary_school_2026_intake_allocation_summary.pdf', 'Gloucestershire secondary school 2026 intake allocation summary'),
    ('pates_policy_2026', 'https://www.gloucestershire.gov.uk/media/oxvnhfgb/pates-determined-admissions-policy-for-september-2026-entry.pdf',
     'pates_determined_admissions_policy_2026.pdf', "Pate's Grammar School determined admissions policy, Sept 2026 entry"),
    ('str_policy_2026', 'https://www.gloucestershire.gov.uk/media/wy1nwtp2/sir-thomas-richs-determined-admissions-policy-y7-11-and-sixth-form-2026-entry.pdf',
     'sir_thomas_richs_determined_admissions_policy_2026.pdf', "Sir Thomas Rich's determined admissions policy, 2026 entry"),
    ('str_policy_2027', 'https://www.gloucestershire.gov.uk/media/10efpvz3/sirtho-1.pdf',
     'sir_thomas_richs_admissions_policy_2027.pdf', "Sir Thomas Rich's admissions policy 2027/28 (per search)"),
    ('bluecoat_faq_2026', 'https://www.bluecoatschoolliverpool.org.uk/_site/data/files/admissions/y7/E6CD1B1C65FF3A1A61C7845C3AEF76C9.pdf',
     'blue_coat_admission_y7_2026_faq.pdf', "Blue Coat School Liverpool 'Admission to Year 7 in September 2026 FAQ'"),
    ('bluecoat_policy_2027', 'https://www.bluecoatschoolliverpool.org.uk/attachments/download.asp?file=137&type=pdf',
     'blue_coat_admissions_policy_2027.pdf', 'Blue Coat School Liverpool admissions policy 2027 (per search)'),
    ('colyton_scores_2025', 'https://colytongrammar.reactfiles.co.uk/uploads/document/2025-Standardised-Scores-including-in-year.pdf',
     'colyton_2025_standardised_scores_including_in_year.pdf', 'Colyton Grammar School 2025 anonymised standardised scores (incl. in-year)'),
    ('colyton_faq_2026', 'https://colytongrammar.reactfiles.co.uk/uploads/document/Admission-FAQs-2026.pdf',
     'colyton_admission_faqs_2026.pdf', 'Colyton Grammar School admission FAQs 2026'),
    ('colyton_policy_2026', 'https://colytongrammar.reactfiles.co.uk/uploads/key_information/Year-7-Admissions-Policy-2026-27.pdf',
     'colyton_year7_admissions_policy_2026_27.pdf', 'Colyton Grammar School Year 7 admissions policy 2026-27'),
    ('kings_lincs_record', 'https://www.lincolnshire.gov.uk/directory-record/61386/grantham-the-kings-school',
     'lincs_directory_kings_school_grantham.html', "Lincolnshire CC directory record: The King's School Grantham"),
    ('kings_policy', 'https://www.kings.lincs.sch.uk/admissionspolicy',
     'kings_grantham_admissions_policy_page.html', "King's School Grantham admissions policy page"),
    ('sutton_prev_years', 'https://www.sutton.gov.uk/schools-and-learning/school-admissions/apply-start-secondary-school/secondary-school-allocation-information-previous-years',
     'sutton_secondary_allocation_previous_years.html', 'Sutton Council secondary school allocation information, previous years'),
    ('wcgs_secondary_lt', 'https://www.leadingtuition.co.uk/blog/wallington-county-designated-area-2027',
     'secondary_leadingtuition_wcgs_designated_area_2027.html', 'SECONDARY: Leading Tuition on Wallington County designated area 2027'),
    ('whsg_secondary_lt', 'https://www.leadingtuition.co.uk/blog/wallington-girls-designated-area-2027',
     'secondary_leadingtuition_whsg_designated_area_2027.html', 'SECONDARY: Leading Tuition on Wallington Girls designated area 2027'),
    ('nw_policy_2026', 'https://www.newsteadwood.co.uk/Portals/0/adam/Content/0UfmP3uYokykO4_7blbtLg/Link/Admission%20Policy%202026-27.pdf',
     'newstead_wood_admission_policy_2026_27.pdf', 'Newstead Wood admission policy 2026-27'),
    ('colyton_policy_2025', 'https://colytongrammar.reactfiles.co.uk/uploads/key_information/Year-7-Admissions-Policy-2025-26-2.pdf',
     'colyton_year7_admissions_policy_2025_26.pdf', 'Colyton Grammar School Year 7 admissions policy 2025-26'),
    # --- Kent Test ---
    ("kent_results", "https://www.kent.gov.uk/education-and-children/schools/school-places/kent-test/kent-test-results",
     "kent_test_results.html", "KCC Kent Test results page"),
    ("kent_results_wayback_20250907", "https://web.archive.org/web/20250907150239id_/https://www.kent.gov.uk/education-and-children/schools/school-places/kent-test/kent-test-results",
     "kent_test_results_wayback_20250907.html",
     "Wayback Machine capture 2025-09-07 of the KCC Kent Test results page (live page returns 403 to scripts)"),
    ("kent_scores_2024", "https://www.kent.gov.uk/__data/assets/excel_doc/0007/196315/Report-of-Kent-Test-scores-2024.xlsx",
     "kent_test_scores_report_2024.xlsx", "KCC Report of Kent Test scores 2024 (test sat Sept 2024, Sept 2025 entry)"),
    ("kent_scores_2023", "https://www.kent.gov.uk/__data/assets/excel_doc/0009/196317/Kent-Test-scores-report-2023.xlsx",
     "kent_test_scores_report_2023.xlsx", "KCC Kent Test scores report 2023 (test sat Sept 2023, Sept 2024 entry)"),
    ("kent_scores_2022", "https://www.kent.gov.uk/__data/assets/excel_doc/0010/196318/Kent-Test-scores-report-2022.xlsx",
     "kent_test_scores_report_2022.xlsx", "KCC Kent Test scores report 2022 (test sat Sept 2022, Sept 2023 entry)"),
    # kent.gov.uk sits behind Cloudflare, which refuses python-requests (403) though not a browser: the same
    # KCC files are taken from Wayback Machine captures (id_ = the original bytes, unmodified).
    ("kent_scores_2024_wb", "https://web.archive.org/web/20250708210551id_/https://www.kent.gov.uk/__data/assets/excel_doc/0007/196315/Report-of-Kent-Test-scores-2024.xlsx",
     "kent_test_scores_report_2024_wayback.xlsx", "Wayback capture 2025-07-08 of KCC Report of Kent Test scores 2024 (test sat Sept 2024, Sept 2025 entry)"),
    ("kent_scores_2023_wb", "https://web.archive.org/web/20250708210503id_/https://www.kent.gov.uk/__data/assets/excel_doc/0009/196317/Kent-Test-scores-report-2023.xlsx",
     "kent_test_scores_report_2023_wayback.xlsx", "Wayback capture 2025-07-08 of KCC Kent Test scores report 2023 (test sat Sept 2023, Sept 2024 entry)"),
    ("kent_scores_2022_wb", "https://web.archive.org/web/20250708210536id_/https://www.kent.gov.uk/__data/assets/excel_doc/0010/196318/Kent-Test-scores-report-2022.xlsx",
     "kent_test_scores_report_2022_wayback.xlsx", "Wayback capture 2025-07-08 of KCC Kent Test scores report 2022 (test sat Sept 2022, Sept 2023 entry)"),
]


def polite_fetch(sid, url, filename, note, day=None):
    dest = snapshot_dir(SOURCE, day) / filename
    if dest.exists() and dest.stat().st_size > 0:
        return dest
    host = urlparse(url).netloc
    wait = 1.1 - (time.time() - _last_hit.get(host, 0))
    if wait > 0:
        time.sleep(wait)
    try:
        return fetch(SOURCE, url, filename, note=f"[{sid}] {note}", day=day, retries=2)
    except RuntimeError as e:
        new = not BLOCKED.exists()
        with BLOCKED.open("a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if new:
                w.writerow(["id", "url", "error", "retrieved_utc"])
            w.writerow([sid, url, str(e)[:200], dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")])
        print(f"BLOCKED {sid}: {e}")
        return None
    finally:
        _last_hit[host] = time.time()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--day")
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--retry-blocked", action="store_true", help="retry ids already in the blocked log")
    a = ap.parse_args()
    blocked = set()
    if BLOCKED.exists() and not a.retry_blocked:
        with BLOCKED.open(encoding="utf-8") as f:
            blocked = {r["id"] for r in csv.DictReader(f)}
    for sid, url, filename, note in SOURCES:
        if (a.only and sid not in a.only) or sid in blocked:
            continue
        p = polite_fetch(sid, url, filename, note, a.day)
        if p:
            print(f"{sid:28s} {p.name:60s} {p.stat().st_size:>10,d}")


if __name__ == "__main__":
    main()
