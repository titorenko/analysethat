"""Harvest published admission figures for the 30 private schools in data/derived/top30_independent.csv: school
admissions pages and policies, and trustees' reports in charity accounts (Charity Commission register).

Usage: .venv/Scripts/python -I code/harvest/independent_admissions.py [--day YYYY-MM-DD] [--only ID ...]

Same mechanics as grammar_intake.py (per-host delay; failures logged to
data/manifest/independent_admissions_blocked.csv). SOURCES rows: (id, url, filename, note); the id is what
code/derive/independent_admissions_curated.py cites. Private schools are not covered by FOI, so every source is
something the school or its charity publishes itself.
"""
import argparse
import csv
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import MANIFEST  # noqa: E402
from grammar_intake import polite_fetch  # noqa: E402

SOURCE = "independent_admissions"
BLOCKED = MANIFEST / f"{SOURCE}_blocked.csv"

# ---------------- found by discovery agent A, 2026-11-07
CC = ("https://register-of-charities.charitycommission.gov.uk/en/charity-search?p_p_id=uk_gov_ccew_onereg_charitydetails_web_portlet_CharityDetailsPortlet"
      "&p_p_lifecycle=2&p_p_state=maximized&p_p_mode=view&p_p_resource_id=%2Faccounts-resource&p_p_cacheability=cacheLevelPage"
      "&_uk_gov_ccew_onereg_charitydetails_web_portlet_CharityDetailsPortlet_objectiveId={obj}"
      "&_uk_gov_ccew_onereg_charitydetails_web_portlet_CharityDetailsPortlet_priv_r_p_mvcRenderCommandName=%2Faccounts-and-annual-returns"
      "&_uk_gov_ccew_onereg_charitydetails_web_portlet_CharityDetailsPortlet_priv_r_p_organisationNumber={org}")

SOURCES_A = [
    # ---- St Paul's Girls' School (100366)
    ("p7_spgs_policy_2021", "https://spgs.org/wp-content/uploads/2021/02/Admissions-Policy-1-1.pdf",
     "spgs_admissions_policy_2021.pdf", "SPGS admissions policy approved 25 June 2020 (uploaded 2021-02)"),
    ("p7_spgs_policy_2022", "https://spgs.org/wp-content/uploads/2022/06/Admissions-Policy-.pdf",
     "spgs_admissions_policy_2022.pdf", "SPGS admissions policy approved 22 June 2022"),
    ("p7_spgs_policy_2024", "https://spgs.org/wp-content/uploads/2024/06/Admissions-Policy-.pdf",
     "spgs_admissions_policy_2024.pdf", "SPGS admissions policy completed April/May 2024"),
    ("p7_spgs_policy_2025", "https://spgs.org/wp-content/uploads/2025/06/Admissions-Policy.pdf",
     "spgs_admissions_policy_2025.pdf", "SPGS admissions policy completed June 2025"),
    ("p7_spgs_11", "https://spgs.org/admissions/11-entry/", "spgs_11_entry.html", "SPGS 11+ entry page (Sept 2027 cycle)"),
    ("p7_spgs_16", "https://spgs.org/admissions/16-entry/", "spgs_16_entry.html", "SPGS 16+ entry page (Sept 2027 cycle)"),
    ("p7_spgs_accounts_2024", CC.format(obj="A17173241", org="4031239"), "spgs_accounts_fy2024.pdf",
     "St Paul's Girls' School (charity 1119613) report and accounts, year ended 31 Aug 2024 (Charity Commission)"),
    # ---- St Paul's School (102942)
    ("p7_stpauls_13", "https://www.stpaulsschool.org.uk/admissions/entry-to-st-pauls-13/", "stpauls_13_entry.html",
     "St Paul's School 13+ entry page"),
    ("p7_stpauls_16", "https://www.stpaulsschool.org.uk/admissions/entry-to-st-pauls-16/", "stpauls_16_entry.html",
     "St Paul's School 16+ entry page"),
    ("p7_stpauls_policy", "https://intranet.stpaulsschool.org.uk/resource.aspx?id=395195", "stpauls_admissions_policy_2026-01.pdf",
     "St Paul's School admissions policy, last reviewed 01/26"),
    ("p7_stpauls_accounts_2025", CC.format(obj="A18462595", org="4031126"), "stpauls_accounts_fy2025.pdf",
     "St Paul's School (charity 1119619) report and accounts, year ended 31 Aug 2025 (Charity Commission)"),
    # ---- Westminster School (101162)
    ("p7_westminster_13", "https://www.westminster.org.uk/admissions/13-entry-westminster-school/", "westminster_13_entry.html",
     "Westminster School 13+ entry page"),
    ("p7_westminster_feeders", "https://www.westminster.org.uk/admissions/13-entry-westminster-school/feeder-schools/",
     "westminster_13_feeder_schools.html", "Westminster School 13+ feeder schools of the Sept 2026 Year 9 intake"),
    ("p7_westminster_16", "https://www.westminster.org.uk/admissions/16-entry-westminster-school/", "westminster_16_entry.html",
     "Westminster School 16+ entry page"),
    ("p7_westminster_results", "https://www.westminster.org.uk/westminster-school/academic-life/exam-results-and-higher-education/",
     "westminster_exam_results_he.html", "Westminster School exam results and higher education page (2026 destinations)"),
    ("p7_westminster_accounts_2025", CC.format(obj="A18588051", org="312728"), "westminster_accounts_fy2025.pdf",
     "St Peter's College (Westminster School, charity 312728) governors' report and accounts, year ended 30 June 2025"),
    ("p7_westminster_accounts_2024", CC.format(obj="A16878116", org="312728"), "westminster_accounts_fy2024.pdf",
     "St Peter's College (Westminster School, charity 312728) governors' report and accounts, year ended 30 June 2024"),
    # ---- North London Collegiate School (102257)
    ("p7_nlcs_11", "https://www.nlcs.org.uk/admissions/joining-the-senior-school/", "nlcs_joining_senior_school.html",
     "NLCS joining the Senior School (Year 7, Sept 2027)"),
    ("p7_nlcs_16", "https://www.nlcs.org.uk/admissions/joining-the-sixth-form/", "nlcs_joining_sixth_form.html",
     "NLCS joining the Sixth Form"),
    # ---- Brighton College (114614)
    ("p7_brighton_16", "https://www.brightoncollege.org.uk/assets/files/uploads/brighton-college-sixth-form-entry-2027.pdf",
     "brighton_sixth_form_entry_2027.pdf", "Brighton College 'Admissions (16+) for entry in 2027' brochure"),
    # ---- King's College School Wimbledon (102684): JS site, page content from the site's own JSON endpoint
    ("p7_kcs_11", "https://www.kcs.org.uk/?method=url&path=/admissions/senior-school/11plus", "kcs_11plus.json",
     "KCS 11+ entry page content (site JSON endpoint behind https://www.kcs.org.uk/admissions/senior-school/11plus)"),
    ("p7_kcs_13", "https://www.kcs.org.uk/?method=url&path=/admissions/senior-school/13plus", "kcs_13plus.json",
     "KCS 13+ entry page content (site JSON endpoint behind https://www.kcs.org.uk/admissions/senior-school/13plus)"),
    ("p7_kcs_16", "https://www.kcs.org.uk/?method=url&path=/admissions/senior-school/16plus", "kcs_16plus.json",
     "KCS 16+ entry page content (site JSON endpoint behind https://www.kcs.org.uk/admissions/senior-school/16plus)"),
    # ---- Guildford High School (125342)
    ("p7_guildford_entry", "https://www.guildfordhigh.co.uk/admissions/entry-points/", "guildford_high_entry_points.html",
     "Guildford High School admissions process / entry points"),
    ("p7_guildford_faqs", "https://www.guildfordhigh.co.uk/admissions/faqs/", "guildford_high_admissions_faqs.html",
     "Guildford High School admissions FAQs"),
    # ---- Godolphin and Latymer (100369)
    ("p7_gl_policy", "https://www.godolphinandlatymer.com/wp-content/uploads/2026/09/Admissions-Policy-1.pdf",
     "godolphin_latymer_admissions_policy_2026.pdf", "Godolphin and Latymer admissions policy, reviewed May 2026"),
    # ---- City of London School for Girls (100001)
    ("p7_clsg_11", "https://clsg.org.uk/admissions/11-admissions/", "clsg_11_admissions.html", "CLSG 11+ admissions (Sept 2027 cycle)"),
    ("p7_clsg_16", "https://clsg.org.uk/admissions/16-admissions/", "clsg_16_admissions.html", "CLSG 16+ admissions (Sept 2027 cycle)"),
    # ---- Wimbledon High School GDST (102692)
    ("p7_whs_senior", "https://www.wimbledonhigh.gdst.net/admissions/senior-admissions/", "wimbledon_high_senior_admissions.html",
     "Wimbledon High School senior admissions (Sept 2027 cycle)"),
    # ---- Magdalen College School Oxford (123311)
    ("p7_mcs_11", "https://www.mcsoxford.org/admissions/entry-at-11/", "mcs_entry_at_11.html", "MCS entry at 11+"),
    ("p7_mcs_pretest", "https://www.mcsoxford.org/admissions/entry-at-pre-test/", "mcs_entry_at_pre_test.html",
     "MCS pre-test entry (Year 9 from prep schools)"),
    ("p7_mcs_sixth", "https://www.mcsoxford.org/admissions/entry-at-sixth-form/", "mcs_entry_at_sixth_form.html", "MCS entry at Sixth Form"),
    # ---- The Perse School (110923)
    ("p7_perse_accounts_2025", CC.format(obj="A18890671", org="4033900"), "perse_accounts_fy2025.pdf",
     "The Perse School (charity 1120654) report and accounts, year ended 31 Aug 2025 (Charity Commission)"),
    # ---- Latymer Upper School (100370)
    ("p7_latymer_11", "https://www.latymer-upper.org/admissions/joining-at-11/", "latymer_upper_joining_at_11.html",
     "Latymer Upper joining at 11+ (Sept 2027 cycle)"),
    ("p7_latymer_16", "https://www.latymer-upper.org/admissions/joining-in-sixth-form/", "latymer_upper_joining_sixth_form.html",
     "Latymer Upper joining in Sixth Form"),
    ("p7_latymer_accounts_2025", CC.format(obj="A18837109", org="312714"), "latymer_upper_accounts_fy2025.pdf",
     "Latymer Foundation at Hammersmith (charity 312714) report and accounts, year ended 31 Aug 2025"),
    ("p7_latymer_accounts_2024", CC.format(obj="A17256943", org="312714"), "latymer_upper_accounts_fy2024.pdf",
     "Latymer Foundation at Hammersmith (charity 312714) report and accounts, year ended 31 Aug 2024"),
    # ---- King Edward VI High School for Girls, Birmingham (103585)
    ("p7_kehs_admissions", "https://kehs.org.uk/admissions/", "kehs_admissions.html", "KEHS admissions page (Sept 2027 cycle)"),
    # ---- Highgate School (102163)
    ("p7_highgate_11", "https://www.highgateschool.org.uk/senior-school/admissions-11/", "highgate_admissions_11.html",
     "Highgate Senior School admissions 11+ (read 2026-11-07: 'next September' = Sept 2027)"),
    ("p7_highgate_16", "https://www.highgateschool.org.uk/sixth/admissions-16/", "highgate_admissions_16.html",
     "Highgate Sixth Form admissions 16+ (read 2026-11-07: 'next September' = Sept 2027)"),
]

# ---------------- found by discovery agent B, 2026-11-07
"""Private-school admission panels, batch B (q7_): primary sources only (school pages, school policies,
Charity Commission accounts, City of London governors' papers). Pages read 2026-11-07.

Same layouts as code/harvest/grammar_intake.py SOURCES and code/derive/grammar_intake_curated.py CURATED
(13 fields: the trailing `name` field is left blank).
"""

CC_ACC = ("https://register-of-charities.charitycommission.gov.uk/en/charity-search?p_p_id=uk_gov_ccew_onereg_charitydetails_web_portlet_CharityDetailsPortlet"
          "&p_p_lifecycle=2&p_p_state=maximized&p_p_mode=view&p_p_resource_id=%2Faccounts-resource&p_p_cacheability=cacheLevelPage"
          "&_uk_gov_ccew_onereg_charitydetails_web_portlet_CharityDetailsPortlet_objectiveId={obj}"
          "&_uk_gov_ccew_onereg_charitydetails_web_portlet_CharityDetailsPortlet_priv_r_p_mvcRenderCommandName=%2Faccounts-and-annual-returns"
          "&_uk_gov_ccew_onereg_charitydetails_web_portlet_CharityDetailsPortlet_priv_r_p_organisationNumber={org}")

SOURCES_B = [
    # --- Wycombe Abbey ---
    ("q7_wycombe_admissions", "https://www.wycombeabbey.com/admissions/", "q7_wycombe_admissions.html",
     "Wycombe Abbey admissions page (11+, 13+, 16+ process; 2027-entry cycle)"),
    ("q7_wycombe_oxbridge_2026", "https://www.wycombeabbey.com/exceptional-university-offers/",
     "q7_wycombe_exceptional_university_offers_2026.html", "Wycombe Abbey news 'Exceptional University Offers', 11 Feb 2026"),
    # --- Alleyn's ---
    ("q7_alleyns_11", "https://www.alleyns.org.uk/admissions/senior-school-11-", "q7_alleyns_senior_school_11.html",
     "Alleyn's Senior School 11+ admissions page (2027-entry cycle)"),
    ("q7_alleyns_16", "https://www.alleyns.org.uk/admissions/sixth-form-16-", "q7_alleyns_sixth_form_16.html",
     "Alleyn's Sixth Form 16+ admissions page"),
    # --- South Hampstead High GDST ---
    ("q7_shhs_faq_11_2027", "https://www.shhs.gdst.net/wp-content/uploads/2026/09/FAQs-11-Admissions-2027-Autumn-2026-.pdf",
     "q7_shhs_faqs_11_admissions_2027.pdf", "South Hampstead 11+ admissions FAQs for September 2027 entry (Autumn 2026)"),
    ("q7_shhs_policy_2024", "https://www.shhs.gdst.net/wp-content/uploads/2024/10/15a-Admissions-Policy-October-2024.pdf",
     "q7_shhs_admissions_policy_2024_10.pdf", "South Hampstead admissions policy, last reviewed August 2024"),
    # --- Lady Eleanor Holles ---
    ("q7_leh_11", "https://lehs.org.uk/admissions/entry-procedure/11-plus-entry-procedure/", "q7_leh_11_plus_entry_procedure.html",
     "LEH 11+ entry procedure and FAQ (2027-entry cycle)"),
    ("q7_leh_16", "https://lehs.org.uk/admissions/entry-procedure/sixth-form-entry-procedure/", "q7_leh_sixth_form_entry_procedure.html",
     "LEH Sixth Form entry procedure (2027-entry cycle)"),
    ("q7_leh_accounts_2025", CC_ACC.format(obj="A18837147", org="4045274"), "q7_leh_accounts_ye_2025_08.pdf",
     "The Lady Eleanor Holles School (charity 1130254) report and accounts, year to 31 Aug 2025 (Charity Commission)"),
    # --- City of London School ---
    ("q7_cls_policy_2024", "https://www.cityoflondonschool.org.uk/wp-content/uploads/2024/11/Admissions-Policy-July-2024.pdf",
     "q7_cls_admissions_policy_2024_07.pdf", "City of London School admissions policy, July 2024 (Appendix 2: places for 2025 entry)"),
    ("q7_cls_governors_2013", "https://democracy.cityoflondon.gov.uk/mgAi.aspx?ID=7107", "q7_cls_governors_headmasters_report_2013_03.html",
     "Board of Governors of the City of London School, 22 Mar 2013, minutes item 'Headmaster's Report' (admissions 2013)"),
    ("q7_cls_oxbridge_2025", "https://www.cityoflondonschool.org.uk/news/35-offers-from-oxford-and-cambridge/",
     "q7_cls_35_offers_oxford_cambridge_2025.html", "City of London School news '35 offers from Oxford and Cambridge', 4 Feb 2025"),
    # --- Haberdashers' Boys' / Girls' ---
    ("q7_habsboys_11", "https://www.habselstree.org.uk/boys/admissions/11and11deferred/", "q7_habsboys_11_and_11_deferred.html",
     "Habs Boys 11+ and 11+ deferred admissions page (2027-entry cycle)"),
    ("q7_habsgirls_process", "https://www.habselstree.org.uk/girls/admissions/admissions-process/", "q7_habsgirls_admissions_process.html",
     "Habs Girls admissions process page (4+, 7+, 11+, 16+)"),
    # --- Putney High GDST ---
    ("q7_putney_results", "https://www.putneyhigh.gdst.net/about-us/results-destinations/", "q7_putney_results_destinations.html",
     "Putney High results and destinations page"),
    ("q7_putney_senior", "https://www.putneyhigh.gdst.net/admissions/senior-admissions/", "q7_putney_senior_admissions.html",
     "Putney High senior (11+) admissions page (2027-entry cycle)"),
    # --- Withington Girls' ---
    ("q7_wgs_policy_2026", "https://www.wgs.org/wp-content/uploads/2026/09/Admissions-Policy-2026.pdf", "q7_wgs_admissions_policy_2026.pdf",
     "Withington Girls' School admissions policy, September 2026"),
    # --- Eton College ---
    ("q7_eton_16", "https://www.etoncollege.com/admissions/entry-sixth-form-16-entry/", "q7_eton_sixth_form_16_entry.html",
     "Eton Sixth Form (16+) entry page"),
    ("q7_eton_13", "https://www.etoncollege.com/admissions/year-9-13/", "q7_eton_year_9_13.html", "Eton Year 9 (13+) entry page"),
    ("q7_eton_booklet_2019", "https://www.etoncollege.com/wp-content/uploads/2020/05/Admissions-Booklet.pdf",
     "q7_eton_admissions_booklet_2019_20.pdf", "Eton 'Admissions Information 2019/20' booklet"),
    # --- James Allen's Girls' ---
    ("q7_jags_apply", "https://www.jags.org.uk/admissions/apply/", "q7_jags_apply.html", "JAGS 'Apply' admissions page (2027-entry cycle)"),
    ("q7_jags_accounts_2025", CC_ACC.format(obj="A18746024", org="4040346"), "q7_jags_accounts_ye_2025_08.pdf",
     "James Allen's Girls' School (charity 1124853) report and accounts, year to 31 Aug 2025 (Charity Commission)"),
    # --- Royal Grammar School Guildford ---
    ("q7_rgs_faq", "https://www.rgsg.co.uk/admissions/faq/", "q7_rgs_guildford_admissions_faq.html", "RGS Guildford admissions FAQ"),
    # --- Kingston Grammar School ---
    ("q7_kgs_faq", "https://www.kgs.org.uk/admissions/faqs/", "q7_kgs_admissions_faqs.html", "Kingston Grammar School admissions FAQs"),
    ("q7_kgs_11", "https://www.kgs.org.uk/admissions/11-entry/", "q7_kgs_11_entry.html", "Kingston Grammar School 11+ entry page"),
    # --- Bancroft's ---
    ("q7_bancrofts_11", "https://www.bancrofts.org/admissions/11-entry/", "q7_bancrofts_11_entry.html",
     "Bancroft's 11+ admissions page (2027-entry cycle)"),
    ("q7_bancrofts_16", "https://www.bancrofts.org/admissions/entry-at-16/", "q7_bancrofts_entry_at_16.html",
     "Bancroft's 16+ admissions page (2027-entry cycle)"),
    ("q7_bancrofts_faq", "https://www.bancrofts.org/about-us/frequently-asked-questions/", "q7_bancrofts_faq.html", "Bancroft's FAQ page"),
    # --- Tonbridge School ---
    ("q7_tonbridge_13", "https://www.tonbridge-school.co.uk/admissions/year-9-13-entry/", "q7_tonbridge_year_9_13_entry.html",
     "Tonbridge Year 9 (13+) entry page"),
    ("q7_tonbridge_16", "https://www.tonbridge-school.co.uk/admissions/year-12-16-entry/", "q7_tonbridge_year_12_16_entry.html",
     "Tonbridge Year 12 (16+) entry page"),
]

SOURCES = SOURCES_A + SOURCES_B


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--day")
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--retry-blocked", action="store_true", help="retry ids already in the blocked log")
    a = ap.parse_args()
    blocked = set()
    if BLOCKED.exists() and not a.retry_blocked:
        with BLOCKED.open(encoding="utf-8") as f:
            blocked = {r["id"] for r in csv.DictReader(f)}
    for sid, url, filename, note in SOURCES:
        if (a.only and sid not in a.only) or sid in blocked:
            continue
        p = polite_fetch(sid, url, filename, note, a.day, source=SOURCE)
        if p:
            print(f"{sid:30s} {p.name:55s} {p.stat().st_size:>10,d}")


if __name__ == "__main__":
    main()
