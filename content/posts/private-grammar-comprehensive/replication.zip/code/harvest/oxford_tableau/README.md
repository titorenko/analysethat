# Oxford "Applications by UCAS Apply Centre" (Tableau Public) — capture and OCR

Oxford's answer to our FOI (FOI/202610/1180, 6 Nov 2026) pointed to this dashboard instead of sending a file:
https://public.tableau.com/views/UniversityofOxford-AdmissionsStatistics2025UCASApplyCentre/UCASApplyCentre
(author: Oxford Student Data Modelling and Analytics). It lists, per UCAS apply centre, applications, offers,
offer rate, acceptances and acceptance rate, for cycles 2021-2025 and a 2023-25 total; counts below 3 are greyed.

**Why not `fetch.py`.** The publisher has switched off data and crosstab downloads (`allow_summary` and
`allow_view_underlying` false; the toolbar offers only "Image"), the `.csv` view URL returns 404, and the
table is drawn on the server as image tiles, so no numbers reach the browser. Scripted requests are stopped by
the site's AWS WAF, and each tile URL can be fetched only once (a second fetch returns 410). So the tiles were
copied from inside a real Chrome session, as the page loaded them, and read by OCR. This is the only harvest in
the project that does not go through `fetch.py`; the manifest (`data/manifest/oxford_apply_centre.csv`) is
written in the same format by hand.

## 1. Capture (Chrome, by the Claude in Chrome extension, 2026-11-07)

1. Open the view URL with `?:embed=y&:showVizHome=no`.
2. Paste `oxgrab.js` into the page. It hooks the page's XHRs: command responses go to `window.__cap` (the
   table's pixel height is in the layout response), and tile responses (`/vizql/tilecache/...webp`) are kept as
   blobs in `window.__tiles`.
3. Pick a cycle in "Select UCAS Cycle(s)" by mouse. The first click after page load is sometimes ignored:
   check the dropdown shows the cycle. Then run `__setDir()` (newest tile folder = current table state),
   `__scan()` (scrolls by synthetic wheel events until every `viz_N` and `yheader_N` tile has loaded) and poll
   `__status()`. Fast scrolling can skip a tile: scroll back up until `nmiss` is 0.
4. `__save('<cycle>')` downloads `oxford_applycentre_<cycle>_tiles.tar` (one folder, `yheader_NNN.webp` =
   ID/name/postcode/type pane, `viz_NNN.webp` = number pane). Saved as `data/raw/oxford_apply_centre/<day>/tiles_<cycle>.tar`.

Table heights (CSS px; 20 px per row) recorded at capture and asserted in the gate:
2021 70040, 2022 71740, 2023 71860, 2024 71160, 2025 72320, 2023-25 98540.

## 2. OCR

`ox_ocr.py <tile_dir> <out_csv>` stacks the tiles, cuts rows on the gridlines (mid-grey rows in both panes)
and cells on fixed column bounds (asserted empty gaps), and reads every non-blank cell with Surya
recognition given that cell's box (no layout model). It needs Surya 0.17.1 with a GPU, which is not in this
project's venv: it was run with the marker environment from analysis-v3,

    C:/kostya/blog/analysis-v3/work/markerenv/Scripts/python.exe -I ox_ocr.py <extracted tiles_2025/> ocr_2025.csv

(about 5 minutes per cycle on an RTX 5070 Ti). Output: `data/raw/oxford_apply_centre/<day>/ocr_<cycle>.csv`.

## 3. Derive and check (project venv)

    .venv/Scripts/python -I code/derive/oxford_apply_centre.py
    .venv/Scripts/python -I code/checks/g2_oxford_apply_centre.py

Verification done on 2026-11-07, beyond the gate: the 17 rows (of 17,856) that failed a first-pass
check were each read on the tile images; all were OCR padding or O/0 slips, fixed by the two rules in
the derive script, and the 5 `NULL` postcodes are printed by the dashboard. Two independent reviewers
(Claude Haiku agents) compared 300 random rows (60 per cycle) with image crops of the same rows: 0 mismatches.
