// Installed into the Oxford Tableau page: capture tile XHRs, scan by wheel, tar + download.
window.__tiles = window.__tiles || {}; window.__cap = window.__cap || [];
if (!window.__hooked) { window.__hooked = true;
  const oo = XMLHttpRequest.prototype.open, os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__u = u; return oo.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (b) {
    this.addEventListener('load', () => { try {
      const s = String(this.__u);
      if (s.includes('/commands/')) window.__cap.push({ u: s, status: this.status, t: this.responseText });
      if (s.includes('/tilecache/') && this.status === 200) { const v = this.response; window.__tiles[s.split('?')[0].split('/').slice(-2).join('/')] = v instanceof Blob ? v : new Blob([v]); }
    } catch (e) {} });
    return os.apply(this, arguments); };
}
window.__ny = function () { const t = window.__cap[window.__cap.length - 1].t;
  const p = [...t.matchAll(/"vizAltText": "([^"]*)"[\s\S]*?"geometryJson": "((?:[^"\]|\.)*)"/g)].map(m => ({ alt: m[1], g: JSON.parse(JSON.parse('"' + m[2] + '"')) })).find(p => p.alt.startsWith('Square chart of Measure Names'));
  const ysum = p.g.pi.yHeights.reduce((a, b) => a + b, 0); return { ysum, ny: Math.ceil(ysum / p.g.ts.h) }; };
window.__have = function () { const s = new Set(); const dirs = new Set();
  for (const k of Object.keys(window.__tiles)) { const m = k.match(/^([0-9a-f]+)\/.*\.(viz|yheader)\.0\.(\d+)\.webp$/); if (m && m[1] === window.__dir) s.add(m[2] + '_' + m[3]); } return s; };
window.__scan = function () { window.__scanState = 'running'; (async () => {
  const tgt = document.elementFromPoint(260, 350);
  const wheel = d => tgt.dispatchEvent(new WheelEvent('wheel', { deltaY: d, bubbles: true, cancelable: true, clientX: 260, clientY: 350 }));
  for (let i = 0; i < 40; i++) { wheel(-5000); await new Promise(r => setTimeout(r, 50)); }
  await new Promise(r => setTimeout(r, 2000));
  const { ny } = window.__ny();
  for (let step = 0; step < ny * 5; step++) { const h = window.__have(); let done = true;
    for (let y = 0; y < ny; y++) if (!h.has('viz_' + y) || !h.has('yheader_' + y)) { done = false; break; }
    if (done) break; wheel(500); await new Promise(r => setTimeout(r, 450)); }
  await new Promise(r => setTimeout(r, 1500)); window.__scanState = 'done'; })().catch(e => window.__scanState = 'error ' + e); };
window.__status = function () { const { ny, ysum } = window.__ny(); const h = window.__have(); const miss = [];
  for (let y = 0; y < ny; y++) { if (!h.has('viz_' + y)) miss.push('viz_' + y); if (!h.has('yheader_' + y)) miss.push('yheader_' + y); }
  return { state: window.__scanState, dir: (window.__dir || '').slice(0, 8), ny, ysum, have: h.size, nmiss: miss.length, missing: miss.slice(0, 12) }; };
// Directory (state hash) of the newest tile request = the current table state.
window.__setDir = function () { const n = performance.getEntriesByType('resource').map(e => e.name).filter(n => /\.(viz|yheader)\.0\.\d+\.webp/.test(n)).pop(); window.__dir = n.split('?')[0].split('/').slice(-2)[0]; return window.__dir.slice(0, 8); };
window.__tar = async function (files) { const enc = new TextEncoder(); const parts = [];
  const oct = (n, len) => n.toString(8).padStart(len - 1, '0') + '\0';
  for (const [name, b] of files) { const h = new Uint8Array(512); const put = (s, off) => h.set(enc.encode(s), off);
    put(name, 0); put(oct(0o644, 8), 100); put(oct(0, 8), 108); put(oct(0, 8), 116); put(oct(b.size, 12), 124); put(oct(Math.floor(Date.now() / 1000), 12), 136);
    put('        ', 148); put('0', 156); put('ustar\u000000', 257);
    let sum = 0; for (const x of h) sum += x; put(sum.toString(8).padStart(6, '0') + '\0 ', 148);
    parts.push(h, b); const pad = (512 - (b.size % 512)) % 512; if (pad) parts.push(new Uint8Array(pad)); }
  parts.push(new Uint8Array(1024)); return new Blob(parts, { type: 'application/x-tar' }); };
window.__save = async function (tag) { const files = [];
  for (const [k, b] of Object.entries(window.__tiles)) { const m = k.match(/^([0-9a-f]+)\/.*\.(viz|yheader)\.0\.(\d+)\.webp$/); if (m && m[1] === window.__dir) files.push([tag + '/' + m[2] + '_' + m[3].padStart(3, '0') + '.webp', b]); }
  files.sort((a, b) => a[0] < b[0] ? -1 : 1); const tar = await window.__tar(files);
  const a = document.createElement('a'); a.href = URL.createObjectURL(tar); a.download = 'oxford_applycentre_' + tag + '_tiles.tar'; document.body.appendChild(a); a.click(); a.remove();
  return [files.length, tar.size]; };
'installed';
