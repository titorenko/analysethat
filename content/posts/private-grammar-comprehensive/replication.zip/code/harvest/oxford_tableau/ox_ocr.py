"""OCR the Oxford 'Applications by UCAS Apply Centre' Tableau tiles for one cycle.

usage: python -I ox_ocr.py <tile_dir> <out_csv>

Tiles: yheader_NNN.webp (ID, name, postcode, type) and viz_NNN.webp (applications,
offers, offer rate, acceptances, acceptance rate), same height, stacked top to bottom.
Rows are cut on the table's gridlines, cells on fixed column bounds, and each non-blank
cell is read by Surya recognition with an explicit box (no layout guessing).
"""
import csv, re, sys
from pathlib import Path
import numpy as np
from PIL import Image

tile_dir, out_csv = Path(sys.argv[1]), Path(sys.argv[2])

def stack(prefix):
    files = sorted(tile_dir.glob(f"{prefix}_*.webp"))
    ims = [Image.open(f).convert("RGB") for f in files]
    w = ims[0].width
    assert all(i.width == w for i in ims), prefix
    out = Image.new("RGB", (w, sum(i.height for i in ims)), "white")
    y = 0
    for i in ims:
        out.paste(i, (0, y)); y += i.height
    return out, len(files)

Y, ny = stack("yheader")
V, nv = stack("viz")
assert ny == nv and Y.height == V.height, (ny, nv, Y.height, V.height)
gy = np.asarray(Y.convert("L")).astype(np.int16)
gv = np.asarray(V.convert("L")).astype(np.int16)

# Gridlines: rows where >=90% of pixels are mid-grey (line colour ~175) in BOTH panes.
def line_rows(g):
    m = g[:, 3:-3]
    return ((m >= 130) & (m <= 200)).mean(1) >= 0.90
is_line = line_rows(gy) & line_rows(gv)
bands, start = [], None
for yy, ln in enumerate(is_line):
    if not ln and start is None:
        start = yy
    elif ln and start is not None:
        bands.append((start, yy)); start = None
if start is not None:
    bands.append((start, len(is_line)))
bands = [b for b in bands if b[1] - b[0] >= 15]          # drop slivers
h = np.median([b[1] - b[0] for b in bands])
odd = [b for b in bands if abs((b[1] - b[0]) - h) > 3]
print(f"{tile_dir.name}: {len(bands)} rows, median height {h}, odd-height bands {len(odd)} {odd[:5]}")

# Number-pane columns: 5 equal columns separated by white gaps.
VW = V.width; cw = VW / 5
vcols = [(int(round(i * cw)) + 3, int(round((i + 1) * cw)) - 3) for i in range(5)]
# Header-pane columns: fixed bounds at the ink gaps measured over every tile of 2021
# and 2025 (ID ends <89, name <482, postcode 492-586, type from 618). Assert the gaps
# are empty so a layout change fails loudly.
assert Y.width == 739 and V.width == 640, (Y.width, V.width)
ycols = [(0, 87), (87, 487), (487, 602), (602, Y.width)]
for gap in ((483, 491), (588, 617)):
    assert not (gy[:, gap[0]:gap[1]] < 120).any(), f"ink in header gap {gap}"

def has_ink(g, x0, x1, y0, y1):
    return (g[y0:y1, x0:x1] < 120).any()

# Build recognition jobs in chunks of ~60 rows so images stay small.
from surya.foundation import FoundationPredictor
from surya.recognition import RecognitionPredictor
rec = RecognitionPredictor(FoundationPredictor())

rows = [{"row": i, "y0": b[0], "y1": b[1]} for i, b in enumerate(bands)]
FIELDS_Y = ["ucas_id", "school_name", "postcode", "school_type"]
FIELDS_V = ["applications", "offers", "offer_rate", "acceptances", "acceptance_rate"]
CH = 60
for c0 in range(0, len(rows), CH):
    chunk = rows[c0:c0 + CH]
    top, bot = chunk[0]["y0"] - 2, chunk[-1]["y1"] + 2
    imgs, boxes, keys = [], [], []
    for pane, g, cols, fields in ((Y, gy, ycols, FIELDS_Y), (V, gv, vcols, FIELDS_V)):
        im = pane.crop((0, top, pane.width, bot))
        bb, kk = [], []
        for r in chunk:
            for (x0, x1), f in zip(cols, fields):
                if has_ink(g, x0, x1, r["y0"], r["y1"]):
                    bb.append([x0, r["y0"] - top, x1, r["y1"] - top]); kk.append((r["row"], f))
                else:
                    rows[r["row"]][f] = ""
        if bb:
            imgs.append(im); boxes.append(bb); keys.append(kk)
    res = rec(imgs, bboxes=boxes, math_mode=False)
    for kk, rr in zip(keys, res):
        assert len(kk) == len(rr.text_lines)
        for (ri, f), tl in zip(kk, rr.text_lines):
            rows[ri][f] = re.sub(r"<[^>]+>", "", tl.text).strip()
            rows[ri][f + "_conf"] = round(float(tl.confidence or 0), 3)
    print(f"  rows {c0}-{c0 + len(chunk) - 1} done", flush=True)

cols = ["row", "y0", "y1"] + FIELDS_Y + FIELDS_V + [f + "_conf" for f in FIELDS_Y + FIELDS_V]
with open(out_csv, "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow(r)
print("wrote", out_csv, len(rows))
