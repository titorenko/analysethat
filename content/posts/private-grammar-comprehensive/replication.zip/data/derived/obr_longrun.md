# obr_longrun.csv

OBR *Fiscal risks and sustainability*, July 2026 (published 7 Jul 2026), Table 2.1: "Summary of baseline long-term demographic and economic assumptions". Annual averages in % over the 50-year projection.

**Source**
- Raw file: `data/raw/obr/2026-10-10/frs_july_2026.html`, from `https://obr.uk/frs/fiscal-risks-and-sustainability-july-2026/`. The table is found by its caption in the page HTML.
- Built by `code/derive/build_rates.py`.

| column | meaning |
|---|---|
| section | Table section: Employment and real economy; Earnings and nominal economy; Interest rates |
| assumption | Row label as printed |
| column | `mar2026_efo_avg` (average over the March 2026 EFO forecast), `frs_2024`, `frs_2026` |
| value_pct_per_year | Value in % a year |
| methodology | OBR's "Methodology in long-term projection" text |
| source_file | Raw HTML |

27 rows: 9 assumptions × 3 columns.

**Caveats**
- **Average earnings growth is nominal.** OBR describes it as the "Sum of labour productivity and GDP deflator growth".
  - FRS 2026: 3.7% nominal, 2.2% GDP deflator, so about 1.5% real on a GDP-deflator basis. Productivity is 1.4%; the gap is rounding.
  - This is **not** the CPI-real earnings growth that IFS uses: 1.83%, or 1.75% after the OBR's March 2026 determinants (see `ifs2026_assumptions.md`).
- **The gilt rate is nominal.** "Sum of long-maturity real yields and GDP deflator growth": 4.3 − 2.2 = 2.1% real (GDP deflator).
