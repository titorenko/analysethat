# evidence_table.csv

Every quantitative literature estimate the write-up may use, one row per estimate. It covers:
- private-school and grammar-school effects on HE entry, elite (Russell Group) entry, degree and adult earnings;
- the channel estimates for the cohort bridge (PLAN §4.2.6).

**Build and check**
- Built by `code/derive/build_evidence_table.py` from an evidence list held in the script.
- Checked by `code/checks/g_evidence.py` (G-evidence: PASS, 312 rows).
- Sources are under `data/raw/literature/2026-10-10/` (manifest `data/manifest/literature.csv`), plus the IFS 2026 report in `data/raw/ifs/2026-10-10/`.
- Fetch log and contradictions with the scouting file: `data/notes/literature.md`.

**Rows:** 312 in total, from 25 study keys.
- verified: 303.
- unverified_other: 9, all numbers quoted second-hand:
  - the 1980 and 1993 graduate premiums, quoted in Britton et al. 2016;
  - Burgess, Crawford & Macmillan 2019 and Mansfield 2019, quoted in HEPI 2020.
- unverified_paywalled: 0. Every study on the list had an open copy. For Clark & Del Bono, Clark (2010) and Macmillan et al. the open copy is the working paper or briefing, not the journal version.

## Columns

| column | meaning |
|---|---|
| row_id | `<study>-NN`, sequential within study in build order |
| study | short key, e.g. `GHV2017`; `citation` gives the full reference and the version read |
| comparison | `private_vs_state`, `private_vs_comprehensive`, `grammar_vs_comprehensive`, `grammar_vs_secondary_modern`, `grammar_vs_other_state` (secondary modern + comprehensive), `selective_system_vs_comprehensive_system` (area or LEA contrasts), `school_quality_other` (grammar and private pooled; grammar-intake expansion), `channel_second_stage` (IFS returns to HE, for the bridge) |
| cohort | `NCDS58`, `BCS70`, `NextSteps89`, `MCS01`, `SES2006_2012` (Skills and Employment Survey cross-section), `DLHE2006_07` (graduates), `LEO_GCSE2002`, `Aberdeen1950s`, `EastRiding1969_71`, `USoc_born1961_83`, `NI1977_80`, `TEDS94_96`, `graduates1980`, `graduates1993` |
| birth_years, country | as reported by the source |
| outcome | snake_case. IFS outcomes carry the HE route after `__`, e.g. `net_lifetime_return_gbp__russell_group` |
| measure | `log_points`; `pp` (percentage points printed on a 0-100 scale); `pct`; `frac` (a difference on a 0-1 scale: LPM or probit marginal effects, shares, A-level rank fractions); `sd`; `grade` (GCSE grades); `points` (raw test points); `gbp`; `ratio` (odds ratio); `elasticity` |
| age | age, or the age span, at which the outcome is measured |
| sex | `all` / `men` / `women` |
| estimand | `RAW` / `ADJ-PRE` / `ADJ-MED` (PLAN §1, §3) |
| controls | what is conditioned on, in that row's model |
| spec_order | position in the study's nested sequence for that outcome, cohort and sex. Non-nested exceptions are noted (e.g. GMMZ Table 4 nests on spec 3, not spec 4) |
| estimate, se, ci_low, ci_high | as printed. `se` is blank where the source prints t-statistics (GAHH2020) or p-values (AGHH2024); those go in `note` |
| n | the sample size the source gives for that model. GHV2017 n is pooled across sexes |
| table_or_page | `PDF p.N` (1-based PDF page index) plus the table or text location |
| quote | verbatim snippet containing the number, as extracted by pdfplumber |
| source_url, source_file | download URL (from the manifest) and local path |
| status | `verified` = primary source, quote matched. `unverified_other` = number quoted second-hand (the quote still matches the citing PDF). `unverified_paywalled` = no open copy (none here) |
| note | caveats. Every derived or worded estimate is flagged here: `[derived]` marks a difference of two printed numbers, `[worded]` a number written in words, `[signed]` a sign taken from the wording ("2.1 percentage points ... lower") |
| estimate_pct | `exp(estimate) - 1`, as a proportion (0.346 = 34.6%), on `log_points` rows only. This is the table's only unit conversion |

**Quote check.** It is applied to every row with a source file, in both the build and the gate.
- Whitespace and NULs are deleted.
- U+2212 and the per-file `(cid:N)` minus glyphs become "-". Those files are GHV 2017, Dearden et al. 2002 and BDM 2020.
- The quote is then searched on the stated page in four forms:
  - the whole page;
  - the left column crop;
  - the right column crop;
  - the character-reversed page. GHV 2017 Table 3 is printed rotated, and its quote reads SEs, then the label, then the coefficients.
- The printed estimate (and SE) must also appear inside the quote.

**Labelling conventions.**
- Graduate-only samples are labelled ADJ-MED throughout, raw columns included, because the sample conditions on graduating. This applies to CV2014, MTV2015, DV2000 and NSM2002. The within-graduate sequence is in `spec_order`.
- Henderson et al. (HAGH2020) condition on GCSE, so they are ADJ-MED by PLAN §1. GCSE is pre-treatment only for a sixth-form-only route.
- Rows estimated by RD or IV are labelled ADJ-PRE, with the design stated in `controls`.
- IFS 2026 rows use RAW / ADJ-PRE for the HE-vs-no-HE contrast. They are not school effects.

## Coverage: comparison × estimand × sex (row counts)

| comparison | estimand | all | men | women | studies |
|---|---|---|---|---|---|
| private_vs_state | RAW | 16 | 6 | 6 | AGHH2024, GAHH2020, GHV2017, GMMZ2012, HAGH2020 |
| private_vs_state | ADJ-PRE | 30 | 13 | 13 | AGHH2024, GAHH2020, GHV2017, GMMZ2012, GPSW2018 |
| private_vs_state | ADJ-MED | 30 | 18 | 18 | CV2014, DV2000, GAHH2020, GHV2017, GMMZ2012, GPSW2018, HAGH2020, MTV2015, NSM2002 |
| private_vs_comprehensive | RAW | 5 | 0 | 0 | SPGWP2018, SULLIVAN2020, SW2018 |
| private_vs_comprehensive | ADJ-PRE | 2 | 3 | 2 | DFM2002, SPGWP2018, SULLIVAN2020, SW2018 |
| private_vs_comprehensive | ADJ-MED | 0 | 2 | 2 | DFM2002 |
| grammar_vs_comprehensive | RAW | 4 | 0 | 0 | SPGWP2018, SULLIVAN2020, SW2018 |
| grammar_vs_comprehensive | ADJ-PRE | 4 | 2 | 2 | BCM2019, DFM2002, SPGWP2018, SULLIVAN2020, SW2018 |
| grammar_vs_comprehensive | ADJ-MED | 0 | 2 | 2 | DFM2002 |
| grammar_vs_secondary_modern | RAW | 5 | 5 | 4 | CDB2016, CLARK2010, PJ2023, SPGWP2018, SULLIVAN2020 |
| grammar_vs_secondary_modern | ADJ-PRE | 7 | 14 | 12 | CDB2016, CLARK2010, PJ2023 |
| grammar_vs_other_state | RAW | 1 | 0 | 0 | BCBK2021 |
| grammar_vs_other_state | ADJ-PRE | 4 | 1 | 1 | BCBK2021 |
| grammar_vs_other_state | ADJ-MED | 1 | 0 | 0 | BCBK2021 |
| selective_system_vs_comprehensive_system | RAW | 12 | 0 | 0 | BDM2020, MANSFIELD2019, MP2006 |
| selective_system_vs_comprehensive_system | ADJ-PRE | 16 | 9 | 9 | BCM2019, BDM2020, GRV2005, MP2006 |
| school_quality_other | ADJ-PRE | 5 | 2 | 2 | DFM2002, GMM2012 |
| channel_second_stage | RAW | 0 | 1 | 1 | IFS2026 |
| channel_second_stage | ADJ-PRE | 0 | 11 | 7 | IFS2026 |

**Gaps.**
- There is no private-school earnings estimate for anyone schooled after 2003.
- There is no *school-level* grammar earnings estimate for anyone who sat the 11+ after the 1970s. BDM2020 is system-level and covers people born up to 1983.
- Grammar → elite HE has no adjusted point estimate:
  - For BCS70 (SULLIVAN2020) the adjusted effect is stated only as "no advantage".
  - The modern matched estimates (BCM2019) are second-hand.
- There are no quantile estimates for private schooling. The only quantile rows are BDM2020, which is system-level.

## What the evidence says

Percentages in brackets are `exp(b) - 1`.

- **Private schooling, NCDS58 and BCS70 hourly pay.**
  - **At 33-34 (GMMZ).** Raw gap: NCDS58 0.228 (25.6%), BCS70 0.348 (41.6%).
    - Family background removes most of it, giving 0.078 and 0.202 (8.1%, 22.4%).
    - Adding the early tests barely moves it: BCS70 0.202 → 0.197 (21.8%).
    - Adding highest qualification leaves 0.041 / 0.100 (4.2% / 10.5%).
    - Rows GMMZ2012-01 to -06, -25, -26.
    - Caveat: the treatment may be private *primary* schooling, so the age-10/11 tests may be partly post-treatment.
  - **BCS70 at 42, men (GHV 2017 Table 3).** Raw 0.584 (79.3%), then ADJ-PRE 0.297 (34.6%), then 0.173 (18.9%) after the whole education block, then 0.146 (15.7%) after job facets. Rows GHV2017-02, -04, -06, -08.
  - **BCS70 at 42, women.** Raw 0.477 (61.1%), then 0.192 (21.2%), then 0.058 (6.0%, n.s.), then 0.064 (6.6%). Rows GHV2017-11, -13, -15, -17.
  - Dreaming Big agrees. Men 0.294 → 0.171 (34.2% → 18.6%); women 0.187 → 0.0688 (20.6% → 7.1%). Rows GPSW2018-01 to -06.
  - **The industry step exists only in the Skills and Employment Survey, not in BCS70.** Men in that survey go 0.399 → 0.292 → 0.106 → 0.081 → 0.045 (4.6%, n.s.). Rows GHV2017-01, -03, -05, -07, -09.

- **Private schooling, Next Steps at 25 (private at 13).**
  - Log weekly pay: raw 0.346 (41.3%), then 0.159 (17.2%) after background only (no ability control), then 0.0975 (10.2%) after highest qualification and Russell Group entry. Rows GAHH2020-01 to -03.
  - High-status (NS-SEC 1-2) occupation: +0.279, then +0.120, then +0.055 on a 0-1 scale. Rows GAHH2020-04 to -06.
  - The scouting file's "5.5 percent direct premium" is this occupation coefficient, not pay.

- **First stages: university and exams.**
  - Degree by 23 (BCS70): raw +0.393, ADJ-PRE +0.222. Rows GMMZ2012-32, -36.
  - Next Steps, private sixth form, among A-level students, given GCSE and background:
    - Any HE: +0.09, falling to +0.06 once A-level subjects and grades are added. Rows HAGH2020-03 to -06.
    - Russell Group among HE entrants: +0.10, then +0.06 with A-level grades, then +0.02 (n.s.) with facilitating subjects disaggregated. Rows HAGH2020-07 to -10.
  - MCS01, born 2000-02: the private GCSE edge is 0.87 of a grade raw, 0.05 after SES, and −0.18 (n.s.) with all controls. In maths it is −0.84 (state ahead). Rows AGHH2024-01, -02, -06, -14.
  - So the academic channel of the 1970 cohort has not been shown to exist for the newest cohort. The A-level subject route to the Russell Group has (Next Steps).

- **Graduate-only direct premium (ADJ-MED: conditions on graduating).**
  - Raw within-graduate gap: 0.128 lp (13.7%) at 6 months and 0.172 (18.8%) at 3.5 years.
  - After A levels, degree class, institution and subject: 0.067 and 0.068 (6.9%, 7.0%). The occupation step takes these to 0.058 / 0.060. Rows CV2014-01 to -08.
  - By sex at 3.5 years: men 0.091 (9.5%), women 0.046 (4.7%). Rows CV2014-19, -23.

- **Second stages (IFS 2026, LEO, 2002 GCSE cohort).** Net individual lifetime returns against *no HE*, 2025/26 prices:
  - Men: Russell Group £178k (median £93k), pre-1992 £109k, other universities £60k / £64k.
  - Women: Russell Group £107k. No other institution figure is printed for women.
  - All HE, gross: £215k men and £148k women. Net: £109k men and £90k women.
  - Rows IFS2026-03 to -06, -09 to -14.

  These are not Russell Group premiums over another university. For men, RG minus pre-1992 is £69k, but that difference also reflects which students go where.

- **Grammar earnings: about zero for men at the margin, uncertain for women.**
  - Aberdeen RD (2SLS), log annual income: men −0.066 (−6.3%), women +0.158 (17.1%, imprecise). The raw gaps were 0.422 / 0.490. Rows CDB2016-01, -03, -05, -07.
  - NCDS RD, log hourly wage at 33: +0.069 (7.2%, SE 0.167). Row PJ2023-03.
  - NCDS lifetime earnings (2018 £), ADJ-PRE: £38.7k (SE £19.4k), from a raw £255k. Men £82.3k, women £5.5k (n.s.). Controlling for general ability only gives £88k. Rows BCBK2021-01 to -05.
  - Dearden et al. (NCDS): men at 33, 0.086 (9.0%) ADJ-PRE. Row DFM2002-04.
  - The education effects are large: A levels +0.26 and degree +0.15 (RD). Rows PJ2023-01, -02.

- **Grammar and elite HE.**
  - BCS70: the raw elite-degree gap is grammar 12% vs comprehensive 5% (+7pp), against private 29% (+24pp). After background and tests to age 10 there is "no advantage" for grammar, while the private advantage persists. No number is printed. Rows SULLIVAN2020-04, -06, -07, -08.
  - Modern NPD-HESA matching, second-hand: grammar pupils +7pp in high-status HE, but near-misses −7.0pp and low-KS2 pupils −2.1pp in selective areas. Rows BCM2019-01 to -03.
  - The area-level raw gap is +16pp (39% vs 23%), not area-matched. Row MANSFIELD2019-02.

- **Grammar: why proxy-adjusted estimates are upper bounds.**
  - Manning & Pischke's placebo is an age-11 maths score on age-7 controls. Its fullest-control estimate is −3.29, larger than the age-16 value-added estimate of −1.48. Rows MP2006-05, -10.
  - Galindo-Rueda & Vignoles show the same within their own matching. For top-quintile men, the age-11 "effect" is 2.573 against 1.916 at 16. Rows GRV2005-06, -10.
  - Selective *systems* left mean wages unchanged (−£0.01/h) but widened the distribution: P10 −£1.02 and P90 +£1.31 per hour, conditional. Rows BDM2020-01, -03, -11.
  - TEDS: once SES, prior ability, prior achievement and the polygenic score are controlled, GCSE gaps shrink from about 1 SD to 0.026 SD (grammar) and 0.070 SD (private). Rows SW2018-01 to -04.

## Consequences for the cohort bridge (PLAN §4.2.6)

PLAN plans to decompose the BCS70 ADJ-PRE premium into degree, Russell Group, subject, industry and a residual. No published BCS70 table supports that.

- **Education is one block.**
  - In GHV 2017 and Dreaming Big, Model 3 / column 5 adds GCSE, A levels, highest qualification and degree subject × elite university × class together.
  - In GMMZ, only highest qualification is added.
  - The bridge can separate ADJ-PRE → after-education → residual, and nothing finer.
- **Industry is SES-only.** The industry step comes from the Skills and Employment Survey (ages 25-60, 2006/2012, school type self-reported), which has no ability control. Using it for BCS70 means transporting a ratio across datasets.
- **Finer splits come from other studies, as separate first and second stages.**
  - Russell Group and subject: Henderson et al. (first stage, given GCSE) and IFS 2026 (second stage, against no HE).
  - Within-graduate institution and subject block: Crawford & Vignoles.
  - Each comes from a different cohort and sample. The bridge has to say so.
