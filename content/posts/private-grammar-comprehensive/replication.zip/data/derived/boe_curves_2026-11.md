# boe_curves_2026-11.csv

Bank of England UK government liability curves (GLC) for one day: the latest date common to the nominal, real and inflation files. That date is **2026-11-04**.

**Source**
- Raw file: `data/raw/boe/2026-11-05/latest-yield-curve-data.zip`, from `https://www.bankofengland.co.uk/-/media/boe/files/statistics/yield-curves/latest-yield-curve-data.zip`.
- Each value comes from sheet "4. spot curve" of the matching file:
  - `GLC Nominal daily data current month.xlsx`
  - `GLC Real daily data current month.xlsx`
  - `GLC Inflation daily data current month.xlsx`
- Built by `code/derive/build_boe.py`. The output file name carries the curve month.

| column | meaning |
|---|---|
| date | Curve date |
| maturity_years | 0.5 to 40, in 0.5-year steps |
| nominal_spot_pct | Nominal spot rate, % a year |
| real_spot_pct | Implied real spot rate from RPI-linked gilts, % a year. Starts at 2.5 years; null below. |
| implied_inflation_spot_pct | BoE implied RPI inflation spot rate, % a year. Starts at 2.5 years. |

80 rows.

**Caveats**
- **The columns are additive.** nominal − real − inflation = 0 exactly (to float precision) at every maturity. BoE's inflation curve is therefore the difference of the other two. The info sheets do not state a compounding convention; this file records what the data show and makes no further claim.
- **The real rates are RPI-real.** RPI is aligned to CPIH from 2030, so CPI-real yields on the pre-2030 part of each bond would be somewhat higher.
