# dest_ks4_school.csv

KS4 leavers' destinations by state-funded school, urn x time_period (2020/21-2022/23 leavers); independents not covered. Source: data/raw/dfe_dest/2026-10-10/dest_ks4_inst.csv (EES catalogue 7be58881-d49f-4e3b-b2b6-0877a1a0fe6e, 2023/24 release).

Columns, measures, time-period convention and caveats: see [destinations.md](destinations.md). Built by `code/derive/build_destinations.py`.
