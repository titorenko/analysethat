# obr_inflation_2026_03.csv

OBR *Economic and fiscal outlook*, March 2026 (published 3 Mar 2026), detailed forecast tables: economy, Table 1.7
"Inflation", year-on-year growth by fiscal year. Built by `code/derive/build_obr_inflation.py`.

**Source:** `data/raw/obr/2026-10-10/efo_march_2026_economy_tables.xlsx`, from
https://obr.uk/download/march-2026-economic-and-fiscal-outlook-detailed-forecast-tables-economy/ (manifest
`data/manifest/obr.csv`).

| column | meaning |
|---|---|
| fiscal_year | `2008-09` ... `2030-31` |
| rpi_pct, cpi_pct, cpih_pct | % change on the previous fiscal year |
| status | `outturn`; `part_outturn` (2025-26: the table's note says outturn data run to December 2025); `forecast` (2026-27 to 2030-31) |
| source_file, source_table | where read |

**Use in the engine:** cash-frozen income tax and NI thresholds (to April 2031) are deflated to 2025/26 prices by the
CPI index 2026-27 to 2030-31 (cumulative 1.1041). RPI is aligned to CPIH from 2030; the 2030-31 RPI forecast (2.08%) is
close to CPIH (2.14%).

**House prices (added):** `house_price_pct` is Table 1.16, "House price index (per cent change on a year earlier)", by
fiscal year. The engine's real house-price growth is the geometric mean, over the forecast years 2026-27 to
2030-31, of (1 + house prices) / (1 + CPI) − 1 = 0.65% a year.
