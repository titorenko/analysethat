# beyond_pay.csv

Outcomes other than pay, by school type, for the article's "beyond pay" section (§8). One row per printed number (or, with
`measure` = `claim`, one sentence the article quotes or relies on). Built by `code/derive/build_beyond_pay.py` from
four PDFs fetched by `code/harvest/beyond_pay.py` (plus the Sullivan et al. 2018 manuscript already in `2026-10-10/`) into `data/raw/literature/2026-10-11/` (logged in
`data/manifest/literature.csv`). Checked by `code/checks/g_beyond_pay.py`.

Every value is parsed from the pdfplumber text of its page; nothing is typed in. The gate re-reads each page and
checks that the quote is on it (whitespace-insensitive, whole page or either half for two-column pages) and that the
value is one of the numbers printed in the quote.

| source | document | what is read |
|---|---|---|
| `ifs_pg` | Britton & van der Erve, IFS Briefing Note, *Family background and access to postgraduate degrees* | Table 1, PDF p.9: share of the 2002 GCSE cohort in England (born 1986-87) who **started** each kind of degree by age 30, for the poorest and richest fifths of state-school pupils (area-based index), private-school pupils and everyone. Claim rows p.15. |
| `eb2025` | Sutton Trust, *Elitist Britain 2025* | Each of the 46 profession pages (PDF pp.19-91): % who attended an independent, grammar and comprehensive school. Population benchmarks and the all-elite figure, PDF p.15. Data coverage, PDF p.107 (aim: find at least 60% of each group; seven groups at 50-60%). Claim rows on definitions, PDF pp.15, 106. |
| `st2009` | Sutton Trust (2009), *The educational backgrounds of leading scientists and scholars* | Table 1, PDF p.6: Royal Society and British Academy fellows with a known UK school, by school type (counts and %). School mix of 1950-1970, PDF p.9. Fellows born 1950-59, Appendix 4, PDF p.22. |
| `spgwp2018` | Sullivan, Parsons, Green, Wiggins & Ploubidis (2018), *BJS*, accepted manuscript (`data/raw/literature/2026-10-10/`) | Table 3, PDF p.31: Model 4 odds ratios (and 95% CIs) of reaching the top social class at 42, against comprehensive, for grammar, private outside the Tatler list, and Tatler-list private. One pooled model with a gender control; the Tatler split is made for boys only (claim row p.14). |
| `hagh2022` | Henderson, Anders, Green & Henseke (2022), *Cambridge Journal of Education*, doi 10.1080/0305764X.2022.2040951 | Next Steps (born 1989-90). Table 1, PDF p.10: % very or fairly satisfied with life at 25 by sex and school type. Table 3, PDF p.11: private-school coefficient (linear probability) on that outcome, Model 1 (no controls) and Model 3 (+ ethnicity, tenure, parental class and education, region, household income), with standard errors. Claim row p.12. |

| column | meaning |
|---|---|
| row_id | `<source>-NN` |
| source | see above |
| group | the population the number describes (an IFS group, an Elitist Britain profession, a fellowship, a sex) |
| school_type | `private`, `grammar`, `comprehensive`, `direct_grant`, `non_selective_state`, `secondary_modern`, `state`, `all`, `private_vs_state` |
| measure | what the number is (e.g. `started_phd_by_30`, `share_of_group`, `population_benchmark`, `claim`) |
| value | the number as printed; empty for claims |
| unit | `pct` (per cent), `count`, `frac` (a proportion: regression coefficient or SE), `text` |
| page | 1-based PDF page |
| quote | the text the value was read from (whitespace collapsed) |
| source_file | saved copy |
| note | caveats |

**Caveats.**
- IFS: starts, not completions. Grammar pupils are among the state-school fifths, not shown separately. The report
  adjusts the private-state gap only for postgraduate study as a whole, not for PhDs alone, and against the poorest
  fifth of state pupils only. Many private pupils have no age-11 test score, so that adjustment relies on GCSEs and
  A levels, which the school itself influences.
- Elitist Britain: shares are of everyone whose school is known, including people schooled outside the UK
  (the remainder after private + grammar + comprehensive). "Comprehensive" includes secondary moderns and technical
  schools; direct-grant grammars count as private. School = where the person spent most of their secondary education.
  Raw shares only: nothing allows for family background or ability. The population benchmark the report uses is 7%
  private; grammar schools have taught about 5% of pupils since the late 1970s and about 25% in the 1960s, so grammar
  shares of older groups have no single benchmark.
- 2009 fellows: Table 1 is inconsistent with itself. Its combined independent count (557) is not the Royal Society
  count plus the British Academy count (293 + 267 = 560), and 41 non-selective fellows of 1,341 is 3.1%, printed as 2%.
  The article computes the fellows' shares from the counts (3% non-selective) and states the printed 2%. In Appendix 4 the school counts for each decade do not quite sum to the decade
  total. "The majority were born before World War 2" (PDF p.4), so the comparison is with the school system of the 1940s-1960s; the report's benchmark is 1950-1970.
- Henderson et al.: raw differences are Model 1; "background" is Model 3, the first model with family background.
