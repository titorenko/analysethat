# cambridge_school_type.csv

University of Cambridge undergraduate applications, offers and acceptances by type of school/college, 2013-2025 UCAS cycles. Each cycle has 13 rows: 8 in the Home block, 4 in the Other block, and 1 grand total. 169 rows in all. Built by `code/derive/cambridge_school_type.py`.

**Source:** the annual "Undergraduate Admissions Statistics" PDFs, one per cycle, at `data/raw/cambridge_stats/2026-10-10/ug_admissions_statistics_<cycle>_cycle.pdf`. All are linked from https://www.undergraduate.study.cam.ac.uk/apply/before/application-statistics, and the URLs and sha256 hashes are in `data/manifest/cambridge_stats.csv`.

| cycles | source table | page |
|---|---|---|
| 2013-2021 | Table 1.1 "Applications, offers and acceptances to Cambridge by type of school/college and gender <cycle>" (2013: "Applications and acceptances ...") | 4 |
| 2022-2025 | Table 2.1 (same title; the 2023 contents page misspells it "ofers") | 5 |

| column | meaning |
|---|---|
| cycle | UCAS cycle; for example, 2025 = applications made in autumn 2024 for 2025 entry |
| block | `home` = Home applications (fee status); `other` = all other applications; `all` = the Totals row |
| school_type | label as printed: `Maintained`, `Comprehensive School`, `Grammar School`, `Sixth Form College`, `FE and Tertiary Colleges`, `Independent`, `Other and Overseas`, `Subtotals`, `Totals` |
| level | `sector` (Maintained / Independent / Other and Overseas), `maintained_subtype` (the four rows under Maintained, Home block only), `subtotal`, `total` |
| applications, offers, acceptances | printed Totals columns. **offers is empty for 2013**, because that table has no offers column |
| success_rate_pct | printed success rate, which is acceptances / applications |
| scope | plain-language scope of the block |
| source_table, source_page, source_file | where the row was read |

**Caveats**
- "Maintained" and "Independent" mean UK schools/colleges. In the `other` block, they are applicants resident outside the UK who were educated at UK schools.
- "Other and Overseas" is mostly schools outside the UK. It also includes UK non-school institutions and applicants who applied without a school.
- Academies count as Comprehensive if their admissions policy is non-selective and as Grammar if it is selective. In 2013 the note says "Schools previously categorised as Other Maintained" were reallocated the same way.
- Use the "Home applicants from UK schools" figure (task scope) as `block == "home"` with `school_type in {Maintained, Independent}`, or the four maintained sub-types plus Independent.
- Men + Women do not sum to Totals (other or unknown gender appears only in Totals), so only the printed Totals are kept.
- Internal arithmetic is asserted for every cycle at build time:
  - the four sub-types sum to Maintained;
  - Maintained + Independent + Other = Subtotals in each block;
  - Home + Other Subtotals = Totals.
- The headline maintained share printed under each table (for example, 72.5% in 2025) is recomputed in gate G1-Cambridge for all 13 cycles.
