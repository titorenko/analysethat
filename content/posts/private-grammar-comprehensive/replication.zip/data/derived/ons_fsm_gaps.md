# ons_fsm_gaps.csv

Raw and adjusted gaps in average PAYE earnings at age 30 relative to state FSM recipients, by sex.

**Source.** ONS FSM earnings article, 4 Aug 2022, Figure 6 data download.
- Raw file: `data/raw/ons_fsm/2026-10-10/Fig_6_Raw_adjusted_gaps.xlsx`
- Built by `code/derive/build_ons_fsm.py`.

| column | meaning |
|---|---|
| group | `independent` or `state_non_fsm` (each compared with `state_fsm`) |
| sex | `male` or `female` |
| age | 30 |
| gap_type | `raw` or `adjusted` |
| gap_vs_fsm_pct | % by which the group's average earnings exceed FSM recipients' average earnings |

8 rows. Tax years ending 2017 to 2019.

**Caveats**
- **Adjusted gaps.** The article's model adjusts for:
  - education (highest qualification)
  - KS4 attainment
  - labour-market experience
  - ethnicity
  - region of secondary school

  These are partly post-treatment controls (education, experience), so the adjusted gap is not a causal school effect.
- **Fig 7 is not tabulated.** The raw file is saved alongside. It decomposes the FSM gap in log earnings: education 42.1%, experience 55.7%, total explained 95.3%.
- **Figs 2-4 are not derived.** Their raw files are saved alongside:
  - Fig 2: by age and gender
  - Fig 3: highest qualification
  - Fig 4: by age and highest qualification
