# glms_2024_employment.csv

DfE *Graduate labour market statistics*, calendar year 2024 (published 5 Jun 2025, last updated 1 Apr 2026; the
series is discontinued, superseded by LEO graduate outcomes). England, Labour Force Survey. Built by
`code/derive/build_glms.py`.

**Source:** `data/raw/dfe_glms/2026-10-10/glms_2024_all_files.zip` (release 947eb47c-7115-444a-be5a-6c689d183687,
"Download all data"), from https://explore-education-statistics.service.gov.uk/find-statistics/graduate-labour-markets.

| column | meaning |
|---|---|
| measure | `employment_rate` (% of population aged 16-64, or of the age band) or `part_time_share_of_employed` |
| graduate_type | Graduate (first degree, no postgraduate), Postgraduate, Non-graduate |
| breakdown_topic, breakdown | `age` (16-64, 21-30 for employment; 16-20 ... 61-64 for part-time) or `sex` |
| value_raw, value_pct | as published; `c` = suppressed, `z` = no sample (value_pct empty) |

**Key 2024 values (graduates):**
- **Employment:** 87.6% overall; men 89.5%, women 85.9%; 86.5% at ages 21-30.
- **Part-time share of the employed:** men 8.7%, women 27.9%. By age: 13.4% (21-30), 17.3% (31-40),
  19.4% (41-50), 23.2% (51-60), 43.2% (61-64).

**Caveats:**
- No sex × age cross-tabulation is published.
- Employment rates by age exist only for 16-64 and 21-30.
- Nothing is published for ages 65-67.
