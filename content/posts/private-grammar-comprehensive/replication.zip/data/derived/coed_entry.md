# coed_entry.csv

This table has one row for each of 16 independent schools that DfE lists as "Mixed". It records the ages at which girls and boys can join each school. Some of these schools take girls only into the sixth form, and others are phasing co-education in. It was built by `code/derive/build_coed_entry.py` from the schools' own admissions pages and admissions policies. Those files are saved under `data/raw/school_docs/2026-10-10/` (`<urn>_coed_*`) and logged in `data/manifest/school_docs.csv`.

**Entry year.** The answers are for **September 2027 entry**, because that is the cycle every school's admissions pages covered on 2026-10-10. The brief asked for September 2026, or 2027 where that is what the page now covers. The `girls_at_11_or_13_for_2027_entry` column keeps the name the brief gave it. Only Trinity gives a different answer for 2026: it admitted girls at 16+ only, so the flag would have been `no`.

**Scope.** Entry points are the school's main or usual points of entry into this URN at age 10+ or above. The following go in `note` instead:
- junior, pre-prep and 7+ entry
- feeder routes through a separate establishment, such as Westminster Under School and The Pilgrims' School
- occasional places and places offered "subject to availability"

| column | meaning |
|---|---|
| urn, name | school (DfE URN) |
| girls_entry_points | ages at which girls can join, for September 2027 entry, separated by `;` |
| boys_entry_points | the same for boys |
| girls_at_11_or_13_for_2027_entry | `yes` if girls can join at 11+ or 13+ (see "Entry year"), `no` otherwise, `unverified` if no quote was found (none) |
| source_url | the URL requested (from the manifest) |
| source_file | the saved copy |
| quote | verbatim text from `source_file`. ` … ` separates non-adjacent fragments of the same file, in page order. |
| note | phase-in dates, out-of-scope routes and caveats, plus further verbatim evidence from other files (`Also <file>: "<quote>"`) |

**Verification.** The build normalises the extracted text of each saved file: tags are stripped, whitespace is collapsed, text is lower-cased, curly quotes and dashes are straightened, and PDF page headers are removed. Every quote fragment, including the `Also` quotes, must then occur in that text in order, or the build fails. The KCS `.json` files come from the site's content API, and the build decodes the HTML held in their string fields before checking. A negative test changed one word in each quote and every check failed, as it should. The test also reversed the order of fragments, and every check failed except the UCS Year 7 page, which repeats its text.

**Result.** Girls cannot join at 11+ or 13+ at five schools (Westminster, King's College School, Magdalen College School, Winchester, UCS), where they join at 16+ only. Phase-in dates:
- Westminster: 13+ from 2028.
- KCS: 11+ from 2033 and 13+ from 2035.
- MCS: 11+ from 2030 and 13+ from 2032.
- Trinity: 10+ and 11+ from 2027, and 13+ from 2029.
- Winchester and UCS: no date found on the admissions pages checked.

Trinity admits girls at 10+, 11+ and 16+ for 2027 entry. Its 13+ entry in 2027 is for boys only, with girls at 13+ from 2029. The other 10 schools admit girls at the same points as boys: Perse, Latymer, Highgate, Alleyn's, KGS, Bancroft's, Reigate, Sevenoaks, Nottingham High and Brighton.

**Caveats**
- `school_master.csv` gives KCS (102684) the DfE gender `Boys`, not `Mixed`.
- Westminster's girls at 11+ (from September 2026) join Westminster Under School, not this URN, so the flag is `no`.
- The quotes for several schools come from admissions policy PDFs, not web pages, because their entry pages never mention girls. These are Latymer, Alleyn's, KGS, Bancroft's, Highgate and MCS. Nottingham High's girls statement is on its mission page, and its entry points are on the admissions page. Brighton College publishes no written admissions policy. Its row rests on the Lower School page ("boys and girls" in Years 7-8), its description of itself as co-educational, and the Year 7/Year 9 join page.
- Westminster's "Admissions and Awards Policy September 2026 Entry Onwards" PDF returned 404, so its co-education and 13+ entry pages were used instead.
- At Highgate, the "13+ admissions" URL now serves the Occasional Places page. That page lists the main entry points as 4+, 7+, 11+ and 16+.

**Correction (2026-10-10, review round 3):** Westminster is flagged `yes`. Girls join Westminster Under School in Year 7 from September 2026 and move up to Westminster School at 13+ without reapplying, which is the same route as boys' 11+ entry. The column is renamed `girls_at_11_or_13_for_2027_entry` to match the entry year actually checked.
