# ons_fsm_percentiles.csv

PAYE earnings at age 30, percentiles 1-99, for three groups.

**Source.** ONS, *Why free school meal recipients earn less than their peers*, 4 Aug 2022, Figure 1 data download.
- Raw file: `data/raw/ons_fsm/2026-10-10/Fig_1_Earnings_percentiles.xlsx`
- URL: `https://www.ons.gov.uk/visualisations/dvc2083/Fig_1_Earnings_percentiles/datadownload.xlsx`
- Built by `code/derive/build_ons_fsm.py`. Gate: `code/checks/g1_ons_fsm.py` (G1-ONS).

| column | meaning |
|---|---|
| group | `independent`; `state_non_fsm` (state school, not FSM); `state_fsm` (state school, FSM recipient). There is no grammar split. |
| age | 30 |
| percentile | 1-99 |
| earnings_gbp | Annual PAYE earnings at that percentile, at full file precision. Some values have decimals (e.g. 71304.8); ONS text rounds to £1. |

297 rows: 3 groups × 99 percentiles.

**Caveats**
- **Data.** LEO PAYE earnings only, so self-employment income is excluded. This matters most for the top of the independent group. The data cover people aged 30 in the tax years ending 2017 to 2019.
- **Price base.** Not stated in the file or the article for Fig 1. Fig 5 is explicitly in April 2019 prices.
- **Who is included.** The subtitle doesn't say whether zero or very low earners are included. The bottom percentiles are very low (independent P1 £673), which suggests anyone with any PAYE earnings is included.
- **School type.** Measured at school age; FSM is FSM recipient status.
