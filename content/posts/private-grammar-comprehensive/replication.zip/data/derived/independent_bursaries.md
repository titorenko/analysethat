# independent_bursaries.csv

Fee income and fee remissions (bursaries, scholarships, staff and sibling discounts) from the most recent filed accounts of the charity that runs each of the 45 schools in `top30_independent.csv`. Financial years end between 30 Jun and 31 Aug 2025.

**Source.**
- Charity Commission register extract `data/raw/charity_commission/2026-10-10/publicextract.charity.zip` (OGL). Charities were matched to schools by postcode, web domain and name, then confirmed from the accounts.
- Accounts are the Charity Commission filings as mirrored by OpenCharities, in `data/raw/charity_accounts/2026-10-10/`:
  - `<number>_<fy end>_accounts.pdf`, read with pdfplumber;
  - `.md`, OpenCharities' OCR text of the same filing;
  - `<number>.json`, the OpenCharities record listing the filings.
- Built by `code/derive/build_bursaries.py`; gate `code/checks/g_fees.py`.

**How the values were made.** Values were transcribed by hand from the fee-income note and the trustees' report. The builder checks two things:
1. each quoted figure or phrase occurs in the stated source (PDF page text, any PDF page, or the OCR text);
2. the fee note adds up: gross − remissions + printed adjustments = the printed subtotal.

One row per school. Schools run by the same charity repeat the charity's figures; see `charity_scope`.

| column | meaning |
|---|---|
| urn, name | From `top30_independent.csv` |
| charity_number | Registered charity number of the main charity (not a linked subsidiary) |
| fy_end | Financial year end of the accounts used |
| gross_fees | Gross fees (£) before remissions, as printed. In a few cases it is a sum of printed lines (see `note`). St Albans High's is computed: fees receivable + remissions stated in the accounting policy. |
| total_remissions | Sum (£) of the remission lines deducted from gross fees: bursaries, scholarships, grants, allowances, staff/clergy/sibling discounts. It excludes add-backs of bursaries paid by restricted funds and financing discounts (Eton's pre-paid fees discount). It is the charity's deduction before any add-back, so Westminster's is £2,988k. |
| means_tested_amount | Means-tested bursary value (£) as disclosed. Some disclosures are rounded (£1.1m, £2.5m, £5.9m, £5.2m, "over £1.7m"); see `note`. Blank if not disclosed. |
| means_tested_pupils | Pupils on means-tested awards, as disclosed. Blank if not disclosed. |
| full_remission_pupils | Pupils on 100% (or 100%+) awards, as disclosed. The definitions vary slightly; see `note`. Blank if not disclosed. |
| remission_share | total_remissions / gross_fees |
| means_tested_share | means_tested_amount / gross_fees |
| source_url | `https://opencharities.uk/ew/<number>`. The PDF itself is `files.opencharities.uk/ew/<number>/<fy end>-accounts.pdf`; see `data/manifest/charity_accounts.csv`. |
| source_location | Note and page (PDF page index, with the printed page where it differs) |
| status | `confirmed`, `partial` (gross fees and remission totals not disclosed: GDST, Withington) or `not_charity` (City of London School and CLSG, run by the City of London Corporation) |
| charity_name | Register name |
| charity_scope | `school` (one school, sometimes with its own prep/junior school on the same charity); `group of 2 schools in this list` (Haberdashers' Aske's Charity: Boys' and Girls'); `multi-school trust` (figures cover other schools too: UCST/United Learning, GDST, Whitgift Foundation, KE VI Birmingham, United Westminster & Grey Coat, Francis Holland Trust). **Do not sum shared rows.** |
| verification | `pdf_text`: figures found in the PDF text layer (28 schools). `ocr_text`: scanned filing, figures found in OpenCharities' OCR text, with OCR spellings recorded in the builder (7). `visual`: OCR unusable, figures read from the rendered page; checked only by the identity and against rounded figures in the report text (8: Highgate, Alleyn's, LEH, Habs ×2, St Mary's Ascot, Merchant Taylors', Francis Holland). |
| local_path | Accounts PDF used |
| note | What was summed, definitions and caveats |

**Coverage (of 45 schools).**

| field | schools |
|---|---|
| gross fees and total remissions | 39 (38 charities) |
| means-tested amount | 32 |
| means-tested pupils | 36 |
| full-remission pupils | 21 |

Remission share: median 8.8%, range 4.8% (Francis Holland Trust) to 18.2% (Whitgift Foundation).

**Caveats.**
- **Definitions differ by school.** "Bursaries, scholarships and allowances", "fee assistance" and "financial aid" are not uniform. The PEPF/Manchester report found only about 31% of HMC schools disclose full means-tested data. Compare `remission_share` across schools with care.
- **Restricted-fund bursaries.** The amount added back in respect of bursaries paid by restricted funds is not deducted from `total_remissions`. The pupil still receives the whole remission.
- **Gross includes junior and prep pupils.** Gross fees include the charity's junior/prep pupils, and sometimes holiday courses (Concord, now out of the list) or music fees (Highgate).
