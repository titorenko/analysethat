# wp_school_type.csv

DfE Widening Participation in HE, "School Type" file, tidied. Key: cohort_age15 × by_age × student_group × school_type_at_17. 504 rows. Built by `code/derive/build_wp.py`.

**Source:** `data/raw/dfe_wp/2026-10-10/wp_school_type.csv`. This is EES catalogue file `93f0e5c3-6cf9-4344-a88b-6c64c3c01143` (School_Type.csv), in the "Widening participation in higher education" 2024/25 release, published 2026-07-09. The companion `wp_school_type_gap.csv` (state vs independent gap, no selective split) is harvested but not derived.

| column | meaning |
|---|---|
| cohort_age15 | academic year in which the cohort was aged 15 (2004/05 … 2021/22). The by-19 figures for 2020/21 = HE by 2024/25 |
| by_age | HE entry by age 18, 19, 20, 25 or 30 |
| student_group | `a_level` (A level students) or `all_ks5` (the file's "Total" = wider KS5 cohort) |
| school_type_at_17 | `independent`, `selective_state`, `other_state`, `total` |
| he_rate, high_tariff_rate | % participating in HE / in high-tariff HE |
| he_students, high_tariff_students, cohort_students | counts |

**Caveats**
- School type is the institution attended **at age 17**, where A levels were taken. `selective_state` therefore means grammar sixth forms, which also recruit at 16. `other_state` includes sixth-form and FE colleges.
- Independent figures include DfE estimates (methodology).
- Gate G1-WP reproduces the published 2020/21 by-19 figures and the 2009/10 by-30 figures exactly.
