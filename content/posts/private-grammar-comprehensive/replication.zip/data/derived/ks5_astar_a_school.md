# ks5_astar_a_school.csv

Top-grade counts per school. Key: `urn` × `time_period` × `qualification`. 2,717 rows: 2,639 GCE A level and 78 IB Higher level component; 2024/25 only. Built by `code/derive/build_ks5.py`.

**Source:** `data/raw/dfe_ks5/2026-10-10/ks5_subject_grades_v1.0.1.csv`, "Schools and colleges - subject entries and grades", API `019c2960-df54-772f-8ad4-a2bc3d3b134f` v1.0.1. Rows used: subject `All subjects`.
- GCE A level: exam cohort `A level`.
- IBO Higher level component: exam cohort `Other academic`.

| column | meaning |
|---|---|
| urn, school_name, time_period | institution; 2024/25 |
| qualification | `GCE A level` or `IBO Higher level component` |
| astar_grade_label, a_grade_label | `A*`/`A` for A level; `7`/`6` for IB HL. IB HL 7 and 6 carry the same UCAS tariff (56/48) as A*/A |
| astar_count, a_count | entries at those grades |
| total_entries | `Total exam entries` (all grades incl. E/U/Fail) |
| suppressed_entries | entries in the `Suppressed` grade row. If > 0 the grade split is withheld, so astar/a counts are blank (187 rows, small cohorts) |
| pct_astar_a | 100 × (astar + a) / total_entries |

**Basis:** students at the end of 16-18 study in 2024/25, all their A level entries. This reproduces the three verified schools exactly (gate G3): St Paul's 354+228/650, Westminster 326+190/591, QE Barnet 296+189/560.

**Caveats**
- Use the `All subjects` row. Summing per-subject rows undercounts, because the grades of subjects with fewer than about 5 entries are `c`.
- Self-reported school figures differ by 1-3 points (different cohort definition).
- IB Diploma totals (points 24-45) are not included.
- Pre-U rows (21) are not included.
