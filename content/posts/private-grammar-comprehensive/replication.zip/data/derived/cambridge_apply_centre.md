# cambridge_apply_centre.csv

University of Cambridge "Applications, Offers and Acceptances by UCAS Apply Centre", 2013-2025 UCAS cycles. There is one row per cycle × apply centre: 44,823 rows covering 2,875-3,859 centres per cycle. Built by `code/derive/cambridge_apply_centre.py`.

**Source:** one PDF per cycle at `data/raw/cambridge_apply_centre/2026-10-10/undergraduate_admissions_by_apply_centre_<cycle>_cycle.pdf`. All are linked from https://www.undergraduate.study.cam.ac.uk/apply/before/application-statistics, and the URLs and sha256 hashes are in `data/manifest/cambridge_apply_centre.csv`. The 2025 file (`/sites/default/files/2026-05/...`) exists, is linked on the index page, and is the apply-centre table (51 pages).

| column | meaning |
|---|---|
| cycle | UCAS cycle |
| centre_number | UCAS apply-centre number (5 digits, kept as text) |
| centre_name | name as printed. Names change between cycles, e.g. "Wycombe Abbey School, High Wycombe" (2024) became "Wycombe Abbey" (2025) |
| name_norm | lower case; `&` becomes `and`; apostrophes dropped; other punctuation becomes a space; whitespace collapsed. Use it for the later GIAS join |
| postcode | as printed. It is blank for most overseas centres and for 9 UK-sector rows that print no postcode (e.g. Fearnhill School 2017). 28 UK-sector rows print a malformed postcode (`OX4 1 BD`, `SL9 8JQB`, `L76HQ`, `HUI7 0GH`, `BT61 7X` ...) |
| sector | as printed: `Maintained`, `Independent` or `Other and Overseas`. "Other and Overseas" also covers UK non-school centres (1,585 such rows carry a UK postcode) |
| applications, offers, acceptances | printed count. It is empty where the PDF prints `<3` |
| *_floor5 | True where a 2024-2025 value is printed as 5. The PDF note says "raw figures less than 5 are reported as 5, with the exception of zeros", so the true count is 1-5 |
| *_lt3 | True where a 2013-2023 value is printed `<3` |
| suppression_rule | `lt3` (2013-2023) or `floor5` (2024-2025) |
| page, source_file | where the row was read |

**Suppression: two regimes. Do not mix them naively.**

| rule | cycles | zeros | what a suppressed cell means |
|---|---|---|---|
| `lt3` | 2013-2023 | never printed: no 0 appears in any of these 11 files | `<3` = 0, 1 or 2 for offers and acceptances. For applications it is 1 or 2, because a listed centre has at least one application; the smallest exact applications value printed is 3 |
| `floor5` | 2024-2025 | printed as 0 | a printed 5 = 1 to 5. An exact 5 cannot be told apart from a floored 1-4 |

- Summing printed values therefore overstates 2024-25 totals: 2025 Maintained acceptances sum to 3,988 printed, against 1,938 in Table 2.1. It understates 2013-23 totals, because `<3` cells are counted as empty.
- Gate G2 checks that the table total lies between the lower and upper bounds. It also reports the implied mean per suppressed cell, which is plausible in every cycle:
  - about 1.3-1.5 applications and 0.4-0.7 acceptances per `<3` cell;
  - about 1.7-2.3 per floored 5.

**Caveats**
- The sector is the centre's sector as printed in that cycle. 17 centres change sector across cycles:
  - 5 go Independent → Maintained (e.g. Polam Hall, Liverpool College, Bradford Girls' Grammar);
  - 1 goes Maintained → Independent (Campbell College, Belfast);
  - 11 are non-school institutions moving into or out of "Other and Overseas".
- There is no grammar or selective flag. Get it from GIAS by name and postcode later.
- The table counts every applicant from the centre, of any fee status. It is wider than the Home block of the school-type table.
- Applicants with no apply centre are absent. This is why "Other and Overseas" applications in the school-type table exceed the centre-file upper bound by 1,300-2,700 a year in 2013-2023.
- Parser method and structural assertions: see `data/notes/cambridge_oxford.md`.
