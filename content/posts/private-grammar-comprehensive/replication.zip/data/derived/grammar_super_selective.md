# grammar_super_selective.csv

One row per grammar in `top30_grammar.csv` (45). Built by `code/derive/build_grammar_intake.py` from
`grammar_intake.csv` in the same run (row ids refer to that build).

Rule (scouting C 4d, **intake side only**; outcome measures are never used): super-selective = places ranked on test
score alone with no catchment or a catchment of at least ~10 km, **and** at least ~5 test-takers per place in the
school's own or consortium data. "~" is applied strictly: radius >= 10 km, ratio >= 5. The latest entry year with a
ratio is used. Criterion 3 of 4d (cohort mean KS2) is not used (no KS2ASS data).

| column | meaning |
|---|---|
| urn, name | school |
| flag | `yes` / `probable` / `no` / `unassessed` |
| criterion_score_ranked | `pass` (score_rank; or score rank inside a radius >= 10 km), `fail` (qualify-then-distance/catchment models; radius < 10 km), `area_not_radius` (score rank inside a postcode / district area, size not a radius), `unknown` (no model found, or faith categories, which the rule does not address); suffix `_secondary` if the model or radius rests on a secondary source |
| criterion_testers_per_place | `pass` / `fail` on the school's own testers per place; `_secondary` if from a secondary source; `_proxy` if test applicants (St Olave's, "around 1600"); `_consortium` if only the consortium ratio exists (matched by `test_used`, by sex where the consortium file gives sex); `unknown` |
| testers_per_place_basis | the value used and its level/year |
| admissions_model | latest model code |
| evidence_row_ids | `grammar_intake.csv` row ids behind the two criteria |
| note | short comment |

**Flag logic**
- `yes`: criterion 1 `pass` and criterion 2 `pass` or `pass_consortium` (4d admits consortium data).
- `no`: criterion 1 `fail`, or criterion 2 `fail` / `fail_consortium` (confirmed data).
- `probable`: criterion 1 in {pass, pass_secondary, area_not_radius} and criterion 2 a pass of any kind, but not both firm.
- `unassessed`: anything else (missing data is never `no`).
- Hand-set overrides (`FLAG_OVERRIDES` in `grammar_intake_curated.py`) apply only where the computed flag is `unassessed`; the
  reason is written into the `note` column. Henrietta Barnett is the only one.

**Result (build of 2026-10-20)**: yes 4 (QE Barnet 18.0 testers/place, no catchment; Tiffin School 10.0, 10 km area;
Chelmsford County High 6.7, 12.5-mile area; Blue Coat 6.0, no catchment); probable 6 (St Olave's: applicants proxy;
Tiffin Girls', Reading, Kendrick: postcode areas; Langley: postcode areas + Slough consortium 6.8; Henrietta Barnett: hand-set,
see below); no 22; unassessed 13.

**Caveats**
- Consortium ratios below 5 decide several `no`s: CSSE boys 4.33-4.58 (2023-2026; KEGS, CRGS, Westcliff Boys),
  Kent 3.0 (Judd, Tonbridge Grammar), Warwickshire 3.5-3.9 (KES Stratford, Stratford Girls'). The CSSE figure is an
  upper bound (partially selective places excluded from the denominator), so the fail is robust to that exclusion;
  a consortium average says nothing about competition for the most selective school in it (e.g. KEGS out-of-area
  cut-off 368-376).
- Colyton `no` rests on 544 scores including in-year candidates for 160 places (3.4, an upper bound).
- Five schools are awaiting FOI answers (testers, offers, lowest scores): flags for Wilson's, Sutton Grammar,
  Wallington County and Wallington Girls are `unassessed`; Nonsuch is `no` on its 5.25 km catchment. HBS answered on
  2026-10-19 (21.98-26.86 testers per place, DfE offers as denominator). Its policy and FAQs are image-only PDFs, so no
  admissions model is recorded and the computed flag is `unassessed`; read by eye, they say looked-after children, pupil
  premium and girls within 3 miles (a 4.8 km priority, below the 10 km line) are offered places first, all from the top 300
  in Round 1, then the rest in rank order. Flag hand-set to `probable`: a judgement call, not a computed result, and not
  `yes` because the share of places the priority groups take is not published. QE
  answered on 2026-10-12 and pointed to its own admissions guide for testers, so QE moved from `probable` to `yes`.
