# oxford_context.csv

The "CONTEXT" box beside Table 4.1 of each Oxford Annual Admissions Statistical Report (editions 2018 and 2020-2026). It gives the state vs independent/other split of the national AAA+ and A\*A\*A+ A-level pools and of Oxford's own UK intake. The file has 24 rows: 8 reports × 3 measures. It is built by `code/derive/oxford_school_type.py`. Source files are listed in [oxford_school_type.md](oxford_school_type.md).

| column | meaning |
|---|---|
| report_year | edition of the report |
| measure | `aaa_plus_pool` = students achieving AAA or better at A-level; `astar_astar_a_plus_pool` = A\*A\*A or better; `oxford_uk_admitted` = Oxford's UK intake for that cycle |
| reference | population as printed, e.g. "all UK universities, 2025 main admissions scheme acceptances" |
| reference_year | year of that population (intake year or UCAS cycle) |
| basis | data source of the national pool (see below) |
| state_pct, independent_other_pct | printed percentages. Independent/other for the national pools; independent for Oxford |
| source_page, source_file | where the row was read |

**2026 report (task target):**

| measure | state % | independent/other % |
|---|---|---|
| AAA+ | 74.8 | 25.2 |
| A\*A\*A+ | 71.3 | 28.7 |
| Oxford, 2025 UK intake | 66.5 | 33.5 |

The national pools are all UK universities, 2025 main-scheme acceptances.

**Caveats: the basis changed in 2026. Do not splice the series.**

| reports | national pool | basis | qualifications included |
|---|---|---|---|
| 2018-2025 | first-year, first-degree, UK-domiciled undergraduates (HESA Student Record); unknown school type excluded | intake lags the report by 2-4 years (the 2024 and 2025 reports both use the 2021 intake) | the AAA+ pool includes equivalent Scottish qualifications |
| 2026 | UCAS: UK-domiciled main-scheme acceptances to UK universities, 2025 cycle | the report says HESA data could not be sourced in time, so "all data, including historical data, have been sourced from UCAS" | A-level only |

"Independent/other" in the national pools also includes the "other" school type. The Oxford intake row is state vs independent only.
