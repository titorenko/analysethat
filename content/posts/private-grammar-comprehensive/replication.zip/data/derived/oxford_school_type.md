# oxford_school_type.csv

University of Oxford: UK-domiciled applications, offers and admitted students, state vs independent, 2013-2025 UCAS cycles. Every report vintage is kept: 8 reports × 5 cycles × 2 school types = 80 rows. Use `latest_vintage == True` for one series (26 rows, 2013-2025). Built by `code/derive/oxford_school_type.py`.

**Source:** Table 4.1, "UK applications to Oxford, offers made and students admitted by school type", in the Annual Admissions Statistical Report:

| report_year | cycles | page | file (data/raw/oxford/2026-10-10/) | origin |
|---|---|---|---|---|
| 2026 | 2021-2025 | 16 | oxford_ug_admissions_report_2026.pdf | assets-oxweb.admin.ox.ac.uk (current report) |
| 2025 | 2020-2024 | 18 | oxford_admissions_report_2025.pdf | Wayback capture of ox.ac.uk/sites/files/oxford/... |
| 2024 | 2019-2023 | 18 | oxford_admissions_report_2024.pdf | Wayback |
| 2023 | 2018-2022 | 16 | oxford_admissions_report_2023.pdf | Wayback (file name `...2023b.pdf`) |
| 2022 | 2017-2021 | 16 | oxford_admissions_report_2022.pdf | Wayback |
| 2021 | 2016-2020 | 16 | oxford_admissions_report_2021.pdf | Wayback |
| 2020 | 2015-2019 | 16 | oxford_admissions_report_2020.pdf | Wayback |
| 2018 | 2013-2017 | 16 | oxford_admissions_report_2018.pdf | Wayback (the 2019 report is not in the archive; not needed) |

| column | meaning |
|---|---|
| report_year | edition of the report |
| cycle | UCAS cycle (e.g. 2025 = applied by 15 Oct 2024, mostly for entry in Oct 2025) |
| school_type | `state` or `independent` |
| applications, offers, admitted | counts as printed |
| state_share_uk_admitted_pct_printed | the table's "state proportion of total UK students admitted" for that cycle. It is repeated on both rows of the cycle and asserted at build time to equal round(state / (state + independent) admitted, 1 dp) |
| source_table, source_page, source_file | where the row was read |
| latest_vintage | True for the row from the newest report covering the cycle |

**Caveats**
- Values are identical across all overlapping vintages: no revisions were found for any cycle.
- UK-domiciled applicants from "other" school types (overseas or unknown schools; 4.5% of applications in 2023-25) are excluded. The state share is therefore state / (state + independent).
- There is no grammar or selective split. Oxford publishes nothing by named school.
- How school type is defined changed in wording:
  - The 2025 report uses "standard UCAS school type categories, as declared by schools and colleges", with State = academy, comprehensive, FE, grammar, sixth-form college and other maintained.
  - The 2026 report uses "a customised approach ... relies on the applicant's UCAS Apply Centre and is partially based on school type data received from UCAS".
  - The overlapping 2021-2024 figures are nonetheless identical in the two reports.
- Cycle 2020 is the centre-assessed-grades year (state admitted 1,937 against 1,557 in 2019).
