# dest_national_by_type.csv

National destination and progression rates by institution group/type (selective / non-selective in highly selective area / other non-selective; independent mainstream for 16-18), long format. Sources: data/raw/dfe_dest/2026-10-10/dest_1618_nat.csv, dest_ks4_nat.csv, progression_nat.csv (2023/24 releases).

Columns, measures, time-period convention and caveats: see [destinations.md](destinations.md). Built by `code/derive/build_destinations.py`.
