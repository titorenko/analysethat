# ons_fsm_age_ks4.csv

Mean annual PAYE earnings by age (18-30), by KS4 attainment quintile and by group.

**Source**
- ONS FSM earnings article (4 Aug 2022), Figure 5 data download.
- Raw file: `data/raw/ons_fsm/2026-10-10/Fig_5_Earnings_age_KS4.xlsx`
- Figure title: "Top performing free school meals students earn similarly to average independent school pupils".
- Built by `code/derive/build_ons_fsm.py`.

| column | meaning |
|---|---|
| group | `independent`, `state_non_fsm` or `state_fsm` |
| age | 18-30 |
| ks4_quintile | 1 = bottom … 5 = top quintile of KS4 points |
| mean_earnings_gbp_apr2019 | Mean annual PAYE earnings, April 2019 prices (stated in the file subtitle) |

The table has 195 rows: 3 groups × 13 ages × 5 quintiles.

**Caveats**
- The file note says "Figures are only for people in employment and out of education."
- The file does not say whether quintiles are national or within-group. They are KS4 points quintiles.
- Independent pupils' KS4 results are affected by IGCSEs not counting in DfE measures (see scouting file A §1.2). Independent quintile 1-2 cells are therefore likely to include high-attaining IGCSE pupils. PLAN.md labels every KS4-conditioned result ADJ-MED.
- At age 18, mean earnings fall as the KS4 quintile rises; the top quintile is lowest. The file says the figures cover only people out of education, so the pattern reflects who is in work at 18. That reading is my inference; the source gives no explanation.
