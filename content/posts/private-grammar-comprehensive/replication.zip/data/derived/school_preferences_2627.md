# school_preferences_2627.csv

Year 7 (secondary) preferences and offers for every state-funded secondary school in England, September 2026 entry.
Built by `code/derive/build_school_preferences.py`.

**Source**: DfE "Primary and secondary school applications and offers", academic year 2026/27 (EES release
`0bf4f9cf-721d-44e3-8473-266c87e17e00`, published 18 Jun 2026, last updated 29 Jun 2026), supporting file
`supporting-files/AppsandOffers_2026_SchoolLevel29062026.csv` inside the release ZIP
`data/raw/dfe_apps_offers/2026-10-10/apps_offers_2026-27_all_files.zip`. OGL v3.0. The file is a time series
2014/15-2026/27; only `time_period = 202627`, `school_phase = Secondary` is kept (3,248 rows, all `entry_year` 7).

| column | meaning |
|---|---|
| time_period | 202627 |
| laestab | DfE LA + establishment number; **unique key** |
| urn | URN; blank on the 19 rows with `n/a` |
| name, la_code, la_name | school name, old 3-digit LA code, LA name |
| establishment_type, admissions_policy | as published (`Selective` 163, `Non-selective` 3,066); blank where `n/a` |
| offers_total | `total_number_places_offered` (offers made on national offer day) |
| offers_preferred, offers_1st_pref, offers_2nd_pref, offers_3rd_pref | offers by preference rank |
| prefs_any, prefs_1st, prefs_2nd, prefs_3rd | times the school was named as any / 1st / 2nd / 3rd preference |
| prefs_from_other_la, offers_to_other_la | applications from, and offers to, residents of another LA |
| row_type | `school`; `site_or_boarding_row_no_urn` (16 rows: boarding / music places or second sites reported separately, e.g. RGS High Wycombe weekly boarding, Ripon boarding, Holyport boarding); `la_pseudo_row` (3 aggregate rows: Welsh schools, special schools, middle schools; laestab 999xxxx) |
| prefs_per_offer, first_prefs_per_offer | prefs_any / offers_total and prefs_1st / offers_total (crude oversubscription) |

**Caveats**
- Preferences are LA-coordinated applications, not 11+ candidates: for grammars they include applicants who did not
  reach the qualifying score and exclude testers who did not name the school.
- Schools with several rows (main row + boarding/site row) must be summed by URN if a whole-school total is wanted.
