# ashe2025_age_percentiles.csv

ASHE Table 6 (age group), **2025 provisional**, UK, employee jobs. One row per published estimate. Two measures:
- Table 6.7a: annual gross pay
- Table 6.5a: hourly gross pay

Each estimate is merged with its coefficient of variation from the matching "b" file (6.7b, 6.5b).

**Source**
- Raw file: `data/raw/ashe/2026-10-10/ashetable62025provisional.zip`. ASHE Table 6 was released 23 Oct 2025; the dataset page is saved alongside.
- Built by `code/derive/build_ashe.py`. Files are read inside the zip; nothing is extracted.
- Gate: `code/checks/g1_ashe.py` (G1-ASHE).

| column | meaning |
|---|---|
| edition | `2025 provisional` |
| measure | `annual_gross_pay_gbp` (6.7a) or `hourly_gross_pay_gbp` (6.5a) |
| sex | `all`, `male` or `female` |
| work_pattern | `all`, `full_time` or `part_time`. These are the sheets All, Male, Female, Full-Time, Part-Time, Male/Female × Full-/Part-Time. |
| age_band | `all` (the "All employees" row), `16-17`, `18-21`, `22-29`, `30-39`, `40-49`, `50-59` or `60+`. "Not Classified" is dropped. |
| statistic | `jobs_thousand`, `median`, `mean`, `p10` `p20` `p25` `p30` `p40` `p60` `p70` `p75` `p80` `p90`. ASHE Table 6 publishes nothing above P90. The annual % change columns are not kept. |
| value | Estimate. Null where ONS shows a symbol. |
| symbol | ONS symbol when the value is null: `x` = CV > 20%, suppressed |
| cv_pct | Coefficient of variation in %, from the b file |
| cv_symbol | ONS symbol when the CV is not numeric: `.` = unavailable, `x` = suppressed |
| quality | ONS key, derived from cv_pct: `precise` (CV ≤ 5), `reasonably_precise` (5-10), `acceptable` (10-20), `unreliable` (> 20) |

The table has 1,872 rows: 2 measures × 9 sheets × 8 bands × 13 statistics.

**Caveats**
- **Coverage.**
  - Footnote a: "Employees on adult rates who have been in the same job for more than a year".
  - Annual pay therefore excludes job movers and the self-employed.
  - ASHE counts jobs, not people.
  - The pay period includes 30 April 2025.
- **Job counts.** Footnote c says "Figures for Number of Jobs are for indicative purposes only".
- **Age bands are coarse.** For a lifetime profile, interpolate between band midpoints.
- **ASHE 2026 provisional is not yet published** as of 2026-10-10: the dataset page says "Next release: To be announced". Re-run `code/harvest/earnings_costs.py --only ashe` when it appears. The script keeps 2025 provisional, which the gate is pinned to, and adds 2026.
