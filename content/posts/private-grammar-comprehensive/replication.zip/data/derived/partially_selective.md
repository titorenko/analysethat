# partially_selective.csv

One row per state secondary school checked by hand for **partial selection by ability**: Year 7 (or Year 12)
places reserved for applicants ranked or admitted on a test of general or academic ability, which is the
grandfathered partial selection of SSFA 1998 s.100. DfE and GIAS code these schools as non-selective.

- **Builder:** `code/derive/build_partially_selective.py`. It holds the hand-entered evidence table.
- **Gate:** `code/checks/g_partial.py` (G-partial).
- **Sources:** `data/raw/partial_selection/2026-10-10/`. URLs, times and hashes are in
  `data/manifest/partial_selection.csv`.
- **Search log:** `data/notes/partial_selection.md`.
- **Built:** 2026-10-10.

## Columns

| column | meaning |
|---|---|
| urn, name, la_name | Open establishment in `school_master.csv` (GIAS name and LA) |
| classification | `partially_selective` / `banding` / `aptitude_only` / `sixth_form_entry_only` / `none` / `unverified` / `blocked`; rules below |
| ability_places_pct | Share of Year 7 places ranked on the ability test. Where the document states it, it is copied (and appears in the quote). Otherwise it is computed as 100 × n / PAN, and `note` says "pct computed" |
| ability_places_n | Number of ability places, as stated (blank if only a percentage is stated) |
| pan | Year 7 published admission number in the cited document |
| test_name | Test used for the ability places, or for banding |
| entry_year_policy | Academic year of Year 7 entry the document governs: `2026/27` = September 2026 entry |
| source_url, source_file | Document the classification rests on: its URL (from the manifest) and its local copy |
| source_quote | Verbatim text. Segments are separated by ` ... ` and each must occur in the extracted text of `source_file` (whitespace, case, curly quotes and dashes normalised) |
| source_location | Page, section or criterion |
| note | Other selection in the same arrangements, caveats, the reasoning-test flag, and the Year 12 finding |
| second_source_url, second_source_file, second_quote | Optional further document(s), joined by ` \|\| `, checked like the first. Used when the arrangements omit n or PAN (e.g. St Clement Danes, Graveney), for Year 12 rules, or to tie a school to an LA document (Brampton Manor) |

## Classification rules

A school gets **one** class, by precedence:
`partially_selective` > `banding` > `aptitude_only` > `sixth_form_entry_only` > `none`.
Lower-precedence mechanisms in the same arrangements are listed in `note`.

- **`partially_selective`:** some places are ranked or admitted on a test of general ability, or of an
  academic subject.
  - **Reasoning-test rule.** A place counts as ability selection if it is ranked on a reasoning test (verbal,
    non-verbal, spatial) or an academic-subject test (English, maths), **whatever the arrangements call it.**
    - Three schools label such places as "aptitude": Mill Hill County High (technology; GL verbal and
      non-verbal reasoning), The John Warner School (technology; non-verbal reasoning and spatial), and
      Westlands (mathematics).
    - Their notes start with "REASONING-TEST RULE". Filter on that to undo the rule.
  - Places restricted to a priority area or postcode still count (e.g. Queens', the Southend schools).
- **`banding`:** every applicant (or every non-specialist applicant) sits a test, which is used only to admit
  across the full ability range.
- **`aptitude_only`:** the only test is aptitude in music, sport, performing or visual arts, dance or modern
  languages. Musical "ability" auditions count as aptitude. Grandfathered aptitude shares above 10% stay here
  (e.g. Chestnut Grove, 60 of 210).
- **`sixth_form_entry_only`:** Year 7 entry has no test, and the determined **Year 12** arrangements set a
  whole-sixth-form academic threshold of **grade 6 or above** (e.g. six GCSEs at grade 6; GPA 6.5).
  - Standard thresholds (five GCSEs at grade 4 or 5) and per-course requirements do not count. Those schools
    are `none`.
  - Year 12 was assessed only for the screen schools whose Year 7 entry has no test, the only rows where it can
    change the class. One screen school, St Thomas More Greenwich, was not assessed. Elsewhere the note says
    "Year 12 not assessed", so the two classes can differ only for screen schools.
- **`none`:** the Year 7 oversubscription criteria contain no test. The quote gives positive evidence: a "without
  reference to ability" statement, or the faith, catchment or distance criteria.
- **`unverified`:** no document with the school's 2025/26-2027/28 oversubscription criteria could be found.
- **`blocked`:** the document exists but the site refuses scripts. No row has this class; blocked LA sites are
  listed in the notes.

## Entry year

- The target was 2026/27 entry, with 2025/26 as the fallback.
- Where the 2026/27 document was no longer online, the **2027/28** determined arrangements were used. They are
  newer, already determined, and govern the admissions round now open.
  - `entry_year_policy` says so on each row. The note also says why.
- The Howard School (Medway) rests on an undated live admissions page.

## Counts (build of 2026-10-10, 78 rows)

| classification | rows |
|---|---|
| partially_selective | 24 |
| none | 26 |
| aptitude_only | 14 |
| banding | 10 |
| sixth_form_entry_only | 2 |
| unverified | 2 |
| blocked | 0 |

- **Partially selective, 25 schools.**
  - Hertfordshire (8): Owen's, Watford Boys, Watford Girls, Parmiter's, Queens', Rickmansworth, St Clement Danes,
    John Warner.
  - London (4): Graveney, Burntwood, Greenshaw, Mill Hill County High.
  - Southend (3): St Bernard's, St Thomas More, Shoeburyness.
  - Kent (2): Homewood, Westlands.
  - Elsewhere: King John (Essex), Reading Girls', Poole High, Budmouth, Winston Churchill, King's Peterborough,
    Ashlawn.
- **Unverified, 2 schools.**
  - The Spires College (Torbay) is likely partially selective. Torbay's 2026 allocation summary lists 60
    selective places of 210, but no current determined arrangements were found.
  - Shirley High (Croydon): no criteria document found.
- **Ability shares** run from 8.0% (King's Peterborough, 12 of 150) to 35% (Queens', 94 of 270).
- **Entry year:** 68 rows use 2026/27, 8 use 2027/28, and 1 uses an undated current page. The Shirley High row
  has no year.

## Caveats

- **Coverage.** This is not a census of England's ~3,000 non-selective secondaries. The checks covered:
  - every Hertfordshire secondary policy on the county's 2026/27 index (82 files);
  - Wandsworth, Southend and Kent (71 non-grammar KCC 2026/27 policies via Wayback);
  - the 29 screen schools;
  - every ability-selecting school on the NFER 2017 list (Appendix A) that is still open. Its music/sport-only
    entries were skipped, and Edenham High was not found;
  - leads from LA booklets and 11+ sites.

  A partially selective school outside these nets would be missed. Search engines were used only for
  discovery, and the session's search budget ran out partway through.
- **Several documents.** Some rows rest on two documents:
  - **St Clement Danes:** the LA copy gives 10%; the school FAQ gives PAN 240 and the 24 places
    allocated in March 2026.
  - **Graveney:** the PAN is on the school's admissions page.
  - **The Spires College** is `unverified`. Its row quotes Torbay Council's 2026 allocation summary (60
    "SELECTIVE PLACES") and the 2022-entry policy (up to 60 selective places). No 2025/26-2027/28 determined
    arrangements were found.
- **Ashcroft Technology Academy.** The content of its design-technology aptitude test was not checked. If it
  is a reasoning test, the reasoning-test rule would move the school to `partially_selective`.
- **Homewood.** It says "ability or aptitude" and does not name its assessment. It is kept
  `partially_selective` because the assessment is a single score-ranked test of all applicants, and NFER lists
  it as academic ability.
- **NFER 2017 schools that have dropped selection** (now `none`): Ernest Bevin, King Edward VI Academy
  (Spilsby), The Howard School, The Archbishop's School, St Hilda's, St Margaret's, Riddlesdown, and
  St Saviour's and St Olave's.
- **Smaller shares than in 2017:** St Bernard's has 30 of 175 places (NFER: 43%); Greenshaw 60 of 314 (NFER: 25%).
