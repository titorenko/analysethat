# IFS (June 2026) lifetime returns to degrees: assumptions needed to reproduce the net return

Source: Britton, Ogden, Ornadel & Waltmann, *New estimates of the impact of undergraduate degrees on lifetime
earnings*, IFS report for DfE, June 2026. File: `data/raw/ifs/2026-10-10/ifs_2026_degrees_lifetime_earnings.pdf`
(manifest `data/manifest/ifs.csv`). 132 PDF pages.

`PDF p.` = 1-based PDF page index; the printed page number is one lower. Every `>` quote below is checked verbatim
(whitespace-normalised) against the pdfplumber text of that page by `code/checks/g_quotes.py`.

This file feeds gate G5 (engine reproduces the IFS net return within 10%).

## 1. Population, prices, horizon

- Cohort: the 2002 GCSE cohort in England. The HE group is defined as follows:
  > "‘HE’ includes those who started a full-time undergraduate degree before the age of 21." — PDF p. 36
- Earnings are actual LEO earnings up to age 37 and simulated thereafter. Retirement is handled by holding parameters fixed:
  > "we fix model parameters for eight years at age 51, with parameters from ages 60 to 67 corresponding to ages 52 to 59 in the data." — PDF p. 22
- Price base: 2025/26 CPI prices.
  > "All figures are shown in 2025/26 CPI prices and are discounted using Green Book discounting." — PDF p. 43
- Horizon: ages 17 to 67.
  > "The formula for converting an individual’s earnings stream between the ages of 17 and 67" — PDF p. 93

## 2. Discounting (discount age 18)

> "we mostly use the Green Book’s recommended real discount rate of 3.5% for the first 30 years of earnings beyond age 18 and a real discount rate of 3.0% thereafter, to express lifetime returns in terms of earnings at age 18." — PDF p. 26

> "This means we do not discount earnings at age 17 or 18, we discount earnings by 3.5% for the next 30 years, and then by 3.0% thereafter." — PDF p. 93

The formula on PDF p. 93 (Appendix B) is:

    Y = y_17 + sum_{a=18..48} y_a / 1.035^(a-18) + sum_{a=49..67} y_a / (1.035^30 * 1.03^(a-48))

Check: 1.035^30 × 1.03^19 = 2.8068 × 1.7535 = 4.92. This matches the report's own statement:
> "This implies that income earned at age 18 is 4.92 times as valuable as income earned at age 67" — PDF p. 94

The report also gives results with 0% real discounting (§7).

## 3. Earnings growth

- Long-run growth after age 37:
  > "For our main estimates, we assume CPI-real earnings growth of 1.83% per year after age 37, in line with the OBR’s most recent published figures as of April 2026." — PDF p. 55
- IFS applies the rate to every age after 37. The OBR series it cites reaches 1.83% only from calendar 2036, and the report's main text rounds it to 1.8%:
  > "They project real growth in average weekly earnings of 1.83% per year from 2036 onwards." — PDF p. 22
  > "which currently project real growth of 1.8% each year in the long run." — PDF p. 22
- The same footnote (PDF p. 22) says the OBR's March 2026 long-run determinants have since fallen to 1.75% a year. IFS judged that change immaterial.
- Sensitivity case: 1.2% a year.
  > "an even less generous earnings growth assumption of 1.2% per year – the same as was used in Britton et al. (2020)." — PDF p. 55
- Cohort uplift. The cohort's earnings are raised to today's economy-wide level:
  > "This adds around 5.4% to all graduate and non-graduate earnings at all ages." — PDF p. 25
  - The main text (PDF p. 25) describes the uplift as covering 2004/05 to 2025/26. The figure note says 2004/05 to 2023/24 plus 1.8% a year after 37. Both are recorded here; the 5.4% is what was applied.
  > "Earnings are uprated to reflect economy-wide real earnings growth between 2004/05 and 2023/24, and by 1.8% per year for every age after 37." — PDF p. 32

## 4. Tax and National Insurance (the 2025/26 system, not 2026/27)

> "We model these systems as if the cohort we study were 18 years old in the 2025/26 academic year" — PDF p. 25

> "We then apply the income tax, employee National Insurance and employer National Insurance rates and thresholds that applied in the 2025/26 tax year and project thresholds forwards in line with current government policy." — PDF p. 25

> "we model planned cash-terms freezes in personal income tax thresholds until April 2031, after which point we assume these thresholds will rise each year in line with forecast CPI inflation." — PDF p. 25

> "we do not differentiate between employment and self-employment earnings even though these are taxed differently." — PDF p. 25

Table B.3 (PDF p. 97), main-estimate column, 2025/26:
> "Personal allowance (PA) £12,570 £12,500 £16,097" — PDF p. 97
> "Higher-rate threshold £50,270 £50,000 £64,386" — PDF p. 97
> "Additional-rate threshold £125,140 £150,000 £193,159" — PDF p. 97
> "PA withdrawn between: £100,000 and £100,000 and £128,773 and" — PDF p. 97
> "Primary threshold (PT) £12,570 £8,632 £11,116" — PDF p. 97
> "Marginal rate between PT 8% 12% 12%" — PDF p. 97
> "Upper earnings limit (UEL) £50,270 £50,024 £64,417" — PDF p. 97
> "Secondary threshold (ST) £5,000 £8,632 £11,116" — PDF p. 97
> "Marginal rate above ST 15% 13.8% 13.8%" — PDF p. 97

- In the first column the PA withdrawal runs from £100,000 to £125,140. Rates are 20/40/45% income tax and 2% employee NI above the UEL.
- These 2025/26 values equal the 2026/27 values in `tax_2026_27.csv`.
- Child benefit withdrawal is not modelled (note to Table B.3).
- Employer NI enters only the exchequer and total returns, not the individual return.

## 5. Student loans (Plan 5) and fees

> "graduates pay back 9% of earnings above £25,000. This threshold is set to be frozen until April 2027, after which we assume it increases each year with forecast RPI inflation, in line with current government policy." — PDF p. 96

Table B.2 states the freeze period differently: "Frozen from 2025/26 to 2027/28, then increased with RPI". It also gives the 2030/31 threshold as £25,168 in 2025/26 prices.
> "Indexation Frozen from 2025/26 Frozen from 2026/27 Increased with" — PDF p. 96

> "We model the application of interest to loan balances at RPI, and assume repayments stop at the end of the write-off period, 40 years after graduation. We assume no borrowers make voluntary repayments." — PDF p. 96

- Write-off: IFS counts 40 years **after graduation**. The scouting note (file E §4.5) said "40 years after repayment due".
- Borrowing: students take the maximum tuition fee and maintenance loans in every year of study.
- Fee cap:
  > "This is £9,535 in 2025/26, £9,790 in 2026/27 and £10,050 in 2027/28, and is thereafter assumed to increase each year in line with forecast RPI (Retail Prices Index) inflation" — PDF p. 94
- Average loan outlay:
  > "we estimate average loan outlay of £53,500 with Green Book (GB) discounting" — PDF p. 95
- Average repayments:
  > "Applying Green Book discounting, we estimate average lifetime student loan repayments of £24,000 (£21,700 among women and £26,700 among men)." — PDF p. 39

## 6. Definition of the net individual return

> "The net individual financial return to HE is the sum of the increase (or decrease) in earnings associated with attending university at each age, minus the increase (or decrease) in taxes paid at each age, plus the value of maintenance loans received and minus the value of any student loan repayments made." — PDF p. 37

- "Taxes" here means income tax plus employee NI.
- The counterfactual is a regression-based non-HE earnings path per graduate, together with a counterfactual employment draw (Section 3.2, PDF pp. 22-25).

## 7. Headline results to reproduce (GB discounting unless stated; £ thousand, 2025/26 CPI prices)

> "we estimate that the overall average discounted present value of enrolling in an undergraduate degree is around £90,000 for women and £109,000 for men." — PDF p. 37
> "Median discounted net lifetime individual returns are £67,000 for women and £60,000 for men (see Table 5.2)." — PDF p. 37

Table 5.2 (PDF p. 43). Columns are net individual (women, men, overall), then net exchequer (women, men, overall):
> "Mean return (£k) 90 109 99 48 107 75" — PDF p. 43
> "Median return (£k) 67 60 63 16 39 24" — PDF p. 43

The share with a positive return is 81% / 69% / 76% for individuals and 58% / 61% / 59% for the exchequer.

Table 6.1 (PDF p. 53). Columns are mean (women, men), median (women, men), share positive (women, men):
> "Main estimates 90 109 67 60 81 69" — PDF p. 53
> "Without discounting 256 371 177 199 85 75" — PDF p. 53
> "Lower long-run real earnings growth 86 100 64 55 81 68" — PDF p. 53

## 8. Points to note for G5

- The mean net return is £99k overall: £90k for women and £109k for men. The "about £100,000" in PLAN.md is the overall mean.
- The medians, £60k for men and £67k for women, come from the distribution of individual returns. They are not the return at the median earner.
- G5 must reproduce three things:
  1. the discount schedule (ages 17-67, discounted to 18);
  2. the 2025/26 tax system, frozen to April 2031 then CPI-uprated;
  3. Plan 5 terms: threshold frozen to April 2027 or 2027/28 then RPI, RPI interest, 40-year write-off from graduation.
- Real growth is 1.83% a year after 37 in CPI terms. The OBR FRS 2026 earnings line in `obr_longrun.csv` is nominal; deflated by the GDP deflator it gives about 1.5%, which is not the same basis.
