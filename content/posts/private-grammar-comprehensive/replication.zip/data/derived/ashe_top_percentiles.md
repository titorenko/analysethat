# ashe_top_percentiles.csv

ONS ad hoc 3105, *Gross annual earnings for the 90 to 99 percentiles of employee jobs by sector in the UK and regions, 2024 and 2025*. Released 4 Nov 2025.

- Tables: J76.7a (estimates), merged with J76.7b (CVs).
- Editions: **2024 revised** and **2025 provisional**, per the release page.

**Source**
- Raw files: `data/raw/ons_adhoc3105/2026-10-10/asheadhocj762024.zip` and `asheadhocj762025.zip`. The release page is saved alongside.
- Built by `code/derive/build_ashe.py`.

| column | meaning |
|---|---|
| year, edition | 2024 (revised) or 2025 (provisional) |
| measure | `annual_gross_pay_gbp` |
| sex, work_pattern | As in `ashe2025_age_percentiles` (9 sheets) |
| geography | United Kingdom; England; Wales / Cymru; Scotland; Northern Ireland; London; England excluding London; the 9 English regions |
| sector | `all` (the geography row), `public`, `private`, `non_profit` (non-profit body or mutual association). Sector rows inherit the geography above them. |
| statistic | `jobs_thousand`, `median`, `mean`, `p90` … `p99` |
| value | Estimate. All cells are numeric in these files. |
| symbol | Always empty here |
| cv_pct | Coefficient of variation in % |
| cv_symbol | `.` = CV unavailable |
| quality | Derived from cv_pct as in the ASHE key |

The table has 14,040 rows: 2 years × 9 sheets × 15 geographies × 4 sectors × 13 statistics.

**Caveats**
- **Unreliable estimates are published.** The release says it "includes figures, at the request of the customer, which would usually be suppressed on quality grounds as the CVs are greater than 20%". Filter on `quality` / `cv_pct` before use.
- **CVs are often unavailable at the top.** `cv_symbol` = `.` affects 1,020 of 1,080 P99 cells. These are mostly sector × region cells, so treat them as unvalidated.
- **No age breakdown.** To get P95 and P99 by age, scale each age band's P90 (Table 6.7a) by the P95/P90 and P99/P90 ratios from here. That method is in PLAN.md §4.5.
- **Internal consistency check (in G1-ASHE).** The 2025 UK male full-time median (41,832) and P90 (84,107) equal Table 6.7a "All employees" male full-time.
