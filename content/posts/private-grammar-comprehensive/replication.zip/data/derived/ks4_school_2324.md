# ks4_school_2324.csv

KS4 (GCSE) school-level results for **2023/24**, the last year with Progress 8 and KS2 prior-attainment bands. Both are `z` for every school in 2024/25. One row per URN; 5,709 schools. Built by `code/derive/build_ks4.py`.

**Source:** `data/raw/dfe_ks4/2026-10-10/ks4_performance_v1.0.3.csv`, "Performance tables schools data", API `19e39901-a96c-be76-b9c2-6af54ae076d2` v1.0.3, 2022/23-2024/25. Rows used, by `breakdown_topic`:
- `Total`, for the totals;
- `Prior attainment`, for the bands;
- `Sex`, for the counts by sex.

| column | meaning |
|---|---|
| urn, school_name, establishment_type_group | DfE |
| time_period | 2023/24 |
| pupils | pupils at the end of KS4 |
| attainment8 | average Attainment 8 |
| progress8, progress8_flag, progress8_lower_ci, progress8_upper_ci | Progress 8 with 95% CI; flag `z` = not published (all independents) |
| progress8_pupils | pupils in the P8 measure |
| pa_high/mid/low_count, _pct | pupils by KS2 prior-attainment band (DfE High / Mid / Low) and % of all pupils |
| pa_none_count, pa_none_pct | pupils with no KS2 result = pupils − (high + mid + low) |
| pa_high_pct_of_known | high / (high + mid + low) × 100 |
| boys_count, girls_count | pupils by sex (blank = `z`, none of that sex) |

**Caveats**
- Independent schools' A8 is an artefact: IGCSEs and unapproved qualifications do not count. Eton's A8 is 23.0. Their P8 and prior-attainment fields are blank.
- %high saturates near 100% at super-selective grammars, so it cannot rank them against each other.
