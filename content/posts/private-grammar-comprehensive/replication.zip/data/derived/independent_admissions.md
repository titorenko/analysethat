# independent_admissions.csv

Long-format table of admission facts for the 30 private schools in `top30_independent.csv`, as the schools publish
them: admissions pages and policies, news pages, and trustees' reports in charity accounts (Charity Commission
register). Private schools are not covered by FOI, so there is no other route. One row per published value. Built by
`code/derive/build_independent_admissions.py` from `code/derive/independent_admissions_curated.py` and the files
fetched by `code/harvest/independent_admissions.py` (`data/raw/independent_admissions/2026-11-07/`). Used for the
admission notes behind school names in Tables 4 and 5 of the schools post (`build_article.py`, `private_notes`).

| column | meaning |
|---|---|
| row_id | `ia0001`... regenerated on every build. |
| urn, name | School URN and name (from `top30_independent.csv`). |
| entry_year | Year of September entry the figure is for, where the source says (Oxbridge rows: year of university entry). **Blank = undated**: the page states it without a year; read 2026-11-07. |
| measure | `places_total` (all places at that entry point), `places_external` (places for pupils from outside the school), `from_own_junior` (pupils moving up from the school's own junior school), `applicants`, `applicants_per_place`, `entry_steps` (text: tests and interviews), `oxbridge_places`, `oxbridge_offers`. |
| category | Entry point: `10+`, `11+`, `13+`, `16+`, or `all` (not stated, or the whole school). |
| value | As printed: a number, or a range or words where the source gives one (`75 to 85`, `one-third`, `5:1 to 11:1`, `several`). |
| unit | `places`, `pupils`, `candidates`, `applications`, `percent`, `share`, `ratio`, `text`, ... |
| source_url, source_file | Page fetched and its local copy. |
| source_location | Where in the source, plus the verbatim snippet (`text: "..."`). |
| status | `confirmed` on every row. |
| note | Caveats: undated, 'up to', 'about', what is and isn't counted. |

**Verification.** The build fails unless every snippet occurs in the extracted text of its file (normalised as in
`build_grammar_intake.py`) and every plain-number value occurs inside its snippet.

**Caveats**
- Most values are undated statements on admissions pages ("we admit about 60"); they describe the school now, not a
  given year. St Paul's Girls' has four policy versions (11+ places 100, 110, 115, 120 from the 2020, 2022, 2024 and
  2025 policies); the article note shows the latest.
- City of London's 2012-2013 applicant counts come from governors' minutes; the article notes skip values before 2020.
- Oxbridge counts are the school's own claims, with differing definitions (places taken up, offers, results-day
  places including post-A-level applicants); the `note` says which.
- Lady Eleanor Holles' accounts say only that applications have "fallen from post-Covid record highs"; kept as text.

**Re-running** `.venv/Scripts/python -I code/harvest/independent_admissions.py`, then
`.venv/Scripts/python -I code/derive/build_independent_admissions.py`.
