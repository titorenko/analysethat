# independent_fees.csv

Fees for the 45 independent schools in `top30_independent.csv`: 2026/27 from the live school pages (retrieved 2026-10-10) and 2025/26 from Wayback Machine captures taken between Sept 2025 and July 2026.

Also fees for the 20 schools in `bottom20_private.csv`, 2026/27 only, from the live school pages or the fee sheets linked from them (retrieved 2026-10-10). In the builder they are `BOTTOM20_ROWS`. The CSV has no column marking which list a school is in, so join on `urn` to tell them apart.

**Source.** Pages are under `data/raw/fees/2026-10-10/` (manifest `data/manifest/fees.csv`).
- Live pages are named `<urn>_2026[_part].<ext>`; Wayback captures are named `<urn>_2025[_part].<ext>`. A fee sheet linked from a live page is `<urn>_2026_pdf.pdf`.
- Wayback discovery listings are in `data/raw/fees_cdx/`.
- Harvested by `code/harvest/fees.py` and built by `code/derive/build_fees.py`.
- Gate: `code/checks/g_fees.py` (G-fees).

**How the values were made.** Every amount was transcribed by hand from the saved page. The builder then re-reads the page text and fails unless each printed figure sits within about 600 characters after (or 150 before) the quoted stage label. This blocks invented numbers. It does not prove the column, so the stage assignment was also read by eye. G-fees writes the surrounding text to `logs/gates.md` for 10 random top-30 schools and for every bottom-20 school with confirmed rows.

One row per school × fee year × stage × years × day/boarding. The first 13 columns are the ones requested; the rest are additions.

| column | meaning |
|---|---|
| urn, name | DfE URN and name, from `top30_independent.csv` or `bottom20_private.csv` |
| fee_year | `2026/27` or `2025/26`. Taken from the year printed on the page, not from the capture date. |
| stage | `senior_lower`: Years 7-8 where priced separately. This includes Years 7-8 at a linked prep school for 11+ entrants: St Paul's Prep/Juniors and Westminster Under School. For the bottom 20 it also covers Years 7-8 in the school's own prep: Wycliffe and King's Rochester. `senior`: Years 7/9-11. `sixth_form`: Years 12-13 (continuing pupils, or everyone where there is one price). `sixth_form_new_entrant`: Years 12-13 for pupils joining at 16+, where they are priced separately (SPGS, St Paul's, Westminster's "16+ day pupils", Sevenoaks). |
| day_or_boarding | `day`, `boarding` (full) or `weekly_boarding`. St Mary's Ascot's "day boarding" is recorded as `day`. |
| amount | Fee as printed. Where a school prints parts, the amount is their sum and the parts are listed in `note`. These are: G&L's, LVS Ascot's and Claires Court's three different termly fees; MCS's fee + sixth-form levy; Withington 2025/26, Merchant Taylors' and Barnard Castle's fee + VAT; Kirkham's term fee + boarding supplement. |
| period | `term` or `year`. Eton's "Half" is a term (three a year). |
| incl_vat | `True`: the page says the amount includes VAT. `False`: the page says it excludes VAT (no row needs this; where only an ex-VAT termly figure exists the incl.-VAT yearly figure is used). Blank: the page does not say. |
| annual_incl_vat | amount × 3 for termly fees (× 1 for yearly fees), × 1.2 only if incl_vat is False. Where incl_vat is blank it assumes the printed fee is VAT-inclusive (see `vat_basis`). This is the list price; extras and compulsory lunch charges are not added. |
| lunch_included | `True` or `False` as the page states, or blank if not stated. Where lunch is a separate (often compulsory) charge, its amount is in `note`. |
| source_url | The live URL, or the `web.archive.org/web/<timestamp>id_/...` capture URL |
| snapshot_date | Wayback capture date, or retrieval date for live pages |
| status | `confirmed`; `no_snapshot` (no saved page carries that year's fees); `not_published` (the school's page does not state 2026/27 fees); `blocked` (the site refused the script). Reasons are in `note`. Only bottom-20 schools are `not_published` or `blocked`. |
| years | Year groups the row covers, e.g. `Y7-11`, `Y9-11`, `Y7-8`, `Y7` (Brighton, St Joseph's, Wycliffe and Sidcot price some year groups separately; `fees_summary` averages a school's senior rows). David Game's GCSE row is `1-yr GCSE`, a one-year course. |
| stage_label | The label quoted from the page that the amount sits next to |
| amount_excl_vat | Ex-VAT fee where the page also prints it |
| vat_basis | How incl_vat was determined |
| entry_ages | Senior entry points evidenced on the saved fee or admissions pages, e.g. `11+;13+;16+`. Blank for Brighton and Nottingham High, whose saved pages do not show them. Not collected for the bottom 20 (blank). |
| local_path | Saved file the row was read from |
| note | Caveats |

**Coverage.**

| measure | Top 30, 2026/27 | Top 30, 2025/26 | Bottom 20, 2026/27 |
|---|---|---|---|
| Schools with confirmed rows | 45 | 37 | 17 of 20 |
| Senior day fee | 44 (Eton has no day pupils) | 36 | 17 |
| Sixth-form day fee | 44 (Westminster: 16+ entrant fee only) | 36 (likewise) | 17 |
| Boarding fee | 11 (all 11 boarding schools) | 11 | 13 of the 14 confirmed boarding schools (David Game: see caveats) |

`no_snapshot` for 2025/26: CLS, CLSG, Guildford High, Latymer Upper, KCS, St Albans High, Francis Holland and Emanuel.

Bottom-20 gaps (2026/27):
- **Camp Hill Education:** `not_published`. The site has no fees page. Its homepage says most places are referred by the local authority.
- **Farringtons:** `blocked`. HTTP 403 to the script.
- **Clayesmore:** `not_published`. Its senior and sixth-form fee URLs both serve one page, which prints a fee table with no academic year and links no dated schedule (Years 9-13 day £11,890.80/term).

The bottom 20 have no 2025/26 rows.

**St Lawrence College has been replaced by Sidcot.** St Lawrence was dropped from `bottom20_private.csv` because GIAS records it as closed on 31 Aug 2026 (see `bottom_closed_excluded.csv`). Sidcot School took its place. Its saved page still showed 2025/26 fees only. Like Concord, its `MISSING` entry stays in the builder but is left out of the output.

**Caveats.**
- **VAT not stated on the page.** St Paul's 2025/26, Winchester 2025/26 and St Swithun's 2026/27. Each is consistent with the other year's stated incl.-VAT fee (a +3.5% to +6% change), so annual_incl_vat treats them as inclusive.
- **Brighton College.** Its incl.-VAT fees include a "transitional price support" (in 2025/26, a fifth of the 20% VAT). They are not ex-VAT × 1.2; both figures are given.
- **Emanuel 2026/27.** The incl.-VAT termly fee (£10,460.40) is in an image on the page (saved as `101071_2026_table.png`). Only the ex-VAT £8,717 is text-checked; the builder asserts 8,717 × 1.2 = 10,460.40.
- **Highgate.** The 2025/26 fee included the obligatory lunch (£355). The 2026/27 page lists lunch (£369) as a separate obligatory charge. Compare like with like.
- **Single price for Years 7-13.** Many schools charge one price for Years 7-13; those rows are repeated for senior and sixth_form. Count schools, not rows.
- **Westminster prices by entry point only.** Its rows are "13+ day pupils", "16+ day pupils", and "13+ and 16+ boarding pupils". The sixth-form fee for pupils who entered at 13+ is not stated, so there is no continuing `sixth_form` day row. Its sixth-form day figure is the 16+ entrant fee (`sixth_form_new_entrant`).
- **Concord College.** It was in the list until it changed at 16:46 on 2026-10-10 (replaced by Emanuel). Its pages are still saved and transcribed in the builder, but it is left out of the output.

**Bottom-20 caveats.**
- **Colleges priced by course.**
  - *Ealing Independent College.* Termly fees by number of subjects. The rows are GCSE "up to 8 subjects" (Years 9-11) and A level "2-3 subjects".
  - *David Game College.* Yearly fees per subject. The rows are a one-year GCSE course with five subjects and a two-year A level with three subjects (£29,760 each). Its boarding fee (from 14) covers accommodation and meals only and is charged on top of tuition (£28,200/yr for a standard single room). Since there is no all-in figure, it has no boarding row.
- **No year printed on the fee page.** Clayesmore's undated page was recorded as `not_published` (see the gaps above). For the two schools below, a dated fee sheet settled the year.
  - *Barnard Castle.* Its page prints no year. The image-only fee sheet it links (`114336_2026_pdf.pdf`, read by eye) gives the same figures for the academic year from 1 September 2026.
  - *Oswestry.* The rows come from the dated fee sheet. The undated web page agrees on the day and full-boarding figures used here; only its weekly-boarding and Years 5-6 boarding figures differ.
- **Fee rises in January 2027.** LVS Ascot and Claires Court charge a lower Autumn 2026 fee, then a higher fee from January 2027. The yearly amount is the sum of the three terms.
- **VAT not stated.** Bosworth's domestic fee sheet does not say whether its fees include VAT; annual_incl_vat treats them as inclusive. Its day fee is the "tuition" column of a mainly boarding fee sheet.
- **Compulsory lunch billed on top** (`lunch_included` False, amount in `note`): Barnard Castle, Ellesmere, the Oratory and Abbey Gate.
- **Boarding coverage.** Only full boarding for Years 9-13 (or 7-13 where one price) was transcribed. Weekly and Years 7-8 boarding fees are in `note` where useful.
