# Destination tables: dest_1618_school.csv, dest_ks4_school.csv, progression_school.csv, dest_national_by_type.csv

Built by `code/derive/build_destinations.py` from the DfE destination-measure catalogue files (2023/24 releases, published 2026-04-23, updated 2026-07-24), in `data/raw/dfe_dest/2026-10-10/`:

| table | source file (EES catalogue id) | grain | coverage |
|---|---|---|---|
| dest_1618_school (26,731 rows) | `dest_1618_inst.csv` (`bbee3278-589b-436f-a031-adeb0368e49f`) | urn × time_period × cohort_level_group (Total, Level 3, Level 2, All other qualifications) | 2020/21-2022/23 leavers; state schools and colleges **and independent mainstream schools** (~575 per year) |
| dest_ks4_school (13,462) | `dest_ks4_inst.csv` (`7be58881-d49f-4e3b-b2b6-0877a1a0fe6e`) | urn × time_period | 2020/21-2022/23 KS4 leavers; state-funded only, incl. special and AP |
| progression_school (2,200) | `progression_inst.csv` (`c3518f1e-7e51-48d9-ac47-1f1ab8767987`) | urn × time_period | 2021/22 16-18 leavers (2-year window); state-funded only |
| dest_national_by_type (8,191) | `dest_1618_nat.csv` (`28cc87b6-…`), `dest_ks4_nat.csv` (`771e2b11-…`), `progression_nat.csv` (`87c46b03-…`) | dataset × time_period × institution_group × institution_type × cohort_level_group × measure | national; institution_type includes `Selective school`, `Non-selective school in highly selective area`, `Other non-selective school`; institution_group includes `Independent mainstream schools` (16-18) |

`time_period` = the academic year in which the cohort finished KS4 or 16-18 study. The destination is measured in the following year; progression is measured within 2 years. Only `breakdown_topic = Total` rows are kept (no sex or disadvantage splits).

**Columns.** Each source observation appears twice in the raw files, as counts and as percentages. Here they are paired:
- `<measure>_n`: count.
- `<measure>_pct`: percent of cohort.
- `<measure>_flag`: EES symbol (`c` < 6 suppressed, `low`), present only where any value is suppressed.
- `cohort` (`all_cohort` etc. for progression): number of students.
- `admission_policy`: as in the destinations file (`Selective`, `Non selective`, `Not collected` for independents).

| measure | meaning |
|---|---|
| overall | sustained education, apprenticeship or employment |
| education | sustained education |
| he | UK higher education institution (any HE; **no top-third / Russell Group / Oxbridge** in these files) |
| fe, ssf, sfc, other_edu | FE college; school sixth form; sixth-form college; other education (KS4) |
| appren | sustained apprenticeship |
| all_work | sustained employment |
| all_notsust, all_unknown | not sustained; activity not captured |
| all_progressed, all_degree, all_top3rd, all_appren, all_htech | progression to level 4+, degree, top-third HEI, apprenticeship, higher technical (progression file) |
| acag_/tlev_/otl3_ cohort and progressed | progression for academic / T level / other level 3 students |

In `dest_national_by_type`, the national `n`, `pct` and `flag` columns hold the same three things in long form, with `measure` naming the measure.

**Caveats**
- Gap years count as "not sustained / unknown", which biases independents down. St Paul's 2022/23: HE 68.3%, unknown 18.1%.
- The 1 GB (16-18) and 538 MB (KS4) "API" files were not downloaded. They hold the same school rows plus geographic levels.
- October 2026 releases ("16 to 19 destination measures") will supersede these. Re-run `code/harvest/dfe_ees.py --day <date>`.
