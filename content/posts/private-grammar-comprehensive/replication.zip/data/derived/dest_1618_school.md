# dest_1618_school.csv

16-18 leavers' destinations by institution (incl. independent mainstream schools), urn x time_period (2020/21-2022/23 leavers) x cohort_level_group; any UK HE (`he_*`), no top-third. Source: data/raw/dfe_dest/2026-10-10/dest_1618_inst.csv (EES catalogue bbee3278-589b-436f-a031-adeb0368e49f, 2023/24 release).

Columns, measures, time-period convention and caveats: see [destinations.md](destinations.md). Built by `code/derive/build_destinations.py`.
