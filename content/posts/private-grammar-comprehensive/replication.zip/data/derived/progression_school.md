# progression_school.csv

Progression to level 4+ / degree / top-third HEI by state-funded school or college, urn x time_period (2021/22 leavers, 2-year window); independents not covered. Source: data/raw/dfe_dest/2026-10-10/progression_inst.csv (EES catalogue c3518f1e-7e51-48d9-ac47-1f1ab8767987, 2023/24 release).

Columns, measures, time-period convention and caveats: see [destinations.md](destinations.md). Built by `code/derive/build_destinations.py`.
