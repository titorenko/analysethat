# national_ks5_by_type.csv

National 16-18 indicators by institution type, sex and exam cohort, in long format: one row per data set × time_period × establishment_type_group × establishment_type × sex × exam_cohort × indicator. 43,095 rows. Built by `code/derive/build_ks5.py`.

**Sources** (EES API, "A level and other 16 to 18 results" 2024/25)

| dataset | file | API id | years |
|---|---|---|---|
| attainment_inst_sex | `data/raw/dfe_ks5/2026-10-10/ks5_nat_attainment_inst_sex_v1.0.csv` | `019d9132-c369-7165-8288-207ef5e5e616` v1.0 | 2020/21-2024/25 |
| va_inst_sex | `data/raw/dfe_ks5/2026-10-10/ks5_nat_va_inst_sex_v1.0.csv` | `019d9131-e08b-7776-b230-ccacc6d75c5c` v1.0 | 2023/24-2024/25 |
| prior_attainment_inst_sex | `data/raw/dfe_ks5/2026-10-10/ks5_nat_prior_attainment_inst_sex_v1.0.csv` | `019d9137-6b57-75c3-8b08-457f83fc2dea` v1.0 | 2020/21-2024/25 |

| column | meaning |
|---|---|
| dataset | one of the three above |
| time_period | 2020/21 … 2024/25 |
| establishment_type_group, establishment_type | e.g. `Independent schools` / `All independent schools`; `State-funded schools` / `All state-funded schools` |
| sex | All / Female / Male |
| exam_cohort | A level, Academic, Applied general, Tech level, Technical certificate, Level 2, Level 3, End of 16-18 study |
| indicator | source column name, e.g. `aps_per_entry`, `aps_per_entry_grade`, `three_astar_to_a_percent`, `aab_two_facilitating_percent`, `value_added`, `entries_count`, `prior_average`, `students_with_prior_count` |
| value | value as published (string; grade labels and symbols kept) |
| value_num | numeric value (blank for symbols or grade labels) |
| version | EES row version (Final / Revised) |

**Caveats**
- `All independent schools` = `Independent schools` + `Independent special schools`. For example, A level VA entries 2024/25 are 97,826 = 97,593 + 233.
- The files carry 3-4 decimals. The release rounds them: APS to 2 dp, VA to 3 dp.
- **There is no selective / non-selective split in these national tables.** Grammar aggregates must be built from `ks5_school` + `school_master`.
