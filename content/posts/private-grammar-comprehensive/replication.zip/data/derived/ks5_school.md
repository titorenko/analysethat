# ks5_school.csv

16-18 (KS5) school-level results. Key: `urn` × `time_period` × `exam_cohort` (A level, Academic). Disadvantage status = Total. 22,336 rows = 2,792 institutions × 4 years × 2 cohorts. Built by `code/derive/build_ks5.py`.

**Sources** (EES API, "A level and other 16 to 18 results" 2024/25)
- `data/raw/dfe_ks5/2026-10-10/ks5_performance_v1.0.3.csv`: "Schools and colleges - performance", API `019c2960-81e3-70c2-8d65-72c3718ae4fd` v1.0.3, 2021/22-2024/25.
- `data/raw/dfe_ks5/2026-10-10/ks5_subject_va_v1.0.1.csv`: "qualification and subject value added", API `019c2960-abc0-700e-91ed-bb9823c0feed` v1.0.1, 2024/25. Supplies `va_entries`.
- `data/raw/dfe_ks5/2026-10-10/ks5_subject_grades_v1.0.1.csv`: "subject entries and grades", API `019c2960-df54-772f-8ad4-a2bc3d3b134f` v1.0.1, 2024/25. Supplies `alevel_exam_entries`.

| column | meaning |
|---|---|
| urn, school_name | DfE institution |
| time_period | 2021/22 … 2024/25 (year of exams) |
| exam_cohort | `A level`, or `Academic` (A level + other academic incl. IB; use this to keep IB schools) |
| end1618_student_count | students at end of 16-18 study (cohort) |
| aps_per_entry_student_count | students in the APS measure |
| aps_per_entry, aps_per_entry_grade | average point score per entry and its grade label |
| best_three_alevels_student_count, best_three_alevels_aps, best_three_alevels_grade | best 3 A levels (A level cohort, **2024/25 only**; 'z' earlier) |
| aab_student_count, aab_percent | % achieving ≥ AAB with ≥ 2 facilitating subjects (A level cohort, 2024/25 only) |
| value_added, value_added_lower_ci, value_added_upper_ci | 16-18 VA (grades per entry) with 95% CI |
| progress_banding | DfE VA banding |
| *_flag | EES symbol when the value is missing: `c` suppressed, `z` not applicable / not published |
| va_entries, va_entries_flag | A level VA entries: GCE A level, All subjects, A level cohort. **2024/25 A level rows only.** Flag `absent` = no VA row for the school |
| alevel_exam_entries | GCE A level total exam entries (all grades), 2024/25 A level rows only |
| va_coverage | va_entries / alevel_exam_entries (both A level only, so consistent) |
| va_entries_as_nc | VA entries for GCE AS levels not continued to A2 (A level cohort), 2024/25 A level rows only |
| va_entries_weighted | va_entries + 0.5 × va_entries_as_nc. This is DfE's own size-weighted VA entry count: on this basis the school-level file sums to 99.87% of the national all-institution total (gate G4) |

**Caveats**
- **VA does not exist for 2021/22 and 2022/23** (`value_added_flag` = `z`). It exists for 2023/24 and 2024/25.
- The performance file lists the 2024/25 institution set in every year. Institutions that closed before 2024/25 have no rows. Earlier years are blank (`z`) where the institution had no results under that URN.
- EES carries no LOWCOV marker. Use `va_coverage` (an entries basis) as the proxy; G4 lists independents below 70%.
- The VA-entries universe is wider than this table: the subject VA file also holds 74 independents missing from the performance-table list (35 closed, 39 open, mostly special) (see notes and G4).
