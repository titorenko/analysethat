# rr1125_school_type.csv

Every school-type split in DfE research report RR1125, *Post-16 education and labour market activities, pathways and outcomes (LEO)*, by Anderson & Nelson.

- The report is dated May 2021; the PDF file is dated December 2022.
- School types are `non_selective` (state-funded, non-selective), `independent` and `selective` (grammar).
- Raw file: `data/raw/rr1125/2026-10-10/RR1125_post16_pathways_LEO.pdf`.
- Built by `code/derive/build_rr1125.py`, which uses pdfplumber page text and checks that the label of each school-type row is exact.
- Gate: `code/checks/g1_rr1125.py` (G1-RR1125, Table 6).

| column | meaning |
|---|---|
| table | Report table number: 5, 6, 7, 8 or 11 |
| measure | See below |
| school_type | `non_selective`, `independent` or `selective` |
| subgroup | `all`; `non_graduates` (Table 8); `graduates` / `non_graduates` (Table 11) |
| value | As printed (whole % / pp / £ rounded to £1,000) |
| unit | `pct`, `pp` or `gbp` |
| page | PDF page index. The printed page number is the same. |
| ks4_cohort | KS4 cohort |
| tax_year | Tax year(s) of the outcome |
| table_title | First line of the table title |

**Tables and measures**
- **Table 5** (PDF p. 45; this is the "29% / 54% / 56%" next to paragraph 85).
  - `share_in_50_most_common_pathways`: the proportion of individuals whose education and labour-market pathway is one of the 50 most common pathways for that sub-group.
  - It measures how **representative / concentrated** pathways are, not an outcome. Independent and selective pupils follow more uniform paths.
  - KS4 cohorts 2001/02-2006/07; tax years 2003-04 to 2017-18.
- **Table 6** (p. 47). Outcomes 15 years after GCSEs, 2001/02 KS4 cohort, tax year 2017-18. Raw, unadjusted.
  - `employment_rate`
  - `out_of_work_benefits_rate`
  - `average_earnings`. Table 6's header just says "Average earnings". Tables 3 and 11 say "(of those in employment)", and paragraph 87 says the trajectories are for those in employment.
- **Table 7** (p. 56). Graduate minus non-graduate, within school type.
  - Employment difference in pp.
  - Average earnings difference in £.
- **Table 8** (p. 58). Non-graduates only: level 3 or above minus level 2 or below.
  - Employment difference in pp.
  - Earnings difference in £.
- **Table 11** (p. 64). Two selected comparisons only: state non-selective **graduates** vs selective **non-graduates**.
  - Employment, benefits, and average earnings for those in employment.

**Caveats**
- All figures are descriptive. The report says it is "not controlling for other factors".
- School type is the school at KS4 (age 16).
- None of the report's 30 figure titles mentions school type. The chart images were not inspected, and figures such as 11 and 12 split by KS4 attainment.
