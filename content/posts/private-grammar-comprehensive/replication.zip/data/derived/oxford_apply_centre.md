# oxford_apply_centre.csv, oxford_apply_centre_2023_2025.csv

University of Oxford undergraduate applications, offers and acceptances by UCAS apply centre: one row per centre
per cycle, 2021-2025 (17,856 rows), plus the dashboard's own 2023-25 three-year total (4,927 rows). Built by
`code/derive/oxford_apply_centre.py`, checked by `code/checks/g2_oxford_apply_centre.py`.

**Source:** Oxford's Tableau Public dashboard "University of Oxford - Admissions Statistics 2025 – UCAS Apply
Centre" (public.tableau.com, profile sdma.oxford.university), which Oxford's FOI reply FOI/202610/1180 (6 Nov 2026)
gave as its answer. Downloads are disabled, so the table was captured as image tiles and read by OCR on
2026-11-07: see `code/harvest/oxford_tableau/README.md`. Raw tiles and OCR output: `data/raw/oxford_apply_centre/2026-11-07/`.

| column | meaning |
|---|---|
| cycle | UCAS cycle (`2021`...`2025`; `2023-2025` in the total file) |
| centre_number | UCAS school ID: the same numbering as Cambridge's apply-centre tables (`cambridge_apply_centre.csv`) |
| centre_name | as printed, with a trailing `..`/`...` removed |
| name_truncated | the dashboard cut the name short (long names end in `..`) |
| postcode | as printed; `Non-UK` for overseas centres, `NULL` where the dashboard prints NULL (5 centres) |
| school_type | `State`, `Independent` or `Other` (Oxford's classification) |
| applications, offers, acceptances | counts as printed; blank = withheld |
| *_lt3 | True where the cell is greyed: Oxford withholds counts below 3 |
| offer_rate_pct, acceptance_rate_pct | rates as printed (whole %), = count / applications |
| suppression_rule | `lt3` throughout |
| table_row | row position in the dashboard table (sorted by UCAS School ID), 0 = top |
| source_file | the OCR file the row came from |

**Caveats**
- Suppression is heavy for offers: in 2025, offers shown at UK state centres sum to 1,264 of the 1,971 that the
  annual report's Table 4.1 gives for state-school applicants (64%); independent 788 of 932 (85%). Any
  per-sector rate needs the suppressed cells calibrated to published totals, as was done for Cambridge.
- Not the same population as Table 4.1: the dashboard counts applicants by the centre that submitted their
  application (overseas pupils at UK independent schools included), while Table 4.1 counts UK-domiciled
  applicants. Shown UK-centre applications at independent centres exceed the report's independent total by
  8-12% in every cycle.
- `Apply Online Overseas` (centre 100) and other `Non-UK` centres are kept; filter on postcode for UK work.
- Read by OCR. Gate G2 passes: 18 hand-read rows exact; every table complete (rows = pixel height / 20); every
  row internally consistent (IDs increasing, formats, counts >= 3, acceptances <= offers <= applications, rates
  match counts); the 2023-25 total equals 2023+2024+2025 in all 1,384 centre-counts shown in all three years
  and lies within suppression bounds in the other 13,397. A 300-row random visual comparison found no errors.
