# imperial_apply_centre.csv

Imperial College London undergraduate applications, offers, rejections and acceptances by UCAS apply centre,
UCAS cycles 2020-2024: one row per centre per cycle (17,559 rows, 3,202-3,738 centres a year). Built by
`code/derive/imperial_apply_centre.py`, checked by `code/checks/g2_imperial_apply_centre.py`.

**Source:** "Application figures by School 2020-24" (xlsx), Imperial's publication scheme, an extract from UCAS
End of Cycle PERS 2024 released in answer to FOI requests IMPFOI-25-237, -276 and -311. Harvested by
`code/harvest/imperial.py`; URL and sha256 in `data/manifest/imperial_apply_centre.csv`.

| column | meaning |
|---|---|
| cycle | UCAS cycle. Imperial's sheet "2024-25" (entry year) is cycle 2024, the same numbering as the Oxford and Cambridge tables |
| centre_number | UCAS apply-centre code, shared with the Oxford and Cambridge tables (100 = Apply Online Overseas, 200 = Apply Online UK) |
| centre_name, centre_type, region | as printed; centre_type is UCAS's (Independent schools, Academies, Free Schools, Local authority maintained schools, Colleges, Welsh/Scotland/Northern Ireland schools, EU School, ...) |
| applications, offers, rejections, acceptances | counts as printed; nothing suppressed. 2024 offers = conditional + unconditional (the sheet's 'Offers') |
| source_file | the workbook |

**Caveats**
- Every applicant at a centre is counted, whatever their nationality or domicile; there is no UK-only figure. The
  workbook's summary sheet splits centres by region (UK, EU, overseas), not applicants by domicile; the gate checks
  that the centre rows add up to the three blocks together.
- Withdrawn applications are not in offers or rejections; acceptance "doesn't constitute enrolment".
- 23 rows have more acceptances than offers, a few with no application that cycle: places counted outside the
  cycle's offers (deferred entry, probably). The excess is 0.16% of acceptances.
- No postcode: for England-only work, `code/analysis/oxford_per_student.py` takes country from the Oxford and
  Cambridge tables for the same centre number.
