# grammar_intake.csv

Long-format table of Year 7 intake-selectivity facts for the 45 grammars in `top30_grammar.csv`, entry 2023-2026
plus 2027 policy. One row per published value (or per documented gap). Built by `code/derive/build_grammar_intake.py`
from files fetched by `code/harvest/grammar_intake.py` (source `grammar_intake`) and
`code/harvest/dfe_apps_offers.py`. Method, coverage and blocked sites: `data/notes/grammar_intake.md`.

| column | meaning |
|---|---|
| row_id | `gi0001`... **Regenerated on every build**, so cite a row id together with the build date (`logs/gates.md` and `grammar_super_selective.csv` are rewritten in the same run). |
| urn | School URN. **Blank for consortium / LA-level rows**: a test shared by several schools (CSSE, Kent Test, Warwickshire 11+, Slough consortium, Bucks STT, Birmingham/West Midlands test, Sutton SET). |
| name | School name (GIAS), or the consortium name on consortium rows. A school's `test_used` row carries the same consortium name, which is the join key. |
| entry_year | Calendar year of September Year 7 entry. A CSSE sheet "for 2026 entry" holds the offers of 1 March 2025, so entry_year 2025. DfE `time_period` 202627 = 2026. The Kent Test sat in Sept 2025 = 2026. Policy rows carry the policy's entry year (often 2027). Blank on gap rows. |
| measure | See the list below. |
| category | `all`, `boys`/`girls` (consortium counts), `inside_priority_area` / `outside_priority_area`, `priority_area_1/2`, `pupil_premium`, `looked_after`, `all_others`, `priority_score_inside_catchment` (KEF), `boarding_places` (a separate DfE row for RGS High Wycombe 2023-24), etc. |
| offer_round | `national_offer_day` (1-3 March), `september`, `april_reallocation`, `end_of_year7`, or blank when the source does not say. |
| value | **Mixed type**: a number; a 1-point range for CCHS (e.g. `106-107`, the school releases only the range); a code (`all_offered`, `no_offers`, model codes); free text (priority areas, test names); or a project-relative file path (`distribution_file`). Blank on gap rows. |
| unit | Scale of the value, e.g. `CSSE total standardised score`, `Kent Test total (max 423)`, `candidates`, `places`, `miles`, `km`, `ratio`, `code`, `file`. Scores are on each test's own scale and are not comparable across tests. |
| source_url | URL fetched (or `mailto:` address of the FOI recipient for `pending_foi`). |
| source_file | Local copy under `data/raw/` (blank if the fetch failed or the value is derived). |
| source_location | Page / table / row / column, plus the verbatim snippet the build matched in the extracted text (`text: "..."`). Derived rows: `derived: <row_id> / <row_id>`. |
| status | `confirmed` (read from a fetched primary document, snippet verified), `secondary_source` (tutoring/blog page, used only where no primary source was found), `not_published` (looked for and not there; or published only as an image-only PDF, said so in `note`), `pending_foi` (FOI sent 2026-10-10, `requests/SENT.md`), `blocked` (site refuses scripts; URL recorded, no value). |
| note | Caveats. |

**Measures**
- Model: `admissions_model` (codes below), `catchment_km` (radius; converted from miles where the source gives miles, the
  location says so), `priority_area` (text), `priority_area_places`, `test_used`.
- Scores: `qualifying_score` (pass / eligibility / priority score; `rank` category = a test-rank cut-off),
  `lowest_score_offered`, `last_distance_offered` (miles or metres), `last_rank_offered`, `waiting_list_position_reached`.
- Volume: `testers_stage1`, `testers_stage2`, `test_applicants`, `registrations`, `applications`,
  `candidates_qualified`, `candidates_scoring_303_plus` (CSSE), `candidates_assessed_grammar` (Kent), `places`
  (places offered as the school reports them), `pan`, `offers`.
- Ratios (derived): `testers_per_place` = testers_stage1 / places, else / pan, else / DfE offers, same school and
  year; on consortium rows = consortium candidates / sum of DfE offers at the consortium's selective schools
  (`dfe_offers_total` row, category `<sex>_grammars`). `test_applicants_per_place` (St Olave's, approximate).
- DfE applications and offers (2023-2026 entry, all 45 schools): `dfe_preferences_total/1st/2nd/3rd`,
  `dfe_offers_total`, `dfe_offers_1st_pref`, `dfe_preferences_per_offer`. These are LA-coordinated preferences, **not
  test-takers** (QE: 763 preferences in 2026 vs about 3,400 testers).
- Files: `distribution_file` (all-candidate score lists / distributions), `candidate_totals_file`,
  `standardisation_report`.

**admissions_model codes**: `score_rank` (test-score rank, no area); `score_rank_priority_area` (score rank inside a
priority area / quota, rest by score); `score_rank_mixed_catchment` (part open by score, part by score inside a small
radius); `qualify_then_distance`, `qualify_then_catchment` (qualifying score, then catchment / distance);
`qualify_then_catchment_distance` (KEF: qualifiers above the priority score inside a ward catchment, by distance);
`faith_categories`, `faith_categories_score_rank`.

**Caveats**
- The key (urn, name, entry_year, measure, category, offer_round) is unique for non-blank values except one deliberate
  conflict: Kent Test minimum per paper for 2025 entry, 106 (KCC page, Wayback copy) vs 108 (Judd School table).
- Kent files are Wayback `id_` copies of KCC files (kent.gov.uk is behind Cloudflare, which refuses python-requests).
- Consortium testers per place uses DfE total offers as places; for CSSE the partially selective schools' selective
  places are not published and are excluded, so the CSSE ratios are upper bounds.
- Colyton's score list includes in-year candidates (upper bound). Blue Coat's 1,089 answers a question about "entry in
  September 2024" inside the 2026-entry FAQ.
- Gap rows (`not_published`, blank entry_year) are generated for every school lacking any row for one of the five core
  measures (model, qualifying score, lowest score/distance/rank, testers, PAN/places); `source_location` lists the
  documents read for that school.
