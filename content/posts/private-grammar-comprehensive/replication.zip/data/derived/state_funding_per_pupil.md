# state_funding_per_pupil.csv

State funding or spending per pupil in England, 2025-26, for the social-cost paragraph: the state's cost avoided when a pupil goes private. There are four measures, each with its own status. **Use the row with `recommended` = True: IFS secondary, £7,800.**

**Sources** (in `data/raw/school_funding/2026-10-10/`, manifest `data/manifest/school_funding.csv`)
- `ifs_annual_report_education_spending_2025-26.pdf`: IFS, *Annual report on education spending in England: 2025-26*, January 2026. IFS HTML pages return 403 to scripts; the PDF downloads.
- `dfe_revenue_funding_5to16_2010-11_to_2026-27.csv`: DfE *School funding statistics*, FY2025-26 release, EES data set `ce1e4917-b2ea-45bc-9a89-e4608c7c67d3`.
- `NFF_LA_summary_tables_2025-26.ods`: DfE *National funding formula tables for schools and high needs: 2025 to 2026*, LA summary. Published Dec 2024.

Built by `code/derive/build_state_funding.py`.

| column | meaning |
|---|---|
| measure | See the rows below |
| recommended | True for the figure to cite |
| value_gbp | £ per pupil (or per student) per year |
| year | 2025-26 |
| price_base | Price base |
| coverage | What is in and out |
| status | Published / projection / derived |
| source | Publication |
| source_file | Raw file |
| page | PDF page index, for IFS |
| evidence | Matched text, or the derivation |

**The four rows**

1. `ifs_secondary_school_spending_per_pupil`: **£7,800** (recommended).
   - Basis: 2025-26 prices, HMT GDP deflator (Nov 2025).
   - Coverage: spending by state secondary schools per pupil, **including school sixth forms**. It excludes central spending by LAs and multi-academy trusts, which IFS puts at £510 per pupil for academies.
   - Status: an IFS projection for 2025-26 from school-level actuals up to 2023-24.
   - Location: PDF p. 8.
2. `ifs_fe_spending_per_student_16_18`: £7,900.
   - Coverage: FE and sixth-form colleges, per 16-18 student.
   - Use: the comparator for Years 12-13 for a state pupil who would leave school at 16.
3. `dfe_revenue_funding_per_pupil_5_16`: £8,400.
   - Coverage: DfE revenue funding per pupil aged 5-16 across all phases (7.725m FTE pupils), so it is **not secondary-specific**.
   - Status: allocation-based, not spending.
4. `nff_secondary_unit_of_funding_weighted_mean`: £7,317.16.
   - Status: **derived here**. It is the mean of the 151 LAs' 2025-26 schools-block secondary units of funding (SUF), weighted by 2024-25 DSG secondary pupil numbers. DfE does not print a national SUF in this file.
   - Coverage: schools block, Years 7-11 only. It excludes premises, growth, high needs, pupil premium and 16-19 funding.

**Caveats**
- A figure of £7,450 for the "national average SUF" turned up in a web-search snippet quoting a council letter. It is **not used**, because it is unverified.
- For an 11-18 route, the avoided state cost is about 5 × the secondary figure plus 2 × the school-sixth-form or FE figure. Pupil premium and SEND funding vary by pupil.
- These figures are in 2025-26 prices or cash. Deflate consistently with the fee series.
