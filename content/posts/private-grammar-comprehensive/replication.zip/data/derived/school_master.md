# school_master.csv

One row per URN: English secondary-relevant establishments. Built by `code/derive/build_school_master.py`.

**Universe (7,051 URNs).**
- Every URN in a harvested DfE school-level file (16-18 performance/info/subject files, KS4 performance/info, 16-18 / KS4 / progression destinations), any year, open or closed. `dfe_sources` lists which files.
- Plus open GIAS establishments in England that are either:
  - secondary-phase (Secondary, Middle deemed secondary, All-through, 16 plus), or
  - `Other independent school` with statutory high age ≥ 16.
- Excluded: the 151 LA-level "AP Institution:…" pseudo-URNs (9xxxxx) in the KS4 destinations file.
- Every URN in the table is in GIAS (`in_gias` is all True).

**Sources**
- `data/raw/gias/2026-10-10/edubasealldata20261010.csv`: GIAS extract dated 2026-10-10. It is **cp1252**, not UTF-8: strict UTF-8 fails at byte 0x92 ("St Paul’s").
- `data/raw/dfe_ks5/2026-10-10/ks5_institution_info_v1.0.2.csv`: 16-18 institution information, 2024/25, 2,792 institutions.
- `data/raw/dfe_ks4/2026-10-10/ks4_school_info.csv`: KS4 school information, 2024/25, 5,755 schools.
- The other DfE files are used for their URN lists only.

| column | meaning |
|---|---|
| urn | Unique Reference Number (string) |
| name | GIAS establishment name |
| la_code / la_gss_code / la_name | GIAS old 3-digit LA code / GSS LA code (E06/E08/E09/E10) / LA name |
| london | la_gss_code starts with E09 (London borough or City of London) |
| establishment_type, establishment_type_group, phase, status, open_date, close_date | GIAS fields (dates dd-mm-yyyy) |
| dfe_establishment_type | DfE type: 16-18 info `establishment_type`, else KS4 info `establishment_type_group` |
| sector | `independent` / `selective` / `non_selective_highly_selective_area` / `non_selective_other` / `other` (rules below) |
| sector_basis | which rule set the sector: `gias_type`, `dfe_ks5_info`, `dfe_ks4_info`, `gias_admissions_policy`, `default_other` |
| dfe_admissions_policy | DfE 2024/25 admissions policy, normalised. 16-18 info `admissions_policy` first, else KS4 info `admpol_pt` (the two never conflict). Blank = no DfE label |
| dfe_admissions_policy_source | `ks5_info`, `ks4_info` or `ks5_info+ks4_info` |
| gias_admissions_policy | GIAS AdmissionsPolicy as published: Selective / Non-selective / Not applicable / blank |
| selectivity_disagreement | Filled where DfE (collapsed to selective / non-selective) ≠ GIAS, for schools with a DfE label, e.g. `dfe=non_selective_other; gias=(blank)` |
| gender, boarders, official_sixth_form | GIAS (Gender, Boarders, OfficialSixthForm names) |
| statutory_low_age, statutory_high_age | GIAS |
| dfe_age_range | DfE age range (16-18 info, else KS4 info) |
| pupils, boys, girls, census_date | GIAS NumberOfPupils / Boys / Girls and CensusDate. Independents' counts can be years old (Eton census 18-01-2024) |
| postcode, easting, northing | GIAS (OSGB36 metres) |
| in_gias | URN found in GIAS |
| dfe_sources | DfE files containing the URN: ks5_info_2425, ks4_info_2425, ks5_perf, ks4_perf, ks5_subject_va, ks5_subject_grades, dest_1618, dest_ks4, progression |

**Sector rules** (first rule that applies)
1. GIAS type `Other independent school` → `independent`. Independent *special* schools go to `other`; for example Canbury School is "Independent School" in DfE but an independent special school in GIAS.
2. DfE 2024/25 label → `selective` / `non_selective_highly_selective_area` / `non_selective_other`.
3. No DfE label, a state-funded mainstream school, and GIAS `Selective` → `selective`. This covers 3 closed predecessor URNs of grammars, e.g. Colchester RGS 137814.
4. Everything else → `other`. That includes special schools, AP, FE and sixth-form colleges, 16-19 schools, and state schools without a 2024/25 DfE label: closed predecessor URNs, plus ~100 open academies that converted after the 2024/25 tables.

**Counts:** independent 1,021 (928 open); selective 166 (163 open, all with DfE labels); non_selective_highly_selective_area 220; non_selective_other 2,967; other 2,677.

**Caveats**
- DfE does not flag partially selective schools. Dame Alice Owen's and the Watford Grammars are `non_selective_other`, and GIAS also calls them Non-selective. They need a hand list (PLAN G-class).
- The DfE "highly selective area" label exists only for schools with a 2024/25 DfE row.
- GIAS `AdmissionsPolicy` is filled for some independents (e.g. Eton "Selective") but has no official meaning for them.
