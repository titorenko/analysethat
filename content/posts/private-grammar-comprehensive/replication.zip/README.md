# Replication files: private, grammar and comprehensive schools

Contents
- code/harvest   downloads every source (logged to data/manifest with URL, date, HTTP status, bytes, sha256)
- code/derive    builds the tidy tables in data/derived (each has a .md describing columns and caveats)
- code/checks    gates: each derived table against the published figure it reproduces (results in the article)
- code/analysis  P2-P4: national comparisons, top-30 selection, Cambridge linkage, profiles, premium scenarios
- code/engine    lifetime earnings and cost-benefit engine (lifetime.py), run_p5.py, run_p6.py
- code/figures   figures and the article (article_values.py computes every number in it)
- results        outputs and FINDINGS_*.md notes
- writeup        article template

Run order (Python 3.13, pip install -r requirements.txt; always run with python -I)
1. code/harvest/*.py      (raw files are not included; manifests give URLs and sha256 to check them)
2. code/derive/*.py       then code/checks/*.py
3. code/analysis/select_top30.py data/derived; join_cambridge.py data/derived; p2_national.py data/derived results;
   p3_profiles.py data/derived results; p4_adjusted_public.py data/derived results; p4_bridge.py data/derived results
4. code/engine/run_p5.py results; code/engine/run_p6.py data/derived results
5. code/figures/make_figures.py <dir>; code/figures/build_article.py <dir>; code/checks/g_article.py writeup/article.md.tmpl

Not included: raw downloads; ISC census tables (isc_*.csv, ISC copyright: see ISC Census and Annual Report 2026);
FOI correspondence. Sources are public; DfE, ONS, GIAS, OBR and HMRC data are under the Open Government Licence.
Cohort microdata (NCDS, BCS70, MCS, Next Steps) were not used.

Updates to the article (first published 10 October 2026)
- 11 October 2026: added section 8, on PhDs, top jobs and satisfaction with life.
- 5 November 2026: new title, and admission figures from freedom of information replies behind the underlined
  schools in Table 5, and index-linked gilts added as a comparison for the return on the fees.
