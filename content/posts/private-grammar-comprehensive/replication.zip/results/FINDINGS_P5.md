# P5 findings — core lifetime and cost-benefit engine (2026-10-10)

**Status: core engine only.** Still to do under PLAN §4.6:
- fees net of bursaries (after G-fees);
- the positional caveat for the social view (fees and state spend are now computed).

Engine: `code/engine/lifetime.py`. Outputs: `code/engine/run_p5.py results` → `results/p5_pv_fees.csv`,
`results/p5_breakeven.csv`. Gates: `code/checks/g_engine.py` (G-tax, G-real, threshold path, G5 components) and
`code/checks/g6_literature.py` (G6), both PASS. **Nothing here uses a premium estimate.** Break-even premiums are
the hurdle that P4's estimates must clear.

## Changes from the planning arithmetic (PLAN §4.7) and why

| Item | Planning v2 | Engine | Reason |
|---|---|---|---|
| Price basis | mixed | CPI-real, 2025/26 prices, everywhere | G-real: one index (IFS 2026 convention) |
| Earnings growth | 1.4% from age 22 | 1.7% CPI-real by calendar year from 2025 | 1.4% was OBR productivity (GDP-deflator basis); and the planning code let growth start only at 22, dropping 12 years of growth between ASHE 2025 and the child's first pay in 2037 |
| Tax thresholds | 2026/27 values held constant in real terms | cash-frozen to 2030/31, then CPI-uprated: real PA £11,385, higher-rate £45,531, taper from £90,573 | stated policy; OBR CPI forecast |
| Plan 5 | £25k threshold, £45k balance, write-off 62 | £25,168 (IFS Table B.2), £56,700 balance (IFS mean outlay), write-off 40 years after graduation (61) | IFS 2026 terms |
| Age profile | step function by band | linear between band mid-ages | smoother; no jumps at band edges |
| Top tail | P90 maximum | P95 and P99 from ASHE ad hoc 3105 ratios | PLAN §4.5 |

Net effect in scenario A: break-even premiums fall by 2-6 points against the planning table (growth outweighs
the higher real tax). Scenario B (part-time and non-employment) raises them again, by 5 points (men) to 11
points (women) at P50.

## PV of fees at the decision age (day school, ISC 2026 incl. VAT, 0% real fee growth)

| Route | 2.1% | 3.0% | 3.5% stepped |
|---|---|---|---|
| 11-18 (headline) | £155.5k | £151.6k | £149.5k |
| 7-18 | £223.6k | £214.2k | £209.2k |
| 13-18 | £113.9k | £111.9k | £110.9k |
| 16-18 (sixth form only) | £48.1k | £47.9k | £47.8k |

## Two earnings scenarios (added after review)

- **A (upper bound on any gain):** full-time pay, in work every year from 22 to 67.
- **B (central):** ASHE pay of all employees (full- and part-time), weighted every year by the graduate
  employment rate. The rate is 89.5% for men and 85.9% for women (DfE Graduate labour market statistics 2024,
  `glms_2024_employment.csv`). It is flat across ages, because no sex × age breakdown is published.

Two consequences:
- A gives gross gains about 30% (men) and 60% (women) above IFS's, which include zero and part-time years. A
  therefore **understates** the break-even premium, especially for women.
- A percentage premium is applied to annual pay in both scenarios. That assumes school type changes neither
  hours nor employment (there is no estimate of either). Premiums from P4 must match the scenario's base:
  hourly or full-time premiums go to A or B with that assumption, and ONS annual PAYE ratios go to B.

### Scenario B (central): break-even gross premium, 11-18 day, men / women

| Percentile | 2.1% borrowing | 3.0% | 3.5% Green Book | 5% equity (flagged) |
|---|---|---|---|---|
| P10 | 36.3 / 63.7% | 47.0 / 81.9% | 52.6 / 91.4% | 80.2 / 137.3% |
| P25 | 25.4 / 38.4% | 32.9 / 49.2% | 36.7 / 54.7% | 56.7 / 82.7% |
| P50 | 21.3 / 26.7% | 27.9 / 34.5% | 31.3 / 38.5% | 47.1 / 58.2% |
| P75 | 15.3 / 21.6% | 19.9 / 28.1% | 22.2 / 31.5% | 34.1 / 46.9% |
| P90 | 10.5 / 15.7% | 13.8 / 20.3% | 15.4 / 22.6% | 24.0 / 34.2% |
| P95 | 8.1 / 12.2% | 10.6 / 15.9% | 11.9 / 17.7% | 18.6 / 27.1% |
| P99 | 4.1 / 6.8% | 5.4 / 8.8% | 6.1 / 9.8% | 9.4 / 14.9% |

Other routes in scenario B at 3.5%, P50, men / women:
- 7-18: 47 / 59%.
- 13-18: 21 / 27%.
- Sixth form only: 8 / 11%.

### Scenario A (upper bound on gains, so a lower bound on the hurdle): 11-18 day, men / women

The premium (on full-time gross pay, ages 22-67) at which the PV of the after-tax, after-loan gain equals the PV
of fees, by the child's **counterfactual** (state-school) percentile.

| Percentile | 2.1% borrowing | 3.0% | 3.5% Green Book | 5% equity (flagged) |
|---|---|---|---|---|
| P10 | 24.2 / 27.1% | 31.6 / 35.2% | 35.2 / 39.3% | 54.3 / 60.1% |
| P25 | 20.3 / 23.1% | 26.6 / 30.0% | 30.0 / 33.5% | 47.3 / 51.4% |
| P50 | 18.8 / 18.5% | 23.9 / 24.6% | 26.6 / 27.8% | 39.8 / 43.7% |
| P75 | 13.0 / 16.2% | 16.9 / 20.8% | 18.9 / 23.1% | 29.2 / 35.0% |
| P90 | 9.0 / 11.4% | 11.8 / 14.8% | 13.2 / 16.6% | 20.7 / 25.6% |
| P95 | 7.0 / 8.8% | 9.2 / 11.5% | 10.3 / 12.9% | 16.1 / 19.9% |
| P99 | 3.5 / 4.9% | 4.6 / 6.4% | 5.1 / 7.1% | 8.0 / 10.9% |

In scenario A at 3.5%, P50:
- 7-18 needs 39 / 45%.
- 13-18 needs 19 / 19%.
- Sixth form only needs 7 / 8%.

## Where does a typical private pupil sit? (`results/p5_counterfactual_rank.csv`)

Method:
- Take each private percentile's PAYE earnings at 30 (ONS 2022).
- Divide by an assumed causal premium.
- Place the result in the state non-FSM distribution at 30. This assumes rank preservation.

The median private pupil's counterfactual rank:
- P75 if the causal premium is zero;
- P69 at 10%;
- P63 at 20%;
- P57 at 30%.

So read the break-even tables at roughly **P60-P75** for a typical private pupil.

Caveats:
- The ONS ranks are among state non-FSM pupils at 30 (PAYE, with very low earners included). The engine's
  percentiles are ASHE ranks among employees in each age band.
- So the mapping is approximate.

## Alternatives and the social view (PV at age 11)

| Item | 2.1% | 3.0% | 3.5% stepped |
|---|---|---|---|
| Private fees, 11-18 day | £155.5k | £151.6k | £149.5k |
| Catchment premium held 7 years, family moving anyway: 10% of the England average (£29.3k) | £4.7k | £6.3k | £7.1k |
| Same, 15% (£44.0k) | £7.1k | £9.4k | £10.7k |
| Same, 20% (£58.6k) | £9.5k | £12.6k | £14.2k |
| Move caused by the school, 10% premium | £17.2k | £18.7k | £19.5k |
| Same, 15% | £19.5k | £21.9k | £23.1k |
| Same, 20% | £21.9k | £25.0k | £26.6k |
| State secondary spending avoided (IFS £7,800 a year) | £51.3k | £50.1k | £49.4k |
| Social net cost of going private (fees ex-VAT − state spend; VAT is a transfer) | £78.3k | £76.3k | £75.2k |
| *(superseded: same incl. VAT, which wrongly counts VAT as a cost)* | *£104.2k* | *£101.5k* | *£100.1k* |

The "moving anyway" row is the user cost of the premium alone:
- **Paid:** the premium plus SDLT at the 5% marginal band.
- **Recovered:** the premium is sold after 7 years, having grown at real house-price growth of 0.65% a year (OBR
  forecast), less 1.8% selling costs (assumption).
- **Financing:** the discount rate.

Inputs and assumptions:
- England average price £293,000 (UK HPI, July 2026).
- No published premium for a good secondary is current. 10-20% spans the evidence: Lloyds 2016/17 top-30 state
  (grammar-heavy) 12-17%; Santander 2025 stated willingness to pay 15%; GMS about 3% per school-level SD.
- Price risk is not modelled.

The "caused by the school" rows add three items: SDLT on the rest of the new home (£4,650 on £293k), 1.8% selling
costs on the old home, and £2,500 of moving costs (an assumption).

**A catchment premium costs about 5-10% of private fees if the family would move anyway. It costs 13-18% if the
school is the reason for the move.** (Corrected 2026-10-10: the first version showed only the "moving anyway"
case, under the wrong label.)

## Grammar route: what premium justifies paying for tutoring? (scenario B, P50, 3.5%)

Tutoring is paid at age 10 for certain and valued at 11 with one year's interest (corrected: the first version
discounted it the wrong way, so its figures were about 7% too low). The child is admitted with probability p. The break-even premium
satisfies p × (PV of the net gain) = tutoring. Results in `results/p5_grammar_tutoring_breakeven.csv`.

| Tutoring | p = 0.10 | p = 0.25 | p = 0.50 |
|---|---|---|---|
| £3,000 | 5.8 / 7.8% | 2.3 / 3.1% | 1.1 / 1.6% |
| £8,000 | 16.5 / 21.0% | 6.2 / 8.3% | 3.0 / 4.2% |

(men / women)

p is a parameter, not an estimate:
- Testers per place gives the unconditional rate: about 6-17% at the super-selectives and 23-33% in the
  Essex/Kent/Warwickshire consortia (`grammar_super_selective.csv`).
- A tutored, able child's chance is higher but unobserved.

The grammar hurdle is an order of magnitude below the private one. Whether it is cleared depends on the grammar
earnings premium, which may be zero for current cohorts (no post-1990s evidence).

## Benchmarks (G5, G6)

- **IFS 2026 (G5).** The headline net degree return (£99k) averages individual LEO paths including zeros and
  part-time years. It cannot be rebuilt from published figures, and the report has no data annex; the July 2026
  revision changes only wording on p.9. The engine instead reproduces the components:
  - the discount factor (4.92);
  - the Plan 5 anchor;
  - the tax and NI share of a 20% gross gain: men 44.6% vs IFS 47.9%, women 42.7% vs 40.5%.

  Its gross gain is larger than IFS's (men £275k vs £215k, women £233k vs £148k) because its paths are full-time
  and conditional on employment. **This is a deviation from the approved G5 (full reproduction within 10%).**
- **GMMZ 2012 (G6).** Their "7% (boarding) to 13% (day)" is a return on capital: £5,000 a year of extra pay
  divided by £75,000 (or £43,000) of fees. It is not a timed IRR. Timing the same inputs (fees at 8-17, premium
  at 23-60) gives about 3.5% (boarding) and 6% (day), before tax. That timing holds the £5,000 flat. A premium
  that grows with pay and continues into pensions (as GMMZ note) would raise it. So this reconstruction shows
  only that their figure is a yield on capital, not a timed IRR. It does not show that the true return was lower.
  The study's own IRRs for today's fees are in FINDINGS_P4_P6.
- **GMS 2013 (G6).** 12% of £10,700 at ages 16-65, 3.5%, discounted to 5: £21,351 vs their £20,600.

## Assumptions to state in the write-up
- **Rank preservation:** a premium applied at the child's counterfactual percentile assumes the child keeps
  that rank whichever school they attend.
- **Pseudo-cohort:** the cross-section of ages stands in for a lifetime path.
- **Both paths graduate.**
- **No effect on work:** school type does not change employment or hours.
- **Flat employment rate by age** (scenario B). The GLMS rate (ages 16-64) is held through 67, although GLMS stops
  at 64 and shows 43% part-time at 61-64.
- **Income:** gross employee pay only. Pensions, self-employment and capital income are excluded.
