# P4 and P6 findings: premiums for today's pupils, NPV, IRR, tornado (2026-10-10)

Scripts:
- `code/analysis/p4_bridge.py data/derived results` writes `results/p4_premiums.csv` and
  `results/p4_premium_anchors.csv`.
- `code/engine/run_p6.py data/derived results` writes `results/p6_npv.csv` and `results/p6_tornado.csv`.

Evidence comes from `data/derived/evidence_table.csv`: 312 rows, 303 of them quote-verified (gate
G-evidence PASS). Every anchor value is asserted against its row. **None of the nine unverified rows is used.**

## Three corrections to the approved plan

1. **The §4.2.6 channel decomposition cannot be done as planned.** No published BCS70 table separates degree,
   Russell Group and subject; education enters as one block. So the bridge can split the 1970-cohort premium
   only into "through education" and "remaining":
   - men 0.297 = 0.124 + 0.173;
   - women 0.192 = 0.134 + 0.058.

   This split is descriptive, not causal, because education is itself an outcome of schooling.
2. **Henderson et al. (2020) estimates are ADJ-MED** (conditional on GCSE), not ADJ-PRE as PLAN §2 listed them.
3. **The "industry controls remove the male direct premium" caveat comes from the Skills and Employment Survey**
   (ages 25-60, no ability control), not from BCS70. Rows GHV2017-01 to -09. The social-view paragraph must cite
   it that way.

## Premium scenarios (log points; % in brackets), applied to annual pay

Each source measures pay differently: GMMZ and GHV hourly, Next Steps weekly, Crawford & Vignoles annual. The
engine applies every scenario as a percentage of annual pay and assumes no effect on hours or employment.

| School, route | Scenario | Men | Women | Basis (row ids) |
|---|---|---|---|---|
| Private 11-18 (13-18 and 7-18 the same) | high: "1970 cohort unchanged" | 0.159 at 25 → 0.184 at 34 → 0.297 from 42 (17 → 35%) | 0.159 at 25 → 0.244 from 34 (17 → 28%) | GAHH2020-02, GMMZ2012-22/-24, GHV2017-04/-13 |
| | central: "Next Steps, held flat" | 0.159 (17.2%) | 0.159 (17.2%) | GAHH2020-02 (born 1989-90, private at 13, weekly pay at 25, background-adjusted, no ability control) |
| | low: "no education channel" | 0.091 (9.5%) | 0.046 (4.7%) | CV2014-19/-23 (graduate-only, after A levels, class, institution, subject) |
| Private 16-18 only | low / central / high | 0 / 0.016 / 0.062 | same | HAGH2020-03 × IFS degree return; GAHH2020-02 minus -03 |
| Grammar 11-18 | low / central / high | 0 / 0 / 0.086 | 0 / 0 / 0.074 | DFM2002-04 (an upper bound: placebos exceed effects, MP2006); CDB2016-15; RD central from CDB2016-03 (−0.066) and PJ2023-03 (+0.069, SE 0.167) |

The central scenario makes one assumption: the 1970 cohort's rise in the premium with age is offset by a smaller
education channel for today's pupils. For MCS pupils (born 2000-02), the private GCSE edge is 0.05 of a grade
after SES, about zero (AGHH2024).

Three things are not modelled:
- **Prep years (7-18):** there is no evidence on them, so that route gets the 11-18 benefit at a higher cost.
- **A zero effect:** a zero causal private effect is not ruled out; the low scenario is not a floor.
- **Grammar comparison:** all grammar evidence compares with secondary moderns. Today's comprehensive
  counterfactual makes those estimates transfer even less well.

## NPV and IRR, private 11-18 day (ISC average fees), scenario B, 3.5% Green Book, flat premium

"Typical" means each scenario's own implied counterfactual rank for the median private pupil:
- central: about P64;
- high: about P63;
- low: about P69 (men) and P72 (women).

Rank comes from ONS earnings at 30 (`p5_counterfactual_rank.csv`).

| | Scenario | NPV P50 | NPV P75 | NPV P90 | **NPV typical** | **IRR typical** |
|---|---|---|---|---|---|---|
| Men | low | −£100k | −£85k | −£57k | −£92k | 0.2% |
| | **central** | −£63k | −£34k | +£18k | **−£53k** | **1.8%** |
| | high | −£19k | +£43k | +£131k | **+£7k** | 3.5% |
| Women | low | −£131k | −£125k | −£119k | −£124k | −2.2% |
| | **central** | −£81k | −£64k | −£36k | **−£68k** | **1.3%** |
| | high | −£51k | −£29k | +£20k | **−£35k** | 2.5% |

IRRs are real (CPI) returns on the fees.

**In the central case, a typical private pupil's real return is 1.3-1.8% a year**, below every discount rate
considered, including the 2.1% real cost of borrowing. Only two cases break even:
- boys whose counterfactual earnings would be at P90 or above (central);
- a typical boy if the 1970-cohort premium has survived intact (high).

Girls fall short in every scenario at the typical rank.

**ONS-shaped premium** (a larger premium higher up the distribution, scaled in log points): at the typical rank it
is close to the flat result. It matters at P90, where central men reach +£66k and central women −£2k.

**Top-30 fees** (median £31.3k senior and £31.8k sixth form in 2026/27, deflated by one year of CPI to 2025/26
prices, against the ISC average of £23.4k) lower every NPV by about £45k (`npv_3.5%_top30_fees`; first version
without deflation: about £50k).

## Grammar 11-18 (p_admit 0.25, £3,000 tutoring), scenario B, 3.5%

| | central (0) | high, P50 | high, P90 |
|---|---|---|---|
| Men | −£3.1k (the tutoring) | +£8.6k | +£18.6k |
| Women | −£3.1k | +£4.5k | +£9.5k |

On the central reading, tutoring for a grammar place is a small loss. On the most generous reading it is a small
gain. Either way the stakes are about a tenth of the private decision.

## Tornado (private 11-18, typical pupil, central, scenario B, 3.5%; base −£53k men / −£68k women)

| Input | Range | Men | Women |
|---|---|---|---|
| Premium scenario | low → high | −£92k → +£7k | −£124k → −£35k |
| Counterfactual rank | P50 → P90 | −£63k → +£18k | −£81k → −£36k |
| Fees | top-30 median vs ISC average | −£99k vs −£53k | −£113k vs −£68k |
| Discount rate | 5% equity → 2.1% borrowing | −£82k → −£12k | −£91k → −£34k |
| Extras on fees | +15% → +5% | −£76k → −£61k | −£90k → −£75k |
| Real fee growth | 3% → 0% | −£72k → −£53k | −£86k → −£68k |
| Earnings scenario | B → A (full-time, always employed) | −£53k → −£32k | −£68k → −£53k |
| Real earnings growth | 1.2% → 1.83% | −£61k → −£46k | −£79k → −£65k |
| Premium shape | flat → ONS | ≈ 0 at the typical rank | ≈ 0 |

What decides the answer, in order:
1. which premium holds for today's pupils;
2. where the child's earnings would otherwise sit;
3. which school (fees);
4. the discount rate.

No single input except the premium scenario and the child's rank turns the typical boy's NPV positive. Nothing
does for the typical girl.

## Not run
- **G7, G-placebo and G-SDC:** not run, because T2 is blocked; UKDS permission is pending (request 1).
- **The NCDS exposure dose and the MCS modern ADJ-PRE estimate:** not available, for the same reason.

## Updates after review round 1 (2026-10-10)

Two independent reviewers looked at the draft article: Claude Opus 5.5 (21 findings) and Claude Fable 5.1 (22 findings). Every finding was addressed in the article template.

**Corrections to the numbers in this note**
- **Central premium interval.** The Next Steps coefficient has t = 2.83, so SE 0.056 and a 95% interval of 5-31%. Both ends are now scenarios in `p4_premiums.csv` (`central_lo95`, `central_hi95`). For a typical pupil at 3.5%, the NPV is −£117k to +£7k for boys and −£123k to −£18k for girls.
- **Top-30 fees.** These are 2026/27 cash fees, now deflated by one year of CPI to 2025/26 prices. The central NPV for a typical pupil is −£99k for boys (was −£103k) and −£113k for girls. The gap to ISC-average fees is about £45k (was "about £50k").
- **Social cost.** It now excludes VAT, because VAT is a transfer to the Treasury. The figure is £75k (was £100k).

**New results**
- **Bursary or sibling discount.** A 10% discount is now a tornado bar: it moves the typical boy from −£53k to −£38k.

**Corrections to the literature**
- **Dearden et al. compare with comprehensives.** They compare grammar with comprehensive schools, not secondary moderns. Their private-school estimate for 1958-cohort men is also +25% (DFM2002-08); the article now cites it.
- **The 1989-90 estimate may overstate the premium.** For the MCS cohort, adding test scores at age 3 turns the private GCSE edge from +0.05 to −0.12 (AGHH2024-04). The Next Steps estimate has no early-ability control, so it may be too high.
