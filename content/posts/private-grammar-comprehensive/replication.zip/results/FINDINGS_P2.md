# P2 findings — national three-way comparisons (2026-10-10)

Script: `code/analysis/p2_national.py data/derived results` → `results/p2_*.csv`. All inputs passed G1.
Every number here is **RAW** unless labelled; sector = where the pupil took A levels at 17 (WP, Cambridge),
except RR1125 and ONS (school at KS4).

## 1. University entry by sixth-form sector (DfE WP, A-level students, by age 19)

| | Independent | Selective state | Other state |
|---|---|---|---|
| Any HE, aged 15 in 2006/07 | 84.1% | 90.9% | 78.0% |
| Any HE, aged 15 in 2020/21 | 86.9% | 88.8% | 77.2% |
| High-tariff HE, 2006/07 | 59.7% | 53.8% | 23.6% |
| High-tariff HE, 2020/21 | 58.6% | 50.2% | 24.2% |

Grammar sixth forms send slightly more students to university than private ones, and the high-tariff gap
between them is 8pp. Both are far above other state sixth forms. All three series are flat over 14 cohorts.

## 2. Cambridge acceptances per 1,000 A-level students of each sector (cycle = age-15 cohort + 3)

**Corrected 2026-10-10 (England-only numerators).** The first version divided Cambridge's UK "Home" block
(which includes Northern Ireland's grammars and Scottish and Welsh schools) by England-only WP cohorts, and
left out pupils at English private schools whose fee status is not Home. Non-England centres are removed using
apply-centre postcodes, with suppressed cells calibrated to the published totals
(`code/analysis/cam_cells.py`, `results/p2_cambridge_per_student_england.csv`).

| Cycle | Independent, all fee statuses | Independent, Home only | Grammar (England) | Other state (England) |
|---|---|---|---|---|
| 2013 | 35.7 | 29.1 | 23.5 | 4.6 |
| 2019 | 28.9 | 24.6 | 24.4 | 5.8 |
| 2020 | 31.6 | 27.3 | 28.3 | 7.0 |
| 2022 | 24.2 | 22.0 | 25.5 | 5.8 |
| 2023 | **23.8** | **21.1** | **26.2** | 5.2 |

**Grammar sixth-formers overtook private-school sixth-formers on Cambridge entry per A-level student between
2020 and 2022, depending on whether non-Home-fee pupils at English private schools are counted. By 2023
they were 10-24% more likely to be accepted.** Private entry per student fell by a third (all fee statuses)
or by about 28% (Home only) between 2013 and 2023.

Two choices bound these figures:
- The grammar figure subtracts **all** NI maintained acceptances, as if every one came from a grammar. That
  is the largest possible correction, so the grammar rate is a lower bound; the uncorrected UK figure is 27.5.
- It is unknown whether WP's independent cohort includes overseas-resident boarders. That is why both
  independent variants are shown.

Remaining caveats: Cambridge counts applicants by apply centre, including post-A-level applicants, while WP
counts the A-level cohort. Mapping grammar to "selective state", and comprehensive + sixth-form + FE colleges
to "other state", is approximate.

The UK Home-block version (first draft) for reference: 2013 31.5 / 25.6 / 5.1; 2020 29.7 / 29.8 / 7.5;
2023 22.2 / 27.5 / 5.6 (independent / grammar / other state).

Offer rates (offers / applications), which condition on applying: 2025 grammar 31.7%, independent 25.9%,
sixth-form college 26.8%, comprehensive 22.7%, FE 21.9%. Oxford (state vs independent only): 2025
independent 25.1%, state 19.8%; the independent advantage narrowed from 2013 (28.6 vs 23.1) to 2021
(20.3 vs 19.0) and widened again since.

## 3. A-level results by sector, 2024/25 (school rows, student-weighted)

| Sector | Schools | Students (A level) | Points per entry | Value added (grades/entry) |
|---|---|---|---|---|
| Independent | 479 | 36,187 | 42.9 (B+) | **+0.20** |
| Selective (grammar) | 158 | 25,690 | 41.6 (B+) | +0.01 |
| Partially selective (hand list, G-class) | 22 | 3,611 | 36.6 | +0.03 |
| Non-selective, other areas | 1,517 | 133,664 | 33.9 (C+) | −0.02 |
| Non-selective in highly selective areas | 144 | 8,983 | 29.0 | −0.13 |

Updated 2026-10-10. Partially selective schools now form their own sector (`partially_selective.csv`, 24 schools,
22 with A-level rows). Moving them out changes the non-selective rows only slightly: APS 34.0 → 33.9 and
29.2 → 29.0.

Raw A-level points are close between private and grammar sixth forms. Value added (conditional on GCSE
results, i.e. the post-16 effect only) is about +0.2 of a grade per entry for private schools and about zero
for grammars. Caveat: VA baselines use GCSEs only, so IGCSE-heavy private schools are partly missing from
the baseline (59 independents below 70% coverage, G4).

## 4. Earnings

- **ONS (LEO, PAYE at age 30, school at KS4):** independent / state non-FSM ratio rises along the
  distribution: 1.25 at P10, 1.45 at P50, 1.61 at P90, 1.72 at P95, **2.12 at P99** (£180.6k vs £85.2k).
  The private advantage is concentrated at the top. RAW; no grammar split.
- **RR1125 (LEO, 15 years after GCSEs, 2001/02 cohort):** mean earnings non-selective £23k,
  selective £33k, independent £35k; employment 60 / 67 / 60%; out-of-work benefits 8 / 2 / 2%. RAW.

## What P2 already tells the write-up
1. At the sixth-form stage, grammar and private schools look alike on raw outcomes, and grammars now beat
   private schools on Cambridge entry per student.
2. Private schools keep a measurable post-16 value-added edge (+0.2 grade per entry); grammars don't.
3. The private earnings advantage grows towards the top of the distribution, which is where the
   cost-benefit will be decided (the break-even at P90 is lowest).
