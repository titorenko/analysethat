# P3 findings: top-30 profiles, sector distributions, comprehensive overlay (2026-10-10)

## Scripts

Run in this order:
1. `code/analysis/select_top30.py`: gate G-pool.
2. `code/analysis/join_cambridge.py`: gate G-join.
3. `code/analysis/p3_profiles.py`.

## Outputs

`results/` holds:
- `p3_top30_independent.csv`
- `p3_top30_grammar.csv`
- `p3_sector_distributions.csv`
- `p3_universe.csv`: one row per eligible school; the overlay data.

## Gates
All of these pass on reruns done by me, not only by the agents:
- G2, G3, G4;
- G-pool;
- G-join, including the check that linked centres hold ≥95% of English-centre acceptances;
- G-fees;
- G-intake;
- G-partial;
- G-class, now complete. It checks that DfE and GIAS agree, applies the partially-selective list, and resolves
  the Cambridge-vs-GIAS sector disagreements by hand.

## Selection rules and changes since the plan

**Universe:**
- DfE 16-18 Academic cohort, with at least 40 students in both 2023/24 and 2024/25.
- Excludes schools with a statutory low age of 14 or more (sixth-form-only and 14-19 colleges).
- Excludes international/tutorial colleges: independents whose A-level VA coverage is below 0.5. This removes
  Abbey College Cambridge, DLD College and Concord College. Concord is confirmed as international by its 2021
  ISI report. As a result **Tonbridge entered the independent top 30**.

**Ranking** is by pooled APS per entry.

**Value added, its CI and coverage, and %AAB** come from the A-level cohort row, 2024/25. The first version took
VA from the Academic row; that is now fixed.

**Partially selective schools** form their own sector (24 schools, `partially_selective.csv`). They are kept out
of both the grammar list and the comprehensive comparator:
- Dame Alice Owen's (APS 47.6, VA +0.39) would otherwise rank about 14th among grammars.
- Their removal moves the comprehensive distribution only slightly.

**Cambridge per 100 leavers** pools cycles 2022-2025 against Academic-cohort leavers in 2021/22-2024/25:
- Each cycle is paired with its leavers' year under the same URN. A URN change had doubled Colchester RGS's rate
  in the first version.
- Suppressed cells enter as calibrated estimates, with bounds.

## Top 30: medians

| | Independent | Grammar |
|---|---|---|
| APS per entry (pooled) | 51.4 (A) | 47.2 (A−) |
| % A*/A (2024/25) | 80% | 66% |
| % AAB | 66% | 60% |
| 16-18 value added (grades per entry) | +0.20 (23 of 30 with CI above 0) | +0.05 (13 of 30 above 0, 3 below) |
| Cambridge applications per 100 leavers | 25.1 | 16.7 |
| Cambridge acceptances per 100 leavers | 6.8 | 4.9 |
| Fees 2026/27, senior day, incl. VAT | £31.3k (range £19.7k-£49.4k; Eton boarding only) | free (state) |
| Fee remissions (bursaries and discounts) / gross fees | 8.8% (5-17%; 24 schools with own accounts) | — |
| Year 7 intake: % high prior attainment (KS4 2023/24) | not published (no KS2) | 96% |
| Progress 8 (2023/24) | not published (IGCSE) | +1.02 |
| First preferences per offer (2026 entry) | — | 3.8 |

**Highest Cambridge acceptances per 100 leavers:**
- Independent: SPGS 16.0, Westminster 15.4, Magdalen College School 13.8.
- Grammar: QE Barnet 17.5, Henrietta Barnett 14.1, Colchester RGS 11.8.

**Fees vs value added:** within the independent top 30 the Spearman correlation is −0.11. Paying more does not
buy more measured value added.

## Where the top 30 sit in the comprehensive distribution (D4 overlay)

The comprehensive distribution is non-selective schools outside highly selective areas, 1,154 school sixth forms.

| Measure | Comprehensive P50 | Comprehensive P90 | Top-30 independent median, as a comprehensive percentile | Top-30 grammar median, as a comprehensive percentile |
|---|---|---|---|---|
| APS per entry | 33.2 | 38.2 | 100th | 99.8th |
| % A*/A | — | — | 99.9th | 99.8th |
| Value added | −0.02 | +0.24 | **87th** | **62nd** |
| Cambridge acceptances per 100 | 0.26 | 0.90 | 99.9th | 99.9th |

On raw results both lists sit entirely above the comprehensives. On value added, the top private schools sit at
the comprehensive 87th percentile and the top grammars at the 62nd. About 13% of comprehensive sixth forms add more
value than the median top-30 private school (0.20).

## Sector distributions (all eligible schools, 2024/25 VA)

| Sector | Schools | VA mean | VA P10 / P50 / P90 | Share with VA CI above 0 | Cambridge per 100, P50 / P90 |
|---|---|---|---|---|---|
| Independent | 302 | +0.20 | −0.06 / +0.21 / +0.45 | 64% | 1.0 / 4.2 |
| Grammar | 159 | −0.01 | −0.22 / +0.01 / +0.19 | 28% | 1.1 / 4.9 |
| Partially selective | 21 | −0.03 | −0.27 / −0.04 / +0.24 | 24% | 0.4 / 1.8 |
| Comprehensive (other areas) | 1,150 | −0.04 | −0.35 / −0.02 / +0.24 | 25% | 0.26 / 0.90 |
| Non-selective in highly selective areas | 91 | −0.16 | −0.54 / −0.14 / +0.19 | 17% | 0.12 / 0.56 |

## Caveats

- **Independent VA.** Baselines are GCSE only, so IGCSE-heavy schools are partly missing. Coverage is below 70%
  at 59 independents in the whole universe, but at only one top-30 school (Tonbridge, 0.68).
- **Grammar intake.** The super-selective flags are intake-side only:
  - yes 4, probable 5, no 14, unassessed 7 (Henrietta Barnett's `probable` is hand-set, see `grammar_super_selective.md`);
  - QE Barnet's tester counts come from its own admissions guide (confirmed 2026-10-12).
- **Remissions** cover bursaries, scholarships and staff discounts. Group-level figures (GDST, United Learning)
  are not school figures.
- **Cambridge rates by school** use the URN-linked apply centres. Unlinked English centres, mostly FE and tutorial
  colleges, hold about 3% of acceptances.
