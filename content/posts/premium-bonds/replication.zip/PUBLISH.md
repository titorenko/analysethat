# Publishing and monthly updates

## First publication (after the Budget on 28 October 2026)

1. Re-check `params/tax.json` against the Budget documents (savings rates, PSA, starting rate band, ISA limits,
   child benefit charge) and set `_checked` to the date checked. G-fresh fails until this is done.
2. Re-check the hand parameters: `params/gilt.json` (price within 35 days; pick the next low-coupon gilt once TN28
   is within about a year of maturity), `params/platform_fees.json` (`_checked` within 120 days).
3. (Once, on a new machine: `npm ci` in this folder, for the calculator's minifier.) `.venv/Scripts/python -I refresh.py` — fetches, runs every gate, rebuilds the post and replication.zip, prints
   the headline numbers.
4. In `writeup/article.md.tmpl` set `draft: false` and `date:` to the publication date; run
   `refresh.py --no-fetch` again.
5. Serve the site (`hugo server -D --port 1314` in `analysethat/`) and run
   `.venv/Scripts/python -I code/checks/g_tables.py http://127.0.0.1:1314/analysethat/posts/premium-bonds/`.
   Look at the page and the five figures, and try the calculator in section 1.3 (refresh.py's G-calc has already
   checked it against the engine and Tables 1 and 2; it needs the site's `pb-calc` shortcode).
6. With the owner's OK: commit `content/posts/premium-bonds/` in the analysethat repo and push.
7. `refresh.py --no-fetch --published` to record the published baseline for next month's diff.

## Monthly update (7th working day, or after an NS&I rate announcement)

1. `refresh.py` (exits cleanly if the Bank of England's row for last month is not out yet).
2. Read the headline diff (against the published baseline). If NS&I has announced a change for the next draw,
   the article says so automatically beside the current rate.
3. Steps 5-7 above; add an "Updated" line under the intro if a headline finding changed.
