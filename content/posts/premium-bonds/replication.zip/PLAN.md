# Premium Bonds vs bank deposits vs money market funds — research plan

**v2, 2026-10-11, after Fable review** (`review/FABLE_REVIEW.md`: 0 critical, 6 major, 15 minor;
dispositions in `review/DISPOSITIONS.md`: 21 accepted, 0 rejected). Evidence base: three scouting
files in `scouting/` (A Premium Bonds, B comparators and fees, C tax and protection). Numbers carry
the status tag they have there (VERIFIED / SECONDARY / UNVERIFIED / DERIVED). Planning arithmetic:
`planning/` (`pb_exact.py`, `oct2026_check.py`, `stakes.py`; `stakes.py` taxes the MMF after the
platform fee, which Fable showed overstates it by 5-15 bp; the engine fixes this, §4).

**Go-ahead.** The user asked for implementation straight after the review ("do not wait for my
review once fable comes in, implement"); D1-D7 take the recommended options. Commit, push and
publication still wait for the user.

**Two facts that shape everything.**
1. The contest is real and flips with **amount × tax position**. At today's rates (PB 4.35%,
   best clean easy access 4.52%), the chance that a year of Premium Bonds beats the best
   easy-access account after tax runs from 28% (basic rate, £10k, savings allowance unused) to
   89% (higher rate, £50k, allowance used) and ~100% (60% taper band, £50k) (`stakes.py`).
2. The Premium Bond rate does **not** follow Bank Rate with a fixed lag. Bank Rate has been 3.75%
   since 18 Dec 2025, yet the prize rate went 3.60 → 3.30 → 3.80 → 4.35% in 2026 (A §4-5). NS&I
   sets it against its Net Financing target (£15bn ± 4bn for 2026-27) and "the wider savings
   market". A Bank-Rate lag model would fail on 2026; the plan treats the lag descriptively.

---

## 0. Decisions (recommended options adopted)

| # | Decision | Options | Recommendation |
|---|---|---|---|
| D1 | Comparator set | (a) as asked: PB, bank deposits, RL money market fund; (b) (a) + NS&I Direct Saver (same Treasury guarantee) + one low-coupon short gilt (TN28) | **(b).** The low-coupon gilt is the main rival for 40%+ taxpayers (TN28 nets 4.23% at 40% tax, B §8) and is also government-backed; one row, not a deep dive. |
| D2 | Deposit benchmark | best "clean" easy access (no bonus, no withdrawal cap, open to all); headline best incl. bonus; market average; big-bank rate | **Clean best buy as the main benchmark** (today Cahoot 4.52%); BoE average advertised easy-access rate excl. bonuses (IUMB6VK, 1.90%) as context and big banks (~1%) as a sentence; 1-year fix (5.13%) as the lock-up option. |
| D3 | MMF platform | one platform or range | **AJ Bell 0.25% as the headline** (cheapest % platform that sells RL Y Acc); HL 0.35%, Fidelity, ii flat fee in a fee-by-pot table. |
| D4 | Tax year shown | 2026/27 only; + 2027/28 | **2026/27 headline + a 2027/28 column** (22/42/47% enacted in FA 2026 s.5; cash-ISA £12k cap SI 2026/1018). |
| D5 | Publication timing | publish when ready; wait for Budget on 28 Oct 2026 | **Build now, publish after 28 Oct**: the Budget can change every 2027/28 rule. |
| D6 | Interactivity | static tables and charts; + an embedded calculator | **Static.** `results/latest.json` exists only as the refresh-diff artefact. |
| D7 | Refresh | manual `refresh.py`; local Windows scheduled task monthly; GitHub Action | **`refresh.py` monthly on the 7th working day** (draw file out on the ~2nd, BoE quoted rates on the ~5th), plus manual runs after rate announcements. If the BoE row is not out it exits cleanly. It refreshes, gates and writes a diff; publishing stays a manual, asked-for step. |

---

## 1. Questions

**Q1 What does a Premium Bond holding really pay?** For £100 … £50,000 held 1, 2 and 5 years:
the full distribution of winnings (P(nothing), P10/P25/P50/P75/P90, mean), as % a year. The
headline is the median ("a typical holder"), not the 4.35% prize fund rate.

**Q2 Which wins, after all fees and taxes?** For each amount × tax position: net return of PB
(distribution) vs deposits, NS&I Direct Saver, cash ISA, RL money market fund (direct and in ISA),
low-coupon gilt (if D1b). Expressed three ways: net % a year; P(PB beats the alternative); and the
"tax-equivalent rate" a taxable account needs to match the PB median.

**Q3 Over the last two years?** Realised returns over the trailing 24 draws (today: Nov 2024 –
Oct 2026), same comparisons, using what each product actually paid month by month.

**Q4 How does the PB rate move relative to Bank Rate and the savings market?** Three per-cycle
facts (F16): 2022-23 rises (Bank Rate +500 bp from 16 Dec 2021; PB +365 bp, first move in the Jun
2022 draw, ~5 months later); 2024-25 cuts (PB cut first, Mar 2024 draw, seven months before the
first Bank Rate cut; then −135 bp vs −150 bp); 2026 (Bank Rate flat, PB +105 bp net). Plus spread
lines over time.

---

## 2. Premium Bond engine (replaces the old Monte Carlo)

**Old repo** (`C:\kostya\repo\premium-bonds`): Monte Carlo, binomial draws per prize band,
3×10⁵ samples × 88 passes on 22 processes; one hard-coded allocation (April 2020); quantiles
averaged across passes; a Dash web app (amount, luck, term pages).

**New: exact distribution by FFT** (`planning/pb_exact.py`, 40 lines). Each eligible £1 bond, each
draw, wins value v_k with p_k = n_k / N_eligible. All prizes are multiples of £25, so on a £25 grid
the total over B bonds and m draws has characteristic function Π_draws φ_d^B. One FFT, 0.3 s, no
sampling error. **Verified in planning:** reproduces the old Monte Carlo at the April 2020 table
(medians £0 / £75 / £450 for £1k / £10k / £50k) and MSE's published medians at the Oct 2026 table
(£350 / £925 / £1,900 for £10k / £25k / £50k; P(nothing) for £1k 56.5%).

Extensions needed:
- **Per-draw allocations**: product over the actual 24 draw tables for the trailing window (A §3:
  all 82 draws Jan 2020 – Oct 2026 parsed from the official zip headers, counts sum exactly).
- **Holding period**: 12, 24, 60 draws; % a year = total / amount / years.
- **Entry and exit timing, counted in draws** (A §1): a bond takes part in draw M if it was bought
  in month M−2 or earlier and is still held on the 1st of M; each draw is worth 4.35/12 = 0.36 pp at
  today's rate. An exactly-12-month holding gets 10 draws (bought on the 1st) or 11 (any other
  day); 12 needs a month-end purchase and a cash-in just after the 1st, 12 months and a few days
  later (F9). Cost at the median: £10k 350 → 325 → 300 for 12/11/10 draws; £50k 1,900 → 1,725 →
  1,575. The "new money" line uses 11 draws. An existing holding has no entry cost.
- **Reinvestment**: prizes reinvested enter the next draw; the mean compounds from 4.35% to 4.44%
  (A §7). At £10k, compound vs simple is ≈ £9 at 1 year, £37 at 2, £250 at 5. Multi-year rows use
  the expected bond path B_t = B₀(1 + r/12)^t, capped at £50k; against a true-reinvestment
  simulation this is within £50 at the median over 5 years (F11; stated in the method note). At
  £50k prizes are paid out; over several years that costs a few tens of pounds (F10, one clause).
- **P(nothing)** from the closed form (1 − Σp)^T, not the FFT cell (F7).
- **The £50k cap** per person; couples = two independent £50k holdings (one sentence).

## 3. Comparators: what each one actually pays, net of fees

| Product | Today (gross) | Fees | Source for "today" | Source for history |
|---|---|---|---|---|
| Premium Bonds | prize rate 4.35%; distribution from the allocation table | none; entry lag | NS&I allocation page + zip header | zip headers, 82 draws (A §3) |
| Best clean easy access | 4.52% (Cahoot Simple Saver) | none | Moneyfacts best-buy JSON (whole market, filterable) | hand-coded to the clean rule for the 24 window months only, from Moneyfacts/MSE Wayback, gaps carried forward and labelled (F4) |
| Average advertised easy access, excl. bonuses | 1.90% (BoE IUMB6VK, Sep) | none | BoE IADB | BoE IADB monthly since 2019 |
| Big-bank easy access | 0.75-2.1% | none | bank pages | a sentence |
| MSE headline easy access (context only) | 5.00% | — | — | MSE page titles via Wayback, 2021-26, labelled "headline incl. bonuses" |
| Best 1-year fix | 5.13% | access locked | Moneyfacts JSON | MSE Wayback + BoE IUMWTFA average |
| Cash ISA (easy / 1-y fixed) | ~4.75% (bonus) / 4.97% | allowance use | Moneyfacts JSON | MSE cash-ISA Wayback (complete 2021-25) |
| NS&I Direct Saver | 3.75% | none | NS&I | NS&I historical rates page |
| RL Short Term MMF, Y Acc | yield 3.95% gross of OCF (31 Aug) | OCF 0.10% in NAV + platform 0.25-0.35% or flat | RLAM page | FT daily NAV (net of OCF; cross-checks RLAM 5y TR to 0.002 pp) |
| Low-coupon gilt TN28 (D1b) | GRY 4.29% gross (94.79, HL) | AJ Bell £5 deal + 0.25% capped £42/yr: 0.29%/yr drag at £10k, 0.09% at £50k | dated hand parameter in `params/` (F14) | none; held to maturity (31 Jan 2028), one row at £10k/£50k (F15) |

Rules:
- **Today's rates = a one-year forward illustration "if today's rates held"**, said in those words.
- **One definition of "clean best buy"**, applied the same way to every month: easy access, no
  introductory bonus, no withdrawal limit, no linked current account, open to new customers
  nationally, minimum deposit ≤ £1,000, maximum balance ≥ £50,000 (F13), FSCS-protected deposit
  (MMF-backed "cash" excluded). Applied mechanically to the live Moneyfacts JSON; the 24 window months
  are hand-coded to the same rule from archived pages, each with its source URL. `refresh.py` appends
  each month's live result to `data/derived/bestbuy_history.csv`, so the archive is a one-off backfill.
- **Platform fee by pot size** (B §3): HL and AJ Bell marginal tiers per account; Fidelity whole-pot
  rate or £90 flat; ii flat £5.99/m → 0.07% at £100k but 1.2% at £6k. The MMF row uses each pot's
  actual effective fee, not a single %.
- **Trailing returns use today's platform tariffs throughout** (HL and ii changed in-window), stated.
- **MMF has no deposit protection** (B §1: mostly bank credit; C §9) — in the safety table, not
  priced.

## 4. Tax engine (all levels)

One function: tax(profile, interest) from a dated parameter file `params/tax_<year>.json`
(re-edited after each fiscal event; 28 Oct 2026 first). Net return = interest − [tax(with) −
tax(without)] − ANI-linked losses. Exact, not marginal-rate: the PSA and starting-rate band
depend on the amount, which is why a £10k higher-rate saver keeps all £452 of deposit interest.

**What is taxed** (F1): deposit interest in full; the MMF's distribution net of OCF (today's yield
3.95% − 0.10% = 3.85%; history: NAV total return), with the platform and dealing fees deducted
**after** tax; the gilt's coupon only (pull-to-par is CGT-exempt), fees after tax.

Inputs (C §1-4): PA and taper; 20/40/45 (2027/28: 22/42/47); starting rate £5,000 cut £1-for-£1;
PSA £1,000 / £500 / £0 set on total income incl. the interest; Scottish taxpayers use UK savings
rates and UK-band PSA, Scottish rates only on the lost-PA part of the taper (62.5%); HICBC 1% per
£200 over £60k (1/2/3 children); £100k childcare cliff (reported, not priced into %); student loan
9% on all unearned income over £2,000 for SA filers (flag only).

**Profiles shown** (F5: six, with "PSA free / used" only where it changes the answer):

| # | Profile | Income example | Marginal on interest (2026/27) |
|---|---|---|---|
| P0 | 0% taxpayer (pensioner on the State Pension, or low earner) | £12,548 / £15k | 0% on the first £6,022 / £3,570 of interest — covers every amount ≤ £50k at ≤ 5.13% |
| P1 | Basic rate, PSA free / used | £35k | 0% inside £1,000 PSA, then 20% |
| P2 | Higher rate, PSA free / used | £70k (no children) | 0% inside £500, then 40% |
| P3 | Higher rate + HICBC, 2 children | £70k | 11.7% inside the PSA / 51.7% above it (F17) |
| P4 | 60% taper band | £110k | 60% (62.5% Scotland), + £100k childcare cliff note |
| P5 | Additional rate | £150k | 45% |

Scotland is one sentence (a Scottish 42%-band saver on £43,663-50,270 pays 20% on interest and keeps
the £1,000 PSA). Scottish 2027/28 taper: "n/a until the Scottish Budget" (F20). Tables: one per
amount (£10k, £50k), profiles as rows, ≤ 5 product columns, so they fit at 768px.

Wrappers: cash ISA and MMF-in-ISA are tax-free and outside ANI, like PB; they are limited by the
£20k allowance (cash £12k for under-65s from Apr 2027; a stocks-and-shares ISA cannot be 100% MMF
from Apr 2027, C §7). The article states the ISA is the first answer for anyone with allowance left.

## 5. The last two years and the lag

- **Alignment rule**: draw M is the return for holding calendar month M−1 (eligibility is fixed on
  the 1st of M). So draws Nov 2024 – Oct 2026 pair with deposit, MMF and SONIA months Oct 2024 –
  Sep 2026. The refresh runs on the 7th working day, when both the draw file (~2nd) and the BoE row
  for M−1 (~5th) exist (F3).
- **Trailing realised returns**, Nov 2024 – Oct 2026 (rolls forward each month):
  PB actual draws (mean prize rate 3.78%, A §4) and the exact luck distribution over those 24
  draws; RL MMF from NAV (net of OCF), taxed, then platform fee; BoE average advertised easy access;
  a "best-buy chaser" who sits in the top clean easy-access account each month (upper bound on
  effort); 1-year fixes bought at the window start and rolled once. **Tax: two 12-month blocks**
  (Nov 24-Oct 25, Nov 25-Oct 26), each with one PSA and one starting-rate band (F2); the savings rules
  were identical across 2024/25-2026/27.
- **Monthly scoreboard**: for each of the last 24 months, which product would have won for each
  profile at that month's rates. "PB median" here is the median of a **12-draw** holding at that
  month's prize table (not one draw), at £10k and £50k, vs the after-tax clean best buy. This shows
  the lag without modelling it.
- **Lag, descriptively** (Q4): rates chart 2020-2026 (PB, Bank Rate, SONIA, BoE average advertised
  easy access excl. bonuses, MSE headline easy access labelled "incl. bonuses", BoE 1-y fixed bond
  average). **Spread lines** 2020-26: PB minus SONIA and PB minus the BoE average; PB minus the clean
  best buy only inside the 24-month window (F4). This matches how NS&I says it sets the rate, shows
  when PB is generous or stingy, and stays defined in 2026 when Bank Rate was flat. Plus the three
  per-cycle facts (Q4) and an event table of the 17 PB changes (announcement, first draw, nearest
  prior Bank Rate move, NS&I's stated reason). No regression.
- **Announced but not yet drawn** (F18): the headline uses the latest drawn table; if the allocation
  page's estimate implies another rate, the article prints "X% from the <month> draw (announced
  <date>)" beside it and the refresh diff flags it. No synthetic tables.

## 6. Data pipeline (updatable)

Folder `premium-bonds/` (study) → post bundle `analysethat/content/posts/premium-bonds/`.

- `code/fetch/` — monthly: `nsi.py` (zip headers by 16 KB range request, rate-history page,
  allocation page, product page), `markets.py` (BoE IADB: IUDBEDR, IUDSOIA, IUMB6VJ/VK, IUMWTFA,
  IUMB6VL, IUMB6VN, rejecting HTML-200; BoE month-end gilt curve; FT daily NAV of RL Y Acc, xid
  52606664; NS&I interest-rates page), `bestbuys.py` (Moneyfacts embedded JSON, clean filter).
  One-off: `wayback.py` (MSE page titles 2021-26; archived best-buy pages for the 24 window months),
  RLAM TR cross-check (F14). No CPI (F14). Each writes `data/raw/<source>/<date>/` + manifest.
- `params/`: `tax.json` (2024/25 … 2027/28, dated, with sources), `platform_fees.json`, `gilt.json`
  (TN28 price/yield, dated hand parameter), `bestbuy_window.csv` (hand-coded clean best buys).
- `code/engine/`: `pb_exact.py`, `tax.py`, `returns.py` (today and trailing).
- `code/figures/`, `writeup/article.md.tmpl` + `build_article.py` (every result number is a
  placeholder; `g_article.py` fails on any hand-typed result), as in schools.
- `refresh.py`: fetch → gates → rebuild → print a diff of headline numbers vs the last published
  build (`results/latest.json`). Publishing = asked-for commit/push.
- The article prints an "as of" date per input and the trailing window it used.

## 7. Gates

| Gate | Check |
|---|---|
| G-alloc | Each draw: 11 counts sum to the stated total and amount; amount × 12 / eligible = published rate (± 1e-4); band split 10/10/80 from Jan 2023 |
| G-pb | Exact engine: mass = 1; mean = prize rate exactly; matches the old Monte Carlo (April 2020) and MSE medians + closed-form P(nothing) at current rate; P(PB ≥ X) matches MSE's "chance of beating 4.55%" table within ±1 pp using MSE's PSA-inclusive thresholds (F8); expected-path reinvestment within £50 of a true-reinvestment simulation at the 5-year median |
| G-tax | Tax engine vs gov.uk/HMRC worked examples (starting rate: £16,000 wages → £1,570 band; PSA examples), the PSA cliff example (C §11), Scottish PSA case, HICBC, hand-worked T0-T6 cases. An external calculator is used only if it is shown to model the starting-rate band and PSA stacking |
| G-mmf | FT NAV 5-year return vs RLAM published cumulative TR (19.81%) within 0.01 pp (one-off, logged) |
| G-boe | Every series returns CSV with the expected code header; no blank latest row used; if the M−1 row is missing, exit "BoE row not yet published" |
| G-fresh | Every input carries an as-of date; refresh refuses to build if best buys > 14 days or the draw table is not the latest draw |
| G-article | No hand-typed result numbers; each chart title's claim asserted against its data |
| G-tables | `tools/check-tables.mjs` at 375, 768, 1366, 1920 (site rule) |

## 8. Article outline (finding-led headings written after results)

1. **The short version** — one ISA line ("if you have ISA allowance left, a cash ISA beats the
   typical Premium Bond holding") then a heat map for **taxable money** (F6): amount × tax position →
   the best home and by how much, after tax and fees, at today's rates.
2. **What Premium Bonds really pay** — luck fan by amount (P10-P90, median, P(nothing)); 1, 2, 5
   years; the advertised 4.35% vs what the typical holder gets; one line on why the median is lower
   (10% of the fund goes on prizes of £5k+, F21).
3. **After tax and fees, today** — one table per amount (£10k, £50k): profiles × ≤ 5 products;
   chance PB beats the best account; tax-equivalent rate.
4. **The fees that matter** — MMF platform fee by pot size; PB entry timing; gilt dealing.
5. **The last two years** — trailing realised returns; monthly scoreboard.
6. **Premium Bonds don't follow Bank Rate** — rates chart, spread lines, three cycle facts, event table.
7. **Safety and access** — Treasury guarantee vs FSCS £120k per licence vs MMF; withdrawals 3-5
   days; the £50k cap; what changes in April 2027.
8. **What this can't tell us** — future rates; individual circumstances beyond the profiles;
   best-buy history gaps; behaviour (switching effort).
9. **How this was done** — sources, as-of dates, refresh, replication code.

## 9. Phases

| Phase | Work | Exit |
|---|---|---|
| P1 | Fetchers + raw data + manifests; params files | G-alloc, G-boe, G-mmf PASS |
| P2 | Engines (PB exact incl. per-draw, tax) | G-pb, G-tax PASS |
| P3 | Today's comparison + trailing 24 months + lag tables | results/FINDINGS.md |
| P4 | Figures, template, build, refresh.py | G-article, G-tables PASS |
| P5 | Review round (Opus + Fable), fix | dispositions logged |
| P6 | Re-check tax after 28 Oct Budget; publish on user's OK | live |

## 10. Risks

- **Scrapers break** (Moneyfacts JSON and FT ajax are undocumented). Fallbacks: MSE page for best
  buys; RLAM TR for the MMF; refresh fails loudly rather than publishing stale numbers.
- **Best-buy history has holes** (Apr-25, Apr-26, Aug-26 in MSE; B §5b): carry forward, mark.
- **Quoted yields aren't comparable** (RL 3.95% gross of OCF; AJ Bell 3.84% undefined): use RLAM's
  defined redemption yield minus OCF for "today", realised NAV for history.
- **NS&I page contradicts itself** on the rate's start date (A §8): read the rate-history page.
