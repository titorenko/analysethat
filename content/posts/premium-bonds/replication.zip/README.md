# Replication files: Premium Bonds vs savings accounts, money market funds and gilts

Contents
- code/fetch     downloads every source (logged to data/manifest with URL, date, HTTP status, bytes, sha256)
- code/derive    builds the tidy tables in data/derived (NS&I draws and rates, Bank of England series, fund prices,
                 best buys with the "clean" filter)
- code/engine    pb.py (exact Premium Bond distribution by FFT), tax.py (savings tax, all bands), gilt.py,
                 inputs.py (today's inputs)
- code/analysis  today.py (today's comparison), trailing.py (last 24 draws), lag.py (rates history)
- code/checks    gates: G-alloc, G-boe/G-mmf, G-pb, G-tax, G-fresh, G-article (log in logs/gates.md)
- code/figures   figures and the article (article_values.py computes every number in it)
- params         tax rules by year, platform fees, the gilt price, protection limits, prize-rate events,
                 the hand-coded best-buy history (with source URLs)
- data/raw/nsi_draws/history  the first 16 KB of each NS&I winning-numbers file (prize counts per draw)
- refresh.py     the monthly run: fetch, derive, gates, analysis, figures, article

Run (Python 3.13, pip install -r requirements.txt; always python -I): refresh.py, or the steps it lists in order.
Not included (third-party data; the fetchers re-download them): the FT daily fund prices, the Moneyfacts market
listings and MoneySavingExpert page text. The picks and rates the article uses are included.
Sources are public: NS&I, Bank of England, Moneyfacts and MoneySavingExpert (best buys, current and archived),
Royal London, FT (fund prices), Hargreaves Lansdown (gilt prices), gov.uk and legislation.gov.uk (tax rules).
