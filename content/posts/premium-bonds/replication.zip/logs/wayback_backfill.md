# Wayback backfill: best buys for the window and MSE headline titles (2026-10-11)

Code: `code/fetch/wayback.py` (`cdx`, `fetch`, `titles`, `mf`). Raw files, CDX indexes and pages are in
`data/raw/wayback/2026-10-11/`, with one manifest row per file in `data/manifest/wayback.csv`. Outputs:
`params/bestbuy_window.csv`, `params/bestfix_window.csv`, `data/derived/mse_headline_titles.csv`.
Scope: the coordinator extended `bestfix_window.csv` from 2 months to all 24 (Oct 2024 to Sep 2026).

## Coverage
- MSE titles: 66 of 69 months (Jan 2021 to Sep 2026). There is no 200 capture for Apr 2025, Apr 2026 or Aug 2026; those attempts got 301, 403 or 404. Every title parsed; no headline field is blank.
- Easy access (24 months): 22 from moneyfacts_json, 1 mse_hand (Sep 2026), 1 carried_forward (Aug 2026).
- 1-year fix (24 months): 19 from moneyfacts_json, 3 mse_hand (Oct 2024, Jun 2026, Sep 2026), 2 carried_forward (Apr 2025, Aug 2026).
- Holes: Aug 2026 has no capture of any of the three pages. Apr 2025 has no fixed-rate page and no MSE page. Moneyfacts has no capture after 24 Jul 2026.
- Every non-carried rate was re-checked against its capture with a script. The 41 Moneyfacts rows must match the named account exactly, at that AER, with no bonus, no sharia flag and no platform; the 4 MSE rows must show the provider and rate in the page text. All 45 passed.
- `data/manifest/wayback.csv` has two rows for `cdx_mfc_fixed.json`: the first query covered Oct 2024 to Oct 2025, then it was re-queried for all 24 months. Only the second sha256 matches the file on disk.

## Capture traps
- Archived pages can be cut off at exactly 1 MiB or 5 MiB, and the HTML still looks valid. Validation therefore requires `</html>` plus a JSON body that parses. Failed captures:
  - Moneyfacts easy access, 13 Oct and 7 Oct 2024.
  - Moneyfacts fixed, 6 Nov 2024, 9 Feb 2025, and both 18 May 2026 captures.
  - In each case the next capture was used.
- Moneyfacts summary JSON depends on a search amount, and leaves out products whose min/max exclude it. The amounts were:
  - £1,000: Oct 2024 and Apr 2025. These are filtered URLs, the only usable captures in those months.
  - £25,000 (the default) until Jan 2026; the Nov 2025 filtered URL is also £25,000.
  - £20,000 from Feb 2026.
  - None from Jul 2026, when the schema changed: `IntroBonusNote` and `TermInDays` = 0, so 1-year bonds are matched on `Term`.
- Summary `MinimumInvestment` is 0 for almost every product, and there is no max or withdrawal field after 2023. So min, max, withdrawal terms and eligibility come from the per-product detail where it is embedded (2024 only), otherwise from MSE prose.
- Moneyfacts was preferred over MSE whenever it had a capture in the month, even when that capture is early or late: Dec 2024 (4th), Dec 2025 (5th), Jun 2025 (24th), Jul 2025 (26th), Jul 2026 fixed (24th).

## Judgement calls
- The clean rule is applied by code to the Moneyfacts JSON for: bonus note, sharia flag, FSCS flag, notice, and names stating limited access. Everything else is checked by hand against the same month's MSE page, or the nearest one; the evidence is in `notes`.
- Platform and intermediary accounts are excluded as a membership/linked-account requirement. MSE files them as non-standard. This covers Raisin, Flagstone, HL Active Savings, Prosper, Meteor, NuWealth, and Snoop via Bondsmith (Snoop also needs an open-banking link to your current account). Where one would have won, `notes` names it. The cases: Monument via Raisin 4.87% (Oct and Nov 2024), Snoop 4.60% (Jun to Aug 2025), Mizrahi via Flagstone 4.85% fix (Oct 2024), Ziraat via Raisin 4.80% fix (Nov 2024), Prosper 4.86% fix (Jun 2026).
- "Max one withdrawal per day" counts as a withdrawal limit. Same-month evidence beats adjacent months: Chetwood stands in Dec 2024 (MSE calls it unlimited), is out in Jan 2025 (MSE: one per day), and is out in May 2025 (the nearest evidence is Feb).
- REVISED 2026-10-11 (article review): Chetwood is now excluded in every month, including Dec 2024 (Secure Trust Bank 4.65% instead of Chetwood 4.71%), so the hand backfill and the live filter apply one rule; exclusions are not dated. This overrides MSE's 13 Dec 2024 page; effect on the two-year chaser about 0.25 bp.
- A rate that drops in any month with a withdrawal (Atom Instant Saver Reward) counts as a withdrawal penalty, so it is excluded.
- Credit-union fixes (Castle Community Bank) need membership of a group, so they are excluded. LHV and Revolut accounts need the provider's current account (Revolut also has paid tiers), so they are excluded.
- A higher Moneyfacts survivor whose terms appear in no archived source was skipped and named in `notes`. The cases: Scottish BS E-Saver Plus and UBL Digital (Jan 2025), Manchester BS Rainy Day (Jan to Mar 2026), Newcastle BS 6 Month Variable (Feb and Mar 2026), Rova (Feb 2026 fix).
- Variable accounts that mature after a year with no bonus (cahoot Simple Saver, Leeds) count as clean, consistent with the plan's own cahoot benchmark. A minimum withdrawal size (£100) is not a limit. App-only is allowed.
- Product-line evidence from another issue or term is accepted for min/max, and cited in `notes`. The cases: Kent Reliance (Apr 2025), Vanquis (Jan 2025), JN and DF Capital fixes from other terms, and the Marcus, Kent Reliance and Birmingham Bank fixes from other months.
- A min of exactly the limit counts as passing: SmartSave fix, min £10,000.
- `max_balance` = `none` means MSE states there is no maximum (Chetwood).
- NS&I bonds are Treasury-backed, not FSCS deposits, but none ever topped a month, so the point never arose.

## Spot-checks (Moneyfacts vs MSE)
- **Oct 2024 (agree):** Moneyfacts 4 Oct: Vanquis Easy Access 4.85%, detail min £1,000, max £250,000. MSE 8 Oct: "our top pick is Vanquis Bank … 4.85% … £1,000+", min £1,000, max £250,000.
- **Nov 2024 (one-day split):** Moneyfacts 14 Nov: Vanquis 4.85% (effective since 30 Sep). MSE 15 Nov: Vanquis 4.65%, with Leeds BS 4.67% as the clean top. Moneyfacts is kept as the preferred source. The 18 bp gap is the size of a mid-month rate cut.
- **Oct 2025 (re-issue between captures):** Moneyfacts 13 Oct: cahoot Simple Saver Issue 13 at 4.40%, effective 9 Oct. MSE 8 Oct: the earlier issue at 4.2%. MSE 14 Nov: 4.4%, min £1, max £500,000, which confirms Moneyfacts.
- **Fixed, Jun 2025 (exact):** Moneyfacts 20 Jun and MSE 20 Jun both show Cynergy 4.55%, min £1,000, max £1m.

## Headline-title series
`mse_headline_titles.csv` is mechanical: it is the `<title>` of the capture nearest the 15th (days 1-20 preferred). The figures include bonus, small-balance and current-account-linked accounts, and fixes of any term. Some months use a query-string variant of the URL (tracking tags, same page); `source_url` keeps it.
