
## G-tax (savings tax engine) — PASS (2026-10-11T10:21:34+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-alloc (NS&I draw tables) — PASS (2026-10-11T10:22:15+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-pb (exact Premium Bond engine) — FAIL (2026-10-11T10:22:37+00:00)
Sources: data/derived/pb_draws.csv

- FAIL mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- FAIL MSE P(nothing) 95/57/6%: got [94, 56, 6]
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvestment path vs true reinvestment, £10k over 60 draws: path median £2,125 vs simulation £2,075

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T10:22:48+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvestment path vs true reinvestment, £10k over 60 draws: path median £2,125 vs simulation £2,075

## G-boe (Bank of England series) — PASS (2026-10-11T10:23:52+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T10:23:52+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-article (no hand-typed result numbers in the write-up template) — FAIL (2026-10-11T10:36:31+00:00)
Sources: writeup/article.md.tmpl

- FAIL no hand-typed result numbers: 61 literal numbers, 23 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 139 placeholders

  - £1,000,: …00 for a year and half of holders win less than   ( ). With £1,000,   win nothing at all. Only at the £50,0…
  - £50,000,: … chance of any prize of £5,000 or more in a year is  ; with £50,000,  . Take those away and the typical hold…
  - £25,: …£50,000,  . Take those away and the typical holder lives on £25, £50 and £100 prizes.  Because every bon…
  - 0%: …art of one-year Premium Bond returns by amount held: median 0% at £1k,   at £5k,   at £10k,   at £25k …
  - £1k: … one-year Premium Bond returns by amount held: median 0% at £1k,   at £5k,   at £10k,   at £25k and   a…
  - £5k: …Premium Bond returns by amount held: median 0% at £1k,   at £5k,   at £10k,   at £25k and   at £50k, al…
  - £10k: …nd returns by amount held: median 0% at £1k,   at £5k,   at £10k,   at £25k and   at £50k, all below the…
  - £25k: …by amount held: median 0% at £1k,   at £5k,   at £10k,   at £25k and   at £50k, all below the   prize fu…
  - £50k: …: median 0% at £1k,   at £5k,   at £10k,   at £25k and   at £50k, all below the   prize fund rate.]]  **…
  - £50,000,: …, open to new customers anywhere in the UK, taking at least £50,000, with deposit protection. Bonus-boosted …
  - 60%: …savers who have used their allowance, up to   points in the 60% band at £50k.]]  In   of the   combinat…
  - £50k: …ave used their allowance, up to   points in the 60% band at £50k.]]  In   of the   combinations the typi…
  - £50,000,: …used.** On £10,000 the typical holder is   points ahead; on £50,000,  . - **The 60% band and the additional …
  - 60%: …he typical holder is   points ahead; on £50,000,  . - **The 60% band and the additional rate: Premium B…
  - £10,000,: …ersonal allowance.  **Table 4. Return after tax and fees on £10,000, % a year, today's rates held for a year…
  - £100,: …n and repays £100 at maturity. Low-coupon gilts trade below £100, and the rise to £100 is a capital gain …
  - £50,000,: …d at   a year), it returns  -  a year on £10,000 and  -  on £50,000, whatever your tax band (Tables 4 and 5)…
  - 1%: … chart, monthly 2020-2026: the Premium Bond rate rises from 1% in 2022 to   in 2023, then falls to   i…
  - 2%: …mium Bonds in 2026; the average easy-access rate stays near 2%.]]  NS&I sets the prize rate to raise a…
  - £10k: …produces MoneySavingExpert's published medians ( ,  ,   for £10k, £25k and £50k) and its chance-of-beati…
  - £25k: …es MoneySavingExpert's published medians ( ,  ,   for £10k, £25k and £50k) and its chance-of-beating tab…
  - £50k: …avingExpert's published medians ( ,  ,   for £10k, £25k and £50k) and its chance-of-beating table to wit…
  - 2.1: …oneyfacts' best-buy tables (filtered by the rule in section 2.1), with archived pages for the past; ave…

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T10:36:43+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 57 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 142 placeholders

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T10:37:10+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T10:52:05+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 57 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 142 placeholders

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T10:54:12+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 58 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 145 placeholders

## G-alloc (NS&I draw tables) — PASS (2026-10-11T10:56:00+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-boe (Bank of England series) — PASS (2026-10-11T10:56:00+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T10:56:00+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T10:56:01+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvestment path vs true reinvestment, £10k over 60 draws: path median £2,125 vs simulation £2,075

## G-tax (savings tax engine) — PASS (2026-10-11T10:56:01+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T10:56:02+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T10:56:07+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 58 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 145 placeholders

## G-bestbuy (live filter reproduces the backfill) — FAIL (2026-10-11T11:04:10+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- FAIL captures tested: 2 months (0 skipped: old schema)
- FAIL filter reproduces the backfill: 1 of 2 (50%)

  - fixed_1y 2026-07: backfill OakNorth Bank 4.91; filter Marcus by Goldman Sachs® 4.9

## G-bestbuy (live filter reproduces the backfill) — FAIL (2026-10-11T11:04:48+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS captures tested: 41 months (0 skipped: old schema)
- FAIL filter reproduces the backfill: 17 of 41 (41%)

  - easy_access 2024-10: backfill Vanquis Bank 4.85; filter cahoot 5.0
  - easy_access 2024-12: backfill Chetwood Bank 4.71; filter Monument Bank 4.81
  - easy_access 2025-01: backfill Vanquis Bank 4.5; filter Chetwood Bank 4.66
  - easy_access 2025-02: backfill Charter Savings Bank 4.57; filter Coventry BS 4.66
  - easy_access 2025-03: backfill GB Bank 4.6; filter Revolut 5.0
  - easy_access 2025-04: backfill Kent Reliance 4.64; filter cahoot 5.0
  - easy_access 2025-05: backfill Charter Savings Bank 4.46; filter Revolut 5.0
  - easy_access 2025-06: backfill cahoot 4.55; filter Snoop 4.6
  - easy_access 2025-07: backfill cahoot 4.55; filter Snoop 4.6
  - easy_access 2025-08: backfill cahoot 4.55; filter Snoop 4.6
  - easy_access 2025-09: backfill cahoot 4.4; filter Revolut 4.5
  - easy_access 2025-10: backfill cahoot 4.4; filter Revolut 4.5
  - easy_access 2025-11: backfill cahoot 4.4; filter Revolut 4.5
  - easy_access 2026-01: backfill Spring (Paragon Bank) 4.11; filter Manchester BS 4.25
  - easy_access 2026-02: backfill Spring (Paragon Bank) 4.11; filter Manchester BS 4.15
  - easy_access 2026-03: backfill cahoot 4.05; filter Coventry BS 4.15
  - easy_access 2026-04: backfill cahoot 4.17; filter LHV Bank 4.25
  - fixed_1y 2024-12: backfill Habib Bank Zurich 4.8; filter Vida Savings 4.77
  - fixed_1y 2025-05: backfill Cynergy Bank 4.55; filter LHV Bank 4.65
  - fixed_1y 2025-07: backfill GB Bank 4.58; filter Castle Community Bank 4.59
  - fixed_1y 2025-11: backfill Habib Bank Zurich 4.44; filter LHV Bank 4.46
  - fixed_1y 2026-02: backfill Cynergy Bank 4.24; filter Rova 4.25
  - fixed_1y 2026-04: backfill MBNA 4.66; filter Castle Community Bank 4.7
  - fixed_1y 2026-07: backfill OakNorth Bank 4.91; filter Marcus by Goldman Sachs® 4.9

## G-bestbuy (live filter reproduces the backfill) — FAIL (2026-10-11T11:05:28+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- FAIL backfill pick passes every live rule: 1 months fail
- FAIL every higher-ranked product is explained in the notes: 3 months fail

  - easy_access 2025-03: live filter rejects the backfill pick: platform product (platform)
  - easy_access 2025-02: not explained: Coventry BS
  - easy_access 2025-11: not explained: Revolut
  - easy_access 2026-03: not explained: Coventry BS

## G-bestbuy (live filter reproduces the backfill) — FAIL (2026-10-11T11:06:16+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS backfill pick passes every live rule: 0 months fail
- FAIL every higher-ranked product is explained in the notes: 1 months fail

  - easy_access 2025-02: not explained: West Brom BS

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:06:30+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

## G-alloc (NS&I draw tables) — PASS (2026-10-11T11:08:01+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-boe (Bank of England series) — PASS (2026-10-11T11:08:01+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T11:08:01+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T11:08:03+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvestment path vs true reinvestment, £10k over 60 draws: path median £2,125 vs simulation £2,075

## G-tax (savings tax engine) — PASS (2026-10-11T11:08:03+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:08:04+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T11:08:05+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T11:08:10+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 58 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 145 placeholders

## G-alloc (NS&I draw tables) — PASS (2026-10-11T11:08:59+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-boe (Bank of England series) — PASS (2026-10-11T11:08:59+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T11:08:59+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T11:09:00+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvestment path vs true reinvestment, £10k over 60 draws: path median £2,125 vs simulation £2,075

## G-tax (savings tax engine) — PASS (2026-10-11T11:09:01+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:09:02+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T11:09:03+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T11:09:08+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 58 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 145 placeholders

## G-bestbuy (live filter reproduces the backfill) — FAIL (2026-10-11T11:30:10+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- FAIL backfill pick passes every live rule: 1 months fail
- FAIL every higher-ranked product is explained in the notes: 1 months fail

Live filter on the archived capture alone picks a different rate in 7 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2024-12: filter Monument Bank 4.81 vs backfill Chetwood Bank 4.71
  - easy_access 2025-01: filter The Co-operative Bank 4.59 vs backfill Vanquis Bank 4.5
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64
  - fixed_1y 2024-12: filter Vida Savings 4.77 vs backfill Habib Bank Zurich 4.8
  - fixed_1y 2025-11: filter DF Capital 4.41 vs backfill Habib Bank Zurich 4.44
  - fixed_1y 2026-07: filter Marcus by Goldman Sachs® 4.9 vs backfill OakNorth Bank 4.91
  - easy_access 2024-12: live filter rejects the backfill pick: at most one withdrawal a day
  - easy_access 2025-01: not explained: The Co-operative Bank

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:31:23+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 6 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-01: filter Scottish BS 4.51 vs backfill Vanquis Bank 4.5
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64
  - fixed_1y 2024-12: filter Vida Savings 4.77 vs backfill Habib Bank Zurich 4.8
  - fixed_1y 2025-11: filter DF Capital 4.41 vs backfill Habib Bank Zurich 4.44
  - fixed_1y 2026-07: filter Marcus by Goldman Sachs® 4.9 vs backfill OakNorth Bank 4.91

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:31:49+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:31:59+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS live filter picks the backfill's rate in at least 90% of months: 39 of 41
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:33:19+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS live filter picks the backfill's rate in at least 90% of months: 39 of 41
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-alloc (NS&I draw tables) — PASS (2026-10-11T11:33:33+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-boe (Bank of England series) — PASS (2026-10-11T11:33:33+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T11:33:33+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T11:33:35+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvestment path vs true reinvestment, £10k over 60 draws: path median £2,125 vs simulation £2,075

## G-tax (savings tax engine) — PASS (2026-10-11T11:33:35+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:33:36+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS live filter picks the backfill's rate in at least 90% of months: 39 of 41
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T11:33:37+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — FAIL (2026-10-11T11:33:42+00:00)
Sources: writeup/article.md.tmpl

- FAIL no hand-typed result numbers: 69 literal numbers, 2 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 156 placeholders

  - 20%: …ding for every saver. For anyone whose interest is taxed at 20% or less, a one-year fixed account ( ) b…
  - 40%: …, and for most savers on £10,000. Once interest is taxed at 40% or more, the gilt wins, because its ret…

## G-tax (savings tax engine) — PASS (2026-10-11T11:35:42+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS HICBC averaged over the £200 step: £500 inside the PSA costs £500 / £200 × 1% of £2,337.40: got £58.43, expected £58.44 (average of the law's steps)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-pb (exact Premium Bond engine) — FAIL (2026-10-11T11:35:43+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- FAIL reinvested mean (expected path) vs true reinvestment, £10k over 60 draws: path £2,425 vs simulation £2,442

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T11:36:13+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvested mean (expected path) vs true reinvestment, £10k over 60 draws: path £2,425 vs simulation £2,442 (standard error £18; rare big prizes)

## G-alloc (NS&I draw tables) — PASS (2026-10-11T11:39:29+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-boe (Bank of England series) — PASS (2026-10-11T11:39:30+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T11:39:30+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T11:39:31+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvested mean (expected path) vs true reinvestment, £10k over 60 draws: path £2,425 vs simulation £2,442 (standard error £18; rare big prizes)

## G-tax (savings tax engine) — PASS (2026-10-11T11:39:31+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS HICBC averaged over the £200 step: £500 inside the PSA costs £500 / £200 × 1% of £2,337.40: got £58.43, expected £58.44 (average of the law's steps)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:39:33+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS live filter picks the backfill's rate in at least 90% of months: 39 of 41
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T11:39:34+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — FAIL (2026-10-11T11:39:40+00:00)
Sources: writeup/article.md.tmpl

- FAIL no hand-typed result numbers: 66 literal numbers, 1 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 175 placeholders

  - £200: …e allowance and   above it, on average (the charge rises in £200 steps). - **The 60% band: Premium Bonds…

## G-alloc (NS&I draw tables) — PASS (2026-10-11T11:39:52+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-boe (Bank of England series) — PASS (2026-10-11T11:39:52+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T11:39:52+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T11:39:54+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvested mean (expected path) vs true reinvestment, £10k over 60 draws: path £2,425 vs simulation £2,442 (standard error £18; rare big prizes)

## G-tax (savings tax engine) — PASS (2026-10-11T11:39:54+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS HICBC averaged over the £200 step: £500 inside the PSA costs £500 / £200 × 1% of £2,337.40: got £58.43, expected £58.44 (average of the law's steps)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:39:56+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS live filter picks the backfill's rate in at least 90% of months: 39 of 41
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T11:39:56+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T11:40:02+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 65 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 176 placeholders

## G-alloc (NS&I draw tables) — PASS (2026-10-11T11:40:47+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-boe (Bank of England series) — PASS (2026-10-11T11:40:47+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T11:40:47+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T11:40:49+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvested mean (expected path) vs true reinvestment, £10k over 60 draws: path £2,425 vs simulation £2,442 (standard error £18; rare big prizes)

## G-tax (savings tax engine) — PASS (2026-10-11T11:40:49+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS HICBC averaged over the £200 step: £500 inside the PSA costs £500 / £200 × 1% of £2,337.40: got £58.43, expected £58.44 (average of the law's steps)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:40:51+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS live filter picks the backfill's rate in at least 90% of months: 39 of 41
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T11:40:51+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T11:40:57+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 65 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 176 placeholders

## G-tables (tables fit, site rule) — PASS (2026-10-11T11:41:18+00:00)
Sources: C:\kostya\blog\analysethat\tools\check-tables.mjs

- PASS all four widths measured: 4 widths
- PASS 375px: page does not scroll sideways: page overflow false
- PASS 768px: page does not scroll sideways: page overflow false
- PASS 768px: no table scrolls: 0 of 11 tables scroll
- PASS 1366px: page does not scroll sideways: page overflow false
- PASS 1366px: no table scrolls: 0 of 11 tables scroll
- PASS 1920px: page does not scroll sideways: page overflow false
- PASS 1920px: no table scrolls: 0 of 11 tables scroll

## G-alloc (NS&I draw tables) — PASS (2026-10-11T11:42:08+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-boe (Bank of England series) — PASS (2026-10-11T11:42:09+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T11:42:09+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T11:42:10+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvested mean (expected path) vs true reinvestment, £10k over 60 draws: path £2,425 vs simulation £2,442 (standard error £18; rare big prizes)

## G-tax (savings tax engine) — PASS (2026-10-11T11:42:10+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS HICBC averaged over the £200 step: £500 inside the PSA costs £500 / £200 × 1% of £2,337.40: got £58.43, expected £58.44 (average of the law's steps)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:42:12+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS live filter picks the backfill's rate in at least 90% of months: 39 of 41
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T11:42:13+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T11:42:19+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 65 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 176 placeholders

## G-alloc (NS&I draw tables) — PASS (2026-10-11T11:44:32+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-boe (Bank of England series) — PASS (2026-10-11T11:44:32+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T11:44:32+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T11:44:34+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvested mean (expected path) vs true reinvestment, £10k over 60 draws: path £2,425 vs simulation £2,442 (standard error £18; rare big prizes)

## G-tax (savings tax engine) — PASS (2026-10-11T11:44:34+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS HICBC averaged over the £200 step: £500 inside the PSA costs £500 / £200 × 1% of £2,337.40: got £58.43, expected £58.44 (average of the law's steps)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:44:36+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS live filter picks the backfill's rate in at least 90% of months: 39 of 41
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T11:44:36+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T11:44:43+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 65 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 176 placeholders

## G-alloc (NS&I draw tables) — PASS (2026-10-11T11:56:05+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-boe (Bank of England series) — PASS (2026-10-11T11:56:06+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T11:56:06+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T11:56:07+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvested mean (expected path) vs true reinvestment, £10k over 60 draws: path £2,425 vs simulation £2,442 (standard error £18; rare big prizes)

## G-tax (savings tax engine) — PASS (2026-10-11T11:56:07+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS HICBC averaged over the £200 step: £500 inside the PSA costs £500 / £200 × 1% of £2,337.40: got £58.43, expected £58.44 (average of the law's steps)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:56:09+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS live filter picks the backfill's rate in at least 90% of months: 39 of 41
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T11:56:10+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T11:56:16+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 68 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 176 placeholders

## G-tables (tables fit, site rule) — PASS (2026-10-11T11:56:28+00:00)
Sources: C:\kostya\blog\analysethat\tools\check-tables.mjs

- PASS all four widths measured: 4 widths
- PASS 375px: page does not scroll sideways: page overflow false
- PASS 768px: page does not scroll sideways: page overflow false
- PASS 768px: no table scrolls: 0 of 11 tables scroll
- PASS 1366px: page does not scroll sideways: page overflow false
- PASS 1366px: no table scrolls: 0 of 11 tables scroll
- PASS 1920px: page does not scroll sideways: page overflow false
- PASS 1920px: no table scrolls: 0 of 11 tables scroll

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T11:56:30+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS live filter picks the backfill's rate in at least 90% of months: 39 of 41
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-alloc (NS&I draw tables) — PASS (2026-10-11T12:02:10+00:00)
Sources: data/derived/pb_draws.csv; data/derived/pb_allocation_page.csv

- PASS counts sum to stated total: 82 draws
- PASS value sums to stated amount: 82 draws
- PASS prizes × odds = amount × 12 / rate: max relative gap 8.6e-07
- PASS bands 10/10/80 from Jan 2023: higher 0.1000-0.1000, medium 0.1000-0.1000
- PASS bands 5/5/90 before Jan 2023: higher 0.0500-0.0500
- PASS allocation page = zip header for the current draw: draw 2026-10
- PASS no missing months: 82 of 82 from 2020-01 to 2026-10

Next-draw estimate (2026-11) implies rate 4.3500% at the current odds (latest drawn rate 4.35%).

## G-boe (Bank of England series) — PASS (2026-10-11T12:02:11+00:00)
Sources: data/derived/boe_monthly.csv

- PASS all series present: IUMB6VJ, IUMB6VK, IUMWTFA, IUMB6VL, IUMB6VN, bank_rate_end, sonia_month_return
- PASS row for 2026-09 published: complete
- PASS 24 window months complete: 24 months

## G-mmf (FT NAV vs RLAM total return) — PASS (2026-10-11T12:02:11+00:00)
Sources: data/derived/rl_nav.csv; data/derived/rl_rlam.csv

- PASS 5 years 2021-08-31 → 2026-08-28: RLAM 19.8051% vs FT NAV 19.8080%
- PASS 2 years 2024-08-30 → 2026-08-28: RLAM 8.8674% vs FT NAV 8.8659%

## G-pb (exact Premium Bond engine) — PASS (2026-10-11T12:02:12+00:00)
Sources: data/derived/pb_draws.csv

- PASS mass = 1: 1.000000001200
- PASS mean = 12 draws × £50k × rate/12: FFT £2,175.00 vs £2,175.00
- PASS each table's own rate = NS&I rate: max gap 1.6e-13 over 82 draws
- PASS old Monte Carlo medians £0/£75/£450: got [0, 75, 450]
- PASS old Monte Carlo £10k P10/P90 £25/£150: got [25, 150]
- PASS MSE medians £0/£350/£925/£1,900: got [0, 350, 925, 1900] (draw 2026-10)
- PASS MSE P(nothing) 95/57/6% (whole %, ±1 pp): got 94.4%, 56.5%, 5.7%
- PASS MSE chance of beating 4.55%: non-taxpayer £100: P(≥ £5) 5.6% vs MSE 6%
- PASS MSE chance of beating 4.55%: non-taxpayer £1k: P(≥ £46) 35.0% vs MSE 35%
- PASS MSE chance of beating 4.55%: non-taxpayer £5k: P(≥ £228) 29.5% vs MSE 30%
- PASS MSE chance of beating 4.55%: non-taxpayer £30k: P(≥ £1,365) 26.9% vs MSE 27%
- PASS MSE chance of beating 4.55%: non-taxpayer £50k: P(≥ £2,275) 25.6% vs MSE 26%
- PASS MSE chance of beating 4.55%: basic £30k: P(≥ £1,292) 32.7% vs MSE 33%
- PASS MSE chance of beating 4.55%: basic £50k: P(≥ £2,020) 40.9% vs MSE 41%
- PASS MSE chance of beating 4.55%: higher £30k: P(≥ £1,019) 61.4% vs MSE 61%
- PASS MSE chance of beating 4.55%: higher £50k: P(≥ £1,565) 76.9% vs MSE 77%
- PASS reinvested mean (expected path) vs true reinvestment, £10k over 60 draws: path £2,425 vs simulation £2,442 (standard error £18; rare big prizes)

## G-tax (savings tax engine) — PASS (2026-10-11T12:02:12+00:00)
Sources: params/tax.json

- PASS gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free: got £0.00, expected £0.00 (gov.uk/apply-tax-free-interest-on-savings)
- PASS same, £100 more interest at 20%: got £20.00, expected £20.00 (hand)
- PASS State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free: got £0.00, expected £0.00 (C §4 PROBE)
- PASS same, +£100 at 20%: got £20.00, expected £20.00 (hand)
- PASS basic rate £35k: £1,000 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS basic rate £35k: £2,000 → £1,000 at 20%: got £200.00, expected £200.00 (hand)
- PASS higher rate £70k: £500 inside PSA: got £0.00, expected £0.00 (PSA s.12B)
- PASS higher rate £70k: £2,260 → £1,760 at 40%: got £704.00, expected £704.00 (Fable scratch §7)
- PASS Scottish £47k: UK-band PSA £1,000, 20% above it: got £100.00, expected £100.00 (ITA s.11D(6), s.12B(8))
- PASS taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%: got £400.00, expected £400.00 (hand: 20% inside PSA, 60% above)
- PASS taper £110k Scotland: £500 lost PA at 45% + £500 at 40%: got £425.00, expected £425.00 (hand: 62.5% above PSA)
- PASS taper £110k: £2,260 → Fable's £1,156: got £1,156.00, expected £1,156.00 (Fable scratch §7)
- PASS additional £150k: 45% from the first £: got £450.00, expected £450.00 (PSA nil)
- PASS HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40: got £46.75, expected £46.75 (gov.uk HICBC + CB rates)
- PASS 2027/28 basic rate £35k: £2,000 → £1,000 at 22%: got £220.00, expected £220.00 (FA 2026 s.5)
- PASS HICBC averaged over the £200 step: £500 inside the PSA costs £500 / £200 × 1% of £2,337.40: got £58.43, expected £58.44 (average of the law's steps)
- PASS PSA cliff, £1,200 interest: total tax £7,326.00, expected £7,326.00 (C §11)
- PASS PSA cliff, £1,300 interest: total tax £7,452.00, expected £7,452.00 (C §11)

## G-bestbuy (live filter reproduces the backfill) — PASS (2026-10-11T12:02:14+00:00)
Sources: params/bestbuy_window.csv; params/bestfix_window.csv

- PASS months tested: 41 archived captures
- PASS live filter picks the backfill's rate in at least 90% of months: 39 of 41
- PASS backfill pick passes every live rule: 0 months fail
- PASS every higher-ranked product is explained in the notes: 0 months fail

Live filter on the archived capture alone picks a different rate in 2 of 41 months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit limit, which one archived search amount cannot test):
  - easy_access 2024-10: filter cahoot 5.0 vs backfill Vanquis Bank 4.85
  - easy_access 2025-04: filter cahoot 5.0 vs backfill Kent Reliance 4.64

## G-fresh (inputs recent enough to publish) — PASS (2026-10-11T12:02:14+00:00)
Sources: data/derived; params

- PASS latest draw table is current: latest 2026-10, expected 2026-10
- PASS allocation page agrees: page 2026-10
- PASS best buys ≤ 14 days old: snapshot 2026-10-11
- PASS fund yield ≤ 70 days old: as at 2026-08-28
- PASS gilt price ≤ 35 days old (hand parameter): as of 2026-10-09
- PASS platform fees checked ≤ 120 days ago: checked 2026-10-11
- PASS tax rules checked after the latest fiscal event: checked 2026-10-11; Budget 2026-10-28

## G-article (no hand-typed result numbers in the write-up template) — PASS (2026-10-11T12:02:20+00:00)
Sources: writeup/article.md.tmpl

- PASS no hand-typed result numbers: 68 literal numbers, 0 not in ALLOWED
- PASS no unfinished markers (TODO, XXX): template text
- PASS placeholders present: 176 placeholders
