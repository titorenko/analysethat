"""Monthly refresh: fetch → derive → gates → analysis → figures → article → diff (PLAN §6, D7).

Run on or after the 7th working day of the month (the draw file is out by the ~2nd, the Bank of England's quoted
rates for the previous month by the ~5th), and after any NS&I rate announcement. Stops cleanly if the BoE row is
not out yet. Never commits or publishes: the diff of headline numbers against the last build is printed for review,
and publishing stays a manual step.

Usage: .venv/Scripts/python -I refresh.py [--no-fetch] [--bundle <dir>] [--published]
  --published   record this build's headline numbers as the published baseline (run once, when publishing), so the
                next month's diff compares against what readers saw, not against a test build.
"""
import argparse
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
PY = sys.executable
BUNDLE = ROOT.parent / "analysethat" / "content" / "posts" / "premium-bonds"
FETCH = ["code/fetch/nsi.py", "code/fetch/markets.py", "code/fetch/bestbuys.py"]
DERIVE = ["code/derive/nsi_derive.py", "code/derive/markets_derive.py", "code/derive/bestbuys_derive.py"]
GATES = ["code/checks/g_alloc.py", "code/checks/g_markets.py", "code/checks/g_pb.py", "code/checks/g_tax.py",
         "code/checks/g_bestbuy.py", "code/checks/g_fresh.py"]
ANALYSIS = ["code/analysis/today.py", "code/analysis/lag.py", "code/analysis/trailing.py"]
HEADLINE = ["pb_rate", "draw_month", "easy_rate", "fix_rate", "isa_easy_rate", "mmf_net_ocf", "gilt_gry", "med_10k",
            "med_50k", "nothing_1k", "margin_zero_10k", "margin_basic_used_50k", "margin_higher_used_10k",
            "margin_higher_used_50k", "margin_additional_50k", "beat_higher_used_50k", "gilt_min_50k", "gilt_max_50k",
            "below_sonia_months", "next_draw_note"]


def run(script, *args):
    r = subprocess.run([PY, "-I", str(ROOT / script), *args], cwd=ROOT)
    return r.returncode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-fetch", action="store_true")
    ap.add_argument("--bundle", default=str(BUNDLE))
    ap.add_argument("--published", action="store_true")
    a = ap.parse_args()
    for s in ([] if a.no_fetch else FETCH) + DERIVE:
        if run(s):
            sys.exit(f"stopped: {s} failed")
    for s in GATES:
        rc = run(s)
        if rc == 2:
            sys.exit("stopped cleanly: a source for last month is not published yet; rerun in a few days")
        if rc:
            sys.exit(f"stopped: gate {s} failed (see logs/gates.md)")
    for s in ANALYSIS:
        if run(s):
            sys.exit(f"stopped: {s} failed")
    for s, args in (("code/figures/make_figures.py", [a.bundle]), ("code/figures/build_article.py", [a.bundle]),
                    ("code/checks/g_article.py", ["writeup/article.md.tmpl"]),
                    ("code/package_replication.py", [str(pathlib.Path(a.bundle) / "replication.zip")])):
        if run(s, *args):
            sys.exit(f"stopped: {s} failed")
    sys.path.insert(0, str(ROOT / "code" / "figures"))
    from article_values import values  # noqa: E402
    v = values()
    now = {k: v[k] for k in HEADLINE}
    base_path = ROOT / "results" / "published.json"
    last = json.loads(base_path.read_text(encoding="utf-8")) if base_path.exists() else {}
    changed = {k: (last.get(k), now[k]) for k in HEADLINE if last.get(k) != now[k]}
    print("\nHeadline changes since the published version:" if changed else
          "\nNo headline changes since the published version.")
    for k, (old, new) in changed.items():
        print(f"  {k}: {old} → {new}")
    (ROOT / "results" / "latest.json").write_text(json.dumps(now, indent=2, ensure_ascii=False), encoding="utf-8")
    if a.published:
        base_path.write_text(json.dumps(now, indent=2, ensure_ascii=False), encoding="utf-8")
        print("Recorded as the published baseline.")
    print(f"\nBuilt {a.bundle}/index.md. Review, then publish by hand (commit and push the analysethat repo).")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
