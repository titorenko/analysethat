"""Paths and the Gate helper shared by derive/, engine/ and checks/."""
import datetime as dt
import pathlib
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")   # Windows console is cp1252

ROOT = pathlib.Path(__file__).resolve().parents[2]          # .../premium-bonds
RAW, DER, RES, PARAMS = ROOT / "data" / "raw", ROOT / "data" / "derived", ROOT / "results", ROOT / "params"
GATES_LOG = ROOT / "logs" / "gates.md"
PRIZES = [1_000_000, 100_000, 50_000, 25_000, 10_000, 5_000, 1_000, 500, 100, 50, 25]
MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
          "November", "December"]


def ym(text):
    """'September 2026' -> '2026-09'."""
    name, year = text.split()
    return f"{int(year)}-{MONTHS.index(name.capitalize()) + 1:02d}"


def rel(p):
    try:
        return str(pathlib.Path(p).resolve().relative_to(ROOT)).replace("\\", "/")
    except ValueError:
        return str(p)


class Gate:
    """Collects PASS/FAIL lines, prints them, appends a section to logs/gates.md, returns an exit code."""

    def __init__(self, name, sources):
        self.name, self.sources, self.lines, self.failed, self.notes = name, sources, [], 0, []

    def check(self, label, ok, detail):
        self.failed += not ok
        self.lines.append(f"- {'PASS' if ok else 'FAIL'} {label}: {detail}")
        print(self.lines[-1])

    def note(self, text):
        self.notes.append(text)
        print(text)

    def finish(self):
        GATES_LOG.parent.mkdir(parents=True, exist_ok=True)
        stamp = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
        verdict = "FAIL" if self.failed else "PASS"
        with GATES_LOG.open("a", encoding="utf-8") as f:
            f.write(f"\n## {self.name} — {verdict} ({stamp})\n")
            f.write("Sources: " + "; ".join(rel(p) for p in self.sources) + "\n\n")
            f.write("\n".join(self.lines) + "\n")
            if self.notes:
                f.write("\n" + "\n".join(self.notes) + "\n")
        print(f"{self.name}: {verdict}")
        return 1 if self.failed else 0
