"""Parse NS&I raw files into tidy tables.

  data/derived/pb_draws.csv       one row per draw (Jan 2020 on): amount, total prizes, the 11 prize counts,
                                  rate and odds in force, eligible bonds derived as amount x 12 / rate
  data/derived/pb_rates.csv       rate history: first draw, prize fund rate, odds
  data/derived/pb_allocation_page.csv  the allocation page: current draw and next-draw estimate

Usage: .venv/Scripts/python -I code/derive/nsi_derive.py
"""
import html
import pathlib
import re
import struct
import sys
import zlib

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "fetch"))
from common import DER, PRIZES, RAW, ym  # noqa: E402
from fetch import latest  # noqa: E402


def zip_text(b):
    """First file of a zip from its first bytes: local header, skip a directory entry, raw-inflate."""
    assert b[:4] == b"PK\x03\x04", "not a zip local header"
    off = 0
    while True:
        _, _, method, _, _, _, _, _, nlen, xlen = struct.unpack("<HHHHHIIIHH", b[off + 4:off + 30])
        name = b[off + 30:off + 30 + nlen].decode("latin-1")
        start = off + 30 + nlen + xlen
        if not name.endswith("/"):
            break
        off = b.find(b"PK\x03\x04", start)
    data = b[start:]
    return (zlib.decompressobj(-15).decompress(data) if method == 8 else data).decode("latin-1")


def parse_header(t):
    draw = re.search(r"PRIZE DRAW\s+(\w+ \d{4})", t).group(1)
    m = re.search(r"amount for distribution is \W?([\d,]+) which sum gives.*?total of ([\d,]+) prizes", t, re.S)
    counts = {int(v.replace(",", "")): int(c.replace(",", ""))
              for c, v in re.findall(r"([\d,]+) prizes? ?(?:\(s\))? of \W?([\d,]+)", t)}
    row = {"draw": ym(draw), "amount": int(m.group(1).replace(",", "")), "total_prizes": int(m.group(2).replace(",", ""))}
    row.update({f"n_{v}": counts.get(v, 0) for v in PRIZES})
    return row


def rate_history():
    page = latest("nsi_pages", "historical-interest-rates.html").read_text(encoding="utf-8", errors="replace")
    i = page.find("Prize draw effective from")
    table = page[i:page.find("</table>", i)]
    rows = re.findall(r"<td>(\w+ \d{4})</td><td>([\d.]+)%</td><td>([\d,]+) to 1</td>", table)
    rates = pd.DataFrame([{"first_draw": ym(d), "rate": round(float(r) / 100, 6), "odds": int(o.replace(",", ""))}
                          for d, r, o in rows]).sort_values("first_draw").reset_index(drop=True)
    return rates


def allocation_page():
    page = latest("nsi_pages", "monthly-prize-allocation.html").read_text(encoding="utf-8", errors="replace")
    i = page.find('<table class="table table-hover">')
    table = page[i:page.find("</table>", i)]
    heads = re.findall(r'<th scope="col">([^<]*)</th>', table)
    cur, est = ym(re.sub(" draw", "", heads[2])), ym(re.sub("Estimated | draw", "", heads[3]))
    out = []
    for tr in re.findall(r"<tr>(.*?)</tr>", table, re.S)[1:]:
        tds = [html.unescape(re.sub(r"<[^>]+>|<!--.*?-->", "", td)).strip() for td in re.findall(r"<td>(.*?)</td>", tr, re.S)]
        label = tds[1].replace("�", "").replace("£", "")
        val = 1_000_000 if "million" in label else (int(label.replace(",", "")) if label.replace(",", "").isdigit() else None)
        key = f"n_{val}" if val else ("total_prizes" if "Total prizes" in tds[0] else "amount")
        num = lambda s: int(re.sub(r"[^\d]", "", s))  # noqa: E731
        out.append({"key": key, cur: num(tds[2]), est: num(tds[3])})
    t = pd.DataFrame(out).set_index("key").T
    t.index.name = "draw"
    t.insert(0, "kind", ["actual", "estimate"])
    return t.reset_index()


def main():
    DER.mkdir(parents=True, exist_ok=True)
    rates = rate_history()
    rates.to_csv(DER / "pb_rates.csv", index=False)
    heads = sorted((RAW / "nsi_draws" / "history").glob("head_*.bin"))
    draws = pd.DataFrame([parse_header(zip_text(p.read_bytes())) for p in heads]).sort_values("draw")
    idx = rates.set_index("first_draw")
    draws["rate"] = [idx.rate[idx.index <= d].iloc[-1] for d in draws.draw]
    draws["odds"] = [idx.odds[idx.index <= d].iloc[-1] for d in draws.draw]
    draws["eligible"] = (draws.amount * 12 / draws.rate).round().astype("int64")
    draws.to_csv(DER / "pb_draws.csv", index=False)
    alloc = allocation_page()
    alloc.to_csv(DER / "pb_allocation_page.csv", index=False)
    print(f"{len(draws)} draws {draws.draw.min()}..{draws.draw.max()}; {len(rates)} rate rows; allocation page:",
          list(alloc.draw))


if __name__ == "__main__":
    main()
