"""Parse market raw files into tidy monthly tables.

  data/derived/boe_monthly.csv     month, quoted household rates (IUMB6VJ/VK instant access incl./excl. bonuses,
                                   IUMWTFA 1-year fixed bond, IUMB6VL variable cash ISA, IUMB6VN 1-year fixed ISA),
                                   Bank Rate at month end and month average, SONIA month average and compounded
                                   monthly return
  data/derived/rl_nav.csv          RL Short Term MMF Y Acc: daily NAV (FT, pence, net of OCF)
  data/derived/rl_rlam.csv         RLAM monthly cumulative total return (Y Acc) and today's redemption yield
  data/derived/gilt_spot.csv       BoE nominal spot curve at month ends: 1-year and 2-year
  data/derived/nsi_direct_saver.csv  NS&I Direct Saver rate history

Usage: .venv/Scripts/python -I code/derive/markets_derive.py
"""
import datetime as dt
import html
import io
import json
import pathlib
import re
import sys
import zipfile

import openpyxl
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "fetch"))
from common import DER  # noqa: E402
from fetch import latest  # noqa: E402


def boe():
    m = pd.read_csv(latest("boe", "boe_monthly.csv"))
    m["month"] = pd.to_datetime(m.DATE, format="%d %b %Y").dt.strftime("%Y-%m")
    m = m.drop(columns="DATE").set_index("month")
    d = pd.read_csv(latest("boe", "boe_daily.csv"))
    d["date"] = pd.to_datetime(d.DATE, format="%d %b %Y")
    d["month"] = d.date.dt.strftime("%Y-%m")
    d = d.dropna(subset=["IUDBEDR"])
    g = d.groupby("month")
    m["bank_rate_end"] = g.IUDBEDR.last()
    m["bank_rate_avg"] = g.IUDBEDR.mean()
    s = d.dropna(subset=["IUDSOIA"]).copy()
    # SONIA accrues on calendar days: each published rate applies until the next business day
    s["days"] = (s.date.shift(-1) - s.date).dt.days.fillna(1)
    s["growth"] = 1 + s.IUDSOIA / 100 * s.days / 365
    gs = s.groupby("month")
    m["sonia_avg"] = gs.IUDSOIA.mean()
    m["sonia_month_return"] = gs.growth.prod() - 1
    m.sort_index().to_csv(DER / "boe_monthly.csv")
    return m


def ft_nav():
    rows = []
    for p in sorted(latest("ft_nav").glob("rl_stmmf_y_acc_*.json")):
        frag = json.loads(p.read_text(encoding="utf-8"))["html"]
        for tr in re.findall(r"<tr>(.*?)</tr>", frag, re.S):
            tds = re.findall(r"<td[^>]*>(.*?)</td>", tr, re.S)
            day = re.search(r'hide-small-below">([^<]+)</span>', tds[0]).group(1)
            close = float(tds[4].replace(",", ""))
            rows.append({"date": dt.datetime.strptime(day, "%A, %B %d, %Y").date().isoformat(), "nav": close})
    nav = pd.DataFrame(rows).drop_duplicates("date").sort_values("date")
    nav.to_csv(DER / "rl_nav.csv", index=False)
    return nav


def rlam():
    h = latest("rlam", "rl_stmmf.html").read_text(encoding="utf-8", errors="replace")
    ry = float(re.search(r'\["Redemption yield","([\d.]+)%"\]', h).group(1)) / 100
    i = h.find('"share_class_plots"')
    plots, _ = json.JSONDecoder().raw_decode(h[i + len('"share_class_plots":'):])
    longest = max((p for p in plots if p["calculation_basis"] == "TR-NUKTAX"), key=lambda p: len(p["data"]))
    tr = pd.DataFrame([{"month_end": dt.datetime.fromtimestamp(t / 1000, dt.timezone.utc).date().isoformat(),
                        "cum_tr_pct": v} for t, v in longest["data"]])
    tr["redemption_yield"] = ry
    tr["as_at"] = tr.month_end.iloc[-1]
    tr.to_csv(DER / "rl_rlam.csv", index=False)
    return tr


def gilt_spot():
    z = zipfile.ZipFile(latest("boe", "glcnominalmonthedata.zip"))
    rows = []
    for name in z.namelist():
        if "1970" in name:
            continue
        ws = openpyxl.load_workbook(io.BytesIO(z.read(name)), read_only=True, data_only=True)["4. spot curve"]
        it = list(ws.iter_rows(values_only=True))
        mats = list(it[3])
        c1, c2 = mats.index(1), mats.index(2)
        for r in it[4:]:
            if isinstance(r[0], dt.datetime) and r[0].year >= 2019:
                rows.append({"month": r[0].strftime("%Y-%m"), "gilt_1y": r[c1], "gilt_2y": r[c2]})
    g = pd.DataFrame(rows).drop_duplicates("month").sort_values("month")
    g.to_csv(DER / "gilt_spot.csv", index=False)
    return g


def direct_saver():
    h = latest("nsi_pages", "historical-interest-rates.html").read_text(encoding="utf-8", errors="replace")
    i = h.find("historic_interest_ds")
    table = h[h.find("<table", i):h.find("</table>", h.find("<table", i))]
    rows = []
    for tr in re.findall(r"<tr>(.*?)</tr>", table, re.S):
        tds = [html.unescape(re.sub(r"<[^>]+>", "", t)).strip() for t in re.findall(r"<td[^>]*>(.*?)</td>", tr, re.S)]
        if len(tds) >= 2 and re.match(r"\d{1,2} \w+ \d{4}", tds[0]):
            rows.append({"from": dt.datetime.strptime(tds[0], "%d %B %Y").date().isoformat(),
                         "rate": round(float(tds[1].rstrip("%")) / 100, 6)})
    t = pd.DataFrame(rows).sort_values("from")
    t.to_csv(DER / "nsi_direct_saver.csv", index=False)
    return t


def cpi():
    j = json.loads(latest("ons", "d7g7.json").read_text(encoding="utf-8"))
    last = j["months"][-1]
    t = pd.DataFrame([{"month": last["date"], "cpi_annual": float(last["value"]) / 100,
                       "released": last.get("updateDate", "")}])
    t.to_csv(DER / "cpi.csv", index=False)
    return t


def main():
    cpi()
    m = boe()
    nav = ft_nav()
    tr = rlam()
    g = gilt_spot()
    ds = direct_saver()
    print(f"BoE months {m.index.min()}..{m.index.max()}; NAV {nav.date.min()}..{nav.date.max()} ({len(nav)} days); "
          f"RLAM TR to {tr.month_end.iloc[-1]}, redemption yield {tr.redemption_yield.iloc[0]:.2%}; "
          f"gilt curve to {g.month.max()}; Direct Saver {len(ds)} rows, now {ds.rate.iloc[-1]:.2%}")


if __name__ == "__main__":
    main()
