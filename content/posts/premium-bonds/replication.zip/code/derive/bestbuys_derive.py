"""Clean best buys from the Moneyfacts whole-market JSON (PLAN §3 rule), today's snapshot.

Clean = easy access (or a 1-year fixed term); no introductory bonus; no withdrawal limit (product names flag
Limited/Single/Double/Triple/Dual access and similar); no current-account, membership, regional or occupational
condition; not a platform or intermediary product (Moneyfacts' PlatformTick / PlatformCompany: Raisin, Flagstone,
HL Active Savings ...); not a business, children's or regular-saver account; FSCS-protected deposit; not sharia
"expected profit"; not offshore. Deposit limits are tested by Moneyfacts' own search: a clean easy-access account
must be listed at both £1,000 and £50,000 (fixed: £10,000 and £50,000; cash ISAs: £1,000/£10,000 and £20,000,
the annual allowance). Accounts that fail on a condition the JSON does not show are listed in
params/bestbuy_exclusions.csv with the reason and source.

Writes data/derived/bestbuys_today.csv (each category's top products down to the clean pick, with the reason
each was passed over) and appends the picks to data/derived/bestbuy_history.csv (one row per category per day).

Usage: .venv/Scripts/python -I code/derive/bestbuys_derive.py
"""
import json
import pathlib
import re
import sys

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "fetch"))
from common import DER, PARAMS  # noqa: E402
from fetch import latest  # noqa: E402

CATEGORIES = {  # category: (test on the product record, search amounts it must appear at). In whole-market
    # results NoticeInDays is always 0; the Notice text ("None", "95 Day") and AccountType are reliable.
    "easy_access": (lambda p: p["AccountType"] == "Variable" and p["Notice"] == "None" and not p["Term"], (1_000, 50_000)),
    "fixed_1y": (lambda p: p["AccountType"] == "Fixed" and p["Term"] in ONE_YEAR, (10_000, 50_000)),
    "isa_easy": (lambda p: p["AccountType"] == "Cash ISA" and p["Notice"] == "None" and not p["Term"], (1_000, 20_000)),
    "isa_fixed_1y": (lambda p: p["AccountType"] == "Cash ISA" and p["Term"] in ONE_YEAR, (10_000, 20_000)),
}
ONE_YEAR = ("1 Year Bond", "12 Month Bond")         # older captures say "12 Month Bond"
LIMITED = re.compile(r"limited|single|double|dual|triple|access[- ]one|\b(?:\d+|one|two|three|four|five|six) access|1 withdrawal|withdrawals? (?:per|a) |"
                     r"regular sav|"
                     r"loyalty|existing customer|members?\b|teacher|police|nhs|forces|club|reward|bonus|boost|"
                     r"business|charity|affinity|junior|child|kids", re.I)
CONDITION = re.compile(r"current account|existing|member|resident|live in|postcode|branch only|local|"
                       r"customers? of|invitation|aged? \d|over \d\d|employee|powered by|\bvia\b|"
                       r"monthly fee|subscription|paid plan", re.I)
CAP = re.compile(r"(?:up to|to|maximum(?: of)?)\s*\W?([\d,]+)", re.I)
SPECIAL = ("IsChildrensAccount", "IsJuniorISA", "IsLifetimeISA", "IsHelpToBuyISA", "IsRegularSavingsAccount",
           "IsRegularSavingsISA", "IsRegularSavingsChildrensAccount")


def normalise(p):
    """Older captures (before mid-2026) use other field names and lack some fields."""
    p.setdefault("MoneyfactsID", p.get("Id"))
    p.setdefault("IntroBonusNote", p.get("IntroductoryBonusNote"))
    p.setdefault("Notice", "None" if not p.get("NoticeInDays") else f"{p['NoticeInDays']} Day")
    p.setdefault("IsISA", False)
    p.setdefault("ShariaaTick", bool(p.get("IsSharia") or p.get("IsShariaa")))
    p.setdefault("IsFSCSProtected", True)
    return p


def products(path):
    h = path.read_text(encoding="utf-8", errors="replace")
    i = h.find('"Results":[{"AllProducts"')
    arr, _ = json.JSONDecoder().raw_decode(h[i + len('"Results":'):])
    seen, out = set(), []
    for r in arr:
        for p in r["AllProducts"]:
            p = normalise(p)
            if p["MoneyfactsID"] not in seen:
                seen.add(p["MoneyfactsID"])
                out.append(p)
    return out


def exclusions():
    """(provider substring, product substring, reason): hand exclusions carried over from the backfill's notes."""
    ex = pd.read_csv(PARAMS / "bestbuy_exclusions.csv", keep_default_na=False)
    return [(r.provider.lower(), r.product_contains.lower(), r.reason) for r in ex.itertuples()]


def reject_reason(p, excl):
    text = " ".join(str(p.get(k) or "") for k in ("ProductName", "KeyInformation", "IntroBonusNote", "EasyOpeningNote"))
    prov, prod = p["ProviderName"].lower(), p["ProductName"].lower()
    for e_prov, e_prod, reason in excl:
        if e_prov in prov and e_prod in prod:
            return reason
    if p.get("IntroBonusNote"):
        return "introductory bonus"
    if p.get("PlatformTick") or p.get("PlatformCompany"):
        return f"platform product ({p.get('PlatformCompany') or 'platform'})"
    if any(p.get(k) for k in SPECIAL):
        return "children's, regular-saver or special ISA"
    if p.get("ShariaaTick"):
        return "sharia expected profit"
    if not p.get("IsFSCSProtected", True) or p.get("IsOffshore"):
        return "not FSCS / offshore"
    if LIMITED.search(p["ProductName"]):
        return "limited access or special group (name)"
    if CONDITION.search(text):
        return "eligibility condition (notes)"
    caps = [int(c.replace(",", "")) for c in CAP.findall(text) if c.replace(",", "").isdigit()]
    if caps and max(caps) < 50_000:
        return f"maximum £{max(caps):,} (notes)"
    return None


def pick(lists, category, excl, audit=None):
    """Top clean product of a category. `lists` maps search amount -> products; a product must be listed at every
    amount the category requires (amounts missing from `lists`, as in a single archived capture, are not tested)."""
    test, amounts = CATEGORIES[category]
    have = [a for a in amounts if a in lists] or [next(iter(lists))]
    ids = [{p["MoneyfactsID"] for p in lists[a]} for a in have]
    base = {p["MoneyfactsID"]: p for p in lists[have[-1]]}
    for p in sorted((p for p in base.values() if test(p)), key=lambda p: -p["AER"]):
        why = reject_reason(p, excl)
        if why is None and (p.get("MinimumInvestment") or 0) > amounts[0]:     # the field, where filled, is reliable
            why = f"minimum £{p['MinimumInvestment']:,.0f}"
        if why is None:
            missing = [a for a, s in zip(have, ids) if p["MoneyfactsID"] not in s]
            why = f"not listed at £{missing[0]:,}" if missing else None
        if audit is not None:
            audit.append({"category": category, "aer": p["AER"], "provider": p["ProviderName"], "product": p["ProductName"],
                          "verdict": why or "CLEAN"})
        if why is None:
            return p
    return None


def main():
    snap = latest("moneyfacts")
    lists = {a: products(snap / f"market_{a}.html") for a in (1_000, 10_000, 20_000, 50_000)}
    excl, audit, picks = exclusions(), [], []
    for cat in CATEGORIES:
        p = pick(lists, cat, excl, audit)
        picks.append({"snapshot": snap.name, "category": cat, "aer": p["AER"], "provider": p["ProviderName"],
                      "product": p["ProductName"], "source": "moneyfacts_json"})
    pd.DataFrame(audit).assign(snapshot=snap.name).to_csv(DER / "bestbuys_today.csv", index=False)
    hist = DER / "bestbuy_history.csv"
    old = pd.read_csv(hist, dtype={"snapshot": str}) if hist.exists() else pd.DataFrame()
    new = pd.concat([old, pd.DataFrame(picks)]).drop_duplicates(["snapshot", "category"], keep="last")
    new.to_csv(hist, index=False)
    for p in picks:
        print(f"{p['category']:<13} {p['aer']:.2f}%  {p['provider']}: {p['product']}")


if __name__ == "__main__":
    main()
