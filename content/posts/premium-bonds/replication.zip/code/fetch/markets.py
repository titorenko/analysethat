"""Market raw data: Bank of England IADB (Bank Rate, SONIA, quoted household deposit rates), the BoE month-end
nominal gilt curve, the Royal London Short Term Money Market Fund (FT daily NAV of the Y Acc class, RLAM page
with monthly total return), the ONS CPI annual rate and NS&I's interest-rates page (Direct Saver etc.).

Usage: .venv/Scripts/python -I code/fetch/markets.py
"""
import datetime as dt
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import fetch  # noqa: E402

IADB = ("https://www.bankofengland.co.uk/boeapps/database/_iadb-fromshowcolumns.asp?csv.x=yes&Datefrom=01/Jan/{y}"
        "&Dateto=now&SeriesCodes={codes}&CSVF=TN&UsingCodes=Y&VPD=Y&VFD=N")
DAILY = ["IUDBEDR", "IUDSOIA"]                       # Bank Rate, SONIA
MONTHLY = ["IUMB6VJ", "IUMB6VK", "IUMWTFA", "IUMB6VL", "IUMB6VN"]   # quoted: instant access (incl./excl. bonus),
#                                                      1-year fixed bond, variable cash ISA, 1-year fixed cash ISA
GILT_CURVE = "https://www.bankofengland.co.uk/-/media/boe/files/statistics/yield-curves/glcnominalmonthedata.zip"
FT = ("https://markets.ft.com/data/equities/ajax/get-historical-prices?startDate={a}&endDate={b}&symbol={xid}")
FT_FUNDS = {"rl_stmmf_y_acc": 52606664}              # GB00B8XYYQ86, xid from the FT tearsheet
RLAM = ("https://www.rlam.com/uk/intermediaries/funds/fund-centre/royal-london-short-term-money-market-fund/")
NSI_RATES = "https://www.nsandi.com/interest-rates"
CPI = "https://www.ons.gov.uk/economy/inflationandpriceindices/timeseries/d7g7/mm23/data"   # CPI 12-month rate
START = 2020


def csv_with(codes):
    def check(content):
        head = content[:200].decode("latin-1")
        return None if head.startswith("DATE," + codes[0]) else f"not an IADB csv: {head[:60]!r}"
    return check


def has(token):
    return lambda content: None if token in content else f"missing {token!r}"


def main():
    today = dt.date.today()
    for name, codes in (("boe_daily.csv", DAILY), ("boe_monthly.csv", MONTHLY)):
        print(fetch("boe", IADB.format(y=START, codes=",".join(codes)), name, note=",".join(codes),
                    validate=csv_with(codes)))
    print(fetch("boe", GILT_CURVE, "glcnominalmonthedata.zip", note="BoE nominal curve, month ends", validate=has(b"PK")))
    for fund, xid in FT_FUNDS.items():
        for y in range(START, today.year + 1):
            a, b = dt.date(y, 1, 1), min(dt.date(y, 12, 31), today)
            print(fetch("ft_nav", FT.format(a=a.strftime("%Y/%m/%d"), b=b.strftime("%Y/%m/%d"), xid=xid),
                        f"{fund}_{y}.json", note=f"FT daily NAV {fund} {y}", validate=has(b'"html"'), pause=1))
    print(fetch("rlam", RLAM, "rl_stmmf.html", note="RLAM fund page (share_class_plots: monthly cumulative TR)",
                validate=has(b"share_class_plots")))
    print(fetch("nsi_pages", NSI_RATES, "interest-rates.html", note="NS&I current rates", validate=has(b"Direct Saver")))
    print(fetch("ons", CPI, "d7g7.json", note="CPI annual rate (one figure in the article: inflation context)",
                validate=has(b'"months"')))


if __name__ == "__main__":
    main()
