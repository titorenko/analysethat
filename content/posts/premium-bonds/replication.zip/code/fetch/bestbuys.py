"""Today's best buys from Moneyfacts, whose best-buy pages embed the whole market as JSON.

With the full search query (the one the archived captures carry), Moneyfacts ignores the page path, returns the
whole personal-savings market when account-types=null, and filters by the search amount: a product is listed only
if it takes that amount. So searching at several amounts tests minimum and maximum deposits mechanically (a
clean easy-access account must be listed at both £1,000 and £50,000). The default page searches at £20,000-25,000
and cannot test either. Parsing and the "clean" filter live in code/derive/bestbuys_derive.py.

Usage: .venv/Scripts/python -I code/fetch/bestbuys.py
"""
import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import fetch  # noqa: E402

URL = ("https://moneyfactscompare.co.uk/savings-accounts/easy-access-savings-accounts/?quick-links-first=false"
       "&product-favorites-first=false&id=null&business-type=16&activity-type=null&investment-amount={amt}"
       "&investment-type=1&account-types=null&interest-paid-frequencies=null&terms=null&account-opening-methods=null"
       "&account-management-methods=null&notice-periods=null&include-notice-period=true&include-term=true&age=21"
       "&has-withdrawal-restrictions=2&existing-customers-only=2&is-shariaa=2&joint-account-only=2")
AMOUNTS = [1_000, 10_000, 20_000, 50_000]


def market_at(amt):
    def check(content):
        h = content.decode("utf-8", errors="replace")
        i = h.find('"Results":[{"AllProducts"')
        if i < 0:
            return "no embedded product JSON"
        try:
            arr, _ = json.JSONDecoder().raw_decode(h[i + len('"Results":'):])
        except ValueError:
            return "product JSON does not parse (truncated page?)"
        j = h.find('"InvestmentAmount":')
        echo = h[j + 19:j + 30].split(",")[0] if j >= 0 else ""
        if echo != str(amt):
            return f"search amount not applied (page says {echo})"
        if sum(len(r["AllProducts"]) for r in arr) < 1000:
            return "too few products for the whole market"
        return None
    return check


def main():
    for amt in AMOUNTS:
        print(fetch("moneyfacts", URL.format(amt=amt), f"market_{amt}.html",
                    note=f"Moneyfacts whole market, search amount £{amt:,}", validate=market_at(amt), pause=2))


if __name__ == "__main__":
    main()
