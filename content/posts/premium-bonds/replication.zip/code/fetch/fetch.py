"""Shared downloader: every raw file in data/raw is fetched through here and logged to data/manifest.

    from fetch import fetch
    path = fetch("nsi_rates", url, "historical-interest-rates.html", note="NS&I rate history")

Each source gets data/raw/<source>/<snapshot date>/ and data/manifest/<source>.csv. Re-running on the same
day skips files already present; another day makes a new dated snapshot. `headers` adds request headers
(e.g. a Range request); `ok` lists acceptable status codes; `validate(content) -> str|None` rejects bad bodies
(e.g. an HTML error page served with HTTP 200).
"""
import csv
import datetime as dt
import hashlib
import pathlib
import time

import requests

ROOT = pathlib.Path(__file__).resolve().parents[2]          # .../premium-bonds
RAW = ROOT / "data" / "raw"
MANIFEST = ROOT / "data" / "manifest"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36"
FIELDS = ["source", "url", "local_path", "retrieved_utc", "http_status", "bytes", "sha256", "note"]


def snapshot_dir(source, day=None):
    d = RAW / source / (day or dt.date.today().isoformat())
    d.mkdir(parents=True, exist_ok=True)
    return d


def fetch(source, url, filename, note="", day=None, headers=None, ok=(200,), validate=None,
          retries=3, timeout=120, pause=0.0):
    dest = snapshot_dir(source, day) / filename
    if dest.exists() and dest.stat().st_size > 0:
        return dest
    last = None
    for attempt in range(retries):
        try:
            r = requests.get(url, headers={"User-Agent": UA, **(headers or {})}, timeout=timeout)
            last = r.status_code
            if r.status_code in ok and r.content:
                problem = validate(r.content) if validate else None
                if problem:
                    raise RuntimeError(f"invalid content ({problem}): {url}")
                dest.write_bytes(r.content)
                _log(source, url, dest, r.status_code, r.content, note)
                time.sleep(pause)
                return dest
        except requests.RequestException as e:   # network hiccup: retry
            last = repr(e)
        time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"fetch failed ({last}): {url}")


def latest(source, filename=None):
    """Newest snapshot directory of a source (or the newest copy of one file)."""
    days = sorted(p for p in (RAW / source).iterdir() if p.is_dir()) if (RAW / source).exists() else []
    if filename:
        days = [d for d in days if (d / filename).exists()]
        return days[-1] / filename if days else None
    return days[-1] if days else None


def _log(source, url, dest, status, content, note):
    MANIFEST.mkdir(parents=True, exist_ok=True)
    mf = MANIFEST / f"{source}.csv"
    new = not mf.exists()
    with mf.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        if new:
            w.writeheader()
        w.writerow({
            "source": source, "url": url, "local_path": str(dest.relative_to(ROOT)).replace("\\", "/"),
            "retrieved_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
            "http_status": status, "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest(), "note": note,
        })
