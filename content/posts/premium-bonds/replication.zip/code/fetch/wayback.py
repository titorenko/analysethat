"""Wayback Machine backfill (one-off, PLAN §3/§6): archived best-buy pages (MSE, Moneyfacts easy access and
fixed-rate bonds) for the 24 window months, and the MSE page titles Jan 2021 - Sep 2026.

  cdx [names]  query the CDX index (all 200 captures, prefix match) for each page or the named ones; save the JSON
  fetch        per month, rank captures (unfiltered Moneyfacts URL first, then day 1-20, then closest to the 15th,
               then no query string), download the best raw (id_) into data/raw/wayback/<day>/ with a manifest row;
               a capture that fails validation (archived pages can be cut off at 1 or 5 MiB) falls back to the next
  titles       parse MSE <title> into data/derived/mse_headline_titles.csv
  mf <file>    print the top products of one Moneyfacts capture (an aid to the hand-coded params/bestbuy_window.csv)

Usage: .venv/Scripts/python -I code/fetch/wayback.py cdx|fetch|titles|mf <file>
Wayback throttles: https only, 3 s between requests, back off on errors; content is validated, not size.
"""
import csv
import html
import json
import pathlib
import re
import sys
import time

import requests

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import ROOT, UA, _log, snapshot_dir  # noqa: E402

SOURCE = "wayback"
DAY = "2026-10-11"                      # the backfill snapshot folder (fixed: a one-off)
PAGES = {   # name: (url, months wanted)
    "mse_easy": ("www.moneysavingexpert.com/savings/savings-accounts-best-interest/", ("2021-01", "2026-09")),
    "mfc_easy": ("moneyfactscompare.co.uk/savings-accounts/easy-access-savings-accounts/", ("2024-10", "2026-09")),
    "mfc_fixed": ("moneyfactscompare.co.uk/savings-accounts/fixed-rate-bonds/", ("2024-10", "2026-09")),
}
PAUSE = 3.0


def get(url, tries=5):
    for i in range(tries):
        try:
            r = requests.get(url, headers={"User-Agent": UA}, timeout=180, allow_redirects=True)
            if r.status_code == 200:
                time.sleep(PAUSE)
                return r
            print("  http", r.status_code, url)
        except requests.RequestException as e:
            print("  error", repr(e)[:120])
        time.sleep(10 * (i + 1))
    raise RuntimeError(f"failed: {url}")


def cdx(*names):
    d = snapshot_dir(SOURCE, DAY)
    for name, (url, (a, b)) in PAGES.items():
        if names and name not in names:
            continue
        q = (f"https://web.archive.org/cdx/search/cdx?url={url}&matchType=prefix&output=json"
             f"&from={a.replace('-', '')}&to={b.replace('-', '')}&filter=statuscode:200"
             f"&fl=timestamp,original,statuscode,digest,length")
        r = get(q)
        rows = r.json()
        assert rows and rows[0][0] == "timestamp", rows[:1]
        (d / f"cdx_{name}.json").write_bytes(r.content)
        _log(SOURCE, q, d / f"cdx_{name}.json", 200, r.content, f"CDX index, {name}")
        print(name, len(rows) - 1, "captures")


HARMLESS = {"quick-links-first", "product-favorites-first", "sort-order", "sort-order-text"}   # Moneyfacts display-only


def filtered(name, original):
    """A Moneyfacts URL whose query filters the product list (investment amount, business type, ...). MSE query
    strings are tracking tags only, so they never filter."""
    query = original.partition("?")[2]
    return name.startswith("mfc") and any(kv.split("=")[0] not in HARMLESS for kv in query.split("&") if kv)


def ranked(name):
    """Captures per month, best first: an unfiltered page, then day 1-20, then closest to the 15th, then the plain
    URL (no query string)."""
    rows = json.loads((snapshot_dir(SOURCE, DAY) / f"cdx_{name}.json").read_text(encoding="utf-8"))
    hdr, rows = rows[0], [dict(zip(rows[0], r)) for r in rows[1:]]
    a, b = PAGES[name][1]
    by = {}
    for r in rows:
        ts, month, day = r["timestamp"], f"{r['timestamp'][:4]}-{r['timestamp'][4:6]}", int(r["timestamp"][6:8])
        if not (a <= month <= b):
            continue
        by.setdefault(month, []).append(((filtered(name, r["original"]), day > 20, abs(day - 15), "?" in r["original"],
                                          ts), r))
    return {m: [r for k, r in sorted(c, key=lambda x: x[0])] for m, c in sorted(by.items())}


def chosen(name):
    """The capture used for each month: the best-ranked one that was downloaded and passed validation."""
    d = snapshot_dir(SOURCE, DAY)
    return {m: next(r for r in c if (d / f"{name}_{r['timestamp']}.html").exists())
            for m, c in ranked(name).items() if any((d / f"{name}_{r['timestamp']}.html").exists() for r in c)}


def valid(name, body):
    """Content checks; archived captures can be cut short (one Moneyfacts capture stops at exactly 1 MiB)."""
    text = body.decode("utf-8", "replace")
    if "</html>" not in text[-5000:].lower():
        return False
    if name.startswith("mse"):
        t = re.search(r"<title>(.*?)</title>", text, re.S)
        return bool(t and "saving" in t.group(1).lower() and re.search(r"easy[- ]access", text, re.I))
    try:
        return len(mf_products(text)[1]) > 50
    except (ValueError, KeyError):
        return False


def fetch_all(tries=3):
    """Per month, download the best-ranked capture; if its content fails validation, try the next one."""
    d = snapshot_dir(SOURCE, DAY)
    for name in PAGES:
        for month, cands in ranked(name).items():
            if any((d / f"{name}_{r['timestamp']}.html").exists() for r in cands):
                continue
            for r in cands[:tries]:
                url = f"https://web.archive.org/web/{r['timestamp']}id_/{r['original']}"
                resp = get(url)
                if not valid(name, resp.content):
                    print("  INVALID content (truncated or not the page):", month, url, len(resp.content), flush=True)
                    continue
                dest = d / f"{name}_{r['timestamp']}.html"
                dest.write_bytes(resp.content)
                _log(SOURCE, url, dest, resp.status_code, resp.content, f"{name} {month}; final {resp.url}")
                print(month, name, r["timestamp"], len(resp.content), flush=True)
                break


def titles():
    d = snapshot_dir(SOURCE, DAY)
    out = ROOT / "data" / "derived" / "mse_headline_titles.csv"
    pct = r"(\d+(?:\.\d+)?)%"
    rows = []
    for month, r in chosen("mse_easy").items():
        f = d / f"mse_easy_{r['timestamp']}.html"
        t = html.unescape(re.search(r"<title>(.*?)</title>", f.read_text("utf-8", "replace"), re.S).group(1))
        t = " ".join(t.split())
        easy = re.search(pct + r"[^%]*?easy[- ]access", t, re.I)
        fixed = re.search(pct + r"[^%]*?fix", t, re.I)
        rows.append({"month": month, "snapshot": r["timestamp"], "title": t,
                     "headline_easy_access": easy.group(1) if easy else "",
                     "headline_fixed": fixed.group(1) if fixed else "",
                     "source_url": f"https://web.archive.org/web/{r['timestamp']}/{r['original']}"})
    with out.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(len(rows), "months ->", out)


def mf_products(page):
    """All products in a Moneyfacts page (a path or its text): the whole-market 'Results' list, plus the per-product
    detail ('data-product') that some page versions embed for the rendered top rows, merged by Id."""
    text = page if "<" in page[:1000] else pathlib.Path(page).read_text("utf-8", "replace")
    model = max(re.findall(r"data-model='(.*?)'", text, re.S), key=len)
    data = json.loads(html.unescape(model))
    detail = {}
    for blob in re.findall(r"data-product='(.*?)'", text, re.S):
        p = json.loads(html.unescape(blob))
        detail[p.get("Id")] = p
    prods = []
    for res in data["Results"]:
        for p in res.get("AllProducts") or [res["PrimaryProduct"]]:
            prods.append({**p, **detail.get(p.get("Id"), {}), "_detail": p.get("Id") in detail})
    return data, prods


def mf(path, n=25):
    data, prods = mf_products(path)
    print(path, "| products:", len(prods), "| ActiveFilter:", data.get("ActiveFilter"), "| detail rows:",
          sum(p["_detail"] for p in prods))
    for p in sorted(prods, key=lambda p: -p["AER"])[:int(n)]:
        bonus = p.get("IntroBonusNote") or p.get("IntroductoryBonusNote") or ""
        print(f"{p['AER']:5.2f} {p.get('ProviderName')} | {p.get('ProductName')} | min {p.get('MinimumInvestment')}"
              f" max {p.get('MaximumInvestment', '?')} | notice {p.get('NoticeInDays')} | sharia "
              f"{p.get('ShariaaTick', p.get('IsSharia'))} | fscs {p.get('IsFSCSProtected', '?')} | platform "
              f"{p.get('PlatformTick', '?')} | bonus: {bonus} | access: {p.get('AccessNote', '?')} | "
              f"wd {p.get('PermittedWithdrawalsPerAnnum', '?')} | criteria: {p.get('OpeningCriteriaNote', '?')}")


if __name__ == "__main__":
    cmd = sys.argv[1]
    {"cdx": lambda: cdx(*sys.argv[2:]), "fetch": fetch_all, "titles": titles}.get(cmd, lambda: mf(*sys.argv[2:]))()
