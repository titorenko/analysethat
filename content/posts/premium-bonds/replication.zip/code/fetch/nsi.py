"""NS&I raw data: monthly winning-numbers zip headers (prize counts per draw), the rate-history page, the
monthly prize allocation page (current draw + next-draw estimate) and the Premium Bonds product page.

Zip headers are immutable, so they live in one snapshot folder ("history") and only new months are fetched.
Each zip is ~30 MB; a 16 KB Range request holds the first page of the report (amount, total, counts).

Usage: .venv/Scripts/python -I code/fetch/nsi.py
"""
import datetime as dt
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from fetch import fetch, RAW  # noqa: E402

ZIP = "https://www.nsandi.com/files/asset/zip/premium-bonds-winning-bond-numbers-{mm:02d}-{yyyy}.zip"
PAGES = {
    "historical-interest-rates.html": "https://www.nsandi.com/historical-interest-rates",
    "monthly-prize-allocation.html": "https://www.nsandi.com/get-to-know-us/monthly-prize-allocation",
    "premium-bonds.html": "https://www.nsandi.com/products/premium-bonds",
}
FIRST = (2020, 1)


def is_zip(content):
    return None if content[:2] == b"PK" else f"not a zip: {content[:40]!r}"


def is_html(content):
    return None if b"<html" in content[:5000].lower() else "not html"


def months(start, end):
    y, m = start
    while (y, m) <= end:
        yield y, m
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)


def fetch_zip_headers(today=None):
    today = today or dt.date.today()
    got = []
    for y, m in months(FIRST, (today.year, today.month)):
        name = f"head_{m:02d}-{y}.bin"
        if (RAW / "nsi_draws" / "history" / name).exists():
            got.append(name)
            continue
        try:
            fetch("nsi_draws", ZIP.format(mm=m, yyyy=y), name, note=f"first 16 KB of the {m:02d}/{y} winning-numbers zip",
                  day="history", headers={"Range": "bytes=0-16383"}, ok=(200, 206), validate=is_zip, retries=1)
            got.append(name)
        except RuntimeError as e:
            if (y, m) >= (today.year, today.month):      # this month's file may not be out yet
                print("not yet published:", f"{m:02d}/{y}")
            else:
                raise
    return got


def main():
    heads = fetch_zip_headers()
    print(len(heads), "draw headers in", RAW / "nsi_draws" / "history")
    for name, url in PAGES.items():
        print("fetched", fetch("nsi_pages", url, name, note="NS&I page", validate=is_html))


if __name__ == "__main__":
    main()
