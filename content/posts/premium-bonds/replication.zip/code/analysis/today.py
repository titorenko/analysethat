"""P3a: today's comparison, "if today's rates held for a year" (PLAN §1 Q1-Q2, §3-§4).

Writes
  results/pb_luck.csv       Premium Bond winnings by amount and holding period: P(nothing), P10-P90, mean
  results/today_net.csv     net return (after tax and fees) by tax year x amount x profile x product
  results/today_beat.csv    chance Premium Bonds beat each alternative; tax-equivalent rate; best easy-access rival
  results/entry_timing.csv  median winnings for 10 / 11 / 12 draws in a year (new money, F9)
  results/mmf_fees.csv      money market fund platform charges by pot size
  results/today_inputs.json the inputs used, with dates
Premium Bonds: latest drawn prize table repeated. Distributions assume prizes are paid out (a fixed holding, so they
are exact; MSE's convention); the average with prizes reinvested is reported separately and is exact too, because
expectations add up draw by draw. Today's comparison counts 12 draws (money already held); new money's first year
gets 11 (section 1.2), reported as the *_new columns.
MMF: tax on the distribution net of OCF; platform fee and dealing (buy + sell) after tax (F1).

Usage: .venv/Scripts/python -I code/analysis/today.py
"""
import datetime as dt
import json
import pathlib
import sys

import numpy as np
import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "code" / "engine")]
import gilt as G  # noqa: E402
import inputs as I  # noqa: E402
import pb  # noqa: E402
import tax as T  # noqa: E402

RES = ROOT / "results"
AMOUNTS = [1_000, 5_000, 10_000, 25_000, 50_000, 100_000]
LUCK_AMOUNTS = [100, 1_000, 5_000, 10_000, 25_000, 50_000, 100_000]
# Above the £50,000 limit the amount is a couple: two people holding half each, both in the same tax position. Their
# bonds are pooled for the luck (independent draws simply add), but tax, allowances and platform fees are per person.


def people(a):
    return 2 if a > pb.CAP else 1


def mean_reinvested(rows, a):
    n = people(a)
    return n * pb.mean(rows, pb.reinvest_path(a / n, rows))
YEARS = ["2026-27", "2027-28"]
HEADLINE = "AJ Bell"
EASY_RIVALS = ["easy", "mmf", "direct_saver"]          # easy-access, taxable alternatives for the heat map


def pb_dist(rows, amount):
    return pb.distribution(rows, amount)


def luck(latest):
    out = []
    for draws in (12, 24, 60):
        rows = [latest] * draws
        yrs = draws / 12
        for a in LUCK_AMOUNTS:
            pmf = pb.distribution(rows, a)
            r = {"amount": a, "draws": draws, "p_nothing": pb.p_nothing(rows, a), "mean": pb.mean(rows, a),
                 "mean_reinvested": mean_reinvested(rows, a)}
            for q in (10, 25, 50, 75, 90):
                r[f"p{q}"] = pb.quantile(pmf, q / 100)
            for k in ("mean", "p10", "p25", "p50", "p75", "p90"):
                r[f"{k}_pa"] = r[k] / a / yrs                     # prizes paid out: a simple annual rate
            r["mean_reinvested_pa"] = (1 + r["mean_reinvested"] / a) ** (1 / yrs) - 1
            out.append(r)
    return pd.DataFrame(out)


def net_rows(inp, settle):
    g = inp["gilt"]
    deal = I.fees()["platforms"][HEADLINE]["fund_deal"]
    gf = I.fees()["platforms"][HEADLINE]["gilts"]
    latest = pb.draws()[-1]
    year12, year11 = [latest] * 12, [latest] * 11
    rows, beat = [], []
    for year in YEARS:
        for a in AMOUNTS:
            pmf = pb_dist(year12, a)
            med = pb.quantile(pmf, 0.5)
            pmf11 = pb_dist(year11, a)
            med11 = pb.quantile(pmf11, 0.5)
            n = people(a)
            for pk, prof in T.PROFILES.items():
                def taxed(rate, wrapper=False):        # per person, then added up for a couple
                    i = rate * a / n
                    return n * (i - (0.0 if wrapper else T.cost(prof, i, year)))
                fee = n * (I.platform_fee(HEADLINE, a / n) + 2 * deal)
                v = {
                    "pb_median": med, "pb_p10": pb.quantile(pmf, 0.10), "pb_p90": pb.quantile(pmf, 0.90),
                    "pb_mean": pb.mean(year12, a), "pb_mean_reinvested": mean_reinvested(year12, a),
                    "pb_median_new": med11,
                    "easy": taxed(inp["easy"]["rate"]), "fix1y": taxed(inp["fix1y"]["rate"]),
                    "avg_easy": taxed(inp["avg_easy"]["rate"]), "direct_saver": taxed(inp["direct_saver"]["rate"]),
                    "mmf": taxed(inp["mmf"]["rate"]) - fee,
                    "isa_easy": taxed(inp["isa_easy"]["rate"], True), "isa_fix1y": taxed(inp["isa_fix1y"]["rate"], True),
                    "mmf_isa": taxed(inp["mmf"]["rate"], True) - fee,
                }
                gy = G.irr(G.flows(g, a / n, settle, prof, deal=gf["deal"], custody_rate=gf["rate"],
                                   custody_cap=gf["cap_per_year_gia"])) if year == YEARS[0] else np.nan
                v["gilt"] = gy * a
                for prod, gbp in v.items():
                    rows.append({"year": year, "amount": a, "profile": pk, "product": prod, "net_gbp": gbp,
                                 "net_pct": gbp / a})
                rivals = {k: v[k] for k in EASY_RIVALS}
                best = max(rivals, key=rivals.get)
                lo, hi = 0.0, 0.2                     # gross rate a taxable account needs to match the PB median
                for _ in range(60):
                    mid = (lo + hi) / 2
                    if taxed(mid) < med:
                        lo = mid
                    else:
                        hi = mid
                beat.append({"year": year, "amount": a, "profile": pk,
                             "p_beat_easy": pb.p_at_least(pmf, v["easy"]), "p_beat_mmf": pb.p_at_least(pmf, v["mmf"]),
                             "p_beat_best_rival": pb.p_at_least(pmf, rivals[best]), "best_rival": best,
                             "best_rival_pct": rivals[best] / a, "pb_median_pct": med / a,
                             "margin_pp": (med - rivals[best]) / a, "tax_equivalent": hi if med > 0 else 0.0,
                             "p_beat_isa_easy": pb.p_at_least(pmf, v["isa_easy"]),
                             "margin_new_pp": (med11 - rivals[best]) / a, "p_beat_new": pb.p_at_least(pmf11, rivals[best]),
                             "mean_margin_pp": (v["pb_mean"] - rivals[best]) / a})
    return pd.DataFrame(rows), pd.DataFrame(beat)


def entry_timing(latest):
    """New money held for about a year: draws received under NS&I's rules (pb.draws_held) for dated examples, and the
    median winnings for that many draws. Example dates use the year of the latest draw."""
    y = int(str(latest["draw"])[:4])
    last_oct = pd.bdate_range(dt.date(y + 1, 10, 1), dt.date(y + 1, 10, 31))[-1].date()
    examples = [(dt.date(y, 10, 30), dt.date(y + 1, 11, 2)), (dt.date(y, 10, 15), last_oct),
                (dt.date(y, 10, 15), dt.date(y + 1, 10, 15)), (dt.date(y, 10, 1), dt.date(y + 1, 10, 1)),
                (dt.date(y, 10, 1), dt.date(y + 1, 9, 24))]
    out = []
    for bought, cash_in in examples:
        n = pb.draws_held(bought, cash_in)
        rows = [latest] * n
        rec = {"bought": bought.isoformat(), "cash_in": cash_in.isoformat(), "days": (cash_in - bought).days, "draws": n}
        for a in (10_000, 50_000):
            rec[f"median_{a}"] = pb.quantile(pb.distribution(rows, a), 0.5)
        out.append(rec)
    return pd.DataFrame(out)


def mmf_fees(inp):
    out = []
    plats = I.fees()["platforms"]
    for name in plats:
        for pot in (5_000, 10_000, 25_000, 50_000, 100_000):
            fee = I.platform_fee(name, pot)
            out.append({"platform": name, "pot": pot, "fee_gbp": fee, "fee_pct": fee / pot,
                        "net_before_tax": inp["mmf"]["rate"] - fee / pot})
    return pd.DataFrame(out)


def main():
    RES.mkdir(exist_ok=True)
    inp = I.today()
    as_of = dt.date.fromisoformat(inp["gilt"]["as_of"])
    settle = as_of + dt.timedelta(days=3 if as_of.weekday() == 4 else 1)
    latest = pb.draws()[-1]
    luck(latest).to_csv(RES / "pb_luck.csv", index=False)
    net, beat = net_rows(inp, settle)
    net.to_csv(RES / "today_net.csv", index=False)
    beat.to_csv(RES / "today_beat.csv", index=False)
    entry_timing(latest).to_csv(RES / "entry_timing.csv", index=False)
    mmf_fees(inp).to_csv(RES / "mmf_fees.csv", index=False)
    inp["gilt_settle"] = settle.isoformat()
    (RES / "today_inputs.json").write_text(json.dumps(inp, indent=2, default=str), encoding="utf-8")
    b = beat[beat.year == YEARS[0]].pivot(index="profile", columns="amount", values="p_beat_best_rival")
    print("P(PB beats the best easy-access rival), 2026/27:\n", (100 * b).round(0).loc[list(T.PROFILES)].to_string())


if __name__ == "__main__":
    main()
