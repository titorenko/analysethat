"""P3c: how the Premium Bond rate moves against Bank Rate and the savings market (PLAN §5, Q4, F4, F16).

Alignment: draw M is the return for holding calendar month M−1, so the prize rate of draw M sits in month M−1.
Writes
  results/lag_monthly.csv   month, PB prize rate, Bank Rate (month average), SONIA, BoE average advertised
                            easy-access rate excl. bonuses (IUMB6VK), BoE average 1-year fixed bond (IUMWTFA), 1-year
                            gilt (month end), NS&I Direct Saver, MSE headline easy access (if backfilled), spreads
  results/lag_events.csv    the 17 prize-rate changes: announcement, first draw, nearest earlier Bank Rate change,
                            1-year gilt and Bank Rate moves in the 3 months before the announcement
  results/lag_cycles.json   three per-cycle facts
Usage: .venv/Scripts/python -I code/analysis/lag.py
"""
import json
import pathlib

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
DER, RES, PARAMS = ROOT / "data" / "derived", ROOT / "results", ROOT / "params"


def monthly():
    b = pd.read_csv(DER / "boe_monthly.csv", dtype={"month": str}).set_index("month")
    g = pd.read_csv(DER / "gilt_spot.csv", dtype={"month": str}).set_index("month")
    d = pd.read_csv(DER / "pb_draws.csv", dtype={"draw": str})
    d["month"] = (pd.PeriodIndex(d.draw, freq="M") - 1).strftime("%Y-%m")
    ds = pd.read_csv(DER / "nsi_direct_saver.csv")
    x = pd.DataFrame({"pb": d.set_index("month").rate * 100})
    x = x.join(b[["bank_rate_avg", "sonia_avg", "IUMB6VK", "IUMWTFA"]], how="outer").join(g[["gilt_1y"]], how="outer")
    ds_m = [ds[ds["from"] <= f"{m}-31"].rate.iloc[-1] * 100 if (ds["from"] <= f"{m}-31").any() else None
            for m in x.index]
    x["direct_saver"] = ds_m
    mse = DER / "mse_headline_titles.csv"
    if mse.exists():
        t = pd.read_csv(mse, dtype={"month": str}).set_index("month")
        x = x.join(t[["headline_easy_access"]].rename(columns={"headline_easy_access": "mse_headline"}))
    bb = PARAMS / "bestbuy_window.csv"
    if bb.exists():
        t = pd.read_csv(bb, dtype={"month": str}).set_index("month")
        x = x.join(t[["rate_aer"]].rename(columns={"rate_aer": "clean_best"}))
    x = x.loc["2020-01":].dropna(subset=["pb"])
    x["pb_minus_sonia"] = x.pb - x.sonia_avg
    x["pb_minus_avg_easy"] = x.pb - x.IUMB6VK
    x["pb_minus_gilt_1y"] = x.pb - x.gilt_1y
    if "clean_best" in x:
        x["pb_minus_clean_best"] = x.pb - x.clean_best
    x.index.name = "month"
    return x


def bank_rate_changes():
    raw = sorted((ROOT / "data" / "raw" / "boe").iterdir())[-1] / "boe_daily.csv"
    d = pd.read_csv(raw)
    d["date"] = pd.to_datetime(d.DATE, format="%d %b %Y")
    d = d.dropna(subset=["IUDBEDR"])
    d["move"] = d.IUDBEDR.diff()
    ch = d[d.move.fillna(0) != 0]
    return pd.DataFrame({"date": ch.date.dt.date.astype(str), "bank_rate": ch.IUDBEDR.values, "move": ch.move.values})


def events(x, br):
    ev = pd.read_csv(PARAMS / "pb_rate_events.csv", dtype={"first_draw": str})
    out = []
    for r in ev.itertuples():
        prior = br[br.date <= r.announced]
        last = prior.iloc[-1] if len(prior) else None
        m = pd.Period(r.announced, "M")
        before, at = (m - 4).strftime("%Y-%m"), (m - 1).strftime("%Y-%m")   # month ends: 3 months before the month
        def move(col):
            if before in x.index and at in x.index:
                return x.loc[at, col] - x.loc[before, col]
            return None
        out.append({"announced": r.announced, "first_draw": r.first_draw, "old_rate": r.old_rate, "new_rate": r.new_rate,
                    "change_bp": round((r.new_rate - r.old_rate) * 1e4), "notice_days": (
                        pd.Period(r.first_draw, "M").to_timestamp() - pd.Timestamp(r.announced)).days,
                    "last_bank_rate_change": last.date if last is not None else None,
                    "days_since_bank_rate_change": (pd.Timestamp(r.announced) - pd.Timestamp(last.date)).days
                    if last is not None else None,
                    "bank_rate_3m_move_pp": move("bank_rate_avg"), "gilt_1y_3m_move_pp": move("gilt_1y"),
                    "reason": r.reason, "source": r.source})
    return pd.DataFrame(out)


def cycles(ev, br):
    first_up = br[(br.date >= "2021-01-01") & (br.move > 0)].iloc[0]
    pb_up = ev[(ev.announced >= "2022-01-01") & (ev.change_bp > 0)].iloc[0]
    first_cut = br[(br.date > first_up.date) & (br.move < 0)].iloc[0]
    pb_cut = ev[(ev.announced >= "2024-01-01") & (ev.change_bp < 0)].iloc[0]
    pb_2026 = ev[ev.announced >= "2026-01-01"]
    br_2026 = br[br.date >= "2026-01-01"]
    pb_low_2026 = pb_2026.new_rate.min()
    return {
        "rise": {"first_bank_rate_rise": first_up.date, "bank_rate_from": float(first_up.bank_rate - first_up.move), "bank_rate_peak": float(br.bank_rate.max()),
                 "first_pb_rise_announced": pb_up.announced, "first_pb_rise_draw": pb_up.first_draw,
                 "months_lag": round((pd.Timestamp(pb_up.announced) - pd.Timestamp(first_up.date)).days / 30.44, 1),
                 "pb_from": round(float(ev[ev.announced < "2022-01-01"].new_rate.iloc[-1] * 100), 4),
                 "pb_peak": round(float(ev.new_rate.max() * 100), 4)},
        "cut": {"first_pb_cut_announced": pb_cut.announced, "first_pb_cut_draw": pb_cut.first_draw,
                "first_bank_rate_cut": str(first_cut.date),
                "months_lead": round((pd.Timestamp(first_cut.date) - pd.Timestamp(pb_cut.announced)).days / 30.44, 1)},
        "y2026": {"bank_rate_changes_2026": int(len(br_2026)), "bank_rate": float(br.bank_rate.iloc[-1]),
                  "pb_low": round(float(pb_low_2026 * 100), 4), "pb_now": round(float(ev.new_rate.iloc[-1] * 100), 4),
                  "pb_changes_2026": int(len(pb_2026))},
    }


def main():
    x = monthly()
    x.to_csv(RES / "lag_monthly.csv")
    br = bank_rate_changes()
    ev = events(x, br)
    ev.to_csv(RES / "lag_events.csv", index=False)
    cy = cycles(ev, br)
    (RES / "lag_cycles.json").write_text(json.dumps(cy, indent=2), encoding="utf-8")
    print(json.dumps(cy, indent=1))


if __name__ == "__main__":
    main()
