"""P3b: the last two years, realised (PLAN §5, F2).

Window: the latest 24 draws (draw M ↔ calendar month M−1), so deposit, fund and SONIA months run one month earlier.
Tax: two 12-month blocks, each taxed under the rules of the tax year it starts in, with one PSA and one
starting-rate band each (the savings rules were identical across 2024/25-2026/27; only child benefit rates moved).
Interest compounds gross inside the window; tax is paid out of pocket, as under self-assessment.

Products: Premium Bonds (the 24 actual prize tables, prizes paid out: exact, a simple annual rate); a "best-buy chaser" in the top clean
easy-access account every month (params/bestbuy_window.csv, hand-coded to the clean rule); a saver earning the BoE
average advertised easy-access rate excl. bonuses; NS&I Direct Saver; two back-to-back 1-year fixes bought at the
start of each block (params/bestfix_window.csv); RL Short Term MMF on AJ Bell (NAV, net of OCF; platform fee and
dealing after tax, at today's tariff); SONIA as the reference.

Writes results/trailing.csv (amount x profile x product), results/trailing_pb.csv (PB distribution) and
results/scoreboard.csv (month by month: PB median of a 12-draw holding at that month's table vs the clean best buy).
Usage: .venv/Scripts/python -I code/analysis/trailing.py
"""
import json
import pathlib
import sys

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "code" / "engine")]
import inputs as I  # noqa: E402
import pb  # noqa: E402
import tax as T  # noqa: E402

DER, RES, PARAMS = ROOT / "data" / "derived", ROOT / "results", ROOT / "params"
AMOUNTS = [10_000, 25_000, 50_000]
HEADLINE = "AJ Bell"


def tax_year_of(month):
    y, m = map(int, month.split("-"))
    y = y if m >= 4 else y - 1
    return f"{y}-{str(y + 1)[2:]}"


def window():
    rows = pb.draws()[-24:]
    months = [(pd.Period(r["draw"], "M") - 1).strftime("%Y-%m") for r in rows]
    return rows, months


def best_buys(backfill="bestbuy_window.csv", category="easy_access"):
    """Clean best rate by month: the hand-coded backfill (params/), extended by the live monthly snapshots
    refresh.py appends (data/derived/bestbuy_history.csv; the latest snapshot in each month)."""
    bb = pd.read_csv(PARAMS / backfill, dtype={"month": str})
    h = pd.read_csv(DER / "bestbuy_history.csv", dtype={"snapshot": str})
    h = h[h.category == category].assign(month=lambda x: x.snapshot.str[:7]).sort_values("snapshot")
    h = h.groupby("month").last().reset_index()
    live = pd.DataFrame({"month": h.month, "rate_aer": h.aer, "provider": h.provider, "account": h["product"],
                         "method": "moneyfacts_json_live", "snapshot_date": h.snapshot})
    out = pd.concat([bb, live[~live.month.isin(bb.month)]]).set_index("month").sort_index()
    return out


def deposit_path(rates_by_month, months, amount):
    """Gross interest per 12-month block for a balance earning the month's AER (monthly compounding)."""
    bal, blocks = float(amount), [0.0, 0.0]
    for i, m in enumerate(months):
        g = bal * ((1 + rates_by_month[m]) ** (1 / 12) - 1)
        blocks[i // 12] += g
        bal += g
    return blocks


def net_after_tax(blocks, prof, years):
    return sum(b - T.cost(prof, b, y) for b, y in zip(blocks, years))


def annualise(gain, amount, years=2):
    """One basis for every product: the total gain over the window, per year, as a share of the amount."""
    return gain / amount / years


def main():
    rows, months = window()
    years = [tax_year_of(months[0]), tax_year_of(months[12])]
    boe = pd.read_csv(DER / "boe_monthly.csv", dtype={"month": str}).set_index("month")
    bb = best_buys()
    fx = best_buys("bestfix_window.csv", "fixed_1y")
    ds = pd.read_csv(DER / "nsi_direct_saver.csv")
    nav = pd.read_csv(DER / "rl_nav.csv")
    def fill(t):                     # a month with no snapshot (a skipped run, an archive hole) carries the last one
        missing = [m for m in months if m not in t.index]
        t = t.reindex(sorted(set(t.index) | set(months))).ffill()
        t.loc[missing, "method"] = "carried_forward"
        return t
    bb, fx = fill(bb), fill(fx)
    assert not bb.loc[months, "rate_aer"].isna().any(), "no best buy before the window starts"
    best = {m: bb.loc[m, "rate_aer"] / 100 for m in months}
    avg = {m: boe.loc[m, "IUMB6VK"] / 100 for m in months}
    sav = {m: float(ds[ds["from"] <= f"{m}-15"].rate.iloc[-1]) for m in months}
    son = {m: boe.loc[m, "sonia_month_return"] for m in months}
    fix = [fx.loc[months[0], "rate_aer"] / 100, fx.loc[months[12], "rate_aer"] / 100]

    def nav_at(month_end):
        return float(nav[nav.date <= month_end].nav.iloc[-1])
    ends = [(pd.Period(months[0], "M") - 1).to_timestamp(how="end").date().isoformat(),
            pd.Period(months[11], "M").to_timestamp(how="end").date().isoformat(),
            pd.Period(months[23], "M").to_timestamp(how="end").date().isoformat()]
    navs = [nav_at(e) for e in ends]
    deal = I.fees()["platforms"][HEADLINE]["fund_deal"]

    out, pbrows = [], []
    for a in AMOUNTS:
        pmf = pb.distribution(rows, a)
        q = {f"p{k}": pb.quantile(pmf, k / 100) for k in (10, 25, 50, 75, 90)}
        pbrows.append({"amount": a, "mean": pb.mean(rows, a), **q, "p_nothing": pb.p_nothing(rows, a)})
        dep = {"best_chaser": deposit_path(best, months, a), "avg_easy": deposit_path(avg, months, a),
               "direct_saver": deposit_path(sav, months, a)}
        f1 = a * fix[0]
        dep["fix_rolled"] = [f1, (a + f1) * fix[1]]
        bal1 = a * navs[1] / navs[0]
        mmf_blocks = [bal1 - a, a * navs[2] / navs[0] - bal1]
        mmf_fees = I.platform_fee(HEADLINE, (a + bal1) / 2) + I.platform_fee(HEADLINE, (bal1 + a * navs[2] / navs[0]) / 2) + 2 * deal
        sonia_g = 1.0
        for m in months:
            sonia_g *= 1 + son[m]
        for pk, prof in T.PROFILES.items():
            vals = {k: net_after_tax(v, prof, years) for k, v in dep.items()}
            vals["mmf"] = net_after_tax(mmf_blocks, prof, years) - mmf_fees
            vals["pb_median"], vals["pb_mean"] = q["p50"], pb.mean(rows, a)
            vals["pb_p10"], vals["pb_p90"] = q["p10"], q["p90"]
            vals["sonia_gross"] = a * (sonia_g - 1)
            for prod, gbp in vals.items():
                out.append({"amount": a, "profile": pk, "product": prod, "gain_gbp": gbp, "pa": annualise(gbp, a)})
            out.append({"amount": a, "profile": pk, "product": "p_pb_beats_chaser",
                        "gain_gbp": None, "pa": pb.p_at_least(pmf, vals["best_chaser"])})
    pd.DataFrame(out).to_csv(RES / "trailing.csv", index=False)
    pd.DataFrame(pbrows).to_csv(RES / "trailing_pb.csv", index=False)

    sb = []
    for r, m in zip(rows, months):
        rec = {"month": m, "draw": r["draw"], "pb_rate": r["rate"], "clean_best": best[m]}
        for a in (10_000, 50_000):
            y12 = [r] * 12
            rec[f"pb_median_{a}"] = pb.quantile(pb.distribution(y12, a), 0.5) / a
        for pk in ("basic_used", "higher_used", "additional"):
            prof = T.PROFILES[pk]
            i = best[m] * 50_000
            rec[f"best_net_{pk}_50000"] = (i - T.cost(prof, i, tax_year_of(m))) / 50_000
        sb.append(rec)
    pd.DataFrame(sb).to_csv(RES / "scoreboard.csv", index=False)
    meta = {"draws": [rows[0]["draw"], rows[-1]["draw"]], "months": [months[0], months[-1]], "tax_years": years,
            "nav_dates": ends, "navs": navs, "fix_rates": fix,
            "carried_forward": [m for m in months if bb.loc[m, "method"] == "carried_forward"]}
    (RES / "trailing_meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    t = pd.DataFrame(out)
    t = t[(t.amount == 50_000) & (t["product"] != "p_pb_beats_chaser")]
    print(meta)
    print((100 * t.pivot(index="profile", columns="product", values="pa")).round(2).to_string())


if __name__ == "__main__":
    main()
