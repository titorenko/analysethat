"""Build replication.zip for the write-up: code, parameters, derived tables, results, manifests (URL, date, hash of
every raw file), the article template and a README. Raw downloads are not redistributed (re-fetch them with
code/fetch); the NS&I zip headers are small and public, so they are included.

Usage: .venv/Scripts/python -I code/package_replication.py <out zip>
"""
import pathlib
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = pathlib.Path(sys.argv[1])
README = """# Replication files: Premium Bonds vs savings accounts, money market funds and gilts

Contents
- code/fetch     downloads every source (logged to data/manifest with URL, date, HTTP status, bytes, sha256)
- code/derive    builds the tidy tables in data/derived (NS&I draws and rates, Bank of England series, fund prices,
                 best buys with the "clean" filter)
- code/engine    pb.py (exact Premium Bond distribution by FFT), tax.py (savings tax, all bands), gilt.py,
                 inputs.py (today's inputs)
- code/analysis  today.py (today's comparison), trailing.py (last 24 draws), lag.py (rates history)
- code/checks    gates: G-alloc, G-boe/G-mmf, G-pb, G-tax, G-fresh, G-article (log in logs/gates.md)
- code/figures   figures and the article (article_values.py computes every number in it)
- params         tax rules by year, platform fees, the gilt price, protection limits, prize-rate events,
                 the hand-coded best-buy history (with source URLs)
- data/raw/nsi_draws/history  the first 16 KB of each NS&I winning-numbers file (prize counts per draw)
- refresh.py     the monthly run: fetch, derive, gates, analysis, figures, article

Run (Python 3.13, pip install -r requirements.txt; always python -I): refresh.py, or the steps it lists in order.
Not included (third-party data; the fetchers re-download them): the FT daily fund prices, the Moneyfacts market
listings and MoneySavingExpert page text. The picks and rates the article uses are included.
Sources are public: NS&I, Bank of England, Moneyfacts and MoneySavingExpert (best buys, current and archived),
Royal London, FT (fund prices), Hargreaves Lansdown (gilt prices), gov.uk and legislation.gov.uk (tax rules).
"""
INCLUDE = ["code", "params", "data/derived", "data/manifest", "data/raw/nsi_draws/history", "results", "writeup",
           "refresh.py", "requirements.txt", "PLAN.md", "PUBLISH.md", "review", "logs/gates.md", "logs/wayback_backfill.md"]
SKIP = ("__pycache__", ".pyc", "results/bundle", "results/figures",
        "data/derived/rl_nav.csv",                 # FT price data: re-fetch with code/fetch/markets.py
        "data/derived/bestbuys_today.csv",         # Moneyfacts market listing: re-fetch with code/fetch/bestbuys.py
        "data/derived/mse_headline_titles.csv",
        "results/FINDINGS.md")                     # working note from before the review rounds; superseded    # MoneySavingExpert page text: re-fetch with code/fetch/wayback.py


def main():
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("README.md", README)
        n = 0
        for item in INCLUDE:
            p = ROOT / item
            files = [p] if p.is_file() else sorted(q for q in p.rglob("*") if q.is_file())
            for f in files:
                rel = f.relative_to(ROOT).as_posix()
                if any(s in rel for s in SKIP):
                    continue
                z.write(f, rel)
                n += 1
    print("wrote", OUT, n, "files")


if __name__ == "__main__":
    main()
