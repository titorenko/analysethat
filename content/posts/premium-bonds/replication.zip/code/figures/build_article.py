"""Render the write-up from writeup/article.md.tmpl: fill {placeholders} from article_values.values() and the
generated tables, assert every qualitative claim the text makes against the results, then fail if any placeholder
is left. Run make_figures.py into the same bundle first.

Usage: .venv/Scripts/python -I code/figures/build_article.py <bundle_dir>
"""
import json
import pathlib
import re
import shutil
import sys

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from article_values import (LABEL, RES, ROOT, T, day_name, gbp, month_name, one_in, pb, pct, pp, values)  # noqa: E402

OUT = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results" / "bundle"
PROFILES = list(T.PROFILES)


def claims():
    """Every qualitative statement in the template, asserted against the results (2026/27, today's rates)."""
    b = pd.read_csv(RES / "today_beat.csv")
    b = b[b.year == "2026-27"]
    m = b.pivot(index="profile", columns="amount", values="margin_pp")
    n = pd.read_csv(RES / "today_net.csv")
    n = n[n.year == "2026-27"].pivot_table(index=["profile", "amount"], columns="product", values="net_pct")
    assert (m.loc["zero"] < 0).all(), "no-tax savers: the bank wins"
    assert (m.loc[["higher_used", "additional"], [a for a in m.columns if a >= 5_000]] > 0).all().all(), "higher rate wins"
    assert (m.loc["taper", [a for a in m.columns if a >= 25_000]] > 0).all(), "60% band wins at £25k+"
    assert m.loc["basic_used", [10_000, 50_000]].abs().max() <= 0.003, "basic rate, allowance used: close to a draw"
    assert (n.isa_easy > n.pb_median).all() and (n.isa_fix1y > n.pb_median).all(), "ISA beats the typical holding"
    assert (n.gilt > n.pb_median).all(), "gilt beats the typical holding for every saver"
    assert (n.mmf < n.easy + 1e-12).all(), "MMF never beats the best easy-access account"
    for pk in ("higher_used", "additional"):
        assert (n.loc[pk].gilt > n.loc[pk].fix1y).all(), "at 40%+ on the fix's interest the gilt wins"
    for pk in ("zero", "basic_free"):
        assert (n.loc[pk].fix1y > n.loc[pk].gilt).all(), "untaxed or allowance-covered: the fix wins"
    assert n.loc[("basic_used", 50_000)].gilt > n.loc[("basic_used", 50_000)].fix1y, "at 20% on £50,000 the gilt wins"
    assert min(b.set_index(["profile", "amount"]).loc[("higher_used", a), "margin_pp"] for a in (5_000, 10_000)) > 0
    for pk in ("zero", "basic_free", "basic_used"):
        assert (n.loc[pk].fix1y > n.loc[pk].pb_median).all(), "the fix beats the typical PB holding at 20% or less"
    hu = b.set_index(["profile", "amount"])
    assert hu.loc[("higher_free", 25_000), "margin_pp"] > 0 and hu.loc[("higher_free", 10_000), "margin_pp"] < 0
    assert hu.loc[("basic_used", 10_000), "margin_pp"] < 0 < hu.loc[("basic_used", 50_000), "margin_pp"], "basic: behind/ahead"
    for pk in ("hicbc", "taper"):
        assert hu.loc[(pk, 10_000), "margin_pp"] < 0 < min(hu.loc[(pk, 25_000), "margin_pp"], hu.loc[(pk, 50_000), "margin_pp"])
    assert min(hu.loc[("additional", a), "margin_pp"] for a in (5_000, 10_000, 25_000, 50_000)) > 0, "additional from £5k"
    assert hu.loc[("zero", 10_000), "mean_margin_pp"] < 0, "even on average the bank wins for a non-taxpayer"
    assert (n.gilt < n.pb_mean).all(), "the gilt does not beat the average Premium Bond return"
    i = json.loads((RES / "today_inputs.json").read_text(encoding="utf-8"))
    assert i["easy"]["rate"] > i["pb"]["rate"] and i["fix1y"]["rate"] > i["pb"]["rate"], "heading 2.1"
    ev = pd.read_csv(RES / "lag_events.csv")
    e26 = ev[ev.announced >= "2026-01-01"]
    assert list(e26.change_bp > 0) == [False, True, True] and e26.announced.iloc[0][5:7] == "02", "2026: a Feb cut, two rises"
    luck = pd.read_csv(RES / "pb_luck.csv").set_index(["draws", "amount"])
    assert luck.loc[(12, 1_000), "p_nothing"] > 0.5 and (luck.xs(12).p50_pa < luck.xs(12).mean_pa).all()
    big = pd.read_csv(RES / "pb_big_prize.csv")
    per = big.p_prize / (big.amount * big.years)
    assert per.max() / per.min() < 1.02, "the chance of a £100k+ prize grows almost in step with amount x years"
    assert (big.p_total >= big.p_prize - 1e-9).all(), "totals reach £100k at least as often as one prize does"
    c20 = big.set_index(["years", "amount"]).loc[(20, 100_000)]
    assert c20.p_total > 2 * c20.p_prize, "totals reach £100k more often over long holdings"
    lag = pd.read_csv(RES / "lag_monthly.csv", dtype={"month": str}).set_index("month")
    assert (lag.loc["2023-01":, "pb_minus_avg_easy"] > 0).all(), "PB above the average easy-access rate since 2023"
    assert lag.pb_minus_sonia.iloc[-1] > 0, "PB above SONIA now"


def md_table(header, rows):
    out = ["| " + " | ".join(header) + " |", "|" + "---|" * len(header)]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


def table_luck():
    t = pd.read_csv(RES / "pb_luck.csv")
    one = t[t.draws == 12].set_index("amount")
    five = t[t.draws == 60].set_index("amount")
    rows = []
    for a in (100, 1_000, 5_000, 10_000, 25_000, 50_000, 100_000):
        r = one.loc[a]
        nothing = pct(r.p_nothing, 0) if r.p_nothing >= 0.005 else "<1%"
        rows.append([gbp(a) + (" (couple)" if a > 50_000 else ""), nothing, f"{gbp(r.p10)} ({pct(r.p10_pa)})", f"**{gbp(r.p50)} ({pct(r.p50_pa)})**",
                     f"{gbp(r.p90)} ({pct(r.p90_pa)})", pct(five.loc[a].p50_pa)])
    return md_table(["Amount", "Win nothing", "Unlucky (1 in 10)", "Typical (median)", "Lucky (1 in 10)",
                     "Typical, a year over 5 years"], rows)


def table_big():
    t = pd.read_csv(RES / "pb_big_prize.csv").set_index(["amount", "years"]).p_prize
    years = sorted(t.index.unique("years"))
    rows = [[gbp(a) + (" (couple)" if a > 50_000 else "")] + [one_in(t.loc[(a, y)]) for y in years]
            for a in t.index.unique("amount")]
    return md_table(["Amount"] + [f"{y} year{'s' if y > 1 else ''}" for y in years], rows)


def table_timing():
    t = pd.read_csv(RES / "entry_timing.csv")
    rows = [[day_name(r.bought), day_name(r.cash_in), r.days, r.draws, gbp(r.median_10000), gbp(r.median_50000)]
            for r in t.itertuples()]
    assert sorted(set(t.draws)) == [10, 11, 12], "the text describes 10, 11 and 12 draws"
    return md_table(["Bought", "Cash-in requested", "Days to the request", "Draws", "£10,000", "£50,000"], rows)


def table_inputs():
    i = json.loads((RES / "today_inputs.json").read_text(encoding="utf-8"))
    g = i["gilt"]
    rows = [
        ["Premium Bonds", f"{pct(i['pb']['rate'], 2)} prize fund rate, tax-free", "", f"{month_name(i['pb']['draw'])} draw", "NS&I"],
        ["Best easy access", pct(i["easy"]["rate"], 2), i["easy"]["name"], day_name(i["easy"]["as_of"]), "Moneyfacts"],
        ["Best 1-year fix", pct(i["fix1y"]["rate"], 2), i["fix1y"]["name"], day_name(i["fix1y"]["as_of"]), "Moneyfacts"],
        ["Best easy-access cash ISA", f"{pct(i['isa_easy']['rate'], 2)}, tax-free", i["isa_easy"]["name"],
         day_name(i["isa_easy"]["as_of"]), "Moneyfacts"],
        ["Best 1-year fixed cash ISA", f"{pct(i['isa_fix1y']['rate'], 2)}, tax-free", i["isa_fix1y"]["name"],
         day_name(i["isa_fix1y"]["as_of"]), "Moneyfacts"],
        ["NS&I Direct Saver", pct(i["direct_saver"]["rate"], 2), "", f"from {day_name(i['direct_saver']['from'])}", "NS&I"],
        ["Money market fund", f"{pct(i['mmf']['yield_gross'], 2)} yield, {pct(i['mmf']['rate'], 2)} after its "
         f"{pct(i['mmf']['ocf'], 2)} charge", "Royal London Short Term Money Market Fund", day_name(i["mmf"]["as_of"]),
         "Royal London"],
        ["Gilt", f"{pct(g['hl_gry']['0'], 2)} to maturity", f"{g['name']}, price {g['clean_price']:.2f}", day_name(g["as_of"]),
         "Hargreaves Lansdown"],
        ["Average easy-access account", pct(i["avg_easy"]["rate"], 2), "Advertised rate, excluding bonuses",
         month_name(i["avg_easy"]["as_of"]), "Bank of England"],
        ["Bank Rate", pct(i["bank_rate"]["rate"], 2), "", month_name(i["bank_rate"]["as_of"]), "Bank of England"],
    ]
    return md_table(["Option", "Rate", "Product", "As of", "Source"], rows)


def table_today(amount):
    n = pd.read_csv(RES / "today_net.csv")
    n = n[(n.year == "2026-27") & (n.amount == amount)].pivot(index="profile", columns="product", values="net_pct")
    b = pd.read_csv(RES / "today_beat.csv")
    b = b[(b.year == "2026-27") & (b.amount == amount)].set_index("profile")
    rows = []
    for pk in PROFILES:
        r = n.loc[pk]
        cells = {"pb": r.pb_median, "easy": r.easy, "fix": r.fix1y, "mmf": r.mmf, "gilt": r.gilt}
        best = max(cells, key=cells.get)
        def f(key, text):
            return f"**{text}**" if key == best else text
        rows.append([LABEL[pk], f("pb", f"{pct(r.pb_median)} ({pct(r.pb_p10)}-{pct(r.pb_p90)})"), f("easy", pct(r.easy, 2)),
                     f("fix", pct(r.fix1y, 2)), f("mmf", pct(r.mmf, 2)), f("gilt", pct(r.gilt, 2)),
                     pct(b.loc[pk, "p_beat_easy"], 0)])
    return md_table(["Saver", "Premium Bonds, typical (unlucky-lucky)", "Best easy access", "Best 1-year fix",
                     "Money market fund (AJ Bell)", "Gilt to Jan 2028", "Chance Premium Bonds beat easy access"], rows) + \
        "\n\nThe best of the five for each saver is in bold. The fix and the gilt tie your money up; the others don't."


def table_new():
    b = pd.read_csv(RES / "today_beat.csv")
    b = b[b.year == "2026-27"].set_index(["profile", "amount"])
    rows = [[LABEL[pk]] + [pp(b.loc[(pk, a), c]) for a in (10_000, 50_000, 100_000) for c in ("margin_pp", "margin_new_pp")]
            for pk in PROFILES]
    return md_table(["Saver", "£10,000, held", "£10,000, new", "£50,000, held", "£50,000, new",
                     "£100,000 couple, held", "£100,000 couple, new"], rows)


def table_teq():
    b = pd.read_csv(RES / "today_beat.csv")
    b = b[b.year == "2026-27"].pivot(index="profile", columns="amount", values="tax_equivalent")
    amounts = [a for a in b.columns if a >= 5_000]
    return md_table(["Saver"] + [gbp(a) + (" (couple)" if a > 50_000 else "") for a in amounts],
                    [[LABEL[pk]] + [pct(b.loc[pk, a], 2) for a in amounts] for pk in PROFILES])


def table_mmf_fees():
    t = pd.read_csv(RES / "mmf_fees.csv")
    pots = [5_000, 10_000, 50_000, 100_000]
    rows = []
    for plat in t.platform.unique():
        s = t[t.platform == plat].set_index("pot")
        rows.append([plat] + [f"{gbp(s.loc[p, 'fee_gbp'])} → {pct(s.loc[p, 'net_before_tax'], 2)}" for p in pots])
    return md_table(["Platform"] + [f"{gbp(p)} pot" for p in pots], rows) + \
        "\n\nEach cell: platform charge a year → the fund's yield left after both charges, before tax and before dealing " \
        "fees (at AJ Bell, £1.50 each time you buy or sell)."


def table_events():
    e = pd.read_csv(RES / "lag_events.csv", dtype={"first_draw": str})
    rows = []
    for r in e.itertuples():
        gm = "" if pd.isna(r.gilt_1y_3m_move_pp) else pp(r.gilt_1y_3m_move_pp / 100, 2)
        rows.append([day_name(r.announced), month_name(r.first_draw), f"{pct(r.old_rate, 2)} → {pct(r.new_rate, 2)}",
                     r.days_since_bank_rate_change, gm])
    return md_table(["Announced", "First draw", "Prize rate", "Days since Bank Rate last moved",
                     "Change in 1-year gilt yield in the 3 months before the announcement month (points)"], rows)


def table_safety(v):
    prot = json.loads((ROOT / "params" / "protection.json").read_text(encoding="utf-8"))
    rows = [
        ["Premium Bonds", "100% Treasury-backed", f"{prot['pb_cashin_days']}; prizes only for whole months held",
         f"{gbp(prot['pb_min'])} to {gbp(prot['pb_max'])}"],
        ["Bank or building society account", f"FSCS, {gbp(prot['fscs_deposit_limit'])} per banking licence",
         "Same day (easy access); locked (fixed)", "Varies"],
        ["NS&I Direct Saver", "100% Treasury-backed", "Easy access", "Up to £2m"],
        ["Money market fund", f"Not a deposit; FSCS investment cover ({gbp(prot['fscs_investment_limit'])}) only if a "
         "firm fails owing you assets", "A few days", "None"],
        ["Gilt", "UK government", "Sell any trading day, at the market price", "None"],
    ]
    return md_table(["Option", "Protection", "Getting money out", "Limits"], rows)


def trailing_parts(v):
    meta = json.loads((RES / "trailing_meta.json").read_text(encoding="utf-8"))
    t = pd.read_csv(RES / "trailing.csv")
    pbd = pd.read_csv(RES / "trailing_pb.csv").set_index("amount")
    w = {"draw_from": month_name(meta["draws"][0]), "draw_to": month_name(meta["draws"][1]),
         "m_from": month_name(meta["months"][0]), "m_to": month_name(meta["months"][1])}
    d = pd.read_csv(ROOT / "data" / "derived" / "pb_draws.csv", dtype={"draw": str})
    win = d[(d.draw >= meta["draws"][0]) & (d.draw <= meta["draws"][1])]
    w["pb_avg_rate"] = pct(win.rate.mean(), 2)

    def val(a, pk, prod):
        return t[(t.amount == a) & (t.profile == pk) & (t["product"] == prod)].pa.iloc[0]
    rows = []
    for pk in PROFILES:
        cells = {prod: val(50_000, pk, prod) for prod in ("pb_median", "best_chaser", "avg_easy", "fix_rolled", "mmf")}
        best = max(cells, key=cells.get)
        def f(key):
            txt = pct(cells[key], 2)
            return f"**{txt}**" if key == best else txt
        rows.append([LABEL[pk], f("pb_median"), f("best_chaser"), f("avg_easy"), f("fix_rolled"), f("mmf"),
                     pct(val(50_000, pk, "p_pb_beats_chaser"), 0)])
    table = md_table(["Saver", "Premium Bonds, typical", "Best-buy chaser", "Average easy-access account",
                      "Two 1-year fixes", "Money market fund (AJ Bell)", "Chance Premium Bonds beat the chaser"], rows)
    hu = {p: val(50_000, "higher_used", p) for p in ("pb_median", "best_chaser")}
    zero = {p: val(50_000, "zero", p) for p in ("pb_median", "best_chaser", "avg_easy", "mmf")}
    assert zero["best_chaser"] > zero["pb_median"]
    pb_vs_avg = all(val(50_000, pk, "pb_median") > val(50_000, pk, "avg_easy") for pk in PROFILES)
    hu_word = "beat" if hu["pb_median"] > hu["best_chaser"] else "trailed"
    bu = {p: val(50_000, "basic_used", p) for p in ("pb_median", "best_chaser")}
    basic_note = ("" if bu["pb_median"] >= bu["best_chaser"] else
                  f" One difference: a basic-rate saver with the allowance used did better in the account "
                  f"({pct(bu['best_chaser'], 2)} against {pct(bu['pb_median'], 2)}), where today's rates give Premium Bonds a small edge.")
    sb = pd.read_csv(RES / "scoreboard.csv")
    beat40 = int((sb.pb_median_50000 > sb.best_net_higher_used_50000).sum())
    beat20 = int((sb.pb_median_50000 > sb.best_net_basic_used_50000).sum())
    months40 = f"all {len(sb)}" if beat40 == len(sb) else f"{beat40} of the {len(sb)}"
    cf = meta["carried_forward"]
    cf_note = (" " + ", ".join(month_name(x) for x in cf) + " has no archived best-buy page, so the previous month's "
               "rate is carried forward." if cf else "")
    gaps = ("Archived best-buy pages were missing for " + ", ".join(month_name(x) for x in cf) +
            "; the previous month's best buy is carried forward." if cf else
            "Every month of the two-year window had an archived best-buy page.")
    bullet = (f"- **The last two years tell much the same story.** From the {w['draw_from']} to the {w['draw_to']} "
              f"draw the prize rate averaged {w['pb_avg_rate']}. On £50,000 the typical holder made "
              f"{pct(zero['pb_median'], 2)} a year. A non-taxpayer who moved to the best clean easy-access account every "
              f"month made {pct(zero['best_chaser'], 2)}; a higher-rate saver with the allowance used made "
              f"{pct(hu['best_chaser'], 2)} after tax, so Premium Bonds {hu_word} the account for them.")
    section = f"""## 4. The last two years: the same pattern, realised

Today's rates are a snapshot. Here is what each option actually paid over the last 24 draws, {w['draw_from']} to {w['draw_to']} (deposits and the fund over {w['m_from']} to {w['m_to']}, the months those draws reward). Tax is worked out separately for each of the two 12-month blocks (not tax years), with one savings allowance each, under the rules of the tax year each block starts in; the savings tax rules did not change over the period. The prize rate averaged {w['pb_avg_rate']}.

[![Figure 3. Line chart over 24 months: the typical one-year Premium Bond return on £50k, at each month's prize table, beat the best easy-access rate after 40% tax in {months40} months and after 20% tax in {beat20}.](fig-scoreboard.svg)](fig-scoreboard.svg)

Month by month, the typical £50,000 holding beat the best easy-access account after 40% tax (allowance used) in {months40} months, and after 20% tax in {beat20} (Figure 3).{cf_note}{basic_note}

**Table 10. What £50,000 actually earned, a year, after tax and fees, over the last two years**

{table}

The "best-buy chaser" moved to the top clean easy-access account at the start of every month, the best a saver could have done with instant access under the rule in section 2.1 (the two 1-year fixes did better still, with the money tied up); the average account is the average rate advertised on new easy-access accounts (money left in old accounts typically earned less){'' if not pb_vs_avg else ', and Premium Bonds beat it for every saver'}. The two 1-year fixes were the best buys in {w['m_from']} and a year later. The money market fund is its actual return after its charge, taxed, then AJ Bell's fee at today's tariff. Every figure is the total two-year gain after tax and fees, divided by two: what £50,000 earned a year, on average.
"""
    return bullet, section, gaps


def calc_files():
    """The calculator of section 1.3: its script, and the latest prize table it works from (the one the tables use)."""
    row = pb.draws()[-1]
    data = {"draw": str(row["draw"]), "draw_month": month_name(row["draw"]), "eligible": int(row["eligible"]),
            "prizes": [[v, int(row[f"n_{v}"])] for v in pb.PRIZES]}
    (OUT / "pb-calc.json").write_text(json.dumps(data), encoding="utf-8")
    shutil.copyfile(ROOT / "code" / "web" / "pb-calc.js", OUT / "pb-calc.js")
    return "{{< pb-calc >}}"                 # the site's shortcode; a value, so format_map leaves its braces alone


def main():
    claims()
    v = values()
    v["table_luck"], v["table_timing"], v["table_inputs"] = table_luck(), table_timing(), table_inputs()
    v["table_big"] = table_big()
    OUT.mkdir(parents=True, exist_ok=True)
    v["calculator"] = calc_files()
    v["table_today_10k"], v["table_today_50k"] = table_today(10_000), table_today(50_000)
    v["table_teq"], v["table_mmf_fees"], v["table_events"] = table_teq(), table_mmf_fees(), table_events()
    v["table_new"] = table_new()
    v["table_safety"] = table_safety(v)
    v["trailing_bullet"], v["trailing_section"], v["gaps_sentence"] = trailing_parts(v)
    v["n_tax_checks"] = str(len(re.findall(r"^\s+\(\"", (ROOT / "code" / "checks" / "g_tax.py").read_text(encoding="utf-8"), re.M)))
    tmpl = (ROOT / "writeup" / "article.md.tmpl").read_text(encoding="utf-8")
    text = tmpl.format_map(v)
    left = re.findall(r"\{[a-z0-9_]+\}", text)
    assert not left, left
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "index.md").write_text(text, encoding="utf-8")
    print("wrote", OUT / "index.md", len(text.split()), "words")


if __name__ == "__main__":
    main()
