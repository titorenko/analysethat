"""Every number quoted in the write-up, computed from results/ (and the engines where a value is not stored).
build_article.py fills writeup/article.md.tmpl with these; nothing in the article's numbers is typed by hand.

Usage (inspection): .venv/Scripts/python -I code/figures/article_values.py
"""
import datetime as dt
import decimal
import json
import math
import pathlib
import sys

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
RES = ROOT / "results"
sys.path.insert(0, str(ROOT / "code" / "engine"))
import inputs as I  # noqa: E402
import pb  # noqa: E402
import tax as T  # noqa: E402

MONTH = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
         "November", "December"]


def rnd(x, d):
    """Round half up (so 6.75 → 6.8 everywhere, whatever the float noise)."""
    q = decimal.Decimal(1).scaleb(-d)
    return decimal.Decimal(repr(round(float(x), 10))).quantize(q, rounding=decimal.ROUND_HALF_UP)


def pct(x, d=1):
    return f"{rnd(100 * x, d)}%".replace("-", "−")


def pp(x, d=1, sign=True):
    v = rnd(100 * x, d)
    s = (f"+{v}" if v > 0 else f"{v}") if sign else f"{abs(v)}"
    return s.replace("-", "−")


def gbp(x):
    return f"£{x:,.0f}"


def k(x):
    return f"£{x / 1000:,.0f}k"


def month_name(ym):
    y, m = map(int, ym.split("-"))
    return f"{MONTH[m - 1]} {y}"


def day_name(d):
    d = dt.date.fromisoformat(d) if isinstance(d, str) else d
    return f"{d.day} {MONTH[d.month - 1]} {d.year}"


def words(n):
    return {1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine", 10: "ten",
            11: "eleven", 12: "twelve"}.get(n, str(n))


LABEL = {"zero": "Pays no tax on interest", "basic_free": "Basic rate, allowance unused",
         "basic_used": "Basic rate, allowance used", "higher_free": "Higher rate, allowance unused",
         "higher_used": "Higher rate, allowance used", "hicbc": "Higher rate + child benefit charge (2 children), allowance unused",
         "taper": "£100k-£125k (60% band)", "additional": "Additional rate (45%)"}


def values():
    v = {}
    inp = json.loads((RES / "today_inputs.json").read_text(encoding="utf-8"))
    luck = pd.read_csv(RES / "pb_luck.csv").set_index(["draws", "amount"])
    beat = pd.read_csv(RES / "today_beat.csv")
    net = pd.read_csv(RES / "today_net.csv")
    lag = json.loads((RES / "lag_cycles.json").read_text(encoding="utf-8"))
    lagm = pd.read_csv(RES / "lag_monthly.csv", dtype={"month": str}).set_index("month")
    ev = pd.read_csv(RES / "lag_events.csv", dtype={"first_draw": str})

    # ---- inputs and dates
    p = inp["pb"]
    v["pb_rate"], v["pb_odds"] = pct(p["rate"], 2), f"{p['odds']:,}"
    v["draw_month"] = month_name(p["draw"])
    v["next_draw_month"] = month_name(p["next_draw"])
    v["next_draw_note"] = ("" if abs(p["next_rate"] - p["rate"]) < 5e-5 else
                           f" NS&I's estimate for the {month_name(p['next_draw'])} draw implies {pct(p['next_rate'], 2)}.")
    v["easy_rate"], v["easy_name"] = pct(inp["easy"]["rate"], 2), inp["easy"]["name"]
    v["fix_rate"], v["fix_name"] = pct(inp["fix1y"]["rate"], 2), inp["fix1y"]["name"]
    v["isa_easy_rate"], v["isa_easy_name"] = pct(inp["isa_easy"]["rate"], 2), inp["isa_easy"]["name"]
    v["isa_fix_rate"], v["isa_fix_name"] = pct(inp["isa_fix1y"]["rate"], 2), inp["isa_fix1y"]["name"]
    v["bestbuy_date"] = day_name(inp["easy"]["as_of"])
    v["avg_easy_rate"], v["avg_easy_month"] = pct(inp["avg_easy"]["rate"], 2), month_name(inp["avg_easy"]["as_of"])
    v["bank_rate"] = pct(inp["bank_rate"]["rate"], 2)
    v["ds_rate"], v["ds_from"] = pct(inp["direct_saver"]["rate"], 2), day_name(inp["direct_saver"]["from"])
    m = inp["mmf"]
    fee = I.fees()["platforms"]["AJ Bell"]
    v["mmf_yield"], v["mmf_ocf"], v["mmf_net_ocf"] = pct(m["yield_gross"], 2), pct(m["ocf"], 2), pct(m["rate"], 2)
    v["mmf_date"] = day_name(m["as_of"])
    v["ajb_fee"] = pct(fee["funds"]["tiers"][0][1], 2)
    v["ajb_deal"] = f"£{fee['fund_deal']:.2f}"
    v["mmf_after_fee"] = pct(m["rate"] - fee["funds"]["tiers"][0][1], 2)
    g = inp["gilt"]
    v["gilt_name"], v["gilt_price"], v["gilt_gry"] = g["name"], f"{g['clean_price']:.2f}", pct(g["hl_gry"]["0"], 2)
    v["gilt_date"], v["gilt_maturity"] = day_name(g["as_of"]), day_name(g["maturity"])
    v["gilt_deal"] = f"£{fee['gilts']['deal']:.0f}"
    v["gilt_cap"] = f"£{fee['gilts']['cap_per_year_gia']:.0f}"
    v["as_of"] = day_name(dt.date.today())

    # ---- luck
    def L(draws, a, col):
        return luck.loc[(draws, a), col]
    for a in (1_000, 5_000, 10_000, 25_000, 50_000):
        tag = f"{a // 1000}k"
        v[f"med_{tag}"] = pct(L(12, a, "p50_pa"))
        v[f"med_{tag}_gbp"] = gbp(L(12, a, "p50"))
        v[f"p10_{tag}"], v[f"p90_{tag}"] = pct(L(12, a, "p10_pa")), pct(L(12, a, "p90_pa"))
        v[f"nothing_{tag}"] = pct(L(12, a, "p_nothing"), 0) if L(12, a, "p_nothing") >= 0.005 else "under 1%"
    v["mean_reinvest"] = pct(L(12, 10_000, "mean_reinvested_pa"), 2)
    year12 = [pb.draws()[-1]] * 12                   # MSE's convention: prizes paid out, a fixed holding
    for a in (10_000, 25_000, 50_000):
        v[f"mse_med_{a // 1000}k"] = gbp(pb.quantile(pb.distribution(year12, a), 0.5))
    v["p10_10k_gbp"] = gbp(L(12, 10_000, "p10"))
    v["med_10k_5y"], v["p25_10k_5y"], v["p75_10k_5y"] = (pct(L(60, 10_000, c)) for c in ("p50_pa", "p25_pa", "p75_pa"))
    v["p10_10k_5y"], v["p90_10k_5y"] = (pct(L(60, 10_000, c)) for c in ("p10_pa", "p90_pa"))
    v["med_1k_2y_gbp"] = gbp(L(24, 1_000, "p50"))
    latest = pb.draws()[-1]
    vals, probs = pb.table(latest)
    big = probs[vals * pb.UNIT >= 5_000].sum()
    v["p_big_10k"] = pct(1 - math.exp(-10_000 * 12 * big), 1)
    v["p_big_50k"] = pct(1 - math.exp(-50_000 * 12 * big), 1)
    v["n_prizes"] = f"{int(latest['total_prizes']):,}"
    v["n_25"] = f"{int(latest['n_25']):,}"
    v["eligible_bn"] = f"{latest['eligible'] / 1e9:,.1f}"
    v["draw_worth"] = pct(p["rate"] / 12, 2)

    # ---- today: who wins
    b26 = beat[beat.year == "2026-27"].set_index(["profile", "amount"])
    b27 = beat[beat.year == "2027-28"].set_index(["profile", "amount"])
    for pk in T.PROFILES:
        for a in (10_000, 50_000):
            tag = f"{pk}_{a // 1000}k"
            v[f"margin_{tag}"] = pp(b26.loc[(pk, a), "margin_pp"])
            v[f"beat_{tag}"] = pct(b26.loc[(pk, a), "p_beat_best_rival"], 0)
            v[f"teq_{tag}"] = pct(b26.loc[(pk, a), "tax_equivalent"], 2)
            v[f"margin27_{tag}"] = pp(b27.loc[(pk, a), "margin_pp"])
            v[f"amargin_{tag}"] = pp(b26.loc[(pk, a), "margin_pp"], sign=False)
            v[f"amargin27_{tag}"] = pp(b27.loc[(pk, a), "margin_pp"], sign=False)
            v[f"amargin_new_{tag}"] = pp(b26.loc[(pk, a), "margin_new_pp"], sign=False)
            v[f"amean_{tag}"] = pp(b26.loc[(pk, a), "mean_margin_pp"], sign=False)
    n26 = net[net.year == "2026-27"].set_index(["profile", "amount", "product"]).net_pct
    for pk in T.PROFILES:
        for a in (10_000, 50_000):
            for prod in ("easy", "mmf", "gilt", "fix1y", "direct_saver"):
                v[f"net_{prod}_{pk}_{a // 1000}k"] = pct(n26.loc[(pk, a, prod)], 2)
    v["gilt_min_50k"] = pct(min(n26.loc[(pk, 50_000, "gilt")] for pk in T.PROFILES), 2)
    v["gilt_max_50k"] = pct(max(n26.loc[(pk, 50_000, "gilt")] for pk in T.PROFILES), 2)
    v["gilt_min_10k"] = pct(min(n26.loc[(pk, 10_000, "gilt")] for pk in T.PROFILES), 2)
    v["gilt_max_10k"] = pct(max(n26.loc[(pk, 10_000, "gilt")] for pk in T.PROFILES), 2)
    v["mmf_vs_easy_gap"] = pp(n26.loc[("zero", 50_000, "easy")] - n26.loc[("zero", 50_000, "mmf")], 1, sign=False)
    cells = beat[beat.year == "2026-27"]
    v["cells_pb_ahead"] = str(int((cells.margin_pp > 0).sum()))
    v["cells_new_ahead"] = str(int((cells.margin_new_pp > 0).sum()))
    v["tax_year_now"] = "2026/27"
    cpi = pd.read_csv(ROOT / "data" / "derived" / "cpi.csv").iloc[0]
    mon, yr = cpi.month.split()[1], cpi.month.split()[0]
    v["cpi_rate"] = pct(cpi.cpi_annual, 1)
    v["cpi_month"] = f"{MONTH[[m[:3].upper() for m in MONTH].index(mon)]} {yr}"
    v["cells_total"] = str(len(cells))

    # ---- lag
    r, c, y = lag["rise"], lag["cut"], lag["y2026"]
    v["rise_first_br"] = day_name(r["first_bank_rate_rise"])
    v["rise_first_pb"] = day_name(r["first_pb_rise_announced"])
    v["rise_lag"] = f"{round(r['months_lag'])} months"
    v["br_from"], v["br_peak"] = pct(r["bank_rate_from"] / 100, 2), pct(r["bank_rate_peak"] / 100, 2)
    v["pb_from"], v["pb_peak"] = pct(r["pb_from"] / 100, 2), pct(r["pb_peak"] / 100, 2)
    v["cut_first_pb"], v["cut_first_br"] = day_name(c["first_pb_cut_announced"]), day_name(c["first_bank_rate_cut"])
    v["cut_lead"] = f"{round(c['months_lead'])} months"
    v["pb_low_2026"], v["pb_now"] = pct(y["pb_low"] / 100, 2), pct(y["pb_now"] / 100, 2)
    v["pb_changes_2026"] = words(y["pb_changes_2026"])
    v["gilt_feb26"] = pct(lagm.loc["2026-02", "gilt_1y"] / 100, 2)
    v["gilt_mar26"] = pct(lagm.loc["2026-03", "gilt_1y"] / 100, 2)
    v["gilt_latest"] = pct(lagm.gilt_1y.dropna().iloc[-1] / 100, 2)
    v["gilt_latest_month"] = month_name(lagm.gilt_1y.dropna().index[-1])
    neg = (lagm.pb_minus_sonia < 0).astype(int)
    run, best, start = 0, (0, None, None), None
    for mth, isneg in neg.items():
        if isneg:
            start = start or mth
            run += 1
            if run > best[0]:
                best = (run, start, mth)
        else:
            run, start = 0, None
    v["below_sonia_months"], v["below_sonia_from"], v["below_sonia_to"] = str(best[0]), month_name(best[1]), month_name(best[2])
    v["n_events"] = str(len(ev))
    v["notice_min"], v["notice_max"] = str(int(ev.notice_days.min())), str(int(ev.notice_days.max()))
    v["avg_easy_gap"] = pp(lagm.pb_minus_avg_easy.loc["2023-01":].mean() / 100, 1, sign=False)

    # ---- rules and limits, from params (so a Budget edit flows through)
    r26, r27 = T.RULES["2026-27"], T.RULES["2027-28"]
    v["psa_basic"], v["psa_higher"] = gbp(r26["psa"]["basic"]), gbp(r26["psa"]["higher"])
    v["starting_band"] = gbp(r26["starting_rate_limit"])
    v["isa_limit"], v["cash_isa_27"] = gbp(r27["isa"]["overall"]), gbp(r27["isa"]["cash_under_65"])
    v["rates_27"] = ", ".join(f"{100 * r27['savings_rates'][b]:.0f}%" for b in ("basic", "higher", "additional"))
    v["rates_27_rise"] = f"{100 * (r27['savings_rates']['basic'] - r26['savings_rates']['basic']):.0f}"
    lo, hi = 0.0, 20_000.0                       # tax-free interest for the State-Pension-only saver
    for _ in range(60):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if T.cost(T.PROFILES["zero"], mid, "2026-27") < 0.005 else (lo, mid)
    v["pension_taxfree"] = gbp(round(lo, -1))
    taper = dict(T.PROFILES["taper"], other_savings=r26["psa"]["higher"])
    v["taper_cost"] = f"{100 * (T.cost(taper, 1000, '2026-27') / 1000):.0f}p"
    v["taper_cost_scot"] = pct(T.cost(dict(taper, scottish=True), 1000, "2026-27") / 1000, 1)
    v["taper_cost_pct"] = pct(T.cost(taper, 1000, "2026-27") / 1000, 0)
    v["taper_from"], v["taper_to"] = gbp(r26["taper_from"]), gbp(r26["additional_from"])
    prot = json.loads((ROOT / "params" / "protection.json").read_text(encoding="utf-8"))
    v["fscs_limit"] = gbp(prot["fscs_deposit_limit"])
    v["pb_cashin"] = prot["pb_cashin_days"]
    v["couple_max"] = gbp(2 * prot["pb_max"])
    v["psa_cliff"] = gbp(r26["personal_allowance"] + r26["basic_rate_band"])
    # cross-checks quoted in the method note, recomputed here rather than typed
    year12 = [pb.draws()[-1]] * 12
    def net(amount, t, psa):
        i = 0.0455 * amount
        return i - t * max(0.0, i - psa)
    mse = [(100, net(100, 0, 0), 6), (1_000, net(1_000, 0, 0), 35), (5_000, net(5_000, 0, 0), 30),
           (30_000, net(30_000, 0, 0), 27), (50_000, net(50_000, 0, 0), 26), (30_000, net(30_000, .2, 1000), 33),
           (50_000, net(50_000, .2, 1000), 41), (30_000, net(30_000, .4, 500), 61), (50_000, net(50_000, .4, 500), 77)]
    dev = max(abs(100 * pb.p_at_least(pb.distribution(year12, a), thr) - want) for a, thr, want in mse)
    v["mse_maxdev"] = f"{rnd(dev, 1)}"
    nav = pd.read_csv(ROOT / "data" / "derived" / "rl_nav.csv")
    tr = pd.read_csv(ROOT / "data" / "derived" / "rl_rlam.csv").set_index("month_end").cum_tr_pct
    a5, b5 = list(tr.index)[-61], list(tr.index)[-1]
    ft = float(nav[nav.date <= b5].nav.iloc[-1]) / float(nav[nav.date <= a5].nav.iloc[-1]) - 1
    v["ft_gap"] = f"{rnd(abs(100 * ft - ((1 + tr[b5] / 100) / (1 + tr[a5] / 100) - 1) * 100), 3)}"
    gt = (ROOT / "code" / "checks" / "g_tax.py").read_text(encoding="utf-8")
    v["n_govuk"] = words(gt.count("\"gov.uk/apply"))
    v["fidelity_flat"] = gbp(I.fees()["platforms"]["Fidelity"]["funds"]["flat_under_25000"])
    h = r26["hicbc"]                                 # child benefit charge, 2 children, per £ of extra income
    cb = (h["cb_weekly_eldest"] + h["cb_weekly_other"]) * 52
    hic = cb / (h["per_1pct"] * 100)
    v["hicbc_inside"], v["hicbc_above"] = pct(hic, 1), pct(hic + r26["savings_rates"]["higher"], 1)
    v["hicbc_step"] = gbp(h["per_1pct"])
    v["new_money_10k"] = gbp(pd.read_csv(RES / "entry_timing.csv").query("draws == 11").median_10000.iloc[0])
    mf = pd.read_csv(RES / "mmf_fees.csv").set_index(["platform", "pot"])
    v["fid_5k_net"] = pct(mf.loc[("Fidelity", 5_000), "net_before_tax"], 2)
    assert mf.loc[("Fidelity", 5_000), "net_before_tax"] < 0.6 * inp["mmf"]["rate"], "small-pot fees bite (heading)"
    bbc = json.loads((RES / "bestbuy_check.json").read_text(encoding="utf-8"))
    v["bb_same"], v["bb_tested"] = str(bbc["same"]), str(bbc["tested"])
    v["n_draws"] = str(len(pb.draws()))
    return v


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for key, val in values().items():
        print(f"{key:<28} {val}")
