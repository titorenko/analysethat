"""Figures for the write-up: hand-built SVGs in the site's house style (system-ui, surface #fcfcfb, light and dark
via prefers-color-scheme), as in the schools post. Every number is read from results/; each title's claim is
asserted against the data it is drawn from (blog-article-layout-and-style).

Palette (the dataviz reference palette, slots 1-3 validated all-pairs in both modes): Premium Bonds blue
#2a78d6 / #3987e5; rival orange #eb6834 / #d95926; aqua #1baf7a / #199e70; neutral #898781. Heat map: diverging
blue (Premium Bonds ahead) <-> red #e34948 / #e66767 (rival ahead) with a gray midpoint, as opacity steps over the
surface so the same marks work in both modes. Every series is direct-labelled; every chart has a table in the text.

Usage: .venv/Scripts/python -I code/figures/make_figures.py <out_dir>
"""
import pathlib
import sys

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
RES = ROOT / "results"
sys.path[:0] = [str(ROOT / "code" / "engine")]
import tax as T  # noqa: E402

OUT = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results" / "figures"
OUT.mkdir(parents=True, exist_ok=True)

CSS = """<style>
  .surface { fill: #fcfcfb; stroke: rgba(11,11,11,.10); }
  .t1 { fill: #0b0b0b; } .t2 { fill: #52514e; } .t3 { fill: #6b6a65; }
  .grid { stroke: #e1e0d9; stroke-width: 1; } .axis { stroke: #c3c2b7; stroke-width: 1; }
  .pb { fill: #2a78d6; stroke: #2a78d6; } .pb-l { stroke: #2a78d6; fill: none; } .pb-band { fill: #2a78d6; opacity: .22; }
  .riv { fill: #eb6834; stroke: #eb6834; } .riv-l { stroke: #eb6834; fill: none; }
  .aq { fill: #1baf7a; stroke: #1baf7a; } .aq-l { stroke: #1baf7a; fill: none; }
  .neu { fill: #898781; stroke: #898781; } .neu-l { stroke: #898781; fill: none; }
  .up1 { fill: #2a78d6; opacity: .16; } .up2 { fill: #2a78d6; opacity: .34; } .up3 { fill: #2a78d6; opacity: .55; }
  .dn1 { fill: #e34948; opacity: .14; } .dn2 { fill: #e34948; opacity: .30; } .dn3 { fill: #e34948; opacity: .50; }
  .mid { fill: #f0efec; }
  .halo { paint-order: stroke; stroke: #fcfcfb; stroke-width: 4px; stroke-linejoin: round; }
  .dash { stroke-dasharray: 5 4; }
  text { font-family: system-ui, -apple-system, 'Segoe UI', sans-serif; }
  @media (prefers-color-scheme: dark) {
    .surface { fill: #1a1a19; stroke: rgba(255,255,255,.10); }
    .t1 { fill: #ffffff; } .t2 { fill: #c3c2b7; } .t3 { fill: #a9a8a1; }
    .grid { stroke: #2c2c2a; } .axis { stroke: #383835; }
    .pb { fill: #3987e5; stroke: #3987e5; } .pb-l { stroke: #3987e5; } .pb-band { fill: #3987e5; }
    .riv { fill: #d95926; stroke: #d95926; } .riv-l { stroke: #d95926; }
    .aq { fill: #199e70; stroke: #199e70; } .aq-l { stroke: #199e70; }
    .up1, .up2, .up3 { fill: #3987e5; } .dn1, .dn2, .dn3 { fill: #e66767; }
    .mid { fill: #383835; }
    .halo { stroke: #1a1a19; }
  }
</style>"""


class Svg:
    def __init__(self, w, h, title, desc):
        self.w, self.h, self.parts = w, h, []
        self.head = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" '
                     f'role="img" aria-labelledby="t d">\n<title id="t">{esc(title)}</title><desc id="d">{esc(desc)}'
                     f'</desc>\n{CSS}\n<rect class="surface" x="0.5" y="0.5" width="{w - 1}" height="{h - 1}" rx="8"/>')

    def add(self, s):
        self.parts.append(s)

    def text(self, x, y, s, cls="t2", size=12, anchor="start", weight=None, halo=False):
        w = f' font-weight="{weight}"' if weight else ""
        c = cls + (" halo" if halo else "")
        self.add(f'<text class="{c}" x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}"{w}>{esc(s)}</text>')

    def line(self, x1, y1, x2, y2, cls, width=1, extra=""):
        self.add(f'<line class="{cls}" x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke-width="{width}"{extra}/>')

    def path(self, pts, cls, width=2):
        d = "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in pts)
        self.add(f'<path class="{cls}" d="{d}" stroke-width="{width}" stroke-linejoin="round" stroke-linecap="round"/>')

    def circle(self, x, y, r, cls):
        self.add(f'<circle class="{cls}" cx="{x:.1f}" cy="{y:.1f}" r="{r}"/>')

    def rect(self, x, y, w, h, cls, rx=0, tip=None):
        t = f"<title>{esc(tip)}</title>" if tip else ""
        self.add(f'<rect class="{cls}" x="{x:.1f}" y="{y:.1f}" width="{max(w, 0):.1f}" height="{max(h, 0):.1f}" rx="{rx}">{t}</rect>')

    def header(self, title, subtitle):
        self.text(24, 34, title, "t1", 17, weight=600)
        self.text(24, 56, subtitle, "t3", 13)

    def save(self, name):
        (OUT / name).write_text(self.head + "\n" + "\n".join(self.parts) + "\n</svg>\n", encoding="utf-8")
        print("wrote", OUT / name)


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def scale(d0, d1, r0, r1):
    return lambda v: r0 + (v - d0) / (d1 - d0) * (r1 - r0)


def money(a):
    return f"£{a / 1000:,.0f}k" if a >= 1000 else f"£{a:,.0f}"


def pct(x, d=1):
    return f"{100 * x:.{d}f}%"


LABEL = {"zero": "Pays no tax on interest", "basic_free": "Basic rate, allowance unused",
         "basic_used": "Basic rate, allowance used", "higher_free": "Higher rate, allowance unused",
         "higher_used": "Higher rate, allowance used", "hicbc": "Higher rate + child benefit charge",
         "taper": "£100k-£125k (60% band)", "additional": "Additional rate (45%)"}


# ---------------------------------------------------------------- F1 heat map: taxable money, today
def fig_heatmap():
    b = pd.read_csv(RES / "today_beat.csv")
    b = b[b.year == "2026-27"]
    amounts = sorted(b.amount.unique())
    profiles = list(T.PROFILES)
    m = 100 * b.pivot(index="profile", columns="amount", values="margin_pp").loc[profiles]   # percentage points
    p = b.pivot(index="profile", columns="amount", values="p_beat_best_rival").loc[profiles]
    wins = int((m > 0).sum().sum())
    higher = m.loc[["higher_free", "higher_used", "hicbc", "taper", "additional"], [a for a in amounts if a >= 25_000]]
    basic_best = m.loc[["basic_free", "basic_used"]].max().max()
    assert (m[1_000] < 0).all() and (higher > 0).all().all() and (m.loc["zero"] < 0).all()         and (m.loc["basic_free"] < 0).all() and basic_best < 0.5
    title = "Premium Bonds beat the best account for higher-rate savers with bigger pots; basic-rate savers gain little"
    sub = ("Typical Premium Bond return minus the best easy-access account after tax and fees, percentage points; "
           "taxable money, a year of 12 draws")
    W, H, L, top, cw, ch = 860, 492, 250, 104, 116, 40
    s = Svg(W, H, title, f"Heat map of {len(profiles)} tax positions by {len(amounts)} amounts; Premium Bonds ahead in "
            f"{wins} of {m.size} cells.")
    s.header(title, sub)
    for j, a in enumerate(amounts):
        s.text(L + j * cw + cw / 2, top - 12, money(a), "t2", 13, "middle", 600)
    for i, pk in enumerate(profiles):
        y = top + i * ch
        s.text(L - 12, y + ch / 2 + 4, LABEL[pk], "t2", 13, "end")
        for j, a in enumerate(amounts):
            v, pr = m.loc[pk, a], p.loc[pk, a]
            cls = ("up3" if v > 1 else "up2" if v > 0.5 else "up1" if v > 0.1 else "mid" if v >= -0.1
                   else "dn1" if v >= -0.5 else "dn2" if v >= -1 else "dn3")
            x = L + j * cw
            s.rect(x + 1, y + 1, cw - 2, ch - 2, cls, 4, f"{LABEL[pk]}, {money(a)}: {v:+.2f} pp; Premium Bonds ahead "
                   f"in {100 * pr:.0f}% of draws")
            s.text(x + cw / 2, y + ch / 2 - 1, f"{v:+.1f}", "t1", 14, "middle", 600)
            s.text(x + cw / 2, y + ch / 2 + 13, f"{100 * pr:.0f}% chance", "t3", 10.5, "middle")
    yb = top + len(profiles) * ch + 26
    s.text(L, yb, "Blue: the typical Premium Bond holder is ahead. Red: the best alternative is ahead.", "t3", 12)
    s.text(L, yb + 18, "Small print: the chance a year of Premium Bonds beats it.", "t3", 12)
    s.save("fig-heatmap.svg")


# ---------------------------------------------------------------- F2 luck by amount, one year
def fig_luck():
    t = pd.read_csv(RES / "pb_luck.csv")
    t = t[(t.draws == 12) & (t.amount >= 1_000)].set_index("amount")
    rate = pd.read_csv(RES / "lag_monthly.csv").pb.iloc[-1] / 100
    assert t.loc[1_000, "p50"] == 0 and t.loc[1_000, "p_nothing"] > 0.5 and (t.p50_pa < rate).all()
    title = f"The typical holder earns less than the advertised {pct(rate, 2)}; most £1k holders win nothing"
    sub = "Premium Bond winnings over one year, % of the amount held: median (dot), middle half (thick), 80% range (thin)"
    W, H, L, R, top, bot = 860, 420, 70, 820, 92, 360
    xs = list(t.index)
    xp = {a: L + (i + 0.5) * (R - L) / len(xs) for i, a in enumerate(xs)}
    ys = scale(0, 0.10, bot, top)
    s = Svg(W, H, title, "Range chart of one-year Premium Bond returns by amount held.")
    s.header(title, sub)
    for v in (0, 0.02, 0.04, 0.06, 0.08, 0.10):
        s.line(L, ys(v), R, ys(v), "grid")
        s.text(L - 8, ys(v) + 4, pct(v, 0), "t3", 11, "end")
    s.line(L, ys(rate), R, ys(rate), "neu-l dash", 1.5)
    s.text(R, ys(rate) - 6, f"Prize fund rate {pct(rate, 2)}", "t3", 11.5, "end", halo=True)
    for a in xs:
        r = t.loc[a]
        x = xp[a]
        s.line(x, ys(r.p10_pa), x, ys(r.p90_pa), "pb-l", 2)
        s.rect(x - 7, ys(r.p75_pa), 14, ys(r.p25_pa) - ys(r.p75_pa), "pb", 3)
        s.circle(x, ys(r.p50_pa), 6, "pb")
        s.add(f'<circle cx="{x:.1f}" cy="{ys(r.p50_pa):.1f}" r="6" class="halo" fill="none"/>')
        s.text(x + 14, ys(r.p50_pa) + 4, f"median {pct(r.p50_pa)}", "t2", 11.5, halo=True)
        s.text(x, bot + 20, money(a), "t2", 13, "middle", 600)
        s.text(x, bot + 38, f"nothing: {100 * r.p_nothing:.0f}%" if r.p_nothing >= 0.005 else "nothing: <1%", "t3", 11,
               "middle")
    s.save("fig-luck.svg")


# ---------------------------------------------------------------- F3 rates since 2020
def fig_rates():
    x = pd.read_csv(RES / "lag_monthly.csv", dtype={"month": str})
    y26 = x[x.month >= "2026-01"]
    feb, sep = x.set_index("month").loc["2026-02"], x.set_index("month").iloc[-1]
    assert y26.bank_rate_avg.nunique() == 1 and y26.pb.nunique() >= 3 and sep.gilt_1y - feb.gilt_1y > 0.5
    title = "Bank Rate stood still in 2026; Premium Bonds rose after gilt yields jumped"
    sub = "Monthly, % a year: Premium Bond prize fund rate, Bank Rate, 1-year gilt yield, average advertised easy-access rate"
    W, H, L, R, top, bot = 860, 440, 56, 740, 84, 390
    months = list(x.month)
    xs = scale(0, len(months) - 1, L, R)
    ys = scale(0, 6, bot, top)
    s = Svg(W, H, title, "Line chart of four interest rates, monthly, 2020 to 2026.")
    s.header(title, sub)
    for v in range(0, 7):
        s.line(L, ys(v), R, ys(v), "grid")
        s.text(L - 8, ys(v) + 4, f"{v}%", "t3", 11, "end")
    for i, mth in enumerate(months):
        if mth.endswith("-01"):
            s.line(xs(i), bot, xs(i), bot + 5, "axis")
            s.text(xs(i), bot + 20, mth[:4], "t3", 11, "middle")
    series = [("bank_rate_avg", "neu-l", 2, "Bank Rate"), ("gilt_1y", "riv-l", 2, "1-year gilt"),
              ("IUMB6VK", "aq-l", 2, "Average easy access"), ("pb", "pb-l", 3, "Premium Bonds")]
    ends = []
    for col, cls, w, lab in series:
        pts = [(xs(i), ys(v)) for i, v in enumerate(x[col]) if pd.notna(v)]
        s.path(pts, cls, w)
        ends.append([pts[-1][1], lab, cls])
    ends.sort()
    for k in range(1, len(ends)):                      # keep end labels 15px apart
        ends[k][0] = max(ends[k][0], ends[k - 1][0] + 15)
    for yv, lab, cls in ends:
        s.text(R + 8, yv + 4, lab, "t1" if lab == "Premium Bonds" else "t2", 12, weight=600 if lab == "Premium Bonds" else None)
    s.save("fig-rates.svg")


# ---------------------------------------------------------------- F4 spread to SONIA
def fig_spread():
    x = pd.read_csv(RES / "lag_monthly.csv", dtype={"month": str})
    best, cur = (0, 0, 0), None                          # longest run of months below SONIA
    for i, v in enumerate(x.pb_minus_sonia):
        cur = (cur if cur is not None else i) if v < 0 else None
        if cur is not None and i - cur + 1 > best[0]:
            best = (i - cur + 1, cur, i)
    run, first, last = best[0], x.month.iloc[best[1]], x.month.iloc[best[2]]
    assert (x.iloc[best[1]:best[2] + 1].pb_minus_sonia < 0).all() and x.pb_minus_sonia.iloc[-1] > 0
    title = f"Premium Bonds paid less than the overnight cash rate for {run} months in a row"
    names = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
             "November", "December"]
    nm = lambda ym: f"{names[int(ym[5:]) - 1]} {ym[:4]}"  # noqa: E731
    sub = f"Prize fund rate minus SONIA, percentage points, by month held (below zero from {nm(first)} to {nm(last)})"
    W, H, L, R, top, bot = 860, 360, 56, 820, 84, 320
    xs = scale(0, len(x) - 1, L, R)
    ys = scale(-1.5, 1.5, bot, top)
    s = Svg(W, H, title, "Bar chart of the Premium Bond rate minus SONIA, monthly, 2020 to 2026.")
    s.header(title, sub)
    for v in (-1.5, -1, -0.5, 0, 0.5, 1, 1.5):
        s.line(L, ys(v), R, ys(v), "axis" if v == 0 else "grid")
        s.text(L - 8, ys(v) + 4, f"{v:+.1f}" if v else "0", "t3", 11, "end")
    bw = (R - L) / len(x) - 2
    for i, r in x.iterrows():
        v = r.pb_minus_sonia
        cls = "pb" if v >= 0 else "riv"
        s.rect(xs(i) - bw / 2, min(ys(v), ys(0)), bw, abs(ys(v) - ys(0)), cls, 1,
               f"{r.month}: {v:+.2f} pp")
        if r.month.endswith("-01"):
            s.text(xs(i), bot + 18, r.month[:4], "t3", 11, "middle")
    s.text(xs(len(x) * 0.62), ys(1.0), "Premium Bonds above SONIA", "t2", 12, "middle", halo=True)
    s.text(xs(len(x) * 0.12), ys(-1.0), "Premium Bonds below SONIA", "t2", 12, "middle", halo=True)
    s.save("fig-spread.svg")


# ---------------------------------------------------------------- F5 scoreboard, last 24 months
def fig_scoreboard():
    sb = pd.read_csv(RES / "scoreboard.csv", dtype={"month": str})
    beat40 = int((sb.pb_median_50000 > sb.best_net_higher_used_50000).sum())
    beat20 = int((sb.pb_median_50000 > sb.best_net_basic_used_50000).sum())
    n = len(sb)
    assert beat40 > n / 2
    title = (f"At 40% tax, Premium Bonds beat the best account in every one of the last {n} months" if beat40 == n
             else f"At 40% tax, Premium Bonds beat the best account in {beat40} of the last {n} months")
    sub = ("£50k, allowance used: typical one-year Premium Bond return at each month's prize table vs the best clean "
           "easy-access rate after tax, %")
    W, H, L, R, top, bot = 860, 420, 56, 690, 84, 372
    xs = scale(0, n - 1, L, R)
    lo = min(sb[["pb_median_50000", "best_net_higher_used_50000"]].min()) - 0.002
    hi = max(sb[["pb_median_50000", "clean_best"]].max()) + 0.002
    ys = scale(lo, hi, bot, top)
    s = Svg(W, H, title, "Line chart over 24 months of the Premium Bond median return and the best easy-access rate "
            "after 0%, 20% and 40% tax.")
    s.header(title, sub)
    v = round(lo * 200) / 200
    while v <= hi:
        s.line(L, ys(v), R, ys(v), "grid")
        s.text(L - 8, ys(v) + 4, pct(v, 1), "t3", 11, "end")
        v += 0.005
    for i, mth in enumerate(sb.month):
        if mth.endswith(("-01", "-07")):
            s.text(xs(i), bot + 18, f"{['Jan', 'Jul'][mth.endswith('-07')]} {mth[:4]}", "t3", 11, "middle")
    series = [("clean_best", "neu-l", 2, "Best account, no tax"), ("best_net_basic_used_50000", "aq-l", 2, "after 20% tax"),
              ("best_net_higher_used_50000", "riv-l", 2, "after 40% tax"), ("pb_median_50000", "pb-l", 3, "Premium Bonds, £50k")]
    ends = []
    for col, cls, w, lab in series:
        pts = [(xs(i), ys(val)) for i, val in enumerate(sb[col])]
        s.path(pts, cls, w)
        ends.append([pts[-1][1], lab])
    ends.sort()
    for k in range(1, len(ends)):
        ends[k][0] = max(ends[k][0], ends[k - 1][0] + 15)
    for yv, lab in ends:
        s.text(R + 8, yv + 4, lab, "t1" if lab.startswith("Premium") else "t2", 12)
    s.save("fig-scoreboard.svg")


if __name__ == "__main__":
    fig_heatmap()
    fig_luck()
    fig_rates()
    fig_spread()
    if (RES / "scoreboard.csv").exists():
        fig_scoreboard()
