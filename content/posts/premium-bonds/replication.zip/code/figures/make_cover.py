"""Cover image for the post in the site's cover style (dark gradient, glowing marks, no text): a glass prize drum
on a stand, full of small blue bond tickets, with a few gold coins (prizes) falling into a tray, beside a stack of
green notes (a bank account) and a short orange line chart rising behind (rates).

Usage: .venv/Scripts/python -I code/figures/make_cover.py <out_dir>   (writes cover.svg; render with Chrome)
"""
import math
import pathlib
import random
import sys

OUT = pathlib.Path(sys.argv[1])
W, H, GROUND = 2000, 1050, 860
BLUE, ORANGE, GREEN, GOLD = "#7fb2ff", "#ff9f66", "#5fdcaa", "#ffd27a"
rnd = random.Random(11)

p = [f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">
<defs>
  <linearGradient id="sky" x1="0" y1="0" x2="1" y2="0.6">
    <stop offset="0" stop-color="#14203a"/><stop offset="0.5" stop-color="#0e1626"/><stop offset="1" stop-color="#1f1830"/>
  </linearGradient>
  <radialGradient id="halo" cx="0.5" cy="0.45" r="0.5">
    <stop offset="0" stop-color="{BLUE}" stop-opacity="0.22"/><stop offset="1" stop-color="{BLUE}" stop-opacity="0"/>
  </radialGradient>
  <radialGradient id="glass" cx="0.4" cy="0.35" r="0.7">
    <stop offset="0" stop-color="#ffffff" stop-opacity="0.10"/><stop offset="1" stop-color="#ffffff" stop-opacity="0.02"/>
  </radialGradient>
  <linearGradient id="ground" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#0b1220"/><stop offset="1" stop-color="#060a12"/>
  </linearGradient>
  <filter id="glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="8"/></filter>
  <filter id="soft" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.5"/></filter>
</defs>
<rect width="{W}" height="{H}" fill="url(#sky)"/>
<rect width="{W}" height="{H}" fill="url(#halo)"/>''']

for _ in range(140):                                     # stars
    x, y, r = rnd.uniform(0, W), rnd.uniform(0, GROUND - 220), rnd.choice([1, 1, 1.5, 2])
    p.append(f'<circle cx="{x:.0f}" cy="{y:.0f}" r="{r}" fill="#ffffff" opacity="{rnd.uniform(.25, .8):.2f}"/>')

# rising rate line behind (orange), with a soft glow
pts = [(120, 640), (360, 650), (560, 600), (760, 420), (980, 380), (1240, 440), (1480, 470), (1700, 390), (1900, 330)]
d = "M" + " L".join(f"{x},{y}" for x, y in pts)
p.append(f'<path d="{d}" fill="none" stroke="{ORANGE}" stroke-width="10" opacity="0.35" filter="url(#glow)"/>')
p.append(f'<path d="{d}" fill="none" stroke="{ORANGE}" stroke-width="4" stroke-linejoin="round" opacity="0.85"/>')
for x, y in pts:
    p.append(f'<circle cx="{x}" cy="{y}" r="7" fill="{ORANGE}" opacity="0.9"/>')

p.append(f'<rect y="{GROUND}" width="{W}" height="{H - GROUND}" fill="url(#ground)"/>')
p.append(f'<line x1="0" y1="{GROUND}" x2="{W}" y2="{GROUND}" stroke="{BLUE}" stroke-opacity="0.25" stroke-width="2"/>')

# prize drum: stand, axle, glass sphere with bond tickets
cx, cy, R = 1000, 520, 250
p.append(f'<path d="M{cx - 170},{GROUND} L{cx - 40},{cy + 40} L{cx + 40},{cy + 40} L{cx + 170},{GROUND}" fill="none" '
         f'stroke="{BLUE}" stroke-width="10" stroke-linejoin="round" opacity="0.7"/>')
p.append(f'<circle cx="{cx}" cy="{cy}" r="{R + 30}" fill="{BLUE}" opacity="0.10" filter="url(#glow)"/>')
p.append(f'<circle cx="{cx}" cy="{cy}" r="{R}" fill="url(#glass)" stroke="{BLUE}" stroke-width="6" opacity="0.95"/>')
for a in range(0, 180, 30):                              # drum ribs
    t = math.radians(a)
    p.append(f'<ellipse cx="{cx}" cy="{cy}" rx="{abs(R * math.cos(t)):.0f}" ry="{R}" fill="none" stroke="{BLUE}" '
             f'stroke-width="1.5" opacity="0.25"/>')
for _ in range(170):                                     # bond tickets tumbling inside
    rr, th = R * math.sqrt(rnd.uniform(0.02, 0.86)), rnd.uniform(0, 2 * math.pi)
    x, y = cx + rr * math.cos(th), cy + rr * math.sin(th)
    if y < cy - 40 and rnd.random() < 0.6:               # most settle in the lower half
        y = cy + abs(y - cy) * 0.8
    rot = rnd.uniform(0, 180)
    col = GOLD if rnd.random() < 0.035 else BLUE
    op = 0.95 if col == GOLD else rnd.uniform(0.45, 0.85)
    p.append(f'<rect x="{x - 14:.0f}" y="{y - 8:.0f}" width="28" height="16" rx="3" fill="{col}" opacity="{op:.2f}" '
             f'transform="rotate({rot:.0f} {x:.0f} {y:.0f})"/>')
p.append(f'<circle cx="{cx}" cy="{cy}" r="18" fill="#0e1626" stroke="{BLUE}" stroke-width="5"/>')

# chute and falling prizes into a tray
p.append(f'<path d="M{cx + R - 20},{cy + 120} L{cx + R + 110},{cy + 210}" stroke="{BLUE}" stroke-width="8" opacity="0.6"/>')
tray_x, tray_y = cx + R + 150, GROUND - 40
p.append(f'<path d="M{tray_x - 90},{tray_y} L{tray_x - 70},{GROUND} L{tray_x + 70},{GROUND} L{tray_x + 90},{tray_y}" '
         f'fill="#0e1626" stroke="{BLUE}" stroke-width="5" opacity="0.9"/>')
for i, (dx, dy, r) in enumerate([(-10, -150, 22), (25, -95, 18), (-30, -40, 20), (10, -12, 24), (-45, -10, 18), (45, -14, 19)]):
    x, y = tray_x + dx, tray_y + dy
    p.append(f'<circle cx="{x}" cy="{y}" r="{r + 10}" fill="{GOLD}" opacity="0.25" filter="url(#glow)"/>')
    p.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{GOLD}" opacity="0.95"/>')
    p.append(f'<circle cx="{x}" cy="{y}" r="{r * 0.65:.0f}" fill="none" stroke="#b8862f" stroke-width="2.5" opacity="0.8"/>')

# stack of green notes (the bank account) on the left
bx = 560
for i in range(9):
    y = GROUND - 26 - i * 22
    p.append(f'<rect x="{bx - 120 + (i % 2) * 8}" y="{y}" width="240" height="18" rx="4" fill="{GREEN}" '
             f'opacity="{0.55 + 0.04 * i:.2f}"/>')
p.append(f'<rect x="{bx - 130}" y="{GROUND - 230}" width="260" height="230" fill="{GREEN}" opacity="0.07" filter="url(#glow)"/>')

p.append("</svg>")
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "cover.svg").write_text("\n".join(p), encoding="utf-8")
print("wrote", OUT / "cover.svg")
