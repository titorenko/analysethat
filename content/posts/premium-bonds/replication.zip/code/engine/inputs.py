"""Today's inputs, each with its source and as-of date (PLAN §3). Everything downstream reads these, never a typed
number. `today()` returns a dict of products: gross annual rate (AER for deposits), tax treatment and fees.
"""
import json
import pathlib

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
DER, PARAMS = ROOT / "data" / "derived", ROOT / "params"


def fees():
    return json.loads((PARAMS / "platform_fees.json").read_text(encoding="utf-8"))


def gilt():
    return json.loads((PARAMS / "gilt.json").read_text(encoding="utf-8"))


def platform_fee(platform, pot, kind="funds"):
    """Annual platform charge in £ on a pot of `pot` held in funds (or gilts), per params/platform_fees.json."""
    p = fees()["platforms"][platform]
    if "flat_monthly" in p:
        for hi, m in p["flat_monthly"]:
            if hi is None or pot <= hi:
                return 12 * m
    if kind == "gilts":
        g = p["gilts"]
        return min(g["rate"] * pot, g["cap_per_year_gia"])
    f = p["funds"]
    if "whole_pot" in f:
        if pot < 25_000:
            return f["flat_under_25000"]
        for hi, rate in f["whole_pot"]:
            if pot <= hi:
                return rate * pot
        return f["whole_pot"][-1][1] * pot
    fee, lo = 0.0, 0.0
    for hi, rate in f["tiers"]:
        top = pot if hi is None else min(pot, hi)
        if top > lo:
            fee += (top - lo) * rate
        if hi is None or pot <= hi:
            break
        lo = hi
    return fee


def _name(row):
    prov, prod = str(row["provider"]), str(row["product"])
    return prod if prod.lower().startswith(prov.lower()) else f"{prov} {prod}"


def today():
    draws = pd.read_csv(DER / "pb_draws.csv", dtype={"draw": str})
    bb = pd.read_csv(DER / "bestbuy_history.csv", dtype={"snapshot": str})
    bb = bb[bb.snapshot == bb.snapshot.max()].set_index("category")
    boe = pd.read_csv(DER / "boe_monthly.csv", dtype={"month": str}).set_index("month")
    ds = pd.read_csv(DER / "nsi_direct_saver.csv")
    rl = pd.read_csv(DER / "rl_rlam.csv")
    alloc = pd.read_csv(DER / "pb_allocation_page.csv", dtype={"draw": str})
    ocf = fees()["fund_ocf"]["rl_stmmf_y_acc"]
    last = draws.iloc[-1]
    est = alloc[alloc.kind == "estimate"].iloc[0]
    est_rate = est.amount * 12 / (est.total_prizes * last.odds)
    out = {
        "pb": {"rate": float(last.rate), "odds": int(last.odds), "draw": last.draw, "next_draw": est.draw,
               "next_rate": float(est_rate), "eligible": int(last.eligible)},
        "easy": {"rate": bb.loc["easy_access", "aer"] / 100, "name": _name(bb.loc["easy_access"]), "as_of": bb.loc["easy_access", "snapshot"]},
        "fix1y": {"rate": bb.loc["fixed_1y", "aer"] / 100, "name": _name(bb.loc["fixed_1y"]), "as_of": bb.loc["fixed_1y", "snapshot"]},
        "isa_easy": {"rate": bb.loc["isa_easy", "aer"] / 100, "name": _name(bb.loc["isa_easy"]), "as_of": bb.loc["isa_easy", "snapshot"]},
        "isa_fix1y": {"rate": bb.loc["isa_fixed_1y", "aer"] / 100, "name": _name(bb.loc["isa_fixed_1y"]), "as_of": bb.loc["isa_fixed_1y", "snapshot"]},
        "avg_easy": {"rate": boe.IUMB6VK.dropna().iloc[-1] / 100, "as_of": boe.IUMB6VK.dropna().index[-1]},
        "bank_rate": {"rate": boe.bank_rate_end.dropna().iloc[-1] / 100, "as_of": boe.bank_rate_end.dropna().index[-1]},
        "direct_saver": {"rate": float(ds.rate.iloc[-1]), "from": ds["from"].iloc[-1]},
        "mmf": {"yield_gross": float(rl.redemption_yield.iloc[0]), "ocf": ocf,
                "rate": float(rl.redemption_yield.iloc[0]) - ocf, "as_of": rl.as_at.iloc[0]},
        "gilt": gilt(),
    }
    return out
