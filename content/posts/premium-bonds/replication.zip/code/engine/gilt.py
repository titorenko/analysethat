"""A low-coupon gilt held to maturity: annualised return after tax and fees (PLAN §3, F1, F15).

Cash flows on £A invested at settlement: buy N nominal at the dirty price (clean + accrued since the last coupon),
pay the dealing fee; receive semi-annual coupons (taxed as savings interest in the tax year paid; the accrued
income scheme adjustment, worth under £2 at £50k, is ignored); pay the platform's capped custody fee; get N back
at maturity, free of CGT (TCGA s.115). The return is the IRR of those flows.
"""
import datetime as dt

import tax as T


def tax_year(d):
    y = d.year if (d.month, d.day) >= (4, 6) else d.year - 1
    return f"{y}-{str(y + 1)[2:]}"


def flows(g, amount, settle, profile=None, deal=0.0, custody_rate=0.0, custody_cap=0.0):
    mat = dt.date.fromisoformat(g["maturity"])
    cdates, d = [], mat
    while d > settle:
        cdates.append(d)
        d = dt.date(d.year if d.month > 6 else d.year - 1, 7 if d.month == 1 else 1, 31)
    cdates.sort()
    prev = dt.date(cdates[0].year if cdates[0].month == 7 else cdates[0].year - 1, 1 if cdates[0].month == 7 else 7, 31)
    half = g["coupon"] / 2 * 100
    accrued = half * (settle - prev).days / (cdates[0] - prev).days
    nominal = amount / ((g["clean_price"] + accrued) / 100)
    out = [(settle, -amount - deal)]
    for c in cdates:
        cp = nominal * half / 100
        t = 0.0
        if profile is not None:
            year = tax_year(c)
            t = T.cost(profile, cp, year if year in T.RULES else max(T.RULES))
        out.append((c, cp - t + (nominal if c == mat else 0.0)))
    years = (mat - settle).days / 365.25
    yearly = min(custody_rate * amount, custody_cap) if custody_cap else custody_rate * amount
    k, d = 1, settle
    while True:
        d = settle + dt.timedelta(days=round(365.25 * k))
        if d >= mat:
            break
        out.append((d, -yearly))
        k += 1
    out.append((mat, -yearly * (years - (k - 1))))
    return sorted(out)


def irr(cf):
    t0 = cf[0][0]

    def npv(r):
        return sum(v / (1 + r) ** ((d - t0).days / 365.25) for d, v in cf)
    lo, hi = -0.5, 0.5
    for _ in range(200):
        mid = (lo + hi) / 2
        if npv(mid) > 0:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2
