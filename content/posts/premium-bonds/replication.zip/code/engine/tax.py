"""What an extra £ of savings interest costs in tax, for a saver profile and tax year (params/tax.json).

cost(profile, interest, year) = [income tax + HICBC](with interest) - [same](without), where the profile's own
non-savings income and any savings interest it already has stay in both. Exact, not a marginal rate: the starting
rate for savings and the Personal Savings Allowance depend on how much interest there is.

Rules (scouting/C_tax.md):
- Adjusted net income = non-savings + savings (no pension contributions or Gift Aid in these profiles).
- Personal allowance tapers by £1 per £2 of ANI over £100,000; set against non-savings income first.
- Savings sit on top of non-savings taxable income: first the starting rate band (£5,000 less non-savings taxable
  income), then the PSA (£1,000 / £500 / £0 by whether any income is higher- or additional-rate income, with the
  PSA-covered interest still occupying the band), then UK savings rates by UK bands. Scottish taxpayers: savings
  at UK rates and bands; only their non-savings income uses Scottish bands.
- HICBC: 1% of Child Benefit for each complete £200 of ANI over £60,000, capped at 100%.
"""
import json
import math
import pathlib

PARAMS = pathlib.Path(__file__).resolve().parents[2] / "params" / "tax.json"
RULES = json.loads(PARAMS.read_text(encoding="utf-8"))["years"]


def personal_allowance(r, ani):
    return max(0.0, r["personal_allowance"] - max(0.0, ani - r["taper_from"]) / 2)


def non_savings_tax(r, taxable, scottish):
    if scottish:
        bands = r["scottish_non_savings"]
        if bands is None:
            raise ValueError("Scottish bands not set for this year")
        tax, lo = 0.0, 0.0
        for hi, rate in zip(bands["limits"], bands["rates"]):
            top = taxable if hi is None else min(taxable, hi)
            if top > lo:
                tax += (top - lo) * rate
            if hi is None or taxable <= hi:
                break
            lo = hi
        return tax
    nr, brb, add = r["non_savings_rates"], r["basic_rate_band"], r["additional_from"]
    return (min(taxable, brb) * nr["basic"] + max(0.0, min(taxable, add) - brb) * nr["higher"]
            + max(0.0, taxable - add) * nr["additional"])


def income_tax(r, non_savings, savings, scottish=False):
    ani = non_savings + savings
    pa = personal_allowance(r, ani)
    ns_taxable = max(0.0, non_savings - pa)
    sav_taxable = max(0.0, savings - max(0.0, pa - non_savings))
    tax = non_savings_tax(r, ns_taxable, scottish)
    brb, add, sr = r["basic_rate_band"], r["additional_from"], r["savings_rates"]
    total_taxable = ns_taxable + sav_taxable
    psa = r["psa"]["additional"] if total_taxable > add else r["psa"]["higher"] if total_taxable > brb else r["psa"]["basic"]
    pos, left = ns_taxable, sav_taxable                      # walk the savings slice up through the UK bands
    start = max(0.0, r["starting_rate_limit"] - ns_taxable)
    nil = min(left, start)
    pos, left = pos + nil, left - nil
    nil = min(left, psa)
    pos, left = pos + nil, left - nil
    for hi, rate in ((brb, sr["basic"]), (add, sr["higher"]), (math.inf, sr["additional"])):
        take = max(0.0, min(left, hi - pos))
        tax += take * rate
        pos, left = pos + take, left - take
    return tax


def hicbc(r, ani, children, smooth=False):
    """The charge is 1% per complete £200 (the law). smooth=True drops the rounding: the average over where in a £200
    step the income falls, used for the article's example saver so the result doesn't hinge on an arbitrary salary."""
    if not children:
        return 0.0
    cb = (r["hicbc"]["cb_weekly_eldest"] + r["hicbc"]["cb_weekly_other"] * (children - 1)) * 52
    steps = (ani - r["hicbc"]["from"]) / r["hicbc"]["per_1pct"]
    pct = min(100, max(0, steps if smooth else math.floor(steps)))
    return cb * pct / 100


def total(profile, savings, year):
    r = RULES[year]
    ns, sc, ch = profile["non_savings"], profile.get("scottish", False), profile.get("children", 0)
    return income_tax(r, ns, savings, sc) + hicbc(r, ns + savings, ch, profile.get("hicbc_smooth", False))


def cost(profile, interest, year):
    """Extra tax (incl. HICBC) caused by `interest` on top of the profile's existing savings income."""
    base = profile.get("other_savings", 0.0)
    return total(profile, base + interest, year) - total(profile, base, year)


PROFILES = {  # PLAN §4 (F5): six profiles; "PSA used" variants carry other savings interest equal to the PSA
    "zero": {"label": "0% taxpayer", "non_savings": 12547.60},
    "basic_free": {"label": "Basic rate, PSA free", "non_savings": 35000},
    "basic_used": {"label": "Basic rate, PSA used", "non_savings": 35000, "other_savings": 1000},
    "higher_free": {"label": "Higher rate, PSA free", "non_savings": 70000},
    "higher_used": {"label": "Higher rate, PSA used", "non_savings": 70000, "other_savings": 500},
    "hicbc": {"label": "Higher rate + child benefit charge, 2 children", "non_savings": 70000, "children": 2,
              "hicbc_smooth": True},
    "taper": {"label": "£100k-£125k taper band", "non_savings": 110000},
    "additional": {"label": "Additional rate", "non_savings": 150000},
}
