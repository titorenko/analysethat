"""Exact distribution of Premium Bond winnings (PLAN §2).

Each eligible £1 bond, in each draw d, wins at most one prize: value v_k with probability p_k = n_k / N_d. All
prizes are multiples of £25, so on a £25 grid the per-bond, per-draw distribution has characteristic function φ_d
and B bonds held through draws d = 1..m win a total whose characteristic function is Π_d φ_d^{B_d}. One inverse
FFT gives the whole distribution, with no sampling error. B_d may vary by draw (the expected path of a holding
whose prizes are reinvested). Bonds are independent draws from the same table: exact for one holder's B ≪ N.

    rows = pb.draws()                      # data/derived/pb_draws.csv, one row per draw
    pmf = pb.distribution([rows[-1]] * 12, 10_000)
    pb.quantile(pmf, 0.5), pb.p_nothing([rows[-1]] * 12, 10_000)
"""
import functools
import pathlib

import numpy as np
import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
UNIT = 25
GRID = 2 ** 18                     # £6.55m of headroom; ample for £50k over 60 draws
PRIZES = [1_000_000, 100_000, 50_000, 25_000, 10_000, 5_000, 1_000, 500, 100, 50, 25]
CAP = 50_000


def draws():
    t = pd.read_csv(ROOT / "data" / "derived" / "pb_draws.csv", dtype={"draw": str})
    return [r for _, r in t.iterrows()]


def draws_held(bought, cash_in):
    """How many draws a bond bought on `bought` and cashed in on `cash_in` (datetime.date) takes part in, under NS&I's
    rules (scouting A §1, VERIFIED): bonds bought in month P first enter the draw of month P+2; a bond is in month M's
    draw if still held on the 1st of M (a cash-in requested on the 1st is taken to keep that draw); a cash-in requested
    in the last two working days of a month is held back until after the next draw. Weekends only, no bank holidays."""
    def month_index(d):
        return d.year * 12 + d.month - 1
    first = month_index(bought) + 2
    last = month_index(cash_in)
    nxt = (pd.Timestamp(cash_in) + pd.offsets.MonthBegin(1)).date()
    working = [d.date() for d in pd.bdate_range(cash_in.replace(day=1), nxt - pd.Timedelta(days=1).to_pytimedelta())]
    if cash_in in working[-2:]:
        last += 1
    return max(0, last - first + 1)


def table(row):
    """(values in £25 units, probability per £1 bond) for one draw."""
    n = np.array([row[f"n_{v}"] for v in PRIZES], dtype=float)
    return np.array(PRIZES) // UNIT, n / float(row["eligible"])


def mean_rate(row):
    v, p = table(row)
    return float((v * UNIT * p).sum() * 12)


@functools.lru_cache(maxsize=256)
def _log_phi(key):
    v, p = _TABLES[key]
    per = np.zeros(GRID)
    per[0] = 1 - p.sum()
    np.add.at(per, v, p)
    return np.log(np.fft.rfft(per))   # |φ - 1| ≤ 2/odds, so the principal log is safe


_TABLES = {}


def _key(row):
    k = str(row["draw"])
    _TABLES.setdefault(k, table(row))
    return k


def distribution(rows, bonds):
    """P(total = j × £25), j = 0..GRID-1, for `bonds` (a number, or one per draw) held through `rows`."""
    b = np.broadcast_to(np.asarray(bonds, dtype=float), (len(rows),))
    acc = np.zeros(GRID // 2 + 1, dtype=complex)
    for row, bd in zip(rows, b):
        acc += bd * _log_phi(_key(row))
    return np.clip(np.fft.irfft(np.exp(acc), n=GRID), 0, None)


def p_nothing(rows, bonds):
    """Closed form: Π_d (1 - Σp_d)^{B_d} (the FFT cell is noisy at ~1e-13, F7)."""
    b = np.broadcast_to(np.asarray(bonds, dtype=float), (len(rows),))
    return float(np.exp(sum(bd * np.log1p(-table(r)[1].sum()) for r, bd in zip(rows, b))))


def mean(rows, bonds):
    b = np.broadcast_to(np.asarray(bonds, dtype=float), (len(rows),))
    return float(sum(bd * mean_rate(r) / 12 for r, bd in zip(rows, b)))


def quantile(pmf, q):
    return int(np.searchsorted(np.cumsum(pmf), q - 1e-12)) * UNIT


def p_at_least(pmf, x):
    """P(total ≥ £x)."""
    return float(pmf[int(np.ceil(x / UNIT - 1e-9)):].sum())


def reinvest_path(b0, rows):
    """Expected bond count per draw when prizes are reinvested: B_{d+1} = B_d (1 + rate_d/12), capped at £50k.
    A prize from draw d buys bonds that are in draw d+1 (A §1)."""
    out, b = [], float(b0)
    for r in rows:
        out.append(b)
        b = min(CAP, b * (1 + mean_rate(r) / 12))
    return out
