"""G-alloc: every draw table parsed from the NS&I zip headers is internally consistent (PLAN §7).

- the 11 counts sum to the stated total prizes and to the stated amount;
- total prizes × odds reproduces eligible bonds (derived as amount × 12 / rate) to 1e-4;
- the higher / medium / lower bands take 10% / 10% / 80% of the fund from Jan 2023 (5/5/90 before);
- the allocation page's actual column equals the zip header for the same draw;
- every month from Jan 2020 to the latest draw is present.
Usage: .venv/Scripts/python -I code/checks/g_alloc.py
"""
import pathlib
import sys

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "code" / "derive"))
from common import DER, Gate, PRIZES  # noqa: E402


def main():
    d = pd.read_csv(DER / "pb_draws.csv", dtype={"draw": str})
    page = pd.read_csv(DER / "pb_allocation_page.csv", dtype={"draw": str})
    g = Gate("G-alloc (NS&I draw tables)", [DER / "pb_draws.csv", DER / "pb_allocation_page.csv"])
    n = d[[f"n_{v}" for v in PRIZES]]
    g.check("counts sum to stated total", (n.sum(axis=1) == d.total_prizes).all(), f"{len(d)} draws")
    g.check("value sums to stated amount", ((n * PRIZES).sum(axis=1) == d.amount).all(), f"{len(d)} draws")
    rel = (d.total_prizes * d.odds / d.eligible - 1).abs()
    g.check("prizes × odds = amount × 12 / rate", (rel < 1e-4).all(), f"max relative gap {rel.max():.1e}")
    hi = (n.iloc[:, :6] * PRIZES[:6]).sum(axis=1) / d.amount
    med = (n.iloc[:, 6:8] * PRIZES[6:8]).sum(axis=1) / d.amount
    new = d.draw >= "2023-01"
    g.check("bands 10/10/80 from Jan 2023", ((hi[new] - 0.10).abs() < 0.002).all() and ((med[new] - 0.10).abs() < 0.002).all(),
            f"higher {hi[new].min():.4f}-{hi[new].max():.4f}, medium {med[new].min():.4f}-{med[new].max():.4f}")
    g.check("bands 5/5/90 before Jan 2023", ((hi[~new] - 0.05).abs() < 0.002).all(),
            f"higher {hi[~new].min():.4f}-{hi[~new].max():.4f}")
    cur = page[page.kind == "actual"].iloc[0]
    row = d[d.draw == cur.draw]
    same = len(row) == 1 and all(int(row.iloc[0][f"n_{v}"]) == int(cur[f"n_{v}"]) for v in PRIZES)
    g.check("allocation page = zip header for the current draw", same, f"draw {cur.draw}")
    months = pd.period_range("2020-01", d.draw.max(), freq="M").strftime("%Y-%m")
    g.check("no missing months", set(months) == set(d.draw), f"{len(d)} of {len(months)} from 2020-01 to {d.draw.max()}")
    est = page[page.kind == "estimate"].iloc[0]
    est_rate = est.amount * 12 / (est.total_prizes * d.odds.iloc[-1])
    g.note(f"Next-draw estimate ({est.draw}) implies rate {est_rate:.4%} at the current odds "
           f"(latest drawn rate {d.rate.iloc[-1]:.2%}).")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
