"""G-article: no result number is typed by hand into the write-up (PLAN §7).

Every number in writeup/article.md.tmpl that states a result must be a {placeholder} filled by article_values.py
or build_article.py from results/ and params/. This gate deletes the placeholders and fails if any %, £ or decimal
number is left, other than section and table numbers, model versions and the inputs and definitions in ALLOWED
(each with its reason).
Usage: .venv/Scripts/python -I code/checks/g_article.py writeup/article.md.tmpl
"""
import pathlib
import re
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "derive"))
from common import Gate  # noqa: E402

ALLOWED = {  # token -> reason
    "£10,000": "example holding (design)", "£50,000": "example holding and the NS&I maximum (design)",
    "£1,000": "example holding (design)", "£25,000": "example holding (design)",
    "£100,000": "the couple example: two £50,000 holdings (design); a prize value (definition)",
    "£5,000": "prize-size definition: the higher value band starts at £5,000 (NS&I allocation rules)",
    "£1k": "example holding (design)", "£5k": "example holding (design)", "£10k": "example holding (design)",
    "£25k": "example holding (design)", "£50k": "example holding (design)",
    "60%": "conventional name of the £100k-£125,140 'personal allowance taper' band (the engine prices it)",
    "£1": "a £1 bond / a £1 of interest (definition)", "£100": "gilt repayment value / prize value (definition)",
    "£25": "smallest prize value (NS&I; also the engine's grid)", "£50": "prize value; reinvestment-check tolerance",
    "10%": "share of the prize fund in the higher value band (NS&I allocation rules; G-alloc checks it)",
    "1-2%": "big-bank easy-access rates, from bank pages (scouting B §4, VERIFIED)",
    "£2m": "NS&I Direct Saver maximum (NS&I)", "£1 million": "top prize value (definition)",
    "20%": "a tax-rate threshold used to describe savers (definition)",
    "40%": "a tax-rate threshold used to describe savers (definition)",
}
MODELS = re.compile(r"(Opus|Fable|Sonnet|Haiku) \d\.\d")


def tokens(text):
    pat = r"[−-]?£?\d(?:[\d,]*\d)?(?:\.\d+)?(?:k|%|m| million)?(?:-\d(?:[\d,]*\d)?(?:\.\d+)?(?:k|%)?)?"
    for m in re.finditer(pat, text):
        t = m.group(0)
        if re.search(r"[%£.]|m$| million", t):
            yield t, text[max(0, m.start() - 60):m.end() + 40].replace("\n", " ")


def main():
    art = pathlib.Path(sys.argv[1]).resolve()
    raw = art.read_text(encoding="utf-8")
    body = raw.split("\n---\n", 1)[1] if raw.startswith("---") else raw
    body = "\n".join(ln for ln in body.splitlines() if not ln.startswith("#"))      # headings
    body = MODELS.sub(" ", re.sub(r"\{[a-z0-9_]+\}", " ", body))
    body = re.sub(r"section \d+(?:\.\d+)?", " ", body)
    body = re.sub(r"\(fig-[^)]*\)|\[replication\.zip\]\(replication\.zip\)", "", body)
    g = Gate("G-article (no hand-typed result numbers in the write-up template)", [art])
    bad, n = [], 0
    for tok, ctx in tokens(body):
        n += 1
        if tok not in ALLOWED:
            bad.append((tok, ctx))
    g.check("no hand-typed result numbers", not bad, f"{n} literal numbers, {len(bad)} not in ALLOWED")
    for tok, ctx in bad:
        g.note(f"  - {tok}: …{ctx}…")
    g.check("no unfinished markers (TODO, XXX)", not re.search(r"TODO|XXX", raw), "template text")
    g.check("placeholders present", len(re.findall(r"\{[a-z0-9_]+\}", raw)) > 80,
            f"{len(re.findall(r'[{][a-z0-9_]+[}]', raw))} placeholders")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
