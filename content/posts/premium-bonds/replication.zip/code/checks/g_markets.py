"""G-boe and G-mmf (PLAN §7).

G-boe: every Bank of England series is present; the month before the latest Premium Bond draw (the alignment rule:
draw M ↔ month M−1) has a complete row. If that row is not out yet the gate says so and exits with code 2, so the
refresh stops without building (F3).
G-mmf: the FT daily NAV of RL Short Term MMF Y Acc reproduces RLAM's published cumulative total return between
month ends (over 5 years and over the last 2 years) within 0.02 pp: the NAV is a net-of-OCF total-return series.
Usage: .venv/Scripts/python -I code/checks/g_markets.py
"""
import pathlib
import sys

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "code" / "derive"))
from common import DER, Gate  # noqa: E402

NEEDED = ["IUMB6VJ", "IUMB6VK", "IUMWTFA", "IUMB6VL", "IUMB6VN", "bank_rate_end", "sonia_month_return"]


def nav_on(nav, day):
    """NAV on the last trading day on or before `day`."""
    s = nav[nav.date <= day]
    return float(s.nav.iloc[-1])


def main():
    m = pd.read_csv(DER / "boe_monthly.csv", dtype={"month": str}).set_index("month")
    draws = pd.read_csv(DER / "pb_draws.csv", dtype={"draw": str})
    need = (pd.Period(draws.draw.max(), "M") - 1).strftime("%Y-%m")
    g = Gate("G-boe (Bank of England series)", [DER / "boe_monthly.csv"])
    g.check("all series present", all(c in m.columns for c in NEEDED), ", ".join(NEEDED))
    if need not in m.index or m.loc[need, NEEDED].isna().any():
        g.check(f"row for {need} published", False, "BoE row not yet published: rerun after the 5th working day")
        g.finish()
        return 2
    g.check(f"row for {need} published", True, "complete")
    window = m.loc[(pd.Period(need, "M") - 23).strftime("%Y-%m"):need, NEEDED]
    g.check("24 window months complete", len(window) == 24 and not window.isna().any().any(), f"{len(window)} months")
    rc = g.finish()

    nav = pd.read_csv(DER / "rl_nav.csv")
    tr = pd.read_csv(DER / "rl_rlam.csv")
    tr = tr.set_index("month_end").cum_tr_pct
    g = Gate("G-mmf (FT NAV vs RLAM total return)", [DER / "rl_nav.csv", DER / "rl_rlam.csv"])
    ends = list(tr.index)
    for label, a in (("5 years", ends[-61]), ("2 years", ends[-25])):
        b = ends[-1]
        rlam = (1 + tr[b] / 100) / (1 + tr[a] / 100) - 1
        ft = nav_on(nav, b) / nav_on(nav, a) - 1
        g.check(f"{label} {a} → {b}", abs(rlam - ft) < 0.0002, f"RLAM {rlam:.4%} vs FT NAV {ft:.4%}")
    return rc or g.finish()


if __name__ == "__main__":
    sys.exit(main())
