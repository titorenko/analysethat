"""G-fresh: every input is recent enough to publish (PLAN §7).

- the latest draw table is this month's (or last month's before the 3rd), and the allocation page's current draw
  matches it;
- today's best buys are at most 14 days old;
- the Royal London yield is at most 70 days old (it is published about 6 weeks after each month end);
- hand parameters (gilt price, platform fees, tax rules) are flagged when older than 35 / 120 / 120 days, and the
  tax file must be checked after the Budget on 28 October 2026.
Usage: .venv/Scripts/python -I code/checks/g_fresh.py
"""
import datetime as dt
import json
import pathlib
import sys

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "code" / "derive"))
from common import DER, PARAMS, Gate  # noqa: E402

BUDGET = dt.date(2026, 10, 28)


def age(d, today):
    return (today - dt.date.fromisoformat(d)).days


def main():
    today = dt.date.today()
    g = Gate("G-fresh (inputs recent enough to publish)", [DER, PARAMS])
    draws = pd.read_csv(DER / "pb_draws.csv", dtype={"draw": str})
    page = pd.read_csv(DER / "pb_allocation_page.csv", dtype={"draw": str})
    want = today.strftime("%Y-%m") if today.day >= 3 else (pd.Period(today, "M") - 1).strftime("%Y-%m")
    g.check("latest draw table is current", draws.draw.max() >= want, f"latest {draws.draw.max()}, expected {want}")
    g.check("allocation page agrees", page[page.kind == "actual"].draw.iloc[0] == draws.draw.max(),
            f"page {page[page.kind == 'actual'].draw.iloc[0]}")
    bb = pd.read_csv(DER / "bestbuy_history.csv", dtype={"snapshot": str})
    g.check("best buys ≤ 14 days old", age(bb.snapshot.max(), today) <= 14, f"snapshot {bb.snapshot.max()}")
    rl = pd.read_csv(DER / "rl_rlam.csv")
    g.check("fund yield ≤ 70 days old", age(rl.as_at.iloc[0], today) <= 70, f"as at {rl.as_at.iloc[0]}")
    gilt = json.loads((PARAMS / "gilt.json").read_text(encoding="utf-8"))
    fees = json.loads((PARAMS / "platform_fees.json").read_text(encoding="utf-8"))
    tax = json.loads((PARAMS / "tax.json").read_text(encoding="utf-8"))
    g.check("gilt price ≤ 35 days old (hand parameter)", age(gilt["as_of"], today) <= 35, f"as of {gilt['as_of']}")
    g.check("platform fees checked ≤ 120 days ago", age(fees["_checked"], today) <= 120, f"checked {fees['_checked']}")
    checked = dt.date.fromisoformat(tax["_checked"])
    g.check("tax rules checked after the latest fiscal event", not (today >= BUDGET > checked),
            f"checked {checked}; Budget {BUDGET}")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
