"""G-bestbuy: the live clean filter and the hand-coded backfill use the same rule (PLAN §3, advisor note).

For each archived Moneyfacts capture the backfill coded (params/bestbuy_window.csv and bestfix_window.csv rows with
method moneyfacts_json), runs the live filter (code/derive/bestbuys_derive.py) on the capture and checks:
  1. the backfill's pick passes every live rule (it is not a bonus, platform, limited-access, conditional, sharia or
     special account by the live filter's tests);
  2. every product the live filter would rank above it is named in the backfill's notes, where the reason it was
     passed over is recorded (in an archived capture the filter cannot see deposit limits, which the backfill read
     from the account terms, and older captures lack the platform field).
Both must hold in every month tested.
Usage: .venv/Scripts/python -I code/checks/g_bestbuy.py
"""
import json
import pathlib
import sys

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "code" / "derive"), str(ROOT / "code" / "fetch")]
from bestbuys_derive import exclusions, pick, products  # noqa: E402
from common import PARAMS, Gate  # noqa: E402

WB = ROOT / "data" / "raw" / "wayback"


def capture(row, kind):
    ts = row.source_url.split("/web/")[1].split("/")[0] if "/web/" in str(row.source_url) else None
    if not ts:
        return None
    hits = list(WB.glob(f"*/mfc_{kind}_{ts}.html"))
    return hits[0] if hits else None


def main():
    g = Gate("G-bestbuy (live filter reproduces the backfill)", [PARAMS / "bestbuy_window.csv", PARAMS / "bestfix_window.csv"])
    excl = exclusions()
    rows = []
    for fname, kind, cat in (("bestbuy_window.csv", "easy", "easy_access"), ("bestfix_window.csv", "fixed", "fixed_1y")):
        bb = pd.read_csv(PARAMS / fname, dtype={"month": str})
        for r in bb[bb.method == "moneyfacts_json"].itertuples():
            path = capture(r, kind)
            if path is None:
                continue
            try:
                lst = products(path)
            except (ValueError, KeyError):
                continue
            audit = []
            pick(dict([(0, lst)]), cat, excl, audit)                      # ranks everything; stops at the first clean
            mine = [p for p in lst if abs(p["AER"] - r.rate_aer) < 0.005 and r.provider.split()[0].lower() in
                    p["ProviderName"].lower()]
            from bestbuys_derive import reject_reason  # noqa: E402
            verdicts = [reject_reason(p, excl) for p in mine]          # a product can be listed direct and via a platform
            own = None if None in verdicts else (verdicts[0] if verdicts else "pick not found in capture")
            above = {a["provider"] for a in audit if a["verdict"] == "CLEAN" and a["aer"] > r.rate_aer + 0.004}
            notes = str(r.notes).lower()
            unexplained = sorted(x for x in above if x.split()[0].lower().rstrip("®") not in notes)
            first = next((a for a in audit if a["verdict"] == "CLEAN"), None)
            differs = first is None or abs(first["aer"] - r.rate_aer) >= 0.005
            rows.append({"cat": cat, "month": r.month, "own": own, "unexplained": unexplained, "differs": differs,
                         "filter": f"{first['provider']} {first['aer']}" if first else "none",
                         "backfill": f"{r.provider} {r.rate_aer}"})
    t = pd.DataFrame(rows)
    g.note(f"Live filter on the archived capture alone picks a different rate in {int(t.differs.sum())} of {len(t)} "
           "months; each such pick is a product the backfill passed over for a reason in its notes (mostly a deposit "
           "limit, which one archived search amount cannot test):")
    for r in t[t.differs].itertuples():
        g.note(f"  - {r.cat} {r.month}: filter {r.filter} vs backfill {r.backfill}")
    bad_own = t[t["own"].notna()]
    bad_above = t[t.unexplained.map(len) > 0]
    (ROOT / "results" / "bestbuy_check.json").write_text(json.dumps(
        {"tested": len(t), "same": len(t) - int(t.differs.sum()),
         "differs": t[t.differs][["cat", "month", "filter", "backfill"]].to_dict("records")}, indent=2), encoding="utf-8")
    g.check("months tested", len(t) >= 30, f"{len(t)} archived captures")
    g.check("live filter picks the backfill's rate in at least 90% of months", t.differs.mean() <= 0.10,
            f"{len(t) - int(t.differs.sum())} of {len(t)}")
    g.check("backfill pick passes every live rule", bad_own.empty, f"{len(bad_own)} months fail")
    for r in bad_own.itertuples():
        g.note(f"  - {r.cat} {r.month}: live filter rejects the backfill pick: {r.own}")
    g.check("every higher-ranked product is explained in the notes", bad_above.empty, f"{len(bad_above)} months fail")
    for r in bad_above.itertuples():
        g.note(f"  - {r.cat} {r.month}: not explained: {', '.join(r.unexplained)}")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
