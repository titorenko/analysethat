"""G-pb: the exact Premium Bond engine (PLAN §7).

1. Mass = 1 (to 1e-8); mean = B × m × rate/12 exactly; the table's own rate = NS&I's published rate.
2. The old Monte Carlo (C:/kostya/repo/premium-bonds, April 2020 table, 34,500:1): medians £0 / £75 / £450 for
   £1k / £10k / £50k over 12 draws; £10k P10 / P90 £25 / £150 (stored sim_result_25_03_2021).
3. MSE's premium bonds guide ("Updated 1 October 2026", scouting A §6) at the Oct 2026 table: medians £0 / £350 /
   £925 / £1,900 for £1k / £10k / £25k / £50k; P(nothing in a year) £100 95%, £1k 57%, £5k 6% (whole %, ±1 pp).
4. MSE's chance of beating a 4.55% account (A §6), using MSE's own PSA-inclusive thresholds and "≥" (F8), ±1.5 pp
   (MSE prints whole percentages).
5. The mean with prizes reinvested (expected bond path; exact by linearity below the cap) vs a seeded simulation
   with true reinvestment: within 3 standard errors over 60 draws at £10k. (Distributions in the article assume prizes paid out.)
6. The closed-form chance of a £100,000+ prize (Table 2) vs the exact chance of £100,000 in total: at £10k over 12 draws
   single prizes are nearly all of it, so the two agree within 1%, the exact one never lower.
Usage: .venv/Scripts/python -I code/checks/g_pb.py
"""
import pathlib
import sys

import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "code" / "derive"), str(ROOT / "code" / "engine")]
from common import DER, Gate  # noqa: E402
import pb  # noqa: E402

APRIL_2020 = dict(zip([f"n_{v}" for v in pb.PRIZES], [2, 5, 9, 18, 48, 94, 1738, 5214, 28274, 28274, 2961456]))
APRIL_2020.update(draw="old-mc-2020-04", eligible=sum(APRIL_2020.values()) * 34_500)


def mc_reinvest(row, b0, draws, paths=40_000, seed=7):
    rng = np.random.default_rng(seed)
    v, p = pb.table(row)
    hold = np.full(paths, float(b0))
    won = np.zeros(paths)
    for _ in range(draws):
        prize = (rng.poisson(np.outer(hold, p)) * (v * pb.UNIT)).sum(axis=1)
        won += prize
        hold = np.minimum(pb.CAP, hold + prize)
    return float(np.mean(won)), float(np.std(won) / np.sqrt(paths))


def main():
    rows = pb.draws()
    latest = rows[-1]
    g = Gate("G-pb (exact Premium Bond engine)", [DER / "pb_draws.csv"])
    year = [latest] * 12
    pmf = pb.distribution(year, 50_000)
    g.check("mass = 1", abs(pmf.sum() - 1) < 1e-8, f"{pmf.sum():.12f}")
    m_fft = (pmf * np.arange(pb.GRID)).sum() * pb.UNIT
    g.check("mean = 12 draws × £50k × rate/12", abs(m_fft - pb.mean(year, 50_000)) < 0.01,
            f"FFT £{m_fft:,.2f} vs £{pb.mean(year, 50_000):,.2f}")
    worst = max(abs(pb.mean_rate(r) - r["rate"]) for r in rows)
    g.check("each table's own rate = NS&I rate", worst < 1e-4, f"max gap {worst:.1e} over {len(rows)} draws")

    old = [APRIL_2020] * 12
    got = [pb.quantile(pb.distribution(old, a), 0.5) for a in (1_000, 10_000, 50_000)]
    g.check("old Monte Carlo medians £0/£75/£450", got == [0, 75, 450], f"got {got}")
    p10k = pb.distribution(old, 10_000)
    got = [pb.quantile(p10k, 0.10), pb.quantile(p10k, 0.90)]
    g.check("old Monte Carlo £10k P10/P90 £25/£150", got == [25, 150], f"got {got}")

    got = [pb.quantile(pb.distribution(year, a), 0.5) for a in (1_000, 10_000, 25_000, 50_000)]
    g.check("MSE medians £0/£350/£925/£1,900", got == [0, 350, 925, 1900], f"got {got} (draw {latest['draw']})")
    got = [100 * pb.p_nothing(year, a) for a in (100, 1_000, 5_000)]
    g.check("MSE P(nothing) 95/57/6% (whole %, ±1 pp)", all(abs(x - w) <= 1 for x, w in zip(got, [95, 57, 6])),
            "got " + ", ".join(f"{x:.1f}%" for x in got))

    def net(amount, t, psa):
        i = 0.0455 * amount
        return i - t * max(0.0, i - psa)
    mse = [("non-taxpayer £100", 100, net(100, 0, 0), 6), ("non-taxpayer £1k", 1_000, net(1_000, 0, 0), 35),
           ("non-taxpayer £5k", 5_000, net(5_000, 0, 0), 30), ("non-taxpayer £30k", 30_000, net(30_000, 0, 0), 27),
           ("non-taxpayer £50k", 50_000, net(50_000, 0, 0), 26), ("basic £30k", 30_000, net(30_000, .2, 1000), 33),
           ("basic £50k", 50_000, net(50_000, .2, 1000), 41), ("higher £30k", 30_000, net(30_000, .4, 500), 61),
           ("higher £50k", 50_000, net(50_000, .4, 500), 77)]
    for label, amount, thr, want in mse:
        got = 100 * pb.p_at_least(pb.distribution(year, amount), thr)
        g.check(f"MSE chance of beating 4.55%: {label}", abs(got - want) <= 1.5, f"P(≥ £{thr:,.0f}) {got:.1f}% vs MSE {want}%")

    v, p = pb.table(latest)
    big = p[v * pb.UNIT >= 100_000].sum()
    closed = -np.expm1(10_000 * 12 * np.log1p(-big))
    tail = pb.p_at_least(pb.distribution(year, 10_000), 100_000)
    g.check("P(a £100k+ prize), closed form, vs the exact P(total ≥ £100k), £10k over 12 draws",
            closed <= tail < 1.01 * closed, f"1 in {1 / closed:,.0f} vs 1 in {1 / tail:,.0f}")

    five = [latest] * 60
    path_mean = pb.mean(five, pb.reinvest_path(10_000, five))
    mc_mean, mc_se = mc_reinvest(latest, 10_000, 60)
    g.check("reinvested mean (expected path) vs true reinvestment, £10k over 60 draws",
            abs(path_mean - mc_mean) < 3 * mc_se,
            f"path £{path_mean:,.0f} vs simulation £{mc_mean:,.0f} (standard error £{mc_se:,.0f}; rare big prizes)")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
