"""G-tables: the site rule that tables fit (blog-article-layout-and-style), logged like the other gates.

Runs the site's tools/check-tables.mjs against a served build of the post (hugo server -D, or a served production
build) at 375, 768, 1366 and 1920px. Passes when no table scrolls at 768px and up and the page never scrolls
sideways at any width (tables may scroll inside their own box on phones).
Usage: .venv/Scripts/python -I code/checks/g_tables.py <post url>
"""
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "code" / "derive"))
from common import Gate  # noqa: E402

SITE = ROOT.parent / "analysethat"


def main():
    url = sys.argv[1]
    out = subprocess.run(["node", "tools/check-tables.mjs", url, "375,768,1366,1920"], cwd=SITE,
                         capture_output=True, text=True, timeout=300).stdout
    g = Gate("G-tables (tables fit, site rule)", [SITE / "tools" / "check-tables.mjs"])
    rows = re.findall(r"vw (\d+): .*?page overflow (\w+); (\d+)/(\d+) tables scroll", out)
    g.check("all four widths measured", len(rows) == 4, f"{len(rows)} widths")
    for vw, overflow, scroll, total in rows:
        g.check(f"{vw}px: page does not scroll sideways", overflow == "false", f"page overflow {overflow}")
        if int(vw) >= 768:
            g.check(f"{vw}px: no table scrolls", scroll == "0", f"{scroll} of {total} tables scroll")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
