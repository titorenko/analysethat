"""G-calc: the in-browser calculator (section 1.3) agrees with the Python engine and with the article.

Runs the shipped pb-calc.js, on the shipped pb-calc.json, in Node, over amounts £1 to £100,000 and 1 to 240 draws:
1. The JSON is the latest drawn prize table (the one every table uses).
2. Each distribution: probabilities sum to 1 (to 1e-9) and the grid's average is the exact average to the penny.
3. Against code/engine/pb.py: P10, P25, median, P75, P90 equal to the pound; P(nothing) and the average to 1e-9
   (relative); P(a £5,000+ / £100,000+ prize) to 1e-9 (relative); P(total ≥ £x), three thresholds, to floating-point
   error: n·log φ carries an absolute error of about n × 2.2e-16 for n bond-draws in either engine (numpy forms
   φ = 1 - Σp + ..., the calculator φ - 1 directly), and a tail sum adds up to N = 2^18 cells of FFT rounding, so the
   tolerance is 10 (n + N) × 2.2e-16: 5.8e-10 for small holdings, 5.3e-8 for £100,000 over 240 draws.
4. Against the article, as printed: every cell of Tables 1 and 2 and the £5,000+ prize chances in section 1.1, each
   formatted by the calculator's own formatting.
Usage: .venv/Scripts/python -I code/checks/g_calc.py <bundle dir>
"""
import json
import math
import pathlib
import subprocess
import sys

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "code" / "derive"), str(ROOT / "code" / "engine"), str(ROOT / "code" / "figures")]
from common import Gate  # noqa: E402
import pb  # noqa: E402
from article_values import RES, gbp, one_in, pct  # noqa: E402

AMOUNTS = [1, 100, 1_000, 5_000, 10_000, 25_000, 50_000, 100_000]
DRAWS = [1, 12, 24, 60, 120, 240]
QS = (0.10, 0.25, 0.50, 0.75, 0.90)
NODE = r"""
const E = require(process.argv[1]);
const run = E.engine(JSON.parse(require("fs").readFileSync(process.argv[2], "utf8")));
const out = JSON.parse(process.argv[3]).map(([a, d, xs]) => {
  const r = run(a, d), y = d / 12, q = [0.10, 0.25, 0.50, 0.75, 0.90].map((p) => r.quantile(p));
  return { a, d, q, mass: r.mass, gridMean: r.gridMean, mean: r.mean, pNothing: r.pNothing,
           atLeast: xs.map((x) => r.pAtLeast(x)), p5k: r.pPrize(5000), p100k: r.pPrize(100000),
           fmt: { p10: `${E.gbp(q[0])} (${E.pct(q[0] / a / y)})`, p50: `${E.gbp(q[2])} (${E.pct(q[2] / a / y)})`,
                  p90: `${E.gbp(q[4])} (${E.pct(q[4] / a / y)})`, med_pa: E.pct(q[2] / a / y),
                  nothing: r.pNothing >= 0.005 ? E.pct(r.pNothing, 0) : "<1%", big5k: E.pct(r.pPrize(5000), 1),
                  big100k: E.oneIn(r.pPrize(100000)) } };
});
console.log(JSON.stringify(out));
"""


def main():
    bundle = pathlib.Path(sys.argv[1]).resolve()
    js, data = bundle / "pb-calc.js", bundle / "pb-calc.json"
    g = Gate("G-calc (the calculator agrees with the engine and the article)", [js, data])
    table = json.loads(data.read_text(encoding="utf-8"))
    latest = pb.draws()[-1]
    g.check("prize table = the latest draw", table["draw"] == str(latest["draw"]) and table["eligible"] == latest["eligible"]
            and all(n == latest[f"n_{v}"] for v, n in table["prizes"]), f"draw {table['draw']}")

    cases = [[a, d, [a * 0.0455 * d / 12, 5_000, 100_000]] for a in AMOUNTS for d in DRAWS]
    res = subprocess.run(["node", "-e", NODE, str(js), str(data), json.dumps(cases)], capture_output=True, text=True,
                         encoding="utf-8", timeout=600)
    g.check("Node runs the calculator", res.returncode == 0, res.stderr.strip()[-200:] or f"{len(cases)} cases")
    if res.returncode:
        return g.finish()
    out = {(r["a"], r["d"]): r for r in json.loads(res.stdout)}

    v, p = pb.table(latest)
    worst = {"mass": 0.0, "grid_mean": 0.0, "nothing": 0.0, "mean": 0.0, "at_least": 0.0, "prize": 0.0}
    eps = 2.2e-16
    quantiles_off = []
    for a, d, xs in cases:
        r, rows = out[(a, d)], [latest] * d
        pmf = pb.distribution(rows, a)
        want_q = [pb.quantile(pmf, q) for q in QS]
        if r["q"] != want_q:
            quantiles_off.append(f"£{a:,} × {d}: {r['q']} vs {want_q}")
        mean = pb.mean(rows, a)
        worst["mass"] = max(worst["mass"], abs(r["mass"] - 1))
        worst["grid_mean"] = max(worst["grid_mean"], abs(r["gridMean"] - mean))
        worst["mean"] = max(worst["mean"], abs(r["mean"] / mean - 1))
        pn = pb.p_nothing(rows, a)
        worst["nothing"] = max(worst["nothing"], abs(r["pNothing"] / pn - 1) if pn > 1e-300 else r["pNothing"])
        worst["at_least"] = max([worst["at_least"]] + [abs(x - pb.p_at_least(pmf, t)) / (10 * (a * d + pb.GRID) * eps)
                                                        for x, t in zip(r["atLeast"], xs)])
        for key, lo in (("p5k", 5_000), ("p100k", 100_000)):
            want = -math.expm1(a * d * math.log1p(-p[v * pb.UNIT >= lo].sum()))
            worst["prize"] = max(worst["prize"], abs(r[key] / want - 1))
    g.check("probabilities sum to 1", worst["mass"] < 1e-9, f"worst |Σ - 1| {worst['mass']:.1e}")
    g.check("grid average = exact average, to the penny", worst["grid_mean"] < 0.005, f"worst gap £{worst['grid_mean']:.1e}")
    g.check("P10, P25, median, P75, P90 equal the engine's, to the pound", not quantiles_off,
            f"{len(cases)} cases" if not quantiles_off else "; ".join(quantiles_off[:4]))
    g.check("P(nothing) = engine (relative 1e-9)", worst["nothing"] < 1e-9, f"worst {worst['nothing']:.1e}")
    g.check("average = engine (relative 1e-9)", worst["mean"] < 1e-9, f"worst {worst['mean']:.1e}")
    g.check("P(total ≥ £x) = engine, to floating-point error", worst["at_least"] < 1,
            f"worst gap {worst['at_least']:.2f} of the tolerance")
    g.check("P(a £5,000+ / £100,000+ prize) = closed form (relative 1e-9)", worst["prize"] < 1e-9,
            f"worst {worst['prize']:.1e}")

    luck = pd.read_csv(RES / "pb_luck.csv").set_index(["draws", "amount"])
    big = pd.read_csv(RES / "pb_big_prize.csv").set_index(["years", "amount"])
    off, n = [], 0
    for a in luck.xs(12).index:
        L, f = luck.loc[(12, a)], out[(a, 12)]["fmt"]
        art = {"p10": f"{gbp(L.p10)} ({pct(L.p10_pa)})", "p50": f"{gbp(L.p50)} ({pct(L.p50_pa)})",
               "p90": f"{gbp(L.p90)} ({pct(L.p90_pa)})",
               "nothing": pct(L.p_nothing, 0) if L.p_nothing >= 0.005 else "<1%"}
        art5 = pct(luck.loc[(60, a), "p50_pa"])
        for k, want in list(art.items()) + [("med_pa", art5)]:
            got = (out[(a, 60)] if k == "med_pa" else out[(a, 12)])["fmt"][k]
            n += 1
            if got != want:
                off.append(f"Table 1 £{a:,} {k}: {got} vs {want}")
    for (yrs, a), row in big.iterrows():
        n += 1
        if out[(a, 12 * yrs)]["fmt"]["big100k"] != one_in(row.p_prize):
            off.append(f"Table 2 £{a:,} {yrs}y: {out[(a, 12 * yrs)]['fmt']['big100k']} vs {one_in(row.p_prize)}")
    big5 = p[v * pb.UNIT >= 5_000].sum()
    for a in (10_000, 50_000):
        n += 1
        want = pct(1 - math.exp(-a * 12 * big5), 1)            # as article_values prints p_big_10k / p_big_50k
        if out[(a, 12)]["fmt"]["big5k"] != want:
            off.append(f"section 1.1 £{a:,} £5,000+ prize: {out[(a, 12)]['fmt']['big5k']} vs {want}")
    g.check("every Premium Bond number of Tables 1 and 2 and section 1.1, as printed", not off,
            f"{n} printed numbers" if not off else "; ".join(off[:4]))
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
