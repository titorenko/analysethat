"""G-tax: the savings tax engine against gov.uk worked examples and hand-worked cases (PLAN §7).

Each case: profile, interest, tax year, expected extra tax (or total tax), and where the expected figure comes from.
Usage: .venv/Scripts/python -I code/checks/g_tax.py
"""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "code" / "derive"), str(ROOT / "code" / "engine")]
from common import Gate  # noqa: E402
import tax as T  # noqa: E402

Y = "2026-27"
CASES = [  # (label, profile, interest, year, expected extra tax, source)
    ("gov.uk starting-rate example: wages £16,000 leave £1,570 of band; +£1,000 PSA → £2,570 tax-free",
     {"non_savings": 16000}, 2570, Y, 0.0, "gov.uk/apply-tax-free-interest-on-savings"),
    ("same, £100 more interest at 20%", {"non_savings": 16000}, 2670, Y, 20.0, "hand"),
    ("State Pension only (£12,547.60): £5,000 starting band + £22.40 of PA + £1,000 PSA = £6,022.40 free",
     {"non_savings": 12547.60}, 6022.40, Y, 0.0, "C §4 PROBE"),
    ("same, +£100 at 20%", {"non_savings": 12547.60}, 6122.40, Y, 20.0, "hand"),
    ("basic rate £35k: £1,000 inside PSA", {"non_savings": 35000}, 1000, Y, 0.0, "PSA s.12B"),
    ("basic rate £35k: £2,000 → £1,000 at 20%", {"non_savings": 35000}, 2000, Y, 200.0, "hand"),
    ("higher rate £70k: £500 inside PSA", {"non_savings": 70000}, 500, Y, 0.0, "PSA s.12B"),
    ("higher rate £70k: £2,260 → £1,760 at 40%", {"non_savings": 70000}, 2260, Y, 704.0, "Fable scratch §7"),
    ("Scottish £47k: UK-band PSA £1,000, 20% above it", {"non_savings": 47000, "scottish": True}, 1500, Y, 100.0,
     "ITA s.11D(6), s.12B(8)"),
    ("taper £110k rUK: £1,000 = £500 lost PA at 40% + £500 above PSA at 40%", {"non_savings": 110000}, 1000, Y, 400.0,
     "hand: 20% inside PSA, 60% above"),
    ("taper £110k Scotland: £500 lost PA at 45% + £500 at 40%", {"non_savings": 110000, "scottish": True}, 1000, Y, 425.0,
     "hand: 62.5% above PSA"),
    ("taper £110k: £2,260 → Fable's £1,156", {"non_savings": 110000}, 2260, Y, 1156.0, "Fable scratch §7"),
    ("additional £150k: 45% from the first £", {"non_savings": 150000}, 1000, Y, 450.0, "PSA nil"),
    ("HICBC £70k 2 children: £500 interest = 2 complete £200 steps = 2% of £2,337.40", {"non_savings": 70000, "children": 2},
     500, Y, 46.748, "gov.uk HICBC + CB rates"),
    ("2027/28 basic rate £35k: £2,000 → £1,000 at 22%", {"non_savings": 35000}, 2000, "2027-28", 220.0, "FA 2026 s.5"),
    ("HICBC averaged over the £200 step: £500 inside the PSA costs £500 / £200 × 1% of £2,337.40", {"non_savings": 70000,
     "children": 2, "hicbc_smooth": True}, 500, Y, 58.435, "average of the law's steps"),
]
TOTALS = [  # C §11 PSA cliff: salary £49k, interest £1,200 → £1,300 takes total tax £7,326 → £7,452
    ("PSA cliff, £1,200 interest", {"non_savings": 49000}, 1200, Y, 7326.0),
    ("PSA cliff, £1,300 interest", {"non_savings": 49000}, 1300, Y, 7452.0),
]


def main():
    g = Gate("G-tax (savings tax engine)", [T.PARAMS])
    for label, prof, interest, year, want, src in CASES:
        got = T.cost(prof, interest, year)
        g.check(label, abs(got - want) < 0.01, f"got £{got:,.2f}, expected £{want:,.2f} ({src})")
    for label, prof, interest, year, want in TOTALS:
        got = T.total(prof, interest, year)
        g.check(label, abs(got - want) < 0.01, f"total tax £{got:,.2f}, expected £{want:,.2f} (C §11)")
    return g.finish()


if __name__ == "__main__":
    sys.exit(main())
