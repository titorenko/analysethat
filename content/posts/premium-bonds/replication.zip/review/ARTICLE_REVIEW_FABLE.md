# Review of the built article (Premium Bonds vs deposits, MMF, gilt) — Fable, 2026-10-11

Reviewed: `analysethat/content/posts/premium-bonds/index.md` and its five figures (rendered with headless Chrome),
against `results/`, `params/`, `code/`, `logs/` and my plan review (`FABLE_REVIEW.md`, `DISPOSITIONS.md`).
Independent re-derivations are in my scratchpad (`rederive.py`: compound-Poisson FFT and a 200k-path Monte Carlo
instead of the study's binomial FFT; my own tax, chaser, draw-counting and gilt-IRR code). I also ran the site's
`tools/check-tables.mjs` against a local Hugo build, which the gates log never records.

## Verdict

**Publishable after the four major fixes below; not as built.** The engines are right: every headline number I
re-derived matches (medians £350 / £950 / £1,900, P(nothing) 56.5%, trailing 3.30% / 4.43% / 2.68%, all five
Table 2 draw counts, gilt 4.17% / 4.23% / 4.03%, the 43-month SONIA run). The problems are in presentation and
in one piece of plumbing: a wrong statistic in §1.1 ("half" for an 80% range), a 5-year cell that makes £50k look
worse than £25k because paid-out prizes are assumed to earn nothing, a 15.6-month gilt bolded as "best" while the
12-month fix that beats it for most savers is left out of Tables 4-5, and a best-buy series whose archived months
were coded by hand to a stricter rule than the live filter can apply, with the exclusions file that should carry
the hand rule forward still empty. 17 of the 21 plan findings were implemented as the dispositions say; 2, 4, 10
and 17 were not, or not fully. No critical findings; 4 major; 10 minor.

## Findings

### 1. Major — "half of £10,000 holders" describes the 10th-90th percentile range
**Where.** §1.1, paragraph after Table 1: "over five years, half of £10,000 holders earn between 2.9% and 5.4% a
year". Template line 55 uses `{p10_10k_5y}` and `{p90_10k_5y}`.
**Evidence.** `pb_luck.csv`, 60 draws, £10k: p10 £1,550 → 2.92%/yr, p90 £3,000 → 5.39%/yr. That band holds eight
holders in ten. The middle half (p25-p75) is £1,800-£2,525 → 3.4%-4.6% (my re-derivation agrees to the £25).
**Fix.** Either "eight in ten £10,000 holders earn between 2.9% and 5.4%" or switch the placeholders to
`p25_pa` / `p75_pa` (both already in `pb_luck.csv`) and keep "half".

### 2. Major — The 1-year fix is absent from Tables 4-5 and §2.3, while a 15.6-month gilt is bolded as "best"
**Where.** Tables 4, 5 ("The best of the four … in bold"), §2.3 heading "The gilt that beats them both", the
short-version bullet "A short gilt beats the typical Premium Bond for every taxpayer".
**Issue.** Once a locked-up product (TN28, held to 31 Jan 2028) is admitted as a column, the simpler 12-month
lock-up in Table 3 (5.12%, FSCS-protected) must be too. It beats the gilt for six of the eight savers at £10k and
for the no-tax and basic-rate savers at £50k, and beats the typical Premium Bond for six of eight at £10k. The
trailing Table 8 does include "Two 1-year fixes" (and they win four rows), so the today tables are the odd ones out.
**Evidence.** `today_net.csv` 2026-27, `fix1y` net: £10k no tax 5.12%, basic/allowance used 4.10% (gilt 4.00%),
higher/unused 5.07%, HICBC 4.60%, 60% band 4.05% (gilt 4.00%); £50k no tax 5.12%, basic/unused 4.50%,
basic/used 4.10% (gilt 4.20%). The bold cell would change in 6 of 8 rows of Table 4 and 3 of 8 of Table 5.
**Fix.** Add a "Best 1-year fix" column to `table_today` (Table 8 already carries seven columns and passes the
768px check), re-bold "best of the five", and reword §2.3: the gilt wins from the higher rate up; at 20% or below
the fix does better and is simpler. Keep the gilt's horizon caveat.

### 3. Major — The "clean best buy" series is two rules, and the live rule cannot reproduce the hand rule
**Where.** §2.1 definition, §4 chaser, §9 "filtered by the rule in section 2.1", `params/bestbuy_window.csv`,
`params/bestbuy_exclusions.csv` (empty), `code/checks/g_bestbuy.py`.
**Issue.** The 24 archived months were coded by hand with MSE prose for conditions the Moneyfacts JSON does not
show (withdrawal frequency, current-account requirement, intermediary apps). The first G-bestbuy run showed the
live filter picking a different, higher product in 17 of 41 months (`logs/gates.md` 11:04:48). The gate was then
redefined to "the backfill pick passes the live rules and higher-ranked products are named in the notes", which
audits the backfill but no longer tests that the two rules agree. From next month the window will mix hand-strict
months with live-loose months, and the article says it is one rule.
**Evidence.** Today's JSON, run through `reject_reason`: LHV Easy Access 4.15%, Snoop 4.00% and Chetwood Easy
Access 3.78% all return `None` (clean). The backfill excluded exactly these three by hand (current account;
Bondsmith intermediary + open-banking link; one withdrawal a day). The only live tests that caught today's
hand-type cases are the two-amount searches (cahoot Sunny Day 5% absent at £50k, Monument 4.56% absent at £1k).
**Fix.** Seed `bestbuy_exclusions.csv` from the backfill notes (Revolut, Snoop, LHV, Chetwood Easy Access, Atom
Instant Saver Reward, Castle Community Bank, Manchester BS Rainy Day, Newcastle BS 6 Month, Rova, Vida/Virgin
defined-access lines not caught by the name regex) with reason and source; add a line to §9: "for the archived
months, conditions the Moneyfacts data does not show were checked by hand against MoneySavingExpert's page for the
same month"; have G-bestbuy also report the count of months where the live filter would pick differently.

### 4. Major — Table 1's 5-year column makes £50k look worse than £25k through an annualisation artefact
**Where.** Table 1, "Typical, a year over 5 years": £25k 4.0%, £50k 3.7%. Also the trailing £50k 3.30%.
**Issue.** At the £50k cap prizes are paid out, and `luck()` annualises the 60-draw total as a CAGR, so the
paid-out prizes are assumed to earn nothing for the rest of the five years. That is not a Premium Bond cost; it is
the article's assumption, and it contradicts the F10 clause the dispositions promised ("a few tens of pounds").
**Evidence.** `pb_luck.csv` 60 draws £50k: p50 £9,825 → CAGR 3.65% (printed 3.7%), simple 3.93%; mean_pa 4.01% vs
4.44% for every other amount. Trailing £50k: £3,350 → CAGR 3.30%, simple 3.35%.
**Fix.** For a holding at the cap, report the simple annual rate (or re-save paid-out prizes at the Direct Saver
rate and say so). Add to the Table 1 note: "At £50,000 prizes are paid out; the five-year figure assumes they are
re-saved at X%." The 2.3 "a few tens of pounds" clause from F10 is still missing and belongs here.

### 5. Minor — §5 heading over-claims; Table 9's gilt column is mislabelled; the short version cites the wrong figure
**Where.** Heading "Premium Bonds follow the gilt market, not Bank Rate"; Table 9 last column; short-version
bullet "in step with gilt yields (Figures 4 and 5)".
**Evidence.** `lag_events.csv`: the gilt column agrees in sign with 15 of 17 changes, but so does Bank Rate in every
one of the 12 changes where it had moved; the five where it was flat are the whole case. The column is
`gilt(m−1) − gilt(m−3)`: a two-month change ending a month before the announcement, not "over the 3 months before"
(May 2022: +0.57 printed, +0.64 over three months). Figure 5 shows SONIA, not gilt yields.
**Fix.** Heading "Premium Bonds don't follow Bank Rate; in 2026 they moved with gilt yields" (the three bullets
already say this). Relabel the column or compute end-of-(m−3) to end-of-m. Cite Figure 4 only.

### 6. Minor — F2 (two tax blocks) is in the code but not in the text, and §4's wording is wrong
**Where.** §4 "with tax worked out year by year"; §9 Tax paragraph.
**Evidence.** `trailing.py`: blocks Nov 2024-Oct 2025 and Nov 2025-Oct 2026, one PSA and one starting-rate band each,
2024/25 and 2025/26 rules. Those are not tax years. The disposition for F2 says "and say so".
**Fix.** "Tax is applied to each of the two 12-month blocks separately, with one savings allowance each; the rules
did not change over the period."

### 7. Minor — F17 (HICBC 11.7% / 51.7%) was not implemented
**Where.** Table 4-5 row "Higher rate + child benefit charge (2 children)"; §2.2.
**Fix.** Row label or §2.2 bullet: "costs 11.7% on interest inside the £500 allowance and 51.7% above it".

### 8. Minor — F4 is only partly what the dispositions say, and 66 archived MSE pages are unused
**Evidence.** `fig-rates.svg` shows PB, Bank Rate, 1-year gilt, IUMB6VK; no SONIA, no MSE headline series.
`data/derived/mse_headline_titles.csv` and the `lag_monthly.mse_headline` column feed nothing. "PB − BoE
average" exists only as the sentence "about 1.7 points".
**Fix.** No article change needed; correct the disposition line and drop the MSE title fetch from `wayback.py`
or use the series. Figure 5's subtitle prints raw "2022-11 to 2026-05"; the convention that "November 2022"
means the December 2022 draw (month = draw − 1) is stated nowhere in the article.

### 9. Minor — The §2.1 definition omits three tests the code applies, and cahoot's 12-month structure
**Evidence.** `bestbuys_derive.py` also rejects platform/intermediary products (this removed OakNorth 5.13% via
Meteor and Monument 4.87% via Raisin), sharia accounts, and products not listed at a £1,000 search. cahoot
Simple Saver pays 4.52% for 12 months, then converts to a lower-rate account (backfill notes), which a reader would
call a bonus.
**Fix.** Add "direct from the bank, not through a savings platform; minimum deposit £1,000 or less" and
"(cahoot's rate lasts 12 months, then the account converts)".

### 10. Minor — Table 4 has three identical rows and an unexplained equality; §2.2 understates the higher-rate case
**Evidence.** At £10k the £452 of interest sits inside every allowance, so no-tax, basic/unused and higher/unused
read 4.52% / 3.57% / 4.03% / 30%, and the 60% band equals basic/used (both 3.62%). `today_beat.csv`: a higher-rate
saver with the allowance *unused* is ahead at £25k (+0.3) and £50k (+0.7) because £1,130+ of interest exceeds the
£500 PSA; the bullet says PB win "once the allowance is used".
**Fix.** One sentence under Table 4 ("at £10,000 the £452 of interest fits inside the £500 allowance, so …") and
"Higher rate: Premium Bonds win once the allowance is used, and from £25,000 even if it is not."

### 11. Minor — Tables 4 and 7 disagree on the MMF by the dealing fees
**Evidence.** Table 7: AJ Bell £10k "£25 → 3.60%". Table 4, no tax: 3.57%. The £3 (two £1.50 deals) is in
`net_rows` but not in `mmf_fees`. Fix: Table 7 note "before dealing fees (£1.50 each way at AJ Bell)".

### 12. Minor — "Hold £10,000 for a year … £350" is for money already held
**Evidence.** §1.2 and `entry_timing.csv`: new money from mid-month gets 11 draws, £325 (3.25%), and the
higher-rate/used margin at £10k becomes +0.55, not +0.8. Fix: one clause in the first short-version bullet.

### 13. Minor — Headings and title vs house style
**Evidence.** "3. The fees that matter", "6. Safety and access", "7. From April 2027" are topics, not findings;
the title repeats "Premium Bonds" and runs to 17 words. "the overnight rate money market funds earn" is SONIA
(RL yields 3.95% vs SONIA 3.73%): say "roughly". Fix: finding-led headings ("The platform fee can cost more than
the fund earns", "Only the bank account has a limit", "April 2027 nudges the answer towards Premium Bonds").

### 14. Minor — Stale and missing records
**Evidence.** `results/FINDINGS.md` (shipped in `replication.zip`) says 17 of 40 cells, ISA 4.52%, trailing
"pending"; the article says 16, 4.26%, done. `logs/gates.md` has no G-tables entry (PLAN §7 lists it). The
disclosure should name this review once the fixes are in. Fix: regenerate FINDINGS.md or drop it from the zip;
log the table check; update the disclosure.

## Plan findings: implemented as the dispositions say?
Yes, verified in code or text: 1, 3, 5, 6, 7, 8, 9 (better than asked: Table 2), 11, 12, 13, 14, 15, 16, 18, 19,
20 (moot: no 2027/28 Scottish cell shown), 21. Not, or not fully: **2** (code yes, text no: finding 6), **4**
(chart content reduced, MSE series unused: finding 8), **10** (clause absent and Table 1 contradicts it:
finding 4), **17** (not implemented: finding 7).

## Checked and correct
- **Re-derived independently** (own code): £10k 12 draws p10/median/p90 £150 / £350 / £675 (compound Poisson and
  Monte Carlo agree); £50k £1,350 / £1,900 / £2,725; £25k £950; P(nothing) £1k 56.5%, £10k 0.33%; MSE fixed-holding
  medians £350 / £925 / £1,900; 16 of 40 cells PB ahead. Trailing 24 draws: mean rate 3.781%, £50k median £3,350 →
  3.30%; chaser 4.43% (no tax), 3.56% (basic/used), 2.68% (higher/used) from the backfill rates with monthly
  compounding and two tax blocks. Table 5 cells HICBC 2.60%, 60% band 2.21%, higher/unused 3.11%, basic/unused
  4.02%. Table 2: all five rows give 12 / 12 / 11 / 11 / 10 draws under NS&I's rules (P+2 first draw; held on the
  1st; 29 Oct 2027 is one of the last two working days of October 2027, so that cash-in keeps the November draw).
  TN28 at 94.79, settlement 12 Oct 2026: 4.17% at 40% and 4.23% at 0% on £50k, 4.03% on £10k, after £5 and the
  £42 cap. 43-month run Nov 2022-May 2026; PB − average easy access 1.7 pts since 2023.
- Every number in the summary, short version, headings, alt texts, Tables 1-10 and §5-§9 traces to `results/` or
  `params/` through `article_values.py`; G-article confirms no hand-typed result numbers. Tax cells of Tables 4-6
  reproduce by hand (PSA, starting rate, taper at 20% inside / 60% above the PSA, HICBC steps). Table 7 fees,
  Table 9 (17 events, 4-71 days' notice, days since Bank Rate moved), the three cycle facts (5 months, 7 months,
  Bank Rate flat in 2026 while the 1-year gilt went 3.42% → 4.25%) all match.
- Fairness: the median is labelled "typical" throughout with p10/p90 and a chance-of-beating column beside it;
  the mean 4.44% / 4.35% is stated; the gilt's horizon and price risk are stated three times; the MMF is taxed on
  the distribution net of OCF with platform and dealing fees after tax (F1), both today and in the window; the
  chaser is labelled an upper bound; IUMB6VK is labelled "advertised, excluding bonuses".
- Figures: all five render cleanly in dark mode, direct-labelled, finding-led titles asserted in
  `make_figures.py`; the heat map's 40 cells and chances match `today_beat.csv`.
- Tables fit: `check-tables.mjs` at 375 / 768 / 1366 / 1920: no table scrolls at 768px and up, no page overflow at
  any width (9 of 10 scroll inside their box at 375px, which the house rule allows).
- Gates: G-alloc, G-pb (closed-form P(nothing)), G-tax (17 cases), G-boe (exit 2 when the row is missing, handled
  by `refresh.py`), G-mmf (0.003 pts), G-fresh, G-article all PASS on the final run; D7 7th-working-day schedule
  and the F18 next-draw note mechanism are in place (estimate for November implies 4.35%, so the note is empty).
