# Review of the Premium Bonds article (draft of 2026-10-11)

Reviewer: Claude Opus 5.5. Reviewed the built `analysethat/content/posts/premium-bonds/index.md`, the five figures
(rendered), results/, code/, params/, logs/gates.md and PLAN v2. Ran `tools/check-tables.mjs`: no table scrolls at 768,
1366 or 1920px.

## Verdict

**Revise before publishing.** Almost every number in the text matches results/, and most headline figures re-derive
independently. But four problems change headline numbers or framing, and all four lean the same way, in Premium Bonds'
favour:

1. The comparison tables assume 12 draws a year, which new money rarely gets.
2. Prizes are reinvested along an *expected* path, which nudges several printed quantiles and P(nothing) upward.
3. One sentence misstates a P10-P90 range as "half".
4. The gilt is bolded as "best" while the like-for-like option, the 1-year fix, is left out of the after-tax tables.

None of these reverses the main story: higher-rate savers whose allowance is used come out ahead, and non-taxpayers lose.

**Counts:** 0 critical, 5 major, 12 minor.

**How I re-derived the numbers (own code, scratchpad):** a compound-Poisson characteristic function per prize band on a
£25 grid, with my own FFT; exact P(nothing) from (1-p)^(B·T); a Monte Carlo of *true* prize reinvestment (2-4 million
holders per case, two seeds); my own TN28 cash-flow IRR with AJ Bell fees and 2026/27 then 2027/28 tax on the coupons;
and my own best-buy chaser, compounding the monthly AERs in params/bestbuy_window.csv.

## Findings

**1. Major. The "who wins" tables use 12 draws, but new money held about a year gets 11.**
- *Where:* short version (bullets 3, 4 and 6), §2.2 (Fig 2, Tables 4-6, "16 of the 40 combinations"), §7.
- *Issue:* §1.2 says money bought mid-month and held a year gets 11 draws. Yet every after-tax comparison uses the
  12-draw median, which needs an existing holding or month-end timing. That assumption is never stated beside the
  tables, and PLAN F9 said "the new-money line uses 11 draws".
- *Evidence:* my 11-draw medians (expected path, as in the engine) are £150, £325, £850 and £1,725 at £5k, £10k, £25k
  and £50k, against £175, £350, £950 and £1,900 for 12 draws. Margins over the best easy-access account:
  - Higher rate, allowance used: +0.79 pp falls to +0.54 pp at £10k; +1.09 pp (P 89%) falls to +0.74 pp (P 81%) at £50k.
  - The sign flips in three cells: basic rate with the allowance used at £25k and £50k (+0.18 to −0.22 and −0.17 pp)
    and higher rate with the allowance unused at £25k (+0.29 to −0.11 pp).
  - Premium Bonds lead in 13 of 40 cells, not 16.
- *Fix:* label Tables 4-6 and Fig 2 "money already held (or bought at month-end)". Add the 11-draw margins for new money
  to the short version and §2.2, or switch the headline to 11 draws.

**2. Major. Modelling reinvestment by the expected holding moves printed numbers, and P(nothing) is computed wrongly.**
- *Where:* Table 1, Fig 1, short version ("Even with £25,000 or more… 3.8%"), §1.1 five-year sentence, Table 6 and Fig 2
  at £25k, method note ("worked out exactly, with no simulation").
- *Issue:* `pb.reinvest_path` gives every holder the average extra bonds, including unlucky holders who won nothing to
  reinvest, which inflates the low quantiles. `today.luck()` also passes that path to `p_nothing`, but a holder who
  wins nothing reinvests nothing.
- *Evidence:*
  - P(nothing) at £5k is printed as 5% (Table 1, Fig 1). The exact value with constant bonds is 5.74%: my calculation,
    my Monte Carlo (5.74%) and the project's own G-pb gate (5.7%) agree, and MSE prints 6%. At £1k it is 56.5% against
    55.8% (both round to 56%).
  - True-reinvestment Monte Carlo against the published figures: £5k one-year P10 is £25 (0.5%), not £50 (1.0%). £25k
    one-year median is £925 (3.7%), not £950 (3.8%); P(≤£925) = 0.504 on both seeds. £10k five-year median is £2,075
    (3.8% a year), not £2,125 (3.9%), with P10/P90 £1,475/£3,075, not £1,550/£3,000.
  - So the £25k median (£950) disagrees with the MSE £925 the article says it reproduces. The gate "within £50" passes
    exactly at its tolerance.
- *Fix:* take P(nothing) from constant bonds. Compute the reinvested quantiles by simulating true reinvestment, or show
  prizes paid out (the exact case). Reword the method note so "exactly" covers only the paid-out case.

**3. Major. "Half of £10,000 holders earn between 2.9% and 5.4%" is wrong.**
- *Where:* §1.1, paragraph after Table 1.
- *Evidence:* pb_luck.csv (60 draws, £10k) has p10_pa = 2.92% and p90_pa = 5.39%. The middle half (P25-P75) is
  3.37%-4.61%. My own run gives the same.
- *Fix:* "eight in ten earn between 2.9% and 5.4%", or "half earn between 3.4% and 4.6%" (after the finding 2 fix).

**4. Major. The gilt (fixed until January 2028) is bolded as "best", but the 1-year fix is left out of Tables 4-5.**
- *Where:* Tables 4-5 ("The best of the four for each saver is in bold"), §2.3, summary.
- *Issue:* TN28 locks in a 4.29% yield for 15.6 months, and sits beside variable rates "held for a year". The natural
  fixed-term comparison, the best 1-year fix at 5.12%, is in Table 3 but dropped from the after-tax tables.
- *Evidence (today_net.csv, fix1y):* the fix beats the bolded gilt for basic rate with the allowance used at £10k (4.10%
  against 4.00%), the 60% band at £10k (4.05% against 4.00%) and basic rate with the allowance unused at £50k (4.50%
  against 4.23%). It also beats the bolded easy-access account for non-taxpayers and allowance-unused savers at £10k
  (5.12% and 5.07% against 4.52%).
- *Fix:* replace the money market fund column (never best; Table 7 covers it) with "Best 1-year fix". Say in §2.3 that
  the gilt's edge is its tax treatment for 40%+ savers, not that it beats fixes generally.

**5. Major. The median is set against certain rates, with no mean beside it.**
- *Where:* short version bullets 2-4, summary, §2.3 ("beats the typical Premium Bond holding for every saver").
- *Issue:* the median is a defensible headline, but every verdict is median-only. A reader will take "non-taxpayers lose
  by 1.0 points" as the expected loss.
- *Evidence:* the mean is 4.44% at £10k (4.35% at £50k). Against 4.52% for a non-taxpayer, the average gap is −0.08 pp
  at £10k and −0.17 pp at £50k, not −1.0 / −0.7. The mean also beats the easy-access cash ISA (4.26%) and the gilt (at
  most 4.23%). For new money (11 draws) the mean falls to about 4.06% (3.99% at £50k), so that gap mostly closes.
- *Fix:* one clause in the short version: "on average, counting the rare big prizes, Premium Bonds pay about 4.4%,
  close to the best account; the median is what most holders actually get". Add a mean row to Table 4 or 5.

**6. Minor. Child benefit charge rows sit on a £200 step.**
- *Where:* Tables 4-6, the HICBC row.
- *Issue:* the profile income of exactly £70,000 is the cheapest position, because the charge is
  floor((ANI−60,000)/200)%. The average marginal cost inside the allowance is 11.7% of interest (PLAN F17).
- *Evidence:* the Table 6 HICBC £5k entry (3.50%) equals the no-tax row, so £175 of interest appears to cost nothing.
  At the average marginal rate it needs 3.96% (£10k: 3.96% against the printed 3.73%).
- *Fix:* use the average 11.7%, or say "costs up to £23 more depending on where your income falls". Also add
  "allowance unused" to the row label.

**7. Minor. The five-year column mixes compound and simple rates, which understates the £50k holding.**
- *Where:* Table 1, last column.
- *Issue:* at £50k prizes are paid out, but the five-year figure is a compound rate on that non-compounding total. So
  £50k shows 3.7% over five years against 3.8% for one year, contradicting "luck evens out with time and size".
- *Evidence:* the five-year median is £9,825: 3.93% a year simple, 3.65% compound. The same effect in Table 8 is smaller
  (3.35% simple against 3.30% shown).
- *Fix:* show simple % a year for paid-out holdings, or footnote the column.

**8. Minor. "In step with gilt yields" overstates what the data show.**
- *Where:* short version bullet 6, §5, Fig 4 title, Table 9.
- *Evidence:* the first 2026 change was a cut (announced 24 February); the 1-year gilt then jumped from 3.42% to 4.25%
  (February to March), and Fig 4 shows Premium Bonds falling as gilts jump. The two rises came 2 and 5 months later, and
  NS&I's stated reasons were "the wider savings market and the 2026-27 financing target". Table 9's "change over the 3
  months before" is the month-end change from m−3 to m−1, which is two months (`lag.events`).
- *Fix:* "In 2026 Bank Rate stood still; NS&I cut, then raised the prize rate twice after gilt yields jumped". Relabel
  the Table 9 column.

**9. Minor. The 43-month run below SONIA depends on an alignment the article doesn't state.**
- *Where:* short version, §5, Fig 5.
- *Evidence:* the 43 months (Nov 2022 to May 2026) re-derive under "draw M rewards month M−1". By calendar month the run
  is Nov 2022 to Jun 2026 (44 months): the June 2026 prize rate was 3.30% against SONIA's 3.73%. October 2022 sits just
  1.4 bp above SONIA. The short version calls SONIA "the Bank of England's overnight cash rate", which readers will take
  for Bank Rate.
- *Fix:* add "(the rate earned in each month)" and "SONIA, the overnight rate banks lend at". Fig 5 subtitle: plain
  dates, not "2022-11".

**10. Minor. Some tax edge cases are missing.**
- *Where:* §2.2, §8.
- *Missing:* Scottish readers should pick their row by **UK** band (a Scottish taxpayer on £43,663-£50,270 pays 42% on
  wages but is a basic-rate saver: 20%, £1,000 allowance). Neither the allowance cliff at £50,270 nor the £100k
  childcare cliff (PLAN §4: report it) is mentioned. The "today" year (Oct 2026 to Oct 2027) is half in 2027/28
  (22/42/47%): deposits are taxed at 2026/27 rates throughout, while the gilt engine taxes its 2027 coupons at 2027/28
  rates (about −0.05 pp on taxed deposit rows at £50k).
- *Fix:* one sentence each in §8, and state the tax-year assumption under Table 4.

**11. Minor. The benchmark's definition and protection wording are incomplete.**
- *Where:* §2.1 rule, short version last paragraph.
- *Issue:* the written rule omits the platform exclusion, which is why the HL Active Savings ISA (4.52%) gives way to
  Charter (4.26%) in the ISA bullet. cahoot Simple Saver reverts to a lower rate after 12 months, so the benchmark itself
  "drops", which the text says only of bonus accounts. "£120,000 per bank" should be per banking licence (cahoot shares
  Santander UK's).
- *Fix:* add "not via a savings platform"; note the 12-month term; say "per banking licence".

**12. Minor. The trailing section's caveats aren't stated.**
- *Where:* §4, Table 8, Fig 3, short version bullet 7.
- *Issue:* tax uses two Oct-Sep blocks, not tax years (unstated). The chaser uses one snapshot a month, ignoring
  mid-month cuts and transfer days; it is "the best a saver could have done" only under the clean rule, and the two
  fixes beat it. One of the two months where Premium Bonds beat the 20%-tax account (August 2026) is carried forward.
  "The picture was the same" overstates: basic rate, allowance used, £50k is +0.18 pp today but −0.26 pp over the two
  years (3.30% against 3.56%). The Fig 3 title "After 40% tax" means "allowance used, £50k".
- *Fix:* one sentence on the blocks; "the best clean easy-access account"; qualify "same"; complete the Fig 3 title.

**13. Minor. Table 3 mixes rate bases and dates.** The prize fund rate is not an AER (4.44% with reinvestment). The
gilt's 4.29% is a semi-annual GRY; my own calculation is 4.28%, or 4.32% a year, the basis the after-tax figures actually
use. The fund yield is from 28 August, six weeks older than every other input. *Fix:* one note under Table 3.

**14. Minor. Some wording is loose.** "Most savers get far less… the average advertised easy-access rate is 1.90%":
advertised rates on new accounts are not what most savers get. "The money market fund rarely wins": it never wins in
any table. "The 60% band and the additional rate: Premium Bonds win clearly at £25,000 and above": additional rate
already wins by 1.0 pp at £5k and £10k, and the HICBC row is missing from that bullet list. §7 "for a basic-rate saver,
from 0.2 to 0.3" needs "with the allowance used" (allowance unused stays negative, −0.22 to −0.17).

**15. Minor. Table 2 and the method note have small inaccuracies.**
- *Table 2:* the 29 October row says "379 days held", but that cash-in is paid after the November draw, so the money is
  tied up for about 385 days or more. The text's "cash in mid-month… you get 10" describes a 24 September cash-in.
- *Method note:* "chance-of-beating table to within 1.5 points", but the gate shows 0.5 pp or less. This number and
  "0.003 points" are hand-typed in the template, and G-article caught neither. "Including gov.uk's worked examples":
  only 1 of the 17 tax cases is from gov.uk.

**16. Minor. Some context is missing.** Inflation is never mentioned, and none of these returns is real. No sentence
on the £50,000 cap being per person (a couple can hold £100,000), which PLAN §2 asked for. NS&I Direct Saver is in
Table 3 but never discussed. PLAN D5 says publish **after** the 28 October Budget; the article is dated 11 October and
says only that the Budget "could change either".

**17. Minor. House style.** Headings 2.1 "The rivals, today", 3 "The fees that matter", 6 "Safety and access" and 7
"From April 2027" are labels, not findings (try "Platform fees push the money market fund further behind"; "From April
2027 the tax rise tilts slightly further to Premium Bonds"). Short-version bullets 3, 6 and 7 run to 45-60 words each;
split them. The Fig 3 alt text has no finding. The title is 17 words.

## Checked and correct

- **Prizes and luck (own code):** October 2026 draw: 6,546,849 prizes, 137.48bn eligible bonds (1 in 21,000), 4.35%,
  10.0% of the fund in prizes of £5k or more; P(any such prize in a year) 0.31% at £10k, 1.53% at £50k. Medians
  £350/£1,900, P10/P90 £150/£675 (£10k) and £1,350/£2,725 (£50k); P(nothing) 94% (£100), 56% (£1k). Monte Carlo matches at £10k.
- **Margins (own code):** higher rate, allowance used: +0.79 pp (P 70.9%) at £10k, +1.09 pp (P 89.5%) at £50k.
  Non-taxpayer at £10k: −1.02 pp (P 29.6%).
- **Entry timing:** medians £350/£325/£300 and £1,900/£1,725/£1,575 for 12/11/10 draws. Days and draw counts in Table 2
  are right under the stated rules.
- **Tables 4-8:** every cell matches today_net, today_beat, mmf_fees and trailing to the printed rounding, including the
  P(beat) roundings (76%, 89%, 95%, 98%) and "16 of 40" as published.
- **Gilt (own IRR):** £10k 3.95-4.03%, £50k 4.16-4.23%; semi-annual GRY 4.28% against HL's 4.29%.
- **Trailing (own code):** the 24 draws average 3.781%. Premium Bonds £50k median £3,350 (3.30% compound). Chaser 4.43%
  (no tax), 2.68% (higher rate, allowance used), 3.56% (basic rate, allowance used); two fixes 4.67%. Scoreboard: 24/24
  months at 40%, 2/24 at 20%.
- **Lag:** the run below SONIA is 43 months (aligned); Premium Bonds are 1.70 pp above the average easy-access rate since
  2023 (minimum 1.31). All 17 events, days since the last Bank Rate move and notice days (4-71) check out, as do the
  5-month lag and 7-month lead. 2027/28 margins at £50k: +1.1 to +1.2 pp (higher rate) and +0.2 to +0.3 pp (basic
  rate), allowance used.
- **Tax engine:** the PSA, starting-rate band, taper (60% and Scottish 62.5%), additional rate (no allowance), HICBC
  whole-£200 flooring and the 2027/28 22/42/47% rates are implemented correctly; all 17 gate cases pass. The pension
  profile's £6,022 tax-free interest is right.
- **Money market fund:** taxing the distribution net of OCF and taking the platform fee after tax is the correct UK
  treatment, since platform fees are not deductible. Using today's AJ Bell tariff for the history is disclosed.
  **Layout:** tables fit at 768px and up; the page never scrolls sideways at 375px.
