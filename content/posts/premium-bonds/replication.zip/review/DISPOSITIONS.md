# Dispositions of the Fable review (PLAN v1 → v2)

2026-10-11. One line per finding in `FABLE_REVIEW.md`. **A** = accepted, **P** = accepted in part
(reason given), **R** = rejected. The user asked for implementation to proceed after the review
without a further approval stop ("do not wait for my review once fable comes in, implement").

| # | Sev. | Finding | Disp. | Change in v2 |
|---|---|---|---|---|
| 1 | major | MMF tax base unspecified; `stakes.py` taxed after the platform fee | **A** | §4: taxable MMF income = distribution net of OCF (today 3.85%; history: NAV total return); platform and dealing fees deducted after tax. Gilt: only the coupon taxed; fees after tax. |
| 2 | major | Trailing window spans three tax years; PSA treatment unstated | **A** | §5: two 12-month blocks, one PSA and one starting-rate band each; rules identical across 2024/25-2026/27. |
| 3 | major | Refresh scheduled before the BoE row exists | **A** | D7: run on the 7th working day; G-boe exits cleanly with "BoE row not yet published" instead of building. |
| 4 | major | Lag section needs a clean best-buy series back to 2020 | **A** | Clean best buy hand-coded for the 24 window months only (labelled, gaps carried forward). 2020-26 context: PB, Bank Rate, SONIA, BoE IUMB6VK, MSE page-title headline rate (labelled "headline incl. bonuses"). Spreads PB − SONIA and PB − BoE average over 2020-26; PB − clean best buy only in the window. |
| 5 | major | Profile set over-built; rows identical | **A** | Six profiles: 0% taxpayer; basic (PSA free / used); higher (PSA free / used); higher + HICBC 2 children; 60% taper; additional. Scotland one sentence. Tables: one per amount (£10k, £50k), profiles as rows, ≤ 5 product columns. |
| 6 | major | Heat map reads "ISA" everywhere | **A** | Heat map framed as "taxable money (ISA allowance used or unavailable)", with a one-line ISA row above. |
| 7 | minor | FFT P(nothing) off 3.8% at £50k | **A** | P(nothing) from the closed form (1 − Σp)^T. |
| 8 | minor | MSE chance-of-beating gate needs MSE's thresholds | **A** | G-pb uses PSA-inclusive thresholds, "≥", ±1 pp. |
| 9 | minor | Entry/exit wording overstates the best case | **A** | "An exactly-12-month holding gets 10 or 11 draws; 12 needs a month-end purchase and a cash-in just after the 1st, 12 months and a few days later." New-money line uses 11 draws. |
| 10 | minor | "Simple interest at the cap" overstated | **A** | One clause: at £50k prizes are paid out; over several years that costs a few tens of pounds. |
| 11 | minor | Reinvestment-path approximation: state the size | **A** | Method note: within £50 at the median over 5 years. |
| 12 | minor | IUMB6VJ is not "what most savers get" | **A** | Use IUMB6VK, labelled "average advertised easy-access rate (excl. bonuses)"; big banks as a sentence. |
| 13 | minor | Clean rule needs a maximum-balance test | **A** | Rule adds "maximum balance ≥ £50,000". |
| 14 | minor | Cut CPI; demote gilt and RLAM fetchers | **A** | CPI dropped. Gilt price/yield a dated hand parameter. RLAM TR cross-check run once in P1. Monthly scrapers: NS&I, BoE, Moneyfacts, FT. |
| 15 | minor | Gilt fee drag and horizon | **A** | Gilt row at £10k/£50k net of AJ Bell dealing + capped fee, "held to maturity (Jan 2028)". |
| 16 | minor | "Pass-through" contradicts §5 | **A** | Q4 and §8.6 use three per-cycle facts (rise lag, cut lead, 2026 rise with Bank Rate flat). |
| 17 | minor | HICBC marginal inside vs above PSA | **A** | Two numbers in the cell (11.7% / 51.7%). |
| 18 | minor | Announced-but-not-drawn changes | **A** | Headline = latest drawn table; if the allocation page's estimate implies another rate, print it beside; refresh diff flags it. |
| 19 | minor | `latest.json` calculator wording speculative | **A** | JSON kept only as the refresh-diff artefact. |
| 20 | minor | Scottish 2027/28 taper uncomputable | **A** | "n/a until the Scottish Budget". |
| 21 | minor | One sentence that explains the median | **A** | One line in §8.2. |

Rejected: none. Partly accepted: none.
