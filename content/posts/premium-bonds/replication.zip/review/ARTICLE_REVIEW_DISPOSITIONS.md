# Dispositions of the article reviews (draft of 2026-10-11)

Reviews: `ARTICLE_REVIEW_FABLE.md` (0 critical, 4 major, 10 minor) and `ARTICLE_REVIEW_OPUS.md` (0 critical,
5 major, 12 minor). Both independently re-derived the headline numbers and found the engines right; the findings
were presentation, two modelling shortcuts and the best-buy plumbing. **A** = accepted, **P** = in part.
Also applied before the reviews (advisor): live best-buy filter aligned with the backfill (two-amount search,
platform exclusion), Table 2 rebuilt from NS&I's draw rules, "average account" relabelled, missing-month carry-forward,
third-party data dropped from replication.zip.

## Fable

| # | Sev. | Finding | Disp. | Change |
|---|---|---|---|---|
| 1 | major | "Half" for the P10-P90 range | A | §1.1 gives the middle half (P25-P75) and the 80% range separately |
| 2 | major | 1-year fix missing from Tables 4-5 while the gilt is bolded | A | Fix column added, best of five bolded; §2.3 rewritten (fix wins where little interest is taxed; gilt from 40%); claims asserted in build_article |
| 3 | major | Clean best buy is two rules; exclusions file empty; gate redefined | A | Exclusions seeded from the backfill notes (provider + product pattern, reason, source); live filter adds a minimum-deposit test and accepts "12 Month Bond"; Dec 2024 backfill revised (Chetwood excluded consistently, Secure Trust 4.65%); G-bestbuy now also requires the live filter to pick the backfill's rate in ≥ 90% of archived months (39 of 41; both others are a £3k-capped account) and writes results/bestbuy_check.json; §9 says so |
| 4 | major | £50k 5-year cell understated by compounding paid-out prizes | A | All Premium Bond figures now assume prizes paid out and are simple annual rates; reinvested average shown separately |
| 5 | minor | §5 heading over-claims; Table 9 gilt column was 2 months; wrong figure cited | A | Heading "...in 2026 they rose after gilt yields jumped"; column now end of m−4 to end of m−1 and relabelled; short version cites Figure 4 |
| 6 | minor | Two tax blocks not stated | A | §4 says two 12-month blocks, not tax years, one allowance each |
| 7 | minor | HICBC 11.7% / 51.7% missing | A | Own bullet in §2.2 |
| 8 | minor | F4 only partly as disposed; MSE titles unused; Fig 5 subtitle dates | P | Fig 5 subtitle uses month names and the alignment is stated in §5. Plan disposition F4 corrected below. The MSE headline series stays fetched-once but unused (not worth a sixth chart) |
| 9 | minor | §2.1 definition omits tests; cahoot's 12-month structure | A | Definition adds platform, £1,000-£50,000 and the after-a-year rate drop |
| 10 | minor | Identical rows unexplained; higher-rate bullet understated | A | Note under Table 5; bullet "and from £25,000 even if it isn't" (asserted) |
| 11 | minor | Tables 4 and 7 disagree by dealing fees | A | Table 8 note: before dealing fees |
| 12 | minor | £10k headline is for money already held | A | New-money Table 6 and short-version figure (Opus 1) |
| 13 | minor | Headings and title vs house style; SONIA wording | A | Title shortened and finding-led; §2.1, §3, §6, §7 headings are findings; SONIA defined |
| 14 | minor | Stale FINDINGS.md; G-tables not logged; disclosure | A | FINDINGS.md left out of replication.zip (working note); G-tables gate added and logged; disclosure names the review |

## Opus

| # | Sev. | Finding | Disp. | Change |
|---|---|---|---|---|
| 1 | major | Tables use 12 draws; new money gets 11 | A | Tables labelled "a year of 12 draws: money already held, or new money timed as in 1.2"; Table 6 gives 11-draw margins; short version and §2.2 give new-money figures (13 of 40 cells) |
| 2 | major | Expected-path reinvestment moves quantiles; P(nothing) wrong | A | Distributions now exact with prizes paid out (MSE's convention: £925 at £25k, P(nothing) £5k 6%); reinvested average exact by linearity, checked against a simulation within 3 standard errors (G-pb) |
| 3 | major | "Half" range | A | As Fable 1 |
| 4 | major | Gilt bolded without the fix | A | As Fable 2 |
| 5 | major | Median only, never the mean | A | Mean in the short version, §1.1, §2.2 (average gap for non-taxpayers 0.2 vs 1.0 points) and §2.3 (gilt below the average); asserted |
| 6 | minor | HICBC profile on a £200 step | A | Example saver priced at the charge's average over the step (tax.hicbc smooth=True; the law's floored version is still the engine default and tested) |
| 7 | minor | 5-year column mixes compound and simple | A | As Fable 4 |
| 8 | minor | "In step with gilt yields" overstated; Table 9 column | A | 2026 bullet now: cut in February, two rises after the March jump, NS&I's stated reasons; Fig 4 title "Bank Rate stood still in 2026; Premium Bonds rose after gilt yields jumped" |
| 9 | minor | Alignment of the SONIA run unstated; SONIA naming | A | Alignment stated; SONIA defined as the overnight rate banks lend to each other at |
| 10 | minor | Tax edge cases | A | §8: Scottish row choice by UK band, the £50,270 allowance cliff; §2.2: £100k childcare cliff; under Table 5: 2026/27 rates, later interest at section 7 rates |
| 11 | minor | Benchmark definition, protection wording | A | As Fable 9; "per banking licence" |
| 12 | minor | Trailing caveats | A | Blocks stated; "best clean"; chaser switched at the start of each month; "much the same story" with the basic-rate exception spelled out; carried-forward month named; Fig 3 subtitle says £50k, allowance used |
| 13 | minor | Table 3 mixes rate bases and dates | A | Note under Table 3 (prize rate not an AER; gilt quoted semi-annually, after-tax figures annual; fund yield date) |
| 14 | minor | Loose wording | A | "Accounts most people hold..."; "never wins"; separate 60% band / additional rate / HICBC bullets with their thresholds (asserted); §7 "with the allowance used" |
| 15 | minor | Table 2 days; method note numbers hand-typed | A | Column "Days to the request" and 10-draw text; "0.5 points" and "0.003 points" now computed in article_values; "one from gov.uk's worked examples, the rest worked by hand" |
| 16 | minor | Inflation, couples, Direct Saver, Budget timing | A | CPI (ONS D7G7) fetched and quoted; couples £100k; Direct Saver sentence; publication held until after the 28 Oct Budget (draft: true and PUBLISH.md; G-fresh fails if run on or after 28 Oct with tax.json unchecked) |
| 17 | minor | House style | A | As Fable 13; long bullets split; Fig 3 alt text states the finding |

## Correction to the plan dispositions (Fable F4)

`DISPOSITIONS.md` F4 said the 2020-26 chart would include SONIA and the MSE headline series. As built, Figure 4 shows
the prize rate, Bank Rate, the 1-year gilt and the average advertised easy-access rate, and SONIA has its own spread
chart (Figure 5); the MSE headline series was fetched but not used.

## Round 2 verification (Fable)

Checked 2026-10-11 against the built `index.md` (12:44), the five figures rendered, `results/`, `params/`, `code/`,
`logs/gates.md`, the archived captures, and a local Hugo build. Own code in my scratchpad (`rederive2.py`: own FFT
on a £25 grid plus a 300k-path Monte Carlo, own tax function, own chaser; `wb_dec2024.py`: own parse of the captures).

**Verdict: publishable as built (after the Budget hold). No blocking findings.** All 31 A/P dispositions are present
in the article or code and correct; every number I re-derived matches. Seven minor points below, none changing a
printed figure.

### Dispositions confirmed
- Fable 1-14 and Opus 1-17: all present. Specifically: P25-P75 and P10-P90 both given (§1.1); fix column and
  best-of-five bolding (Tables 4-5, bold cells re-checked by hand, 16 of 16); exclusions file seeded (14 rows), minimum-
  deposit test and "12 Month Bond" in `bestbuys_derive.py`, G-bestbuy ≥ 90% (39 of 41) and `bestbuy_check.json`;
  prizes paid out everywhere with 4.44% shown separately; §5 heading, Table 10 column (end m−4 to end m−1, values
  re-checked), Figure 4 cited; two 12-month blocks stated; HICBC bullet; Fig 5 subtitle in month names, alignment
  stated; §2.1 definition (platform, £1,000-£50,000, after-a-year drop); Table 5 note; Table 8 note; Table 6 and the
  13-of-40 figure; finding-led headings, SONIA defined; FINDINGS.md out of the zip, G-tables logged, disclosure
  updated; smooth HICBC; mean in four places; Scottish/£50,270/£100k childcare/2026-27 rates; "per banking licence";
  Table 3 note; "never wins"; Table 2 column and 10-draw text; "0.5 points", "0.003 points", "one from gov.uk"
  computed; CPI, couples, Direct Saver. Qualitative claims asserted in `build_article.py` lines 28-58.
- Partial, as the dispositions already say: Fable 8 (MSE titles unused), Fable 13 (title 15 words, from 17).

### Re-derived (own code; article value in brackets)
- £25k, 12 draws, paid out: median £925 [£925]; MC P(<£925) 0.49, P(≤£925) 0.52. P10/P90 £575/£1,500.
- P(nothing): £5k 5.74% [6%], £1k 56.5% [56%]. 11-draw medians £0/£150/£325/£850/£1,725 [Table 2: £325, £1,725].
- Higher rate, allowance used, £50k: held +1.09 pp [1.1], new money +0.74 pp [0.7]. Cells PB ahead: 16 of 40 held,
  13 of 40 new money [16, 13]. Non-taxpayer £10k mean gap −0.17 pp [0.2].
- HICBC, 2 children: £2,337.40 a year → 11.69% inside the allowance, 51.69% above [11.7%, 51.7%]; Table 4/5 row
  3.99% / 2.58% [same]. 60% band and HICBC rows positive only from £25k; additional rate from £5k [as the bullets say].
- Table 9, new basis (total two-year gain ÷ 2 ÷ £50k): chaser gross blocks £2,299 + £2,224 → 4.52% no tax, 4.02%
  basic/unused, 3.62% basic/used, 2.71% higher/used [same]; two fixes 4.78% [4.78%]; PB £3,350 → 3.35% [3.35%].
- £10k: the fix beats the gilt in 6 of 8 rows ["most savers"]. 2026: BoE GLC 1-year spot 3.42% end-Feb → 4.25%
  end-Mar (raw file); events 24 Feb cut, 14 May and 18 Aug rises with the printed reasons.
- Dec 2024 capture (own parse): Atom 4.85 (reward), Monument 4.81 (min £25k), Ulster 4.75 (loyalty), Chetwood 4.71,
  Close Brothers 4.70 (min £10k), Secure Trust 4.65 (min £1), Vanquis Issue 4 4.65 (min £1,000): as the revised note.
- Layout: `check-tables.mjs` at 375/768/1366/1920: 0 of 11 tables scroll at 768px and up; the page never overflows.

### New findings (all minor)
1. **Dec 2024 revision overrides same-month evidence.** MSE's 13 Dec 2024 page lists Chetwood 4.71% as "Top rate with
   unlimited withdrawals - No min or max"; the 16 Jan 2025 page is the first to say "Max one withdrawal per day"
   (4.66%). `logs/wayback_backfill.md` ("Judgement calls") still says "Chetwood stands in Dec 2024". Effect: 6 bp
   for one month, about 0.25 bp on the chaser's annual figure; no printed number changes. Fix: keep 4.65% but say in
   the CSV note and the log that December's page called it unlimited and January's description is taken as the
   product's terms (the exclusions file is undated, so reverting to 4.71% would fail G-bestbuy).
2. **§2.3 gilt-vs-fix rule incomplete.** "Once interest is taxed at 40% or more, the gilt wins" is true, but the gilt
   also wins at 20%: basic rate, allowance used, £50,000 (4.20% v 4.10%, Table 5). Fix: add that clause.
3. **§2.2 higher-rate bullet.** "Premium Bonds win once the allowance is used" fails at £1,000 (median £0, −2.7 pp);
   the additional-rate bullet says "from £5,000". Fix: "from £5,000 once the allowance is used".
4. **HICBC row label.** Every other taxed row says allowance used/unused; the HICBC row (allowance unused, £70k, no
   other interest) does not (Opus 6 asked). Fix: "Higher rate + child benefit charge (2 children), allowance unused".
5. **§9 "39 of 41 months".** The 41 are archived captures: 22 easy-access plus 19 one-year-fix months. Fix: "39 of
   41 archived captures (easy access and one-year fixes)".
6. **"G-fresh enforces" (Opus 16 disposition) overstates.** G-fresh fails only when run on or after 28 Oct with
   `tax.json` unchecked since; the pre-Budget hold is `PUBLISH.md` plus `draft: true`. Fix: reword, or add a check
   that today ≥ Budget date before `draft: false`.
7. **replication.zip ships `review/`**, including this file; rebuild after this section (or exclude `review/`).

## Dispositions of the round 2 verification

All seven minor findings accepted (A); no printed number changed except the wording below.

| # | Finding | Change |
|---|---|---|
| 1 | Dec 2024 revision overrides same-month MSE evidence | Contradiction recorded in the bestbuy_window.csv note and logs/wayback_backfill.md; Chetwood stays excluded in every month (one undated rule; ~0.25 bp) |
| 2 | "Taxed at 40% or more, the gilt wins" incomplete | "...at 40% or more, or at 20% on £50,000"; asserted |
| 3 | Higher-rate bullet fails at £1,000 | "win from £5,000 once the allowance is used"; asserted |
| 4 | HICBC row label | "..., allowance unused" |
| 5 | "39 of 41 months" | "39 of 41 archived pages, easy-access and one-year-fix" |
| 6 | "G-fresh enforces" overstated | Reworded (draft flag + PUBLISH.md; G-fresh fails after 28 Oct if tax.json unchecked) |
| 7 | replication.zip stale | Rebuilt by refresh.py after these edits |

Post-review fixes not seen by the reviewers (advisor): Table 9 now puts every product on one basis (total two-year
gain ÷ 2; the accounts' figures rose by 0.04-0.11 points, removing a small tilt towards Premium Bonds); refresh.py's
headline diff now compares against a baseline written only at publication (`--published`).
