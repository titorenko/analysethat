# Review of PLAN.md v1 (Premium Bonds vs deposits vs MMF) — Fable, 2026-10-11

Reviewed: PLAN.md, scouting A/B/C, planning prototypes (re-run), old Monte Carlo (stored results read),
and web spot-checks of NS&I, gov.uk, legislation.gov.uk, MSE, HL and AJ Bell pages. Scratch tests are in
my scratchpad (`pbtest.py`, `pbtest2.py`); numbers quoted below come from them.

## Verdict

**Ready to start P1–P2 (fetchers, PB engine, tax engine) once the spec gaps in findings 1–3 are written
into the plan. Not ready for P3 as written**: the lag section (§5) silently depends on a hand-coded
"clean best buy" series back to 2020 that nobody has scoped (finding 4), and the profile set and table
shapes are over-built for a site whose rule is "tables must fit" (finding 5). The PB engine itself is
sound: the exact FFT method reproduces the old Monte Carlo, MSE's medians and MSE's chance-of-beating
table to within 1 pp, the per-draw product over the 24 trailing draws works, and the expected-bond-path
approximation for reinvestment is within £50 of a true reinvestment simulation at the median over 60
draws. Nothing is critical; six findings are major, the rest minor.

## Findings

### 1. **Major** — MMF tax base is not specified, and the only worked prototype gets it wrong
**Issue.** Income tax falls on the fund's distribution (net of OCF, which is charged inside the fund).
The platform fee is paid from the account and is not deductible. `stakes.py` taxes `3.95 − 0.10 − 0.25
= 3.60%`, i.e. deducts the platform fee before tax. PLAN §3–4 says "net of fees" and `tax(profile,
interest)` without saying which number is the interest.
**Evidence.** Net MMF return at AJ Bell: stakes-style vs correct — 20%: 2.880 vs 2.830%; 40%: 2.160 vs
2.060%; 60%: 1.440 vs 1.290% (5–15 bp overstated). C §6 (IFM03120): notional distributions on Acc
units are taxed as income.
**Change.** State in §4: taxable interest for the MMF = distribution yield net of OCF (today 3.85%;
history: NAV total return); platform fee and dealing fee are deducted after tax. Same rule for the
gilt: only the coupon is taxable; dealing/custody fees after tax.

### 2. **Major** — Trailing 24-month returns span three tax years; the plan does not say how the PSA
and starting-rate band are applied
**Issue.** §5 says "All taxed by the same engine at each year's rules". The PSA is annual. Deposit
months Oct 2024 – Sep 2026 fall 6/12/6 into 2024/25, 2025/26 and 2026/27. A naive per-tax-year
application gives a "PSA unused" saver three allowances in 24 months; a per-month pro-rata gives
different numbers again.
**Evidence.** Scratch §10. At £50k and 4%, the PSA treatment moves the 2-year basic-rate net return
by up to £200 (0.2 pp/yr), the same order as the PB-vs-deposit gaps the article is about.
**Change.** Treat the window as two 12-month blocks (Nov 24–Oct 25, Nov 25–Oct 26), each with one PSA
and one starting-rate band, and say so. Rules did not change across the three years (C §1), so
"each year's rules" reduces to one parameter set anyway.

### 3. **Major** — Refresh schedule runs before the BoE row it needs exists
**Issue.** D7 schedules the task "after the draw file appears (~3rd working day)". §5 claims the
alignment rule "absorbs the BoE's ~5-working-day publication lag". It does not: the draw-M zip arrives
on the 2nd working day of M (A §9), the BoE quoted-rate row for M−1 on about the 5th (B §5).
**Evidence.** B §5 "published ~5th working day of following month"; raw CSV Sep-26 row already has
quoted rates but blank effective rates.
**Change.** Schedule on the 7th working day (or run G-boe first and exit cleanly with "BoE row not yet
published" rather than failing the build). Keep G-boe's blank-row refusal.

### 4. **Major** — The lag section depends on a "clean best buy" series back to 2020 that exists only
by hand
**Issue.** §5 wants a 2020–2026 rates chart with the clean best buy, spread lines PB − clean best buy,
and an event table with "spread to best buy before and after" for 17 changes. §3 says the clean rule
"can be applied mechanically to Moneyfacts JSON (live and Wayback)" but B §5b says Moneyfacts Wayback
covers ~32 months from Mar 2023 with gaps and changed field names; MSE Wayback starts 2021 and is prose.
That is ~70 months of hand coding, versus the 24 the trailing window needs.
**Evidence.** B §5b; A §4 (17 events, first in Dec 2020, before any MSE capture).
**Change.** Hand-code "clean" only for the 24 window months (21–23 reachable, carry forward, labelled).
For 2021–2026 context use the mechanical series: MSE page-title headline easy-access rate (every month,
labelled "headline incl. bonus") and BoE IUMB6VK (average excl. bonuses). Spread lines: PB − SONIA and
PB − BoE average over 2020–26; PB − clean best buy only inside the window.

### 5. **Major** — Profile set is over-built; several rows are numerically identical
**Issue.** §4 lists 8 profiles × "allowance unused/used" = up to 16 rows, × 5 amounts × 7 products
× 2 tax years. T0a and T0b are identical for every amount ≤ £50k at ≤ 5.13% (both have > £2,565 of
0% headroom: £6,022 and £3,570). T2 (Scottish, £47k) produces the same numbers as T1 (20%, £1,000
PSA); it is a one-sentence trap, not a row. "Allowance unused" for T6 is meaningless (PSA £0).
**Evidence.** Scratch §7: T0a pays £0 on £6,022 of interest; T0b £0 on £3,570; T3 £0 on £452, £704
on £2,260; T5 £1,156 on £2,260 — all as C says, so the engine design is right, the row count is not.
**Change.** Six rows: 0% taxpayer (pension/low earner); basic (PSA free / used); higher (PSA free /
used); higher + HICBC 2 children; 60% taper; additional. Scotland as one sentence (the 42%-band saver
pays 20%). Decide the table shape now: one table per amount (£10k, £50k) with profiles as rows and
≤ 5 product columns, or a heat map. The site rule (no scroll at 768px) will not take 7 × 16.

### 6. **Major** — The heat map "best home for the money" has one answer unless the ISA is taken out
**Issue.** §8.1 promises amount × tax position → best home. At the median, the no-bonus easy-access
cash ISA (4.26%) and the 1-year fixed ISA (4.97%) beat the PB median (3.5–3.8%) for every profile and
amount, so every cell reads "ISA".
**Evidence.** B §4 ISA rates; oct2026_check medians.
**Change.** Frame the heat map as "taxable money (ISA allowance already used or unavailable)", with a
one-line ISA row above it; the plan's sentence "the ISA is the first answer" then does its job.

### 7. Minor — G-pb "P(nothing) matches MSE" at £50k cannot use the FFT cell
**Evidence.** FFT P(0) at £50k, 12 draws = 3.755e-13; exact (1 − Σp)^T = 3.902e-13 (−3.8%); half
the grid cells are clipped noise at the 1e-19 level. At £1k and £10k the FFT is exact to 1e-11.
**Change.** Report P(nothing) from the closed form; use the FFT for everything else.

### 8. Minor — G-pb's MSE chance-of-beating gate needs MSE's own thresholds and a stated convention
**Evidence.** MSE's basic/higher columns are PSA-inclusive (£30k basic: £1,292 = 1,365 − 0.2 × 365).
With those thresholds the FFT gives 32.7 / 40.9 / 61.4 / 76.9% vs MSE 33 / 41 / 61 / 77. Non-taxpayer
£50k: P(> £2,275) = 24.4%, P(≥ £2,275) = 25.6%, MSE 26%.
**Change.** Gate on PSA-inclusive thresholds, "≥", tolerance ±1 pp.

### 9. Minor — Entry/exit wording overstates the best case
**Evidence.** Scratch §6: a holding of exactly 12 months gets 10 draws (buy on the 1st) or 11 (any
other day); 12 draws need the bond held on the 1st of month P+13, i.e. more than 12 months. The cost
is material: £10k median 350 → 325 → 300 for 12/11/10 draws (3.5 → 3.25 → 3.0%); £50k 1,900 → 1,725
→ 1,575.
**Change.** "An exactly-12-month holding gets 10 or 11 draws; 12 needs a month-end purchase and a cash-in
just after the 1st, 12 months and a few days later."

### 10. Minor — "Simple interest at the cap" is overstated
**Evidence.** AER is an annual rate, so at a 1-year horizon compounding does not separate PB from a
deposit at all. Over 5 years at £50k, prizes paid out and re-saved at ~4% lose ≈ £45 against in-PB
reinvestment at 4.35%.
**Change.** One clause ("at £50k prizes are paid out; over several years that costs a few tens of
pounds"), not "a real disadvantage … shown".

### 11. Minor — Reinvestment-path approximation: confirmed small, state the size
**Evidence.** £10k, 60 draws, Oct 2026 table: fixed holding median 1,900; expected-path FFT median
2,125, q10/q90 1,550/3,000, mean 2,424.8 (= compound mean exactly); Monte Carlo with true reinvestment
and the £50k cap: median 2,075, q10/q90 1,475/3,075, mean 2,426.6. Path approximation narrows each tail
by ~£75 and lifts the median £50 over 5 years; negligible at 1–2 years.
**Change.** Keep; print "within £50 at the median over 5 years" in the method note.

### 12. Minor — IUMB6VJ is not "what most savers actually get"
**Evidence.** IUMB6VJ is the average *advertised* instant-access rate for new business (2.06% Sep-26).
The effective rate on outstanding household sight deposits is CFMHSCV, 1.64% (Aug-26), B §5.
**Change.** Either relabel ("average advertised rate") or use CFMHSCV for that line. Do not add both.

### 13. Minor — "Clean best buy" rule needs a maximum-balance test
**Evidence.** Tembo 4.55% (≤ £20k), Starling 5.00% (≤ £25k), Cahoot Sunny Day 5% (≤ £3k) all fail
for a £50k comparison but pass the written rule.
**Change.** Add "maximum balance ≥ £50,000".

### 14. Minor — Scope: cut `ons_cpi.py`, demote `hl_gilts.py` and `rlam_tr.py`
**Evidence.** No question Q1–Q4 and no outline section uses CPI. HL's gilt table is snapshot-only and
feeds one row. The RLAM TR JSON is a cross-check that lags six weeks.
**Change.** Drop CPI. Gilt price/yield as a dated hand parameter in `params/` with URL (TN28 94.79,
4.29% / 4.23% confirmed on HL today). Run the RLAM cross-check once in P1, log it, do not fetch monthly.
The monthly refresh then has four scrapers: NS&I (zip header, rates page, allocation page), BoE, Moneyfacts,
FT NAV.

### 15. Minor — Gilt row needs its fee drag and horizon stated
**Evidence.** TN28 matures 31 Jan 2028 (15.6 months). AJ Bell GIA: £5 deal + 0.25% capped £42/yr →
0.29%/yr drag at £10k (4.23% → 3.94% net at 40%), 0.09% at £50k; HL ≈ 0.40%/yr at £10k. Price risk if
sold early.
**Change.** Show the gilt at £10k/£25k/£50k net of those fees, "held to maturity", one row.

### 16. Minor — "Pass-through" appears in Q4 and §8.6 but §5 rules it out
**Change.** Replace with three per-cycle facts computable from A §4–5 alone: 2022–23 rises: Bank Rate
+500 bp from 16 Dec 2021, PB +365 bp with first move in the Jun 2022 draw (announced 24 May 2022, ~5
months later); 2024–25 cuts: PB cut first (Mar 2024 draw, announced 11 Jan 2024), seven months before the
1 Aug 2024 Bank Rate cut, then −135 bp vs −150 bp; 2026: Bank Rate flat, PB +105 bp net. This also
removes the best-buy dependency from the event table (finding 4).

### 17. Minor — HICBC row: say which marginal applies where
**Evidence.** HICBC bites on interest inside the PSA too (C §4): T4 is 11.7% within the £500 PSA, 51.7%
above it. The table shows only "40% + 11.7%".
**Change.** Two numbers in the cell.

### 18. Minor — Announced-but-not-yet-drawn rate changes: say what the article does
**Evidence.** NS&I gives 1–8 weeks' notice; S2 shows next month's estimate (A §2, §9). The plan detects
the change but does not say what "today's rates" means in that window.
**Change.** Headline uses the latest drawn table; if S2's estimate implies a different rate, print
"X% from the <month> draw (announced <date>)" beside it and let the refresh diff flag it. No synthetic
tables.

### 19. Minor — `results/latest.json` "for the D6 calculator" is speculative
**Change.** Keep the JSON only as the refresh-diff artefact it already is; drop the calculator wording.

### 20. Minor — Scottish 2027/28 taper cell cannot be computed
**Evidence.** C §3: Scottish 2027/28 bands unknown until the Scottish Budget (early 2027).
**Change.** Show "n/a until Scottish Budget" in that cell rather than 64.5%.

### 21. Minor — One cheap sentence that explains the median
**Evidence.** Higher band = 10.0% of the fund; prize rate excluding it is 3.915%; P(any ≥ £5k prize in
12 draws) = 0.31% at £10k, 1.53% at £50k. Medium band 10%, lower band 80%.
**Change.** Optional: one line in §8.2. It replaces a paragraph of explanation; skip if space is tight.

## Checked and found correct

- PB engine: mass = 1 to 1e-9; mean = B·m·rate/12 to 1e-3 £; P(0) exact to 1e-11 at £1k/£10k;
  compound-Poisson cross-check agrees to 1e-6 per cell and to the £25 in every quantile; GRID headroom
  (£6.55m) is ample for 60 draws at £50k; principal-branch log is safe for fractional exponents because
  |φ − 1| ≤ 2/odds.
- Reproduces the old Monte Carlo at April 2020 (stored `sim_result_25_03_2021`: medians 0/75/450, q10/q90
  25/150 at £10k) and MSE's Oct 2026 medians £350/£925/£1,900 and P(nothing) 56.5% at £1k (MSE page
  re-fetched, "Updated 1 October 2026").
- Per-draw product over the 24 zip-header tables: 3.781% simple / 3.778% fund-weighted, as A §4; £10k
  over 24 draws median £625 (3.1%/yr), q10/q90 £350/£1,075.
- All 82 draws in `draws_from_zip_headers.csv` pass value and count checks; eligible from amount vs from
  prizes agree to ≤ 4.7e-7; 21 draws lack a published eligible count and are safely derived.
- Headline claims: P(PB beats clean best buy) 28% / 89% / ~100% reproduced; £9 / £37 / £250 compounding
  deltas reproduced; 17 rate changes counted; 10/10/80 band split from Jan 2023 visible in the counts.
- Tax rules as applied in the plan: PSA by total income incl. interest (£50,270 cliff example 7,326 →
  7,452 reproduced); starting rate £5,000 less other income above PA (gov.uk £16,000 → £1,570 re-fetched);
  T0a £6,022 tax-free; T5 60% rUK / 62.5% Scotland; HICBC 11.7% for two children; Scottish savers on UK
  rates and UK-band PSA (ITA s.11D, s.12B(8)); FA 2026 s.5 22/42/47% for 2027-28 re-fetched; cash-ISA
  £12k under-65 and the 100%-MMF ban from Apr 2027 (SI 2026/1018); FSCS £120k.
- Web spot-checks today: NS&I rate history (4.35% / 21,000 from Sep 2026; 3.80 / 22,000 Jul; 3.30 /
  23,000 Apr); the product page's Switch block still contradicts itself exactly as A §8 says; eligibility
  "buy in November → January draw"; withdrawals 3–5 days; TN28 94.79 / 4.29 / 4.26 / 4.23 / 4.23 on HL;
  AJ Bell 0.25% funds, 0.25% capped £3.50/m shares and gilts, £5 / £1.50 dealing.
- Alignment rule (draw M ↔ holding month M−1) is a defensible convention and is stated as one; the
  "best-buy chaser" and rolled-fix comparators are defensible as labelled upper bounds; Oct-2024 and
  Oct-2025 MSE snapshots exist for the fix rates.
- D1b (gilt row), D2 (clean best buy as main benchmark with headline/average/fix as context), D4, D5
  (publish after 28 Oct), D7 (manual publish) are the right calls.
